export default {
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: {
        ink: "#12263A",
        span: { DEFAULT: "#0E7C86", dark: "#0A5C64", soft: "#E3F2F3" },
        signal: { DEFAULT: "#F2A93B", soft: "#FCF0DA" },
        steel: "#5B6B7B",
        paper: "#F6F8FA",
        line: "#DDE3E9",
        ok: "#2F8F5B",
        danger: "#C2412D",
      },
      fontFamily: {
        display: ['"Bricolage Grotesque"', "system-ui", "sans-serif"],
        body: ['"Public Sans"', "system-ui", "sans-serif"],
      },
      borderRadius: { card: "14px", ctl: "10px" },
      boxShadow: { card: "0 1px 2px rgba(18,38,58,.06), 0 4px 12px rgba(18,38,58,.05)" },
    },
  },
};
