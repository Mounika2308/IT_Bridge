import { api } from "./api.js";

/** The API never lets the browser set a payment's result: these calls only start, read or cancel a payment. */
export const startPayment = async (trainingId, amountPaise, idempotencyKey) =>
  (await api.post(`/trainings/${trainingId}/payments`, { amount_paise: amountPaise }, { headers: { "Idempotency-Key": idempotencyKey } })).data.data;
export const cancelPayment = async (id) => (await api.post(`/payments/${id}/cancel`)).data.data;
export const myPayments = async (page = 1, status) => (await api.get("/payments", { params: { page, ...(status ? { status } : {}) } })).data.data;
export const getPayment = async (id) => (await api.get(`/payments/${id}`)).data.data;
export const paymentsSummary = async () => (await api.get("/payments/summary")).data.data;
export const trainingPaymentSummary = async (trainingId) => (await api.get(`/trainings/${trainingId}/payment-summary`)).data.data;
export const getInvoice = async (paymentId) => (await api.get(`/payments/${paymentId}/invoice`)).data.data;
/** Sandbox only (the server answers 403 outside development/test). Sends a signed simulated result; no real money moves. */
export const simulateSandbox = async (paymentId, outcome) => (await api.post(`/payments/${paymentId}/sandbox/${outcome}`)).data.data;

export const myEarnings = async (page = 1, status) => (await api.get("/earnings", { params: { page, ...(status ? { status } : {}) } })).data.data;
export const earningsSummary = async () => (await api.get("/earnings/summary")).data.data;
