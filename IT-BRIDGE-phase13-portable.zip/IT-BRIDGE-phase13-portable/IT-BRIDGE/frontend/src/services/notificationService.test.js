import { beforeEach, describe, expect, it, vi } from "vitest";

// Phase 13B.3: this file used to read globalThis.__calls / __apiData, which ONLY the stop-gap shim's fake axios (tools/frontend-shim/stubs/axios.js)
// defined. Under real Vitest, calls() was undefined (TypeError in beforeEach) and the real axios would have tried to reach localhost:8000. The mock
// below makes the test self-contained: it records every call and answers with globalThis.__apiData. The factory must not reference outer variables.
// (The shim ignores vi.mock and supplies the same recorder through its own stub, so the file runs under both.)
vi.mock("axios", () => {
  const calls = (globalThis.__calls ||= []);
  const reply = () => Promise.resolve({ data: { success: true, data: globalThis.__apiData ?? {} } });
  const rec = (m) => (url, a, b) => { calls.push([m, url, m === "get" ? a : b ?? a]); return reply(); };
  const inst = { defaults: { baseURL: "" }, interceptors: { request: { use() {} }, response: { use() {} } }, get: rec("get"), post: rec("post"), put: rec("put"), patch: rec("patch"), delete: rec("delete") };
  return { default: { create: () => inst, post() {} } };
});

import { getPreferences, listNotifications, markAllRead, markRead, savePreferences, unreadCount } from "./notificationService.js";

const calls = () => globalThis.__calls;
beforeEach(() => { calls().length = 0; globalThis.__apiData = {}; });

describe("notification API calls", () => {
  it("marks one notification read with POST /notifications/:id/read", async () => {
    await markRead(42);
    expect(calls()).toEqual([["post", "/notifications/42/read", undefined]]);
  });
  it("marks everything read with POST /notifications/read-all", async () => {
    await markAllRead();
    expect(calls().map((c) => c.slice(0, 2))).toEqual([["post", "/notifications/read-all"]]);
  });
  it("reads the unread count", async () => {
    globalThis.__apiData = { unread: 4 };
    expect(await unreadCount()).toBe(4);
    expect(calls()[0].slice(0, 2)).toEqual(["get", "/notifications/unread-count"]);
  });
  it("pages the list and only sends unread_only when it is on", async () => {
    await listNotifications(2, true); await listNotifications(1, false);
    expect(calls()[0][2]).toEqual({ params: { page: 2, unread_only: true } });
    expect(calls()[1][2]).toEqual({ params: { page: 1, unread_only: undefined } });
  });
  it("loads and saves preferences with GET and PUT /notifications/preferences", async () => {
    globalThis.__apiData = { in_app: true, email: false, email_verified: true };
    expect(await getPreferences()).toEqual({ in_app: true, email: false, email_verified: true });
    await savePreferences({ email: true });
    expect(calls().map((c) => c.slice(0, 2))).toEqual([["get", "/notifications/preferences"], ["put", "/notifications/preferences"]]);
    expect(calls()[1][2]).toEqual({ email: true });
  });
});
