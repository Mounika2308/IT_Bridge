import { api, session } from "./api.js";

export async function login(payload) {
  const { data } = await api.post("/auth/login", payload);
  session.set(data.data);
  return data.data.user;
}
export async function register(payload) {
  const body = { ...payload, phone: payload.phone || null };
  const { data } = await api.post("/auth/register", body);
  session.set(data.data);
  return data.data.user;
}
export const logout = () => session.clear();
