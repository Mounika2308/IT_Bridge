import { api } from "./api.js";

export const getSkills = async () => (await api.get("/skills")).data.data;
export const getTrainerProfile = async () => (await api.get("/trainers/me")).data.data;
export const saveTrainerProfile = async (p) => (await api.put("/trainers/me", p)).data.data;
export const getInstitutionProfile = async () => (await api.get("/institutions/me")).data.data;
export const saveInstitutionProfile = async (p) => (await api.put("/institutions/me", p)).data.data;
