import axios from "axios";

export const api = axios.create({ baseURL: import.meta.env.VITE_API_URL || "http://localhost:8000/api/v1" });

const KEY = "itbridge.session";
export const session = {
  get: () => { try { return JSON.parse(localStorage.getItem(KEY)); } catch { return null; } },
  set: (s) => localStorage.setItem(KEY, JSON.stringify(s)),
  clear: () => localStorage.removeItem(KEY),
};

api.interceptors.request.use((cfg) => {
  const s = session.get();
  if (s?.access_token) cfg.headers.Authorization = `Bearer ${s.access_token}`;
  return cfg;
});

let refreshing = null;
api.interceptors.response.use(
  (r) => r,
  async (error) => {
    const { config, response } = error;
    const s = session.get();
    if (response?.status === 401 && s?.refresh_token && !config._retried && !config.url.includes("/auth/")) {
      config._retried = true;
      refreshing ||= axios.post(`${api.defaults.baseURL}/auth/refresh`, { refresh_token: s.refresh_token })
        .then((r) => { session.set(r.data.data); return r.data.data; })
        .catch(() => { session.clear(); window.location.assign("/login"); })
        .finally(() => { refreshing = null; });
      const fresh = await refreshing;
      if (fresh) { config.headers.Authorization = `Bearer ${fresh.access_token}`; return api(config); }
    }
    return Promise.reject(error);
  }
);

export const errorMessage = (e) =>
  e.response?.data?.message || (e.request ? "Cannot reach the server. Check your connection." : "Something went wrong.");
