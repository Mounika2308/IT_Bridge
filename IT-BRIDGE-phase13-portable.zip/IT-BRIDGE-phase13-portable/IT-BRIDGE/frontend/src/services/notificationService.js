import { api } from "./api.js";

export const listNotifications = async (page = 1, unreadOnly = false) =>
  (await api.get("/notifications", { params: { page, unread_only: unreadOnly || undefined } })).data.data;
export const unreadCount = async () => (await api.get("/notifications/unread-count")).data.data.unread;
export const markRead = async (id) => (await api.post(`/notifications/${id}/read`)).data;
export const markAllRead = async () => (await api.post("/notifications/read-all")).data;

/** {in_app, email, email_verified}. Only in_app and email can be changed. */
export const getPreferences = async () => (await api.get("/notifications/preferences")).data.data;
export const savePreferences = async (changes) => (await api.put("/notifications/preferences", changes)).data.data;
