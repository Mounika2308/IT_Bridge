import { api } from "./api.js";

const clean = (o) => Object.fromEntries(Object.entries(o).filter(([, v]) => v !== "" && v != null && v !== false));
export const searchTrainers = async (params) => (await api.get("/trainers", { params: clean(params) })).data.data;
export const getTrainer = async (id) => (await api.get(`/trainers/${id}`)).data.data;
export const getMatches = async (reqId) => (await api.get(`/requirements/${reqId}/matches`)).data.data;
export const getRecommendations = async () => (await api.get("/trainers/me/recommendations")).data.data;
export const getBusyPeriods = async () => (await api.get("/trainers/me/busy-periods")).data.data;
export const addBusyPeriod = async (p) => (await api.post("/trainers/me/busy-periods", p)).data.data;
export const removeBusyPeriod = async (id) => (await api.delete(`/trainers/me/busy-periods/${id}`)).data.data;
