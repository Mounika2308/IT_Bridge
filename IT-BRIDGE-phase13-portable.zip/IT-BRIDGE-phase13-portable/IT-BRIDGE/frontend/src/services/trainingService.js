import { api } from "./api.js";

export const myTrainings = async (page = 1, status = "") =>
  (await api.get("/trainings/mine", { params: { page, status: status || undefined } })).data.data;
export const saveSessionNotes = async (sid, notes) => (await api.put(`/sessions/${sid}/notes`, { notes })).data.data;
export const updatePlannedSessions = async (tid, planned) => (await api.patch(`/trainings/${tid}/planned-sessions`, { planned_sessions: planned })).data.data;
export const updateTrainingDetails = async (tid, p) => (await api.patch(`/trainings/${tid}/details`, p)).data.data;
export const trainingSummary = async () => (await api.get("/trainings/summary")).data.data;
export const getTraining = async (id) => (await api.get(`/trainings/${id}`)).data.data;
export const createSession = async (tid, p) => (await api.post(`/trainings/${tid}/sessions`, p)).data.data;
export const updateSession = async (sid, p) => (await api.patch(`/sessions/${sid}`, p)).data.data;
export const setSessionStatus = async (sid, status) => (await api.post(`/sessions/${sid}/status`, { status })).data.data;
export const saveAttendance = async (sid, p) => (await api.put(`/sessions/${sid}/attendance`, p)).data.data;
export const completeTraining = async (tid) => (await api.post(`/trainings/${tid}/complete`)).data.data;
export const cancelTraining = async (tid, reason) => (await api.post(`/trainings/${tid}/cancel`, { reason })).data.data;
export const updateTrainingDates = async (tid, p) => (await api.patch(`/trainings/${tid}/dates`, p)).data.data;
export const getCalendar = async (start, end) => (await api.get("/calendar", { params: { start, end } })).data.data;
