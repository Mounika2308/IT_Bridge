import { api } from "./api.js";

export const trainingReviews = async (tid) => (await api.get(`/trainings/${tid}/reviews`)).data.data;
export const submitReview = async (tid, p) => (await api.post(`/trainings/${tid}/reviews`, p)).data.data;
export const trainerReviews = async (trainerId, page = 1) => (await api.get(`/trainers/${trainerId}/reviews`, { params: { page } })).data.data;
export const institutionReviews = async (institutionId, page = 1) => (await api.get(`/institutions/${institutionId}/reviews`, { params: { page } })).data.data;
/** Own rating summary and the completed trainings still waiting for this user's review (derived by the server). */
export const myReviewSummary = async () => (await api.get("/reviews/me")).data.data;
