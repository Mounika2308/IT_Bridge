import { api } from "./api.js";

export const getCategories = async () => (await api.get("/categories")).data.data;
export const createRequirement = async (p) => (await api.post("/requirements", p)).data.data;
export const updateRequirement = async (id, p) => (await api.put(`/requirements/${id}`, p)).data.data;
export const closeRequirement = async (id) => (await api.post(`/requirements/${id}/close`)).data.data;
export const getRequirement = async (id) => (await api.get(`/requirements/${id}`)).data.data;
export const myRequirements = async (page = 1) => (await api.get("/requirements/mine", { params: { page } })).data.data;
export const browseRequirements = async (params) => {
  const clean = Object.fromEntries(Object.entries(params).filter(([, v]) => v !== "" && v != null));
  return (await api.get("/requirements", { params: clean })).data.data;
};
