import { api } from "./api.js";

export const applyTo = async (reqId, p) => (await api.post(`/requirements/${reqId}/apply`, p)).data.data;
export const myApplications = async () => (await api.get("/applications/mine")).data.data;
export const withdrawApplication = async (id) => (await api.post(`/applications/${id}/withdraw`)).data.data;
export const requirementApplications = async (reqId, status) =>
  (await api.get(`/requirements/${reqId}/applications`, { params: status ? { status } : {} })).data.data;
export const setApplicationStatus = async (id, status, interviewAt) =>
  (await api.patch(`/applications/${id}/status`, { status, ...(interviewAt ? { interview_at: interviewAt } : {}) })).data.data;
export const hireTrainer = async (id, p) => (await api.post(`/applications/${id}/hire`, p)).data.data;
export const myHiringRequests = async () => (await api.get("/hiring-requests/mine")).data.data;
export const respondHiring = async (id, action) => (await api.post(`/hiring-requests/${id}/${action}`)).data.data; // accept | decline | cancel
