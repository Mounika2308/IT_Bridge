import { useParams, Link } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import AppLayout from "../layouts/AppLayout.jsx";
import Button from "../components/ui/Button.jsx";
import EmptyState from "../components/ui/EmptyState.jsx";
import TrainerCard from "../components/TrainerCard.jsx";
import MatchBreakdown, { ScoreBadge } from "../components/MatchBreakdown.jsx";
import { getMatches } from "../services/matchingService.js";
import { errorMessage } from "../services/api.js";

export default function RequirementMatches() {
  const { id } = useParams();
  const q = useQuery({ queryKey: ["matches", id], queryFn: () => getMatches(id), retry: false });
  return (
    <AppLayout>
      <h1 className="text-3xl font-extrabold">Recommended trainers</h1>
      <p className="mb-6 mt-1 text-sm text-steel">Scores come from skills, experience, location, availability, training mode and budget. Open any trainer to see exactly why.</p>
      {q.isLoading && <p role="status" className="text-steel">Matching trainers...</p>}
      {q.isError && <p role="alert" className="text-danger">{errorMessage(q.error)}</p>}
      {q.data?.matches.length === 0 && (
        <EmptyState title="No trainers match yet" text="No trainer has the skills this requirement asks for. Browse all trainers or loosen the required skills."
          action={<Button as={Link} to="/institution/trainers">Browse all trainers</Button>} />
      )}
      <div className="grid gap-4 md:grid-cols-2">
        {q.data?.matches.map((m) => (
          <TrainerCard key={m.id} t={m} extra={<ScoreBadge score={m.score} />}>
            <details className="mt-4 border-t border-line pt-3">
              <summary className="cursor-pointer text-sm font-semibold text-span-dark">Why this match</summary>
              <div className="mt-3"><MatchBreakdown factors={m.factors} /></div>
            </details>
          </TrainerCard>
        ))}
      </div>
    </AppLayout>
  );
}
