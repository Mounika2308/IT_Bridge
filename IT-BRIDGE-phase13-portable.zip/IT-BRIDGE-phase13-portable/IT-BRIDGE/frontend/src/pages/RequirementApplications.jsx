import { useState } from "react";
import { useParams } from "react-router-dom";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import AppLayout from "../layouts/AppLayout.jsx";
import Button from "../components/ui/Button.jsx";
import Field from "../components/ui/Field.jsx";
import TextArea from "../components/ui/TextArea.jsx";
import SelectField from "../components/ui/SelectField.jsx";
import EmptyState from "../components/ui/EmptyState.jsx";
import TrainerCard from "../components/TrainerCard.jsx";
import StatusBadge from "../components/StatusBadge.jsx";
import ContactBox from "../components/ContactBox.jsx";
import MatchBreakdown, { ScoreBadge } from "../components/MatchBreakdown.jsx";
import { money } from "../components/RequirementCard.jsx";
import { fieldErrors, interviewSchema } from "../schemas/training.js";
import { hireTrainer, myHiringRequests, requirementApplications, respondHiring, setApplicationStatus } from "../services/applicationService.js";
import { errorMessage } from "../services/api.js";

const NEXT = {
  APPLIED: [["UNDER_REVIEW", "Start review"], ["SHORTLISTED", "Shortlist"], ["REJECTED", "Reject"]],
  UNDER_REVIEW: [["SHORTLISTED", "Shortlist"], ["REJECTED", "Reject"]],
  SHORTLISTED: [["INTERVIEW", "Move to interview"], ["REJECTED", "Reject"]],
  INTERVIEW: [["INTERVIEW", "Reschedule interview"], ["REJECTED", "Reject"]],
};

const fmt = (iso) => new Date(iso).toLocaleString([], { dateStyle: "medium", timeStyle: "short" });

function InterviewForm({ initial, pending, onSubmit }) {
  const [when, setWhen] = useState(initial ? initial.slice(0, 16) : "");
  const [error, setError] = useState("");
  const submit = () => {
    const e = fieldErrors(interviewSchema(), { interview_at: when });
    setError(e.interview_at || "");
    if (!e.interview_at) onSubmit(when);
  };
  return (
    <div className="mt-3 flex items-end gap-2 rounded-ctl border border-line p-4">
      <div className="flex-1"><Field label="Interview date and time" type="datetime-local" value={when} error={error} onChange={(e) => setWhen(e.target.value)} /></div>
      <Button className="!py-3" disabled={pending} onClick={submit}>{pending ? "Saving..." : "Confirm interview"}</Button>
    </div>
  );
}

function HireForm({ app, onDone }) {
  const [fee, setFee] = useState(app.proposed_fee ?? "");
  const [terms, setTerms] = useState("");
  const m = useMutation({ mutationFn: () => hireTrainer(app.id, { agreed_fee: Number(fee), terms: terms || null }), onSuccess: onDone });
  const invalid = fee === "" || Number(fee) < 0;
  return (
    <div className="mt-3 space-y-3 rounded-ctl border border-line p-4">
      {m.isError && <p role="alert" className="text-sm text-danger">{errorMessage(m.error)}</p>}
      <Field label="Agreed fee (total, ₹)" type="number" min="0" value={fee} onChange={(e) => setFee(e.target.value)} />
      <TextArea label="Terms (optional)" rows={3} value={terms} onChange={(e) => setTerms(e.target.value)} />
      <Button className="!py-2" disabled={invalid || m.isPending} onClick={() => m.mutate()}>{m.isPending ? "Sending..." : "Send hiring request"}</Button>
    </div>
  );
}

export default function RequirementApplications() {
  const { id } = useParams();
  const qc = useQueryClient();
  const [status, setStatus] = useState("");
  const [hiring, setHiring] = useState(null);
  const [scheduling, setScheduling] = useState(null);
  const apps = useQuery({ queryKey: ["req-applications", id, status], queryFn: () => requirementApplications(id, status) });
  const hires = useQuery({ queryKey: ["my-hiring"], queryFn: myHiringRequests });
  const refresh = () => { setHiring(null); setScheduling(null); qc.invalidateQueries({ queryKey: ["req-applications", id] }); qc.invalidateQueries({ queryKey: ["my-hiring"] }); };
  const move = useMutation({ mutationFn: ({ appId, to, interviewAt }) => setApplicationStatus(appId, to, interviewAt), onSuccess: refresh });
  const cancel = useMutation({ mutationFn: (hid) => respondHiring(hid, "cancel"), onSuccess: refresh });
  const error = move.error || cancel.error;
  const hireByApp = Object.fromEntries((hires.data || []).map((h) => [h.application_id, h]));

  return (
    <AppLayout>
      <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
        <h1 className="text-3xl font-extrabold">Applications</h1>
        <div className="w-48"><SelectField label="Status" value={status} onChange={(e) => setStatus(e.target.value)}
          options={["APPLIED", "UNDER_REVIEW", "SHORTLISTED", "INTERVIEW", "SELECTED", "REJECTED", "WITHDRAWN"].map((s) => [s, s.charAt(0) + s.slice(1).toLowerCase().replace("_", " ")])} /></div>
      </div>
      {error && <p role="alert" className="mb-4 rounded-ctl bg-red-50 p-3 text-sm text-danger">{errorMessage(error)}</p>}
      {apps.isLoading && <p role="status" className="text-steel">Loading applications...</p>}
      {apps.isError && <p role="alert" className="text-danger">{errorMessage(apps.error)}</p>}
      {apps.data?.length === 0 && <EmptyState title="No applications yet" text={status ? "No applications with this status." : "Trainers who apply will appear here, ranked by match score."} />}
      <div className="grid gap-4">
        {apps.data?.map((a) => {
          const h = hireByApp[a.id];
          const locked = ["FILLED", "CLOSED"].includes(a.requirement_status);   // the server refuses these actions too
          return (
            <TrainerCard key={a.id} t={a.trainer} extra={<div className="flex flex-col items-end gap-2"><ScoreBadge score={a.score} /><StatusBadge status={a.status} /></div>}>
              {a.cover_note && <p className="mt-3 text-sm">“{a.cover_note}”</p>}
              {a.proposed_fee != null && <p className="mt-1 text-sm text-steel">Proposed fee: {money(a.proposed_fee)}</p>}
              {a.status === "INTERVIEW" && a.interview_at && <p className="mt-1 text-sm font-semibold">Interview: {fmt(a.interview_at)}</p>}
              <details className="mt-3 border-t border-line pt-3">
                <summary className="cursor-pointer text-sm font-semibold text-span-dark">Why this match</summary>
                <div className="mt-3"><MatchBreakdown factors={a.factors} /></div>
              </details>
              <div className="mt-4 flex flex-wrap gap-2">
                {(locked ? [] : NEXT[a.status] || []).map(([to, label]) => (
                  <Button key={to} variant={to === "REJECTED" ? "secondary" : "primary"} className="!py-2" disabled={move.isPending}
                    onClick={() => (to === "INTERVIEW" ? setScheduling(scheduling === a.id ? null : a.id) : (to !== "REJECTED" || window.confirm("Reject this application?")) && move.mutate({ appId: a.id, to }))}>{label}</Button>
                ))}
                {!locked && ["SHORTLISTED", "INTERVIEW"].includes(a.status) && <Button variant="accent" className="!py-2" onClick={() => setHiring(hiring === a.id ? null : a.id)}>Hire</Button>}
                {h?.status === "PENDING" && <Button variant="secondary" className="!py-2" disabled={cancel.isPending} onClick={() => cancel.mutate(h.id)}>Cancel hiring request</Button>}
              </div>
              {locked && a.status !== "SELECTED" && <p className="mt-3 text-sm text-steel">This requirement has been {a.requirement_status === "FILLED" ? "filled" : "closed"}, so this application can no longer be processed.</p>}
              {scheduling === a.id && <InterviewForm initial={a.interview_at} pending={move.isPending} onSubmit={(when) => move.mutate({ appId: a.id, to: "INTERVIEW", interviewAt: when })} />}
              {hiring === a.id && <HireForm app={a} onDone={refresh} />}
              {h?.status === "PENDING" && <p className="mt-3 text-sm text-steel">Waiting for the trainer to respond to your hiring request.</p>}
              {h?.status === "ACCEPTED" && <ContactBox contact={h.contact} />}
              {h && ["DECLINED"].includes(h.status) && <p className="mt-3 text-sm text-steel">The trainer declined the hiring request.</p>}
            </TrainerCard>
          );
        })}
      </div>
    </AppLayout>
  );
}
