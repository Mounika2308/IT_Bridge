import { Check, ShieldCheck, Sparkles, CalendarCheck, Bell, Wallet, Star, BarChart3 } from "lucide-react";
import Button from "../components/ui/Button.jsx";
import Badge from "../components/ui/Badge.jsx";
import Logo from "../components/Logo.jsx";

const matchReasons = [
  "React skill matched",
  "5 years of experience",
  "Available on requested dates",
  "Offline training supported",
  "Location compatible",
];

const features = [
  [Sparkles, "Smart trainer matching", "Every match shows its score and the reasons behind it."],
  [ShieldCheck, "Verified trainers", "Admins check profiles before a badge appears."],
  [CalendarCheck, "Training management", "Sessions, attendance and progress in one place."],
  [Bell, "Real-time notifications", "Know the moment an application or request changes."],
  [Wallet, "Payment tracking (sandbox)", "Agreed fees, commission and platform invoices are tracked per training. Real online payments are not enabled yet."],
  [Star, "Reviews and ratings", "Rate trainers on teaching, punctuality and more."],
  [BarChart3, "Payment and earnings summaries", "Institutions see totals paid and trainers see pending, available and paid earnings. Trend analytics are not available yet."],
];

const categories = ["Python", "Java", "JavaScript", "React", "Full Stack", "Data Science", "AI/ML", "Cloud", "DevOps", "Cyber Security", "DSA", "Aptitude", "Soft Skills", "Communication", "Interview Prep"];

const Flow = ({ title, steps }) => (
  <div className="rounded-card bg-white p-6 shadow-card">
    <h3 className="mb-4 text-lg font-bold">{title}</h3>
    <ol className="flex flex-wrap items-center gap-2 text-sm font-medium">
      {steps.map((s, i) => (
        <li key={s} className="flex items-center gap-2">
          <span className="rounded-full bg-span-soft px-3 py-1 text-span-dark">{s}</span>
          {i < steps.length - 1 && <span aria-hidden="true" className="text-steel">&rsaquo;</span>}
        </li>
      ))}
    </ol>
  </div>
);

export default function Landing() {
  return (
    <div>
      <header className="mx-auto flex max-w-6xl items-center justify-between px-5 py-5">
        <Logo />
        <nav className="flex items-center gap-3">
          <Button as="a" href="/login" variant="secondary">Log in</Button>
          <Button as="a" href="/register" className="hidden sm:inline-flex">Sign up</Button>
        </nav>
      </header>

      <section className="mx-auto grid max-w-6xl items-center gap-10 px-5 pb-16 pt-8 lg:grid-cols-2">
        <div>
          <h1 className="text-4xl font-extrabold leading-tight sm:text-5xl">Connect institutions with the right trainers</h1>
          <p className="mt-4 max-w-md text-steel">IT BRIDGE helps colleges and training institutes post a requirement, see ranked trainers with clear reasons, and manage the training from hiring to completion.</p>
          <div className="mt-7 flex flex-wrap gap-3">
            <Button as="a" href="/institution/trainers">Find a trainer</Button>
            <Button as="a" href="/register?role=trainer" variant="secondary">Become a trainer</Button>
            <Button as="a" href="/register?role=institution" variant="accent">Post a requirement</Button>
          </div>
        </div>

        <div className="rounded-card bg-white p-6 shadow-card">
          <svg viewBox="0 0 400 90" className="mb-4 w-full" aria-hidden="true">
            <circle cx="30" cy="70" r="10" fill="#12263A" />
            <circle cx="370" cy="70" r="10" fill="#F2A93B" />
            <path className="draw" d="M30 70 Q200 -30 370 70" fill="none" stroke="#0E7C86" strokeWidth="4" strokeLinecap="round" />
          </svg>
          <div className="flex items-center justify-between">
            <div>
              <p className="font-display text-lg font-bold">React Trainer</p>
              <p className="text-sm text-steel">Requirement: Full Stack Workshop</p>
            </div>
            <Badge tone="ok">94% match</Badge>
          </div>
          <ul className="mt-4 space-y-2 text-sm">
            {matchReasons.map((m) => (
              <li key={m} className="flex items-center gap-2"><Check size={16} className="text-ok" /> {m}</li>
            ))}
          </ul>
        </div>
      </section>

      <section className="mx-auto grid max-w-6xl gap-4 px-5 pb-16 md:grid-cols-2">
        <Flow title="For institutions" steps={["Post requirement", "Discover trainers", "Shortlist", "Hire", "Train"]} />
        <Flow title="For trainers" steps={["Create profile", "Find opportunities", "Apply", "Get selected", "Train", "Earn"]} />
      </section>

      <section className="mx-auto max-w-6xl px-5 pb-16">
        <h2 className="mb-6 text-2xl font-bold">Everything the training needs</h2>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {features.map(([Icon, t, d]) => (
            <div key={t} className="rounded-card bg-white p-5 shadow-card">
              <Icon className="mb-3 text-span" size={22} />
              <h3 className="font-bold">{t}</h3>
              <p className="mt-1 text-sm text-steel">{d}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-5 pb-20">
        <h2 className="mb-5 text-2xl font-bold">Browse by category</h2>
        <div className="flex flex-wrap gap-2">
          {categories.map((c) => (
            <a key={c} href={`/institution/trainers?q=${encodeURIComponent(c)}`} className="rounded-full border border-line bg-white px-4 py-2 text-sm hover:border-span">{c}</a>
          ))}
        </div>
      </section>

      <footer className="border-t border-line py-8 text-center text-sm text-steel">IT BRIDGE - Institutions to Trainer Bridge</footer>
    </div>
  );
}
