import { Link, useParams } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import AppLayout from "../layouts/AppLayout.jsx";
import Button from "../components/ui/Button.jsx";
import { getInvoice } from "../services/paymentService.js";
import { errorMessage } from "../services/api.js";
import { INVOICE_NOT_TAX_NOTE, formatPaise } from "../utils/payments.js";

const date = (iso) => (iso ? String(iso).slice(0, 10) : "");

/** The invoice as a printable document. Pure of data fetching. The institution never sees commission or the trainer's net here. */
export function InvoiceDocument({ inv }) {
  return (
    <article className="rounded-card bg-white p-8 shadow-card print:rounded-none print:p-0 print:shadow-none" aria-label={`Invoice ${inv.number}`} data-testid="invoice">
      {inv.sandbox && <p role="note" className="mb-4 rounded-ctl border border-signal bg-signal-soft p-3 text-sm font-bold" data-testid="invoice-sandbox">
        {inv.sandbox_notice || "SANDBOX: no real money was processed. This document has no financial value."}</p>}
      <header className="flex flex-wrap items-start justify-between gap-4 border-b border-line pb-4">
        <div><h1 className="text-2xl font-extrabold">Invoice</h1><p className="text-sm text-steel">{inv.issued_by}</p></div>
        <dl className="text-right text-sm">
          <div><dt className="inline text-steel">Invoice number: </dt><dd className="inline font-bold" data-testid="invoice-number">{inv.number}</dd></div>
          <div><dt className="inline text-steel">Issued: </dt><dd className="inline font-semibold">{date(inv.issued_at)}</dd></div>
          {inv.paid_at && <div><dt className="inline text-steel">Paid: </dt><dd className="inline font-semibold">{date(inv.paid_at)}</dd></div>}
        </dl>
      </header>
      <section className="mt-4 grid gap-4 text-sm sm:grid-cols-2">
        <div><h2 className="text-xs font-semibold uppercase text-steel">Billed to</h2><p className="font-semibold">{inv.billed_to.name}</p>{inv.billed_to.location && <p>{inv.billed_to.location}</p>}</div>
        <div><h2 className="text-xs font-semibold uppercase text-steel">Training</h2><p className="font-semibold">{inv.training.title}</p>
          <p>{[inv.training.technology, `${inv.training.start_date} to ${inv.training.end_date}`].filter(Boolean).join(" · ")}</p>
          <p className="text-steel">Trainer: {inv.trainer_name}</p></div>
      </section>
      <table className="mt-6 w-full text-sm">
        <thead><tr className="border-b border-line text-left text-xs uppercase text-steel"><th className="py-2">Description</th><th className="py-2 text-right">Amount</th></tr></thead>
        <tbody><tr className="border-b border-line"><td className="py-3">{inv.description}</td><td className="py-3 text-right font-semibold" data-testid="invoice-amount">{formatPaise(inv.amount_paise)}</td></tr></tbody>
        <tfoot><tr><td className="py-3 font-bold">Total paid</td><td className="py-3 text-right text-lg font-extrabold">{formatPaise(inv.amount_paise)}</td></tr></tfoot>
      </table>
      {inv.credit_note && (
        <section className="mt-4 rounded-ctl border border-line p-4 text-sm" data-testid="credit-note">
          <h2 className="font-bold">Credit note {inv.credit_note.number}</h2>
          <p>Refunded in full: <strong>{formatPaise(inv.credit_note.amount_paise)}</strong>{inv.credit_note.issued_at ? ` on ${date(inv.credit_note.issued_at)}` : ""}. The invoice above is unchanged; this credit note records the refund.</p>
        </section>
      )}
      <p className="mt-6 text-xs text-steel" data-testid="invoice-notice">{inv.notice || INVOICE_NOT_TAX_NOTE}</p>
    </article>
  );
}

export default function InvoiceView() {
  const { id } = useParams();
  const q = useQuery({ queryKey: ["invoice", id], queryFn: () => getInvoice(id), retry: false });
  return (
    <AppLayout>
      <div className="mb-4 flex items-center justify-between gap-3 print:hidden">
        <Link to="/institution/payments" className="text-sm font-semibold text-span-dark underline">Back to payments</Link>
        <Button variant="secondary" className="!py-2" onClick={() => window.print()} disabled={!q.data}>Print invoice</Button>
      </div>
      {q.isLoading && <p role="status" className="text-steel">Loading invoice...</p>}
      {q.isError && <p role="alert" className="text-danger">{q.error?.response?.status === 404 ? "Invoice not found. It is issued once a payment has succeeded." : errorMessage(q.error)}</p>}
      {q.data && <div className="max-w-3xl"><InvoiceDocument inv={q.data} /></div>}
    </AppLayout>
  );
}
