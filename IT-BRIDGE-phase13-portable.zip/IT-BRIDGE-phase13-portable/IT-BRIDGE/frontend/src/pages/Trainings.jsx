import { useState } from "react";
import { Link } from "react-router-dom";
import { useQuery, keepPreviousData } from "@tanstack/react-query";
import { MapPin, CalendarDays } from "lucide-react";
import AppLayout from "../layouts/AppLayout.jsx";
import Button from "../components/ui/Button.jsx";
import EmptyState from "../components/ui/EmptyState.jsx";
import Pagination from "../components/ui/Pagination.jsx";
import ProgressBar from "../components/ui/ProgressBar.jsx";
import StatusBadge from "../components/StatusBadge.jsx";
import { money } from "../components/RequirementCard.jsx";
import { useAuth } from "../context/AuthContext.jsx";
import { myTrainings } from "../services/trainingService.js";
import { errorMessage } from "../services/api.js";

const TABS = [["", "All"], ["ACTIVE", "Active"], ["COMPLETED", "Completed"], ["CANCELLED", "Cancelled"]];
const MODE = { ONLINE: "Online", OFFLINE: "Offline", HYBRID: "Hybrid" };

export default function Trainings() {
  const { user } = useAuth();
  const [status, setStatus] = useState("");
  const [page, setPage] = useState(1);
  const q = useQuery({ queryKey: ["trainings", status, page], queryFn: () => myTrainings(page, status), placeholderData: keepPreviousData });
  const trainer = user.role === "TRAINER";

  return (
    <AppLayout>
      <h1 className="mb-4 text-3xl font-extrabold">Trainings</h1>
      <div role="tablist" aria-label="Filter by status" className="mb-6 flex gap-2 overflow-x-auto">
        {TABS.map(([value, label]) => (
          <button key={label} role="tab" aria-selected={status === value} onClick={() => { setStatus(value); setPage(1); }}
            className={`whitespace-nowrap rounded-full border px-4 py-2 text-sm font-semibold ${status === value ? "border-span bg-span-soft text-span-dark" : "border-line bg-white text-steel"}`}>{label}</button>
        ))}
      </div>
      {q.isLoading && <p role="status" className="text-steel">Loading trainings...</p>}
      {q.isError && (
        <div role="alert" className="text-danger">
          <p>{errorMessage(q.error)}</p>
          <Button variant="secondary" className="mt-3" onClick={() => q.refetch()}>Try again</Button>
        </div>
      )}
      {q.data?.items.length === 0 && (
        <EmptyState title={status ? "No trainings with this status" : "No trainings yet"}
          text={status ? "Try another tab." : trainer ? "A training starts here once you accept a hiring request." : "A training starts here once a trainer accepts your hiring request."}
          action={!status && <Button as={Link} to={trainer ? "/trainer/opportunities" : "/institution/requirements"}>{trainer ? "Browse opportunities" : "View requirements"}</Button>} />
      )}
      <div className="grid gap-4 md:grid-cols-2">
        {q.data?.items.map((t) => (
          <article key={t.id} className="rounded-card bg-white p-5 shadow-card">
            <div className="flex items-start justify-between gap-3">
              <div>
                <h2 className="text-lg font-bold"><Link to={`/trainings/${t.id}`} className="hover:text-span-dark">{t.title}</Link></h2>
                <p className="text-sm text-steel">{trainer ? t.institution_name : t.trainer_name} · {t.technology}</p>
              </div>
              <StatusBadge status={t.phase} />
            </div>
            <ul className="mt-3 grid grid-cols-2 gap-y-1 text-sm text-steel">
              <li className="flex items-center gap-1.5"><CalendarDays size={14} />{t.start_date} to {t.end_date}</li>
              <li className="flex items-center gap-1.5"><MapPin size={14} />{t.location} ({MODE[t.mode]})</li>
              <li>Fee {money(t.agreed_fee)}</li>
              <li>{t.student_count} students</li>
            </ul>
            <div className="mt-4"><ProgressBar value={t.progress.percent} label={`${t.progress.completed} of ${t.planned_sessions} sessions done`} /></div>
          </article>
        ))}
      </div>
      {q.data && <Pagination page={page} pageSize={q.data.page_size} total={q.data.total} onChange={setPage} />}
    </AppLayout>
  );
}
