import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useNavigate, useParams } from "react-router-dom";
import AppLayout from "../layouts/AppLayout.jsx";
import Field from "../components/ui/Field.jsx";
import TextArea from "../components/ui/TextArea.jsx";
import SelectField from "../components/ui/SelectField.jsx";
import Button from "../components/ui/Button.jsx";
import { requirementSchema } from "../schemas/profile.js";
import { getSkills } from "../services/profileService.js";
import { createRequirement, getCategories, getRequirement, updateRequirement } from "../services/requirementService.js";
import { errorMessage } from "../services/api.js";

export default function RequirementForm() {
  const { id } = useParams();
  const editing = !!id;
  const nav = useNavigate();
  const qc = useQueryClient();
  const [serverError, setServerError] = useState("");
  const skills = useQuery({ queryKey: ["skills"], queryFn: getSkills });
  const cats = useQuery({ queryKey: ["categories"], queryFn: getCategories });
  const existing = useQuery({ queryKey: ["requirement", id], queryFn: () => getRequirement(id), enabled: editing });
  const { register, handleSubmit, reset, watch, setValue, formState: { errors, isSubmitting } } = useForm({
    resolver: zodResolver(requirementSchema),
    defaultValues: { skill_ids: [], preferred_experience_years: 0, category_id: "" },
  });

  useEffect(() => {
    const r = existing.data;
    if (r) reset({ ...r, category_id: r.category?.id ?? "", skill_ids: r.skills.map((s) => s.id), additional_requirements: r.additional_requirements ?? "" });
  }, [existing.data, reset]);

  const selected = watch("skill_ids") || [];
  const toggle = (sid) => setValue("skill_ids", selected.includes(sid) ? selected.filter((x) => x !== sid) : [...selected, sid], { shouldValidate: true });

  const onSubmit = async (values) => {
    setServerError("");
    try {
      const body = { ...values, additional_requirements: values.additional_requirements || null };
      editing ? await updateRequirement(id, body) : await createRequirement(body);
      qc.invalidateQueries({ queryKey: ["my-requirements"] });
      nav("/institution/requirements", { replace: true });
    } catch (e) {
      const fields = e.response?.data?.data;
      setServerError(fields && typeof fields === "object" ? Object.values(fields).join(". ") : errorMessage(e));
    }
  };

  const e = (k) => errors[k]?.message;
  return (
    <AppLayout>
      <h1 className="mb-6 text-3xl font-extrabold">{editing ? "Edit requirement" : "Post a training requirement"}</h1>
      <form onSubmit={handleSubmit(onSubmit)} noValidate className="max-w-2xl space-y-4 rounded-card bg-white p-6 shadow-card">
        {serverError && <p role="alert" className="rounded-ctl bg-red-50 p-3 text-sm text-danger">{serverError}</p>}
        <Field label="Requirement title" error={e("title")} {...register("title")} />
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Course or technology" error={e("technology")} {...register("technology")} />
          <SelectField label="Category" error={e("category_id")} {...register("category_id")} options={(cats.data || []).map((c) => [c.id, c.name])} />
        </div>
        <TextArea label="Description" error={e("description")} {...register("description")} />
        <fieldset>
          <legend className="mb-2 text-sm font-semibold">Skills required</legend>
          <div className="flex flex-wrap gap-2">
            {skills.data?.map((s) => (
              <label key={s.id} className={`cursor-pointer rounded-full border px-3.5 py-2 text-sm ${selected.includes(s.id) ? "border-span bg-span-soft font-semibold" : "border-line"}`}>
                <input type="checkbox" className="sr-only" checked={selected.includes(s.id)} onChange={() => toggle(s.id)} />{s.name}
              </label>
            ))}
          </div>
          {e("skill_ids") && <p role="alert" className="mt-1 text-xs text-danger">{e("skill_ids")}</p>}
        </fieldset>
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Number of students" type="number" min="1" error={e("student_count")} {...register("student_count")} />
          <SelectField label="Student level" error={e("student_level")} {...register("student_level")} options={[["BEGINNER", "Beginner"], ["INTERMEDIATE", "Intermediate"], ["ADVANCED", "Advanced"]]} />
          <Field label="Duration (days)" type="number" min="1" error={e("duration_days")} {...register("duration_days")} />
          <Field label="Number of sessions" type="number" min="1" error={e("sessions")} {...register("sessions")} />
          <Field label="City" error={e("location")} {...register("location")} />
          <SelectField label="Mode" error={e("mode")} {...register("mode")} options={[["ONLINE", "Online"], ["OFFLINE", "Offline"], ["HYBRID", "Hybrid"]]} />
          <Field label="Start date" type="date" error={e("start_date")} {...register("start_date")} />
          <Field label="End date" type="date" error={e("end_date")} {...register("end_date")} />
          <Field label="Application deadline" type="date" error={e("application_deadline")} {...register("application_deadline")} />
          <Field label="Preferred experience (years)" type="number" min="0" error={e("preferred_experience_years")} {...register("preferred_experience_years")} />
          <Field label="Minimum budget (₹)" type="number" min="0" error={e("budget_min")} {...register("budget_min")} />
          <Field label="Maximum budget (₹)" type="number" min="0" error={e("budget_max")} {...register("budget_max")} />
        </div>
        <TextArea label="Additional requirements (optional)" rows={3} error={e("additional_requirements")} {...register("additional_requirements")} />
        <Button type="submit" className="w-full" disabled={isSubmitting}>{isSubmitting ? "Saving..." : editing ? "Save changes" : "Post requirement"}</Button>
      </form>
    </AppLayout>
  );
}
