import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Link, useNavigate } from "react-router-dom";
import AuthLayout from "../layouts/AuthLayout.jsx";
import Field from "../components/ui/Field.jsx";
import Button from "../components/ui/Button.jsx";
import { loginSchema } from "../schemas/auth.js";
import { useAuth } from "../context/AuthContext.jsx";
import { errorMessage } from "../services/api.js";
import { homeFor } from "../routes/ProtectedRoute.jsx";
import { session } from "../services/api.js";

export default function Login() {
  const { login } = useAuth();
  const nav = useNavigate();
  const [serverError, setServerError] = useState("");
  const { register, handleSubmit, formState: { errors, isSubmitting } } = useForm({ resolver: zodResolver(loginSchema) });

  const onSubmit = async (values) => {
    setServerError("");
    try {
      await login(values);
      nav(homeFor(session.get().user.role), { replace: true });
    } catch (e) { setServerError(errorMessage(e)); }
  };

  return (
    <AuthLayout title="Log in" subtitle="Welcome back to IT BRIDGE.">
      <form onSubmit={handleSubmit(onSubmit)} noValidate className="space-y-4">
        {serverError && <p role="alert" className="rounded-ctl bg-red-50 p-3 text-sm text-danger">{serverError}</p>}
        <Field label="Email" type="email" autoComplete="email" error={errors.email?.message} {...register("email")} />
        <Field label="Password" type="password" autoComplete="current-password" error={errors.password?.message} {...register("password")} />
        <Button type="submit" className="w-full" disabled={isSubmitting}>{isSubmitting ? "Logging in..." : "Log in"}</Button>
      </form>
      <p className="mt-5 text-center text-sm text-steel">New here? <Link to="/register" className="font-semibold text-span-dark">Create an account</Link></p>
    </AuthLayout>
  );
}
