import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Link, useNavigate, useSearchParams } from "react-router-dom";
import { GraduationCap, Building2 } from "lucide-react";
import AuthLayout from "../layouts/AuthLayout.jsx";
import Field from "../components/ui/Field.jsx";
import Button from "../components/ui/Button.jsx";
import { registerSchema } from "../schemas/auth.js";
import { useAuth } from "../context/AuthContext.jsx";
import { errorMessage, session } from "../services/api.js";
import { homeFor } from "../routes/ProtectedRoute.jsx";

const roles = [
  { value: "TRAINER", label: "I'm a trainer", desc: "Find training opportunities", Icon: GraduationCap },
  { value: "INSTITUTION", label: "I'm an institution", desc: "Hire trainers for my students", Icon: Building2 },
];

export default function Register() {
  const [params] = useSearchParams();
  const initial = params.get("role")?.toUpperCase();
  const [role, setRole] = useState(["TRAINER", "INSTITUTION"].includes(initial) ? initial : null);
  const [serverError, setServerError] = useState("");
  const { register: signUp } = useAuth();
  const nav = useNavigate();
  const { register, handleSubmit, formState: { errors, isSubmitting } } = useForm({
    resolver: zodResolver(registerSchema),
    values: { role, full_name: "", email: "", phone: "", password: "", institution_name: "" },
  });

  if (!role) {
    return (
      <AuthLayout title="Join IT BRIDGE" subtitle="Choose how you will use the platform.">
        <div className="space-y-3" role="group" aria-label="Account type">
          {roles.map(({ value, label, desc, Icon }) => (
            <button key={value} type="button" onClick={() => setRole(value)}
              className="flex w-full items-center gap-4 rounded-card border border-line p-4 text-left hover:border-span">
              <Icon className="text-span" />
              <span><span className="block font-bold">{label}</span><span className="text-sm text-steel">{desc}</span></span>
            </button>
          ))}
        </div>
        <p className="mt-5 text-center text-sm text-steel">Already registered? <Link to="/login" className="font-semibold text-span-dark">Log in</Link></p>
      </AuthLayout>
    );
  }

  const onSubmit = async (values) => {
    setServerError("");
    try {
      await signUp({ ...values, role });
      nav(role === "TRAINER" ? "/trainer/profile" : "/institution/profile", { replace: true });
    } catch (e) { setServerError(errorMessage(e)); }
  };

  return (
    <AuthLayout title={role === "TRAINER" ? "Create trainer account" : "Create institution account"} subtitle="You can complete your profile after signing up.">
      <form onSubmit={handleSubmit(onSubmit)} noValidate className="space-y-4">
        {serverError && <p role="alert" className="rounded-ctl bg-red-50 p-3 text-sm text-danger">{serverError}</p>}
        {role === "INSTITUTION" && <Field label="Institution name" error={errors.institution_name?.message} {...register("institution_name")} />}
        <Field label="Full name" autoComplete="name" error={errors.full_name?.message} {...register("full_name")} />
        <Field label="Email" type="email" autoComplete="email" error={errors.email?.message} {...register("email")} />
        <Field label="Phone (optional)" type="tel" autoComplete="tel" error={errors.phone?.message} {...register("phone")} />
        <Field label="Password" type="password" autoComplete="new-password" hint="At least 8 characters, with letters and numbers" error={errors.password?.message} {...register("password")} />
        <Button type="submit" className="w-full" disabled={isSubmitting}>{isSubmitting ? "Creating account..." : "Create account"}</Button>
        <button type="button" onClick={() => setRole(null)} className="w-full text-sm text-steel underline">Change account type</button>
      </form>
    </AuthLayout>
  );
}
