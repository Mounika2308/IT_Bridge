import { useState } from "react";
import { Link } from "react-router-dom";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import AppLayout from "../layouts/AppLayout.jsx";
import Button from "../components/ui/Button.jsx";
import EmptyState from "../components/ui/EmptyState.jsx";
import Pagination from "../components/ui/Pagination.jsx";
import { ago, emptyText, notificationTarget, refreshNotifications } from "../utils/notifications.js";
import { listNotifications, markAllRead, markRead } from "../services/notificationService.js";
import { errorMessage } from "../services/api.js";

export default function Notifications() {
  const qc = useQueryClient();
  const [page, setPage] = useState(1);
  const [unreadOnly, setUnreadOnly] = useState(false);
  const q = useQuery({ queryKey: ["notifications", page, unreadOnly], queryFn: () => listNotifications(page, unreadOnly) });
  const refresh = () => refreshNotifications(qc);
  const read = useMutation({ mutationFn: markRead, onSuccess: refresh });
  const readAll = useMutation({ mutationFn: markAllRead, onSuccess: refresh });

  return (
    <AppLayout>
      <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
        <h1 className="text-3xl font-extrabold">Notifications</h1>
        <div className="flex flex-wrap items-center gap-3">
          <Link to="/notifications/settings" className="text-sm font-semibold text-span-dark">Settings</Link>
          <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={unreadOnly} onChange={(e) => { setUnreadOnly(e.target.checked); setPage(1); }} /> Unread only</label>
          <Button variant="secondary" className="!py-2" disabled={readAll.isPending || q.data?.items.every((n) => n.is_read)} onClick={() => readAll.mutate()}>Mark all read</Button>
        </div>
      </div>
      {q.isLoading && <p role="status" className="text-steel">Loading...</p>}
      {q.isError && <p role="alert" className="text-danger">{errorMessage(q.error)}</p>}
      {q.data?.items.length === 0 && <EmptyState title="No notifications" text={emptyText(unreadOnly)} />}
      <ul className="space-y-2">
        {q.data?.items.map((n) => (
          <li key={n.id} className={`rounded-card p-4 shadow-card ${n.is_read ? "bg-white" : "bg-span-soft"}`}>
            <div className="flex items-start justify-between gap-3">
              <div>
                <p className="font-semibold">{notificationTarget(n) ? <Link to={notificationTarget(n)} onClick={() => !n.is_read && read.mutate(n.id)} className="hover:text-span-dark">{n.title}</Link> : n.title}</p>
                {n.body && <p className="text-sm text-steel">{n.body}</p>}
                <p className="mt-1 text-xs text-steel">{ago(n.created_at)}</p>
              </div>
              {!n.is_read && <button className="text-xs font-semibold text-span-dark" onClick={() => read.mutate(n.id)}>Mark read</button>}
            </div>
          </li>
        ))}
      </ul>
      {q.data && <Pagination page={page} pageSize={q.data.page_size} total={q.data.total} onChange={setPage} />}
    </AppLayout>
  );
}
