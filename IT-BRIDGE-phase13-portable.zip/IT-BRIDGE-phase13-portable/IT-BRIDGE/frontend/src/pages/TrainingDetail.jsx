import { useState } from "react";
import { useParams } from "react-router-dom";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import AppLayout from "../layouts/AppLayout.jsx";
import Button from "../components/ui/Button.jsx";
import Field from "../components/ui/Field.jsx";
import ProgressBar from "../components/ui/ProgressBar.jsx";
import StatusBadge from "../components/StatusBadge.jsx";
import ContactBox from "../components/ContactBox.jsx";
import SessionCard from "../components/SessionCard.jsx";
import EmptyState from "../components/ui/EmptyState.jsx";
import ReviewSection from "../components/ReviewSection.jsx";
import PaymentSection, { PAYMENT_QUERY_KEYS } from "../components/PaymentSection.jsx";
import { money } from "../components/RequirementCard.jsx";
import { fieldErrors, plannedSessionsSchema, sessionSchema } from "../schemas/training.js";
import { cancelTraining, completeTraining, createSession, getTraining, updatePlannedSessions, updateTrainingDates, updateTrainingDetails } from "../services/trainingService.js";
import { errorMessage } from "../services/api.js";

const blank = { title: "", session_date: "", start_time: "10:00", end_time: "12:00" };

export default function TrainingDetail() {
  const { id } = useParams();
  const qc = useQueryClient();
  const [form, setForm] = useState(blank);
  const [dates, setDates] = useState(null);
  const [link, setLink] = useState(null);
  const [errors, setErrors] = useState({});
  const [plan, setPlan] = useState(null);
  const [planError, setPlanError] = useState("");
  const q = useQuery({ queryKey: ["training", id], queryFn: () => getTraining(id), retry: false });
  const refresh = () => { qc.invalidateQueries({ queryKey: ["training"] }); qc.invalidateQueries({ queryKey: ["trainings"] }); for (const key of PAYMENT_QUERY_KEYS) qc.invalidateQueries({ queryKey: [key] }); };
  const add = useMutation({ mutationFn: () => createSession(id, form), onSuccess: () => { setForm(blank); refresh(); } });
  const complete = useMutation({ mutationFn: () => completeTraining(id), onSuccess: refresh });
  const cancel = useMutation({ mutationFn: (reason) => cancelTraining(id, reason || null), onSuccess: refresh });
  const reschedule = useMutation({ mutationFn: () => updateTrainingDates(id, dates), onSuccess: () => { setDates(null); refresh(); } });

  const savePlan = useMutation({ mutationFn: () => updatePlannedSessions(id, Number(plan)), onSuccess: () => { setPlan(null); refresh(); } });
  const saveLink = useMutation({ mutationFn: () => updateTrainingDetails(id, { meeting_link: link?.trim() ? link.trim() : null }), onSuccess: () => { setLink(null); refresh(); } });

  if (q.isLoading) return <AppLayout><p role="status" className="text-steel">Loading training...</p></AppLayout>;
  if (q.isError) {
    const missing = q.error.response?.status === 404;
    return (
      <AppLayout>
        <p role="alert" className="text-danger">{missing ? "Training not found, or you do not have access to it." : errorMessage(q.error)}</p>
        {!missing && <Button variant="secondary" className="mt-3" onClick={() => q.refetch()}>Try again</Button>}
      </AppLayout>
    );
  }
  const t = q.data;
  const active = t.status === "ACTIVE";
  const institution = t.viewer_role === "INSTITUTION";
  const error = add.error || complete.error || cancel.error || reschedule.error || saveLink.error || savePlan.error;

  const submitSession = () => {
    const e = fieldErrors(sessionSchema(t), form);
    setErrors(e);
    if (!Object.keys(e).length) add.mutate();
  };
  const submitPlan = () => {
    const e = fieldErrors(plannedSessionsSchema(t.progress.scheduled), { planned_sessions: plan });
    setPlanError(e.planned_sessions || "");
    if (!e.planned_sessions) savePlan.mutate();
  };

  return (
    <AppLayout>
      <div className="max-w-3xl space-y-6">
        <section className="rounded-card bg-white p-6 shadow-card">
          <div className="flex items-start justify-between gap-3">
            <div>
              <h1 className="text-2xl font-extrabold">{t.title}</h1>
              <p className="text-sm text-steel">{t.institution_name} with {t.trainer_name}</p>
            </div>
            <StatusBadge status={t.phase} />
          </div>
          <dl className="mt-4 grid grid-cols-2 gap-4 text-sm sm:grid-cols-3">
            <div><dt className="text-xs text-steel">Technology</dt><dd className="font-semibold">{t.technology}</dd></div>
            <div><dt className="text-xs text-steel">Mode</dt><dd className="font-semibold">{{ ONLINE: "Online", OFFLINE: "Offline", HYBRID: "Hybrid" }[t.mode]}</dd></div>
            <div><dt className="text-xs text-steel">Location</dt><dd className="font-semibold">{t.location}</dd></div>
            <div><dt className="text-xs text-steel">Dates</dt><dd className="font-semibold">{t.start_date} to {t.end_date}</dd></div>
            <div><dt className="text-xs text-steel">Agreed fee</dt><dd className="font-semibold">{money(t.agreed_fee)}</dd></div>
            <div><dt className="text-xs text-steel">Students</dt><dd className="font-semibold">{t.student_count}</dd></div>
          </dl>
          <p className="mt-3 text-sm">Planned sessions: <strong>{t.planned_sessions}</strong> ({t.progress.scheduled} scheduled)
            {institution && active && <button className="ml-2 text-span-dark underline" onClick={() => { setPlanError(""); setPlan(plan === null ? String(t.planned_sessions) : null); }}>Change</button>}</p>
          {plan !== null && (
            <div className="mt-2 flex items-end gap-2">
              <div className="w-40"><Field label="Planned sessions" type="number" min={Math.max(1, t.progress.scheduled)} value={plan} error={planError} onChange={(e) => setPlan(e.target.value)} /></div>
              <Button className="!py-3" disabled={savePlan.isPending} onClick={submitPlan}>Save</Button>
            </div>
          )}
          {t.description && <p className="mt-4 whitespace-pre-line text-sm">{t.description}</p>}
          {t.terms && <p className="mt-3 text-sm"><strong>Agreed terms:</strong> {t.terms}</p>}
          {t.mode !== "OFFLINE" && (
            <div className="mt-3 text-sm">
              {t.meeting_link
                ? <p><strong>Meeting link:</strong> <a href={t.meeting_link} target="_blank" rel="noopener noreferrer" className="text-span-dark underline">{t.meeting_link}</a></p>
                : <p className="text-steel">No meeting link added yet.</p>}
              {active && (
                <div className="mt-2 flex items-end gap-2">
                  <div className="flex-1"><Field label="Meeting link (must start with https://)" value={link ?? t.meeting_link ?? ""} onChange={(e) => setLink(e.target.value)} /></div>
                  <Button className="!py-3" disabled={saveLink.isPending || link === null} onClick={() => saveLink.mutate()}>Save link</Button>
                </div>
              )}
            </div>
          )}
          {t.phase === "ENDED" && <p role="status" className="mt-3 rounded-ctl bg-signal-soft p-3 text-sm">The end date has passed. {institution ? "Complete the training to close it." : "The institution can now mark it as completed."}</p>}
          <div className="mt-4 grid gap-4 sm:grid-cols-2">
            <ProgressBar value={t.progress.percent} label={`${t.progress.completed} of ${t.planned_sessions} sessions completed`} />
            <ProgressBar value={t.attendance_percent ?? 0} label={t.attendance_percent == null ? "Attendance (none recorded)" : "Average attendance"} />
          </div>
          <ContactBox contact={t.contact} />
          {t.cancel_reason && <p className="mt-3 text-sm text-steel">Cancellation reason: {t.cancel_reason}</p>}
          {error && <p role="alert" className="mt-3 rounded-ctl bg-red-50 p-3 text-sm text-danger">{errorMessage(error)}</p>}
          {active && (
            <div className="mt-4 flex flex-wrap gap-2">
              {institution && <Button className="!py-2" disabled={complete.isPending || t.phase === "UPCOMING"} title={t.phase === "UPCOMING" ? "Available once the training starts" : undefined}
                onClick={() => window.confirm("Mark this training as completed? Sessions that have not happened will be cancelled.") && complete.mutate()}>Complete training</Button>}
              {institution && <Button variant="secondary" className="!py-2" onClick={() => setDates(dates ? null : { start_date: t.start_date, end_date: t.end_date })}>Change dates</Button>}
              <Button variant="secondary" className="!py-2" disabled={cancel.isPending}
                onClick={() => { const r = window.prompt("Why are you cancelling this training? (optional)"); if (r !== null) cancel.mutate(r); }}>Cancel training</Button>
            </div>
          )}
          {dates && (
            <div className="mt-3 grid gap-3 sm:grid-cols-2">
              <Field label="Start date" type="date" value={dates.start_date} onChange={(e) => setDates({ ...dates, start_date: e.target.value })} />
              <Field label="End date" type="date" value={dates.end_date} onChange={(e) => setDates({ ...dates, end_date: e.target.value })} />
              <Button className="!py-2 sm:col-span-2" disabled={reschedule.isPending} onClick={() => reschedule.mutate()}>Save dates</Button>
            </div>
          )}
        </section>

        {active && (
          <section className="rounded-card bg-white p-6 shadow-card">
            <h2 className="mb-3 text-lg font-bold">Schedule a session</h2>
            <div className="grid gap-3 sm:grid-cols-4">
              <div className="sm:col-span-4"><Field label="Title" placeholder="Day 1: Python basics" value={form.title} error={errors.title} onChange={(e) => setForm({ ...form, title: e.target.value })} /></div>
              <Field label="Date" type="date" min={t.start_date} max={t.end_date} value={form.session_date} error={errors.session_date} onChange={(e) => setForm({ ...form, session_date: e.target.value })} />
              <Field label="Start" type="time" value={form.start_time} error={errors.start_time} onChange={(e) => setForm({ ...form, start_time: e.target.value })} />
              <Field label="End" type="time" value={form.end_time} error={errors.end_time} onChange={(e) => setForm({ ...form, end_time: e.target.value })} />
              <Button className="mt-7" disabled={add.isPending} onClick={submitSession}>{add.isPending ? "Adding..." : "Add session"}</Button>
            </div>
          </section>
        )}

        <PaymentSection key={id} trainingId={id} />

        <ReviewSection trainingId={id} status={t.status} />

        <section>
          <h2 className="mb-3 text-lg font-bold">Sessions</h2>
          {t.sessions.length === 0
            ? <EmptyState title="No sessions scheduled" text={active ? "Add the first session above. Both sides can schedule and reschedule." : "No sessions were scheduled."} />
            : <ul className="space-y-3">{t.sessions.map((s) => <SessionCard key={s.id} s={s} role={t.viewer_role} training={t} />)}</ul>}
        </section>
      </div>
    </AppLayout>
  );
}
