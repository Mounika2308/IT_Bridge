import { useState } from "react";
import { Link } from "react-router-dom";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { ChevronLeft, ChevronRight } from "lucide-react";
import AppLayout from "../layouts/AppLayout.jsx";
import Button from "../components/ui/Button.jsx";
import Field from "../components/ui/Field.jsx";
import { useAuth } from "../context/AuthContext.jsx";
import { getCalendar } from "../services/trainingService.js";
import { addBusyPeriod, getBusyPeriods, removeBusyPeriod } from "../services/matchingService.js";
import { errorMessage } from "../services/api.js";

const iso = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
const COLORS = { SESSION: "bg-span", TRAINING: "bg-ink", INTERVIEW: "bg-danger", DEADLINE: "bg-signal", BUSY: "bg-steel" };
const PHASE = { UPCOMING: "Upcoming", IN_PROGRESS: "In progress", ENDED: "Ended", COMPLETED: "Completed", CANCELLED: "Cancelled" };
const MODE = { ONLINE: "Online", OFFLINE: "Offline", HYBRID: "Hybrid" };
const LABEL = { SESSION: "Session", TRAINING: "Training", INTERVIEW: "Interview", DEADLINE: "Deadline", BUSY: "Unavailable" };

function BusyManager() {
  const qc = useQueryClient();
  const [f, setF] = useState({ start_date: "", end_date: "", reason: "" });
  const list = useQuery({ queryKey: ["busy"], queryFn: getBusyPeriods });
  const done = () => { qc.invalidateQueries({ queryKey: ["busy"] }); qc.invalidateQueries({ queryKey: ["calendar"] }); };
  const add = useMutation({ mutationFn: () => addBusyPeriod({ ...f, reason: f.reason || null }), onSuccess: () => { setF({ start_date: "", end_date: "", reason: "" }); done(); } });
  const remove = useMutation({ mutationFn: removeBusyPeriod, onSuccess: done });
  return (
    <section className="mt-6 rounded-card bg-white p-5 shadow-card">
      <h2 className="text-lg font-bold">Dates you are unavailable</h2>
      <p className="mb-3 text-sm text-steel">Institutions and the matching engine use these dates. Your active trainings are blocked automatically.</p>
      {add.isError && <p role="alert" className="mb-2 text-sm text-danger">{errorMessage(add.error)}</p>}
      <div className="grid gap-3 sm:grid-cols-4">
        <Field label="From" type="date" value={f.start_date} onChange={(e) => setF({ ...f, start_date: e.target.value })} />
        <Field label="To" type="date" value={f.end_date} onChange={(e) => setF({ ...f, end_date: e.target.value })} />
        <Field label="Reason (optional)" value={f.reason} onChange={(e) => setF({ ...f, reason: e.target.value })} />
        <Button className="mt-7" disabled={!f.start_date || !f.end_date || add.isPending} onClick={() => add.mutate()}>Mark unavailable</Button>
      </div>
      <ul className="mt-4 divide-y divide-line text-sm">
        {list.data?.map((b) => (
          <li key={b.id} className="flex items-center justify-between py-2">
            <span>{b.start_date} to {b.end_date}{b.reason ? ` · ${b.reason}` : ""}</span>
            <button className="text-danger underline" onClick={() => remove.mutate(b.id)}>Remove</button>
          </li>
        ))}
        {list.data?.length === 0 && <li className="py-2 text-steel">No unavailable dates set.</li>}
      </ul>
    </section>
  );
}

export default function CalendarPage() {
  const { user } = useAuth();
  const [cursor, setCursor] = useState(() => { const n = new Date(); return new Date(n.getFullYear(), n.getMonth(), 1); });
  const [selected, setSelected] = useState(iso(new Date()));
  const first = cursor, last = new Date(cursor.getFullYear(), cursor.getMonth() + 1, 0);
  const q = useQuery({ queryKey: ["calendar", iso(first)], queryFn: () => getCalendar(iso(first), iso(last)) });

  const cells = [...Array(first.getDay()).fill(null), ...Array.from({ length: last.getDate() }, (_, i) => iso(new Date(cursor.getFullYear(), cursor.getMonth(), i + 1)))];
  const onDay = (day) => (q.data || []).filter((e) => e.date <= day && e.end_date >= day);
  const month = cursor.toLocaleString("en", { month: "long", year: "numeric" });
  const shift = (n) => setCursor(new Date(cursor.getFullYear(), cursor.getMonth() + n, 1));

  return (
    <AppLayout>
      <div className="mb-4 flex items-center justify-between">
        <h1 className="text-3xl font-extrabold">Calendar</h1>
        <div className="flex items-center gap-2">
          <Button variant="secondary" className="!px-3 !py-2" aria-label="Previous month" onClick={() => shift(-1)}><ChevronLeft size={16} /></Button>
          <span className="w-36 text-center text-sm font-semibold">{month}</span>
          <Button variant="secondary" className="!px-3 !py-2" aria-label="Next month" onClick={() => shift(1)}><ChevronRight size={16} /></Button>
        </div>
      </div>
      {q.isError && <p role="alert" className="mb-3 text-danger">{errorMessage(q.error)}</p>}
      <div className="rounded-card bg-white p-3 shadow-card" role="grid" aria-label={month}>
        <div className="grid grid-cols-7 text-center text-xs font-semibold text-steel">{["S", "M", "T", "W", "T", "F", "S"].map((d, i) => <div key={i} className="py-1">{d}</div>)}</div>
        <div className="grid grid-cols-7 gap-1">
          {cells.map((day, i) => day ? (
            <button key={day} onClick={() => setSelected(day)} aria-label={day} aria-pressed={selected === day}
              className={`flex h-14 flex-col items-center rounded-ctl border p-1 text-sm sm:h-20 ${selected === day ? "border-span bg-span-soft" : "border-transparent hover:bg-paper"}`}>
              <span className="font-semibold">{Number(day.slice(8))}</span>
              <span className="mt-1 flex flex-wrap justify-center gap-0.5">
                {[...new Set(onDay(day).map((e) => e.type))].map((tp) => <i key={tp} className={`h-1.5 w-1.5 rounded-full ${COLORS[tp]}`} />)}
              </span>
            </button>
          ) : <div key={`b${i}`} />)}
        </div>
        <ul className="mt-3 flex flex-wrap gap-3 border-t border-line pt-3 text-xs text-steel">
          {Object.entries(LABEL).filter(([k]) => user.role === "TRAINER" || k !== "BUSY").map(([k, l]) => <li key={k} className="flex items-center gap-1"><i className={`h-2 w-2 rounded-full ${COLORS[k]}`} />{l}</li>)}
        </ul>
      </div>

      <section className="mt-6 rounded-card bg-white p-5 shadow-card">
        <h2 className="mb-3 text-lg font-bold">{selected}</h2>
        {q.isLoading && <p role="status" className="text-sm text-steel">Loading...</p>}
        {!q.isLoading && onDay(selected).length === 0 && <p className="text-sm text-steel">Nothing scheduled for this day.</p>}
        <ul className="space-y-3">
          {onDay(selected).map((e, i) => (
            <li key={i} className="flex items-start gap-3 text-sm">
              <i className={`mt-1.5 h-2.5 w-2.5 shrink-0 rounded-full ${COLORS[e.type]}`} />
              <div>
                <p className="font-semibold">{e.link ? <Link to={e.link} className="hover:text-span-dark">{e.title}</Link> : e.title}</p>
                <p className="text-steel">{LABEL[e.type]}{e.start_time ? ` · ${e.start_time}${e.end_time ? ` to ${e.end_time}` : ""}` : ""}{e.subtitle ? ` · ${e.subtitle}` : ""}</p>
                {(e.phase || e.mode) && <p className="text-xs text-steel">{[e.phase && PHASE[e.phase], e.type === "SESSION" && e.status && `Session ${e.status.toLowerCase()}`, e.mode && MODE[e.mode], e.location].filter(Boolean).join(" · ")}</p>}
                {e.meeting_link && <p className="text-xs"><a href={e.meeting_link} target="_blank" rel="noopener noreferrer" className="text-span-dark underline">Join online</a></p>}
              </div>
            </li>
          ))}
        </ul>
      </section>
      {user.role === "TRAINER" && <BusyManager />}
    </AppLayout>
  );
}
