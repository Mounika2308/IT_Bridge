import { renderToStaticMarkup } from "react-dom/server";
import { MemoryRouter } from "react-router-dom";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { describe, expect, it, vi } from "vitest";
// useAuth() is null without an AuthProvider, so pages that call it need this mock under real vitest. The role can be switched per test.
vi.mock("../context/AuthContext.jsx", () => ({ useAuth: () => ({ user: { role: globalThis.__role || "TRAINER", full_name: "Test User" } }) }));
vi.mock("../layouts/AppLayout.jsx", () => ({ default: ({ children }) => children }));

import Notifications from "./Notifications.jsx";
import NotificationSettings, { emailNote } from "./NotificationSettings.jsx";

const T3 = "/trainings/3", T4 = "/trainings/4";
const n = (over = {}) => ({ id: 1, title: "Training cancelled", body: "Python workshop", link: T3, is_read: false, created_at: new Date().toISOString(), ...over });
const render = (Page, key, data) => {
  const qc = new QueryClient(); if (data !== undefined) qc.setQueryData(key, data);
  return renderToStaticMarkup(<QueryClientProvider client={qc}><MemoryRouter><Page /></MemoryRouter></QueryClientProvider>);
};
const page = (items) => render(Notifications, ["notifications", 1, false], { items, total: items.length, page: 1, page_size: 20 });

describe("Notifications page", () => {
  it("lists notifications with a deep link, a Mark read button for unread ones and a settings link", () => {
    const html = page([n(), n({ id: 2, is_read: true, title: "Training completed", link: T4 })]);
    expect(html).toContain(`href="${T3}"`);
    expect(html).toContain(`href="${T4}"`);
    expect(html.match(/Mark read/g)).toHaveLength(1);
    expect(html).toContain('href="/notifications/settings"');
  });
  it("does not render a link for a notification without one, or with an external one", () => {
    const html = page([n({ link: null }), n({ id: 2, link: "https://evil.example" })]);
    expect(html).not.toContain("<a href=\"https://evil.example\"");
    expect(html).not.toContain(`href="${T3}"`);
  });
  it("disables Mark all read when everything is already read", () => {
    const allRead = page([n({ is_read: true })]);
    const button = (h) => h.match(/<button[^>]*>Mark all read<\/button>/)?.[0] ?? "";
    expect(/\sdisabled(=""|\s|>)/.test(button(allRead))).toBe(true);
    expect(/\sdisabled(=""|\s|>)/.test(button(page([n()])))).toBe(false);
  });
  it("shows the loading state, and an empty state that mentions interviews", () => {
    expect(render(Notifications, ["x"])).toContain("Loading...");
    expect(page([])).toContain("No notifications");
    expect(page([])).toContain("interviews");
  });
});

describe("Notification settings", () => {
  const settings = (prefs) => render(NotificationSettings, ["notif-prefs"], prefs);
  it("shows in-app and email switches reflecting the saved values", () => {
    const html = settings({ in_app: true, email: false, email_verified: true });
    expect(html).toContain("In-app notifications");
    expect(html).toContain("Email notifications");
    expect(html.match(/role="switch"/g)).toHaveLength(2);
    expect(html.match(/checked=""/g)).toHaveLength(1);
  });
  it("offers no SMS or WhatsApp control yet", () => {
    const html = settings({ in_app: true, email: true, email_verified: true });
    expect(html).not.toMatch(/sms|whatsapp/i);
  });
  it("explains why no email is sent when the address is not verified, or when email is off", () => {
    expect(emailNote({ email: true, email_verified: false })).toContain("not verified");
    expect(emailNote({ email: false, email_verified: true })).toContain("switched off");
    expect(emailNote({ email: true, email_verified: true })).toContain("verified address");
  });
  it("says that email delivery is a development channel", () => {
    expect(settings({ in_app: true, email: true, email_verified: true })).toContain("development console channel");
  });
  it("shows a loading state first", () => {
    expect(render(NotificationSettings, ["nothing"])).toContain("Loading...");
  });
});
