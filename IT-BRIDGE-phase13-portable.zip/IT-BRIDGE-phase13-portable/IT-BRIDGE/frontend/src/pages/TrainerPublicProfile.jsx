import { useState } from "react";
import { useParams } from "react-router-dom";
import { useQuery, keepPreviousData } from "@tanstack/react-query";
import { RatingSummary, ReviewList } from "../components/ReviewSection.jsx";
import { trainerReviews } from "../services/reviewService.js";
import { BadgeCheck } from "lucide-react";
import AppLayout from "../layouts/AppLayout.jsx";
import Badge from "../components/ui/Badge.jsx";
import { money } from "../components/RequirementCard.jsx";
import { getTrainer } from "../services/matchingService.js";
import { errorMessage } from "../services/api.js";

const List = ({ title, items }) => items?.length ? (
  <section className="mt-5"><h2 className="mb-1 text-sm font-bold">{title}</h2><p className="text-sm text-steel">{items.join(", ")}</p></section>
) : null;

export default function TrainerPublicProfile() {
  const { id } = useParams();
  const [page, setPage] = useState(1);
  const q = useQuery({ queryKey: ["trainer", id], queryFn: () => getTrainer(id), retry: false });
  const reviews = useQuery({ queryKey: ["trainer-reviews", id, page], queryFn: () => trainerReviews(id, page), enabled: q.isSuccess, placeholderData: keepPreviousData });
  if (q.isLoading) return <AppLayout><p role="status" className="text-steel">Loading...</p></AppLayout>;
  if (q.isError) return <AppLayout><p role="alert" className="text-danger">{q.error.response?.status === 404 ? "This trainer is not available." : errorMessage(q.error)}</p></AppLayout>;
  const t = q.data;
  return (
    <AppLayout>
      <div className="max-w-2xl rounded-card bg-white p-6 shadow-card">
        <h1 className="flex items-center gap-2 text-2xl font-extrabold">{t.full_name}
          {t.verified && <Badge tone="ok"><BadgeCheck size={13} className="mr-1 inline" />Verified</Badge>}</h1>
        <p className="text-steel">{t.headline}</p>
        <p className="mt-2 flex flex-wrap items-center gap-2 text-sm">
          <RatingSummary rating={t.rating} count={t.review_count} />
          <span className="text-steel">· {t.completed_trainings} completed {t.completed_trainings === 1 ? "training" : "trainings"}</span>
        </p>
        <p className="mt-4 whitespace-pre-line text-sm">{t.about}</p>
        <div className="mt-4 flex flex-wrap gap-2">{t.skills.map((s) => <Badge key={s.id}>{s.name}</Badge>)}</div>
        <dl className="mt-5 grid grid-cols-2 gap-4 text-sm">
          <div><dt className="text-xs text-steel">Experience</dt><dd className="font-semibold">{t.experience_years ?? "-"} years</dd></div>
          <div><dt className="text-xs text-steel">Location</dt><dd className="font-semibold">{t.location || "-"}</dd></div>
          <div><dt className="text-xs text-steel">Training mode</dt><dd className="font-semibold">{t.training_mode?.toLowerCase() || "-"}</dd></div>
          <div><dt className="text-xs text-steel">Expected fee</dt><dd className="font-semibold">{t.expected_fee != null ? `${money(t.expected_fee)} per day` : "-"}</dd></div>
        </dl>
        <List title="Languages" items={t.languages} /><List title="Education" items={t.education} /><List title="Certifications" items={t.certifications} />
        <section className="mt-6" aria-label="Reviews"><h2 className="mb-2 text-sm font-bold">Reviews</h2>
          <ReviewList q={reviews} page={page} onPage={setPage} empty="This trainer has no reviews yet." /></section>
        <p className="mt-6 text-xs text-steel">Contact details stay private until you hire this trainer.</p>
      </div>
    </AppLayout>
  );
}
