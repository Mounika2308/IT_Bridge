import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useQuery } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import Field from "../components/ui/Field.jsx";
import TextArea from "../components/ui/TextArea.jsx";
import SelectField from "../components/ui/SelectField.jsx";
import Button from "../components/ui/Button.jsx";
import Logo from "../components/Logo.jsx";
import { getInstitutionProfile, saveInstitutionProfile } from "../services/profileService.js";
import { institutionSchema } from "../schemas/profile.js";
import { errorMessage } from "../services/api.js";

export default function InstitutionProfileSetup() {
  const nav = useNavigate();
  const [serverError, setServerError] = useState("");
  const profile = useQuery({ queryKey: ["institution-profile"], queryFn: getInstitutionProfile });
  const { register, handleSubmit, reset, formState: { errors, isSubmitting } } = useForm({ resolver: zodResolver(institutionSchema) });

  useEffect(() => {
    const p = profile.data;
    if (p) reset({ institution_name: p.institution_name, institution_type: p.institution_type ?? "", location: p.location ?? "", about: p.about ?? "", website: p.website ?? "" });
  }, [profile.data, reset]);

  const onSubmit = async (values) => {
    setServerError("");
    try {
      await saveInstitutionProfile({ ...values, website: values.website || null });
      nav("/institution", { replace: true });
    } catch (e) { setServerError(errorMessage(e)); }
  };

  if (profile.isLoading) return <p className="p-10 text-center text-steel" role="status">Loading your profile...</p>;
  if (profile.isError) return <p className="p-10 text-center text-danger" role="alert">{errorMessage(profile.error)}</p>;

  return (
    <main className="mx-auto max-w-xl px-5 py-8">
      <div className="mb-6"><Logo /></div>
      <h1 className="text-3xl font-extrabold">Institution profile</h1>
      <p className="mb-6 mt-1 text-steel">Trainers see this before they apply to your requirements.</p>
      <form onSubmit={handleSubmit(onSubmit)} noValidate className="space-y-4 rounded-card bg-white p-6 shadow-card">
        {serverError && <p role="alert" className="rounded-ctl bg-red-50 p-3 text-sm text-danger">{serverError}</p>}
        <Field label="Institution name" error={errors.institution_name?.message} {...register("institution_name")} />
        <SelectField label="Institution type" error={errors.institution_type?.message} {...register("institution_type")}
          options={[["ENGINEERING_COLLEGE", "Engineering college"], ["DEGREE_COLLEGE", "Degree college"], ["TRAINING_INSTITUTE", "Training institute"], ["SCHOOL", "School"], ["OTHER", "Other"]]} />
        <Field label="City" error={errors.location?.message} {...register("location")} />
        <Field label="Website (optional)" placeholder="https://" error={errors.website?.message} {...register("website")} />
        <TextArea label="About (optional)" error={errors.about?.message} {...register("about")} />
        <Button type="submit" className="w-full" disabled={isSubmitting}>{isSubmitting ? "Saving..." : "Save profile"}</Button>
      </form>
    </main>
  );
}
