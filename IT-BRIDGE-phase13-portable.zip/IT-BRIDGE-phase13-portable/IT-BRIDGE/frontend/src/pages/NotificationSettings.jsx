import { Link } from "react-router-dom";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import AppLayout from "../layouts/AppLayout.jsx";
import { getPreferences, savePreferences } from "../services/notificationService.js";
import { errorMessage } from "../services/api.js";

export const CHANNEL_ROWS = [
  { key: "in_app", label: "In-app notifications", help: "The bell and the notifications page." },
  { key: "email", label: "Email notifications", help: "Sent only for important events, and only to a verified email address." },
];

export const emailNote = (prefs) => {
  if (!prefs.email) return "Email is switched off. You will only see notifications in the app.";
  if (!prefs.email_verified) return "Your email address is not verified yet, so no emails are sent.";
  return "Emails are sent to your verified address.";
};

export default function NotificationSettings() {
  const qc = useQueryClient();
  const q = useQuery({ queryKey: ["notif-prefs"], queryFn: getPreferences });
  const save = useMutation({ mutationFn: savePreferences, onSuccess: (data) => qc.setQueryData(["notif-prefs"], data) });
  const prefs = q.data;

  return (
    <AppLayout>
      <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
        <h1 className="text-3xl font-extrabold">Notification settings</h1>
        <Link to="/notifications" className="text-sm font-semibold text-span-dark">Back to notifications</Link>
      </div>
      {q.isLoading && <p role="status" className="text-steel">Loading...</p>}
      {q.isError && <p role="alert" className="text-danger">{errorMessage(q.error)}</p>}
      {save.isError && <p role="alert" className="mb-3 text-danger">{errorMessage(save.error)}</p>}
      {prefs && (
        <section aria-label="Channels" className="max-w-xl space-y-3">
          {CHANNEL_ROWS.map(({ key, label, help }) => (
            <label key={key} className="flex items-start justify-between gap-4 rounded-card bg-white p-4 shadow-card">
              <span><span className="block font-semibold">{label}</span><span className="block text-sm text-steel">{help}</span></span>
              <input type="checkbox" role="switch" className="mt-1 h-5 w-5" checked={!!prefs[key]} disabled={save.isPending}
                onChange={(e) => save.mutate({ [key]: e.target.checked })} />
            </label>
          ))}
          <p className="text-sm text-steel">{emailNote(prefs)}</p>
          <p className="text-xs text-steel">Email delivery runs through a development console channel for now, so no real emails leave the system yet.</p>
        </section>
      )}
    </AppLayout>
  );
}
