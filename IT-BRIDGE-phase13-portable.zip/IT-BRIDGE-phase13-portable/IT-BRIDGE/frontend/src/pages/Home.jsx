import { Link } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "../context/AuthContext.jsx";
import AppLayout from "../layouts/AppLayout.jsx";
import Button from "../components/ui/Button.jsx";
import ProgressBar from "../components/ui/ProgressBar.jsx";
import Recommended from "../components/Recommended.jsx";
import TrainingSummary from "../components/TrainingSummary.jsx";
import { ReviewSummaryCard } from "../components/ReviewSection.jsx";
import { PaymentDashboardCard } from "../components/PaymentSummaryCard.jsx";
import { getTrainerProfile } from "../services/profileService.js";
import { myReviewSummary } from "../services/reviewService.js";

export default function Home({ title }) {
  const { user } = useAuth();
  const isTrainer = user.role === "TRAINER";
  const profile = useQuery({ queryKey: ["trainer-profile"], queryFn: getTrainerProfile, enabled: isTrainer });
  const reviews = useQuery({ queryKey: ["reviews-me"], queryFn: myReviewSummary, enabled: user.role !== "ADMIN" });

  return (
    <AppLayout>
      <h1 className="text-3xl font-extrabold">{title}</h1>
      <p className="mt-2 text-steel">Signed in as {user.full_name}.</p>
      {user.role !== "ADMIN" && <TrainingSummary />}
      {user.role !== "ADMIN" && <PaymentDashboardCard role={user.role} />}
      {user.role !== "ADMIN" && <ReviewSummaryCard q={reviews} />}
      {isTrainer && profile.data && profile.data.completion < 100 && (
        <section className="mt-6 rounded-card bg-white p-5 shadow-card">
          <ProgressBar value={profile.data.completion} />
          <p className="mb-3 mt-3 text-sm text-steel">A complete profile gets you seen by more institutions.</p>
          <Button as={Link} to="/trainer/profile">Complete your profile</Button>
        </section>
      )}
      {isTrainer && <Recommended />}
      {isTrainer && <Button as={Link} to="/trainer/opportunities" className="mt-6">Browse all opportunities</Button>}
      {user.role === "INSTITUTION" && (
        <div className="mt-6 flex flex-wrap gap-3">
          <Button as={Link} to="/institution/requirements/new">Post a requirement</Button>
          <Button as={Link} to="/institution/requirements" variant="secondary">View requirements</Button>
          <Button as={Link} to="/institution/profile" variant="secondary">Edit profile</Button>
        </div>
      )}
    </AppLayout>
  );
}
