import { renderToStaticMarkup } from "react-dom/server";
import { MemoryRouter } from "react-router-dom";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { describe, expect, it, vi } from "vitest";

vi.mock("../context/AuthContext.jsx", () => ({ useAuth: () => ({ user: { role: "TRAINER", full_name: "Test Trainer" } }) }));
vi.mock("../layouts/AppLayout.jsx", () => ({ default: ({ children }) => children }));

import Trainings from "./Trainings.jsx";

const render = () => renderToStaticMarkup(
  <QueryClientProvider client={new QueryClient()}><MemoryRouter><Trainings /></MemoryRouter></QueryClientProvider>,
);

const item = (over = {}) => ({ id: 1, title: "Python workshop", technology: "Python", institution_name: "Sunrise College", trainer_name: "Asha", phase: "IN_PROGRESS",
  start_date: "2030-03-01", end_date: "2030-03-10", location: "Pune", mode: "OFFLINE", agreed_fee: 40000, student_count: 60, planned_sessions: 3,
  progress: { scheduled: 2, completed: 1, percent: 33 }, ...over });

const renderWithData = (items) => {
  const qc = new QueryClient();
  qc.setQueryData(["trainings", "", 1], { items, total: items.length, page: 1, page_size: 12 });   // what the API would have returned
  return renderToStaticMarkup(<QueryClientProvider client={qc}><MemoryRouter><Trainings /></MemoryRouter></QueryClientProvider>);
};

describe("Trainings page", () => {
  it("shows a progress bar on every training card (regression: it was lost in the Phase 9 rewrite)", () => {
    const html = renderWithData([item(), item({ id: 2, title: "React workshop", progress: { scheduled: 0, completed: 0, percent: 0 } })]);
    expect(html.match(/role="progressbar"/g)).toHaveLength(2);
    expect(html).toContain("1 of 3 sessions done");
    expect(html).toContain("0 of 3 sessions done");
    expect(html).toContain('aria-valuenow="33"');
  });

  it("shows the training phase, mode and location", () => {
    const html = renderWithData([item()]);
    expect(html).toContain("In progress");
    expect(html).toContain("Pune (Offline)");
  });

  it("shows the empty state when there are no trainings", () => {
    expect(renderWithData([])).toContain("No trainings yet");
  });

  it("renders the status filter tabs", () => {
    const html = render();
    for (const label of ["All", "Active", "Completed", "Cancelled"]) expect(html).toContain(label);
  });

  it("shows a loading state before the API answers, not a blank page or fake data", () => {
    const html = render();
    expect(html).toContain("Loading trainings...");
    expect(html).not.toContain("No trainings yet");
  });
});
