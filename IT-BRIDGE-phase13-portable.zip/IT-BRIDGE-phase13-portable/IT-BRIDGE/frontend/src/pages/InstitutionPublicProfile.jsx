import { useState } from "react";
import { useParams } from "react-router-dom";
import { useQuery, keepPreviousData } from "@tanstack/react-query";
import { BadgeCheck } from "lucide-react";
import AppLayout from "../layouts/AppLayout.jsx";
import Badge from "../components/ui/Badge.jsx";
import { RatingSummary, ReviewList } from "../components/ReviewSection.jsx";
import { institutionReviews } from "../services/reviewService.js";
import { errorMessage } from "../services/api.js";

/** What trainers see before accepting work: the institution's name, its rating and the reviews trainers have left. No contact details. */
export default function InstitutionPublicProfile() {
  const { id } = useParams();
  const [page, setPage] = useState(1);
  const q = useQuery({ queryKey: ["institution-reviews", id, page], queryFn: () => institutionReviews(id, page), retry: false, placeholderData: keepPreviousData });
  if (q.isLoading) return <AppLayout><p role="status" className="text-steel">Loading...</p></AppLayout>;
  if (q.isError) return <AppLayout><p role="alert" className="text-danger">{q.error.response?.status === 404 ? "This institution is not available." : errorMessage(q.error)}</p></AppLayout>;
  const d = q.data;
  return (
    <AppLayout>
      <div className="max-w-2xl rounded-card bg-white p-6 shadow-card">
        <h1 className="flex items-center gap-2 text-2xl font-extrabold">{d.institution_name}
          {d.verified && <Badge tone="ok"><BadgeCheck size={13} className="mr-1 inline" />Verified</Badge>}</h1>
        <p className="mt-2 flex flex-wrap items-center gap-2 text-sm"><RatingSummary rating={d.rating} count={d.review_count} completed={d.completed_trainings} /></p>
        <section className="mt-6" aria-label="Reviews"><h2 className="mb-2 text-sm font-bold">Reviews from trainers</h2>
          <ReviewList q={q} page={page} onPage={setPage} empty="No trainer has reviewed this institution yet." /></section>
      </div>
    </AppLayout>
  );
}
