import { useState } from "react";
import { Link } from "react-router-dom";
import { keepPreviousData, useQuery } from "@tanstack/react-query";
import AppLayout from "../layouts/AppLayout.jsx";
import Badge from "../components/ui/Badge.jsx";
import Button from "../components/ui/Button.jsx";
import EmptyState from "../components/ui/EmptyState.jsx";
import Pagination from "../components/ui/Pagination.jsx";
import SandboxBanner from "../components/SandboxBanner.jsx";
import { TrainerEarningsCard } from "../components/PaymentSummaryCard.jsx";
import { earningsSummary, myEarnings } from "../services/paymentService.js";
import { errorMessage } from "../services/api.js";
import { COMMISSION_NOTE, bpsToPercent, earningNote, earningStatus, formatPaise } from "../utils/payments.js";

const TABS = [["", "All"], ["PENDING", "Pending completion"], ["AVAILABLE", "Available"], ["PAID", "Paid out"], ["REFUNDED", "Refunded"]];

export function EarningRow({ e }) {
  const st = earningStatus(e.status);
  return (
    <li className="rounded-card bg-white p-4 shadow-card" data-testid="earning-row">
      <div className="flex flex-wrap items-start justify-between gap-2">
        <div>
          <p className="font-bold"><Link to={`/trainings/${e.training_id}`} className="hover:text-span-dark">{e.training_title || `Training ${e.training_id}`}</Link></p>
          <p className="text-xs text-steel">Received {String(e.created_at).slice(0, 10)}</p>
        </div>
        <div className="text-right"><p className="text-lg font-extrabold">{formatPaise(e.net_paise)}</p><Badge tone={st.tone}>{st.label}</Badge></div>
      </div>
      <dl className="mt-3 grid grid-cols-3 gap-2 text-sm">
        <div><dt className="text-xs text-steel">Paid by institution</dt><dd className="font-semibold">{formatPaise(e.gross_paise)}</dd></div>
        <div><dt className="text-xs text-steel">Commission ({bpsToPercent(e.commission_bps)})</dt><dd className="font-semibold">{formatPaise(e.commission_paise)}</dd></div>
        <div><dt className="text-xs text-steel">Net to you</dt><dd className="font-semibold">{formatPaise(e.net_paise)}</dd></div>
      </dl>
      {earningNote(e) && <p className="mt-2 text-xs text-steel">{earningNote(e)}</p>}
    </li>
  );
}

/** `q` is a react-query result of myEarnings. */
export function EarningsList({ q, page, onPage, filtered = false }) {
  if (q.isLoading) return <p role="status" className="text-steel">Loading earnings...</p>;
  if (q.isError) return (
    <div role="alert" className="text-danger"><p>{errorMessage(q.error)}</p><Button variant="secondary" className="mt-3" onClick={() => q.refetch()}>Try again</Button></div>
  );
  if (!q.data) return null;
  if (q.data.items.length === 0) {
    return <EmptyState title={filtered ? "No earnings with this status" : "No earnings yet"}
      text={filtered ? "Try another tab." : "When an institution pays for one of your trainings, your earning appears here."}
      action={!filtered && <Button as={Link} to="/trainer/trainings">View trainings</Button>} />;
  }
  return (
    <>
      <ul className="space-y-3">{q.data.items.map((e) => <EarningRow key={e.id} e={e} />)}</ul>
      <Pagination page={page} pageSize={q.data.page_size} total={q.data.total} onChange={onPage} />
    </>
  );
}

export default function TrainerEarnings() {
  const [status, setStatus] = useState("");
  const [page, setPage] = useState(1);
  const summary = useQuery({ queryKey: ["earnings-summary"], queryFn: earningsSummary, retry: false });
  const q = useQuery({ queryKey: ["earnings", status, page], queryFn: () => myEarnings(page, status), placeholderData: keepPreviousData });
  return (
    <AppLayout>
      <h1 className="mb-1 text-3xl font-extrabold">Earnings</h1>
      <p className="mb-4 text-sm text-steel">What you are owed for your trainings. Only you can see this. Payouts are recorded by an administrator; IT BRIDGE does not collect bank or UPI details.</p>
      <SandboxBanner show={!!summary.data?.sandbox} className="mb-4" />
      <TrainerEarningsCard q={summary} banner={false} />
      {summary.data?.commission_is_placeholder && <p className="mt-2 text-xs text-steel">{COMMISSION_NOTE}</p>}
      <div role="tablist" aria-label="Filter by status" className="mb-6 mt-6 flex gap-2 overflow-x-auto">
        {TABS.map(([value, label]) => (
          <button key={label} role="tab" aria-selected={status === value} onClick={() => { setStatus(value); setPage(1); }}
            className={`whitespace-nowrap rounded-full border px-4 py-2 text-sm font-semibold ${status === value ? "border-span bg-span-soft text-span-dark" : "border-line bg-white text-steel"}`}>{label}</button>
        ))}
      </div>
      <EarningsList q={q} page={page} onPage={setPage} filtered={status !== ""} />
    </AppLayout>
  );
}
