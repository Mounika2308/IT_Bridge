import { useState } from "react";
import useDebounced from "../hooks/useDebounced.js";
import { useQuery, keepPreviousData } from "@tanstack/react-query";
import { SlidersHorizontal } from "lucide-react";
import AppLayout from "../layouts/AppLayout.jsx";
import Field from "../components/ui/Field.jsx";
import SelectField from "../components/ui/SelectField.jsx";
import Button from "../components/ui/Button.jsx";
import EmptyState from "../components/ui/EmptyState.jsx";
import Pagination from "../components/ui/Pagination.jsx";
import RequirementCard from "../components/RequirementCard.jsx";
import { browseRequirements } from "../services/requirementService.js";
import { getSkills } from "../services/profileService.js";
import { errorMessage } from "../services/api.js";

const EMPTY = { q: "", skill_id: "", location: "", mode: "", max_experience: "", min_budget: "", start_after: "", max_duration: "" };

export default function Opportunities() {
  const [filters, setFilters] = useState(EMPTY);
  const [page, setPage] = useState(1);
  const [open, setOpen] = useState(false);
  const debounced = useDebounced(filters);
  const skills = useQuery({ queryKey: ["skills"], queryFn: getSkills });
  const q = useQuery({
    queryKey: ["opportunities", debounced, page],
    queryFn: () => browseRequirements({ ...debounced, page }),
    placeholderData: keepPreviousData,
  });
  const set = (k) => (ev) => { setFilters({ ...filters, [k]: ev.target.value }); setPage(1); };
  const active = Object.values(filters).filter(Boolean).length;

  return (
    <AppLayout>
      <h1 className="mb-5 text-3xl font-extrabold">Training opportunities</h1>
      <div className="mb-4 flex gap-2">
        <div className="flex-1"><Field label="Search" placeholder="Title or technology" value={filters.q} onChange={set("q")} /></div>
        <Button variant="secondary" className="mt-7 md:hidden" aria-expanded={open} onClick={() => setOpen(!open)}>
          <SlidersHorizontal size={16} /> Filters{active ? ` (${active})` : ""}
        </Button>
      </div>
      <section aria-label="Filters" className={`${open ? "grid" : "hidden"} mb-6 gap-4 rounded-card bg-white p-5 shadow-card sm:grid-cols-2 md:grid md:grid-cols-4`}>
        <SelectField label="Skill" value={filters.skill_id} onChange={set("skill_id")} options={(skills.data || []).map((s) => [s.id, s.name])} />
        <Field label="Location" value={filters.location} onChange={set("location")} />
        <SelectField label="Mode" value={filters.mode} onChange={set("mode")} options={[["ONLINE", "Online"], ["OFFLINE", "Offline"], ["HYBRID", "Hybrid"]]} />
        <Field label="Your experience (years)" type="number" min="0" value={filters.max_experience} onChange={set("max_experience")} />
        <Field label="Budget up to at least (₹)" type="number" min="0" value={filters.min_budget} onChange={set("min_budget")} />
        <Field label="Starts after" type="date" value={filters.start_after} onChange={set("start_after")} />
        <Field label="Max duration (days)" type="number" min="1" value={filters.max_duration} onChange={set("max_duration")} />
        <Button variant="secondary" className="mt-7" onClick={() => { setFilters(EMPTY); setPage(1); }}>Clear filters</Button>
      </section>

      {q.isLoading && <p role="status" className="text-steel">Loading opportunities...</p>}
      {q.isError && <p role="alert" className="text-danger">{errorMessage(q.error)}</p>}
      {q.data?.items.length === 0 && (
        <EmptyState title="No training opportunities found" text={active ? "Try removing a filter or searching a broader term." : "New requirements appear here as institutions post them."}
          action={active ? <Button variant="secondary" onClick={() => setFilters(EMPTY)}>Clear filters</Button> : null} />
      )}
      <div className="grid gap-4 md:grid-cols-2">
        {q.data?.items.map((r) => <RequirementCard key={r.id} r={r} to={`/requirements/${r.id}`} />)}
      </div>
      {q.data && <Pagination page={page} pageSize={q.data.page_size} total={q.data.total} onChange={setPage} />}
    </AppLayout>
  );
}
