import { useState } from "react";
import { useParams, Link } from "react-router-dom";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "../context/AuthContext.jsx";
import TextArea from "../components/ui/TextArea.jsx";
import Field from "../components/ui/Field.jsx";
import StatusBadge from "../components/StatusBadge.jsx";
import { applyTo, myApplications } from "../services/applicationService.js";
import AppLayout from "../layouts/AppLayout.jsx";
import Badge from "../components/ui/Badge.jsx";
import Button from "../components/ui/Button.jsx";
import { money } from "../components/RequirementCard.jsx";
import { getRequirement } from "../services/requirementService.js";
import { errorMessage } from "../services/api.js";
import { formatRating, reviewCountText } from "../utils/reviews.js";

const Row = ({ k, v }) => <div><dt className="text-xs text-steel">{k}</dt><dd className="font-semibold">{v}</dd></div>;

function ApplyBox({ reqId, open, status }) {
  const qc = useQueryClient();
  const [note, setNote] = useState("");
  const [fee, setFee] = useState("");
  const mine = useQuery({ queryKey: ["my-applications"], queryFn: myApplications });
  const apply = useMutation({
    mutationFn: () => applyTo(reqId, { cover_note: note || null, proposed_fee: fee === "" ? null : Number(fee) }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["my-applications"] }),
  });
  const existing = mine.data?.find((a) => a.requirement_id === Number(reqId) && a.status !== "WITHDRAWN");
  if (existing) return (
    <div className="mt-6 rounded-ctl bg-paper p-4 text-sm">You applied to this requirement. Status: <StatusBadge status={existing.status} />
      {" "}<Link to="/trainer/applications" className="font-semibold text-span-dark underline">View your applications</Link></div>
  );
  if (!open) return <p className="mt-6 text-sm text-steel">{status === "FILLED" ? "This requirement has been filled." : "This requirement is no longer accepting applications."}</p>;
  return (
    <div className="mt-6 space-y-3 border-t border-line pt-5">
      <h2 className="text-lg font-bold">Apply for this training</h2>
      {apply.isError && <p role="alert" className="rounded-ctl bg-red-50 p-3 text-sm text-danger">{errorMessage(apply.error)}</p>}
      <TextArea label="Cover note (optional)" rows={3} value={note} onChange={(e) => setNote(e.target.value)} />
      <Field label="Your proposed total fee in ₹ (optional)" type="number" min="0" value={fee} onChange={(e) => setFee(e.target.value)} />
      <Button disabled={apply.isPending} onClick={() => apply.mutate()}>{apply.isPending ? "Applying..." : "Apply now"}</Button>
    </div>
  );
}

export default function RequirementDetail() {
  const { id } = useParams();
  const { user } = useAuth();
  const q = useQuery({ queryKey: ["requirement", id], queryFn: () => getRequirement(id), retry: false });
  if (q.isLoading) return <AppLayout><p role="status" className="text-steel">Loading...</p></AppLayout>;
  if (q.isError) return (
    <AppLayout>
      <p role="alert" className="text-danger">{q.error.response?.status === 404 ? "This requirement is closed or does not exist." : errorMessage(q.error)}</p>
    </AppLayout>
  );
  const r = q.data;
  return (
    <AppLayout>
      <div className="max-w-2xl rounded-card bg-white p-6 shadow-card">
        <Badge tone={r.status === "OPEN" ? "ok" : "signal"}>{r.status.charAt(0) + r.status.slice(1).toLowerCase()}</Badge>
        <h1 className="mt-3 text-2xl font-extrabold">{r.title}</h1>
        <p className="text-steel">{r.institution_id ? <Link to={`/institutions/${r.institution_id}`} className="font-semibold text-span-dark">{r.institution_name}</Link> : r.institution_name}{r.institution_verified ? " (verified)" : ""}{r.institution_review_count > 0 ? ` · rated ${formatRating(r.institution_rating)} from ${reviewCountText(r.institution_review_count)}` : ""}</p>
        <p className="mt-4 whitespace-pre-line text-sm">{r.description}</p>
        <div className="mt-4 flex flex-wrap gap-2">{r.skills.map((s) => <Badge key={s.id}>{s.name}</Badge>)}</div>
        <dl className="mt-5 grid grid-cols-2 gap-4 text-sm">
          <Row k="Technology" v={r.technology} /><Row k="Budget" v={`${money(r.budget_min)} to ${money(r.budget_max)}`} />
          <Row k="Students" v={`${r.student_count} (${r.student_level.toLowerCase()})`} /><Row k="Duration" v={`${r.duration_days} days, ${r.sessions} sessions`} />
          <Row k="Location" v={`${r.location} (${r.mode.toLowerCase()})`} /><Row k="Dates" v={`${r.start_date} to ${r.end_date}`} />
          <Row k="Preferred experience" v={`${r.preferred_experience_years} years`} /><Row k="Apply by" v={r.application_deadline} />
        </dl>
        {r.additional_requirements && <p className="mt-4 text-sm"><strong>Additional:</strong> {r.additional_requirements}</p>}
        {user.role === "TRAINER" && <ApplyBox reqId={id} open={r.status === "OPEN"} status={r.status} />}
        {r.is_owner && <Button as={Link} to={`/institution/requirements/${r.id}/applications`} variant="secondary" className="mr-3 mt-5">View applications</Button>}
        {r.is_owner && r.status === "OPEN" && <Button as={Link} to={`/institution/requirements/${r.id}/edit`} className="mt-5">Edit requirement</Button>}
      </div>
    </AppLayout>
  );
}
