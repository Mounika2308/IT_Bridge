import { useState } from "react";
import { useSearchParams } from "react-router-dom";
import { useQuery, keepPreviousData } from "@tanstack/react-query";
import { SlidersHorizontal } from "lucide-react";
import AppLayout from "../layouts/AppLayout.jsx";
import Field from "../components/ui/Field.jsx";
import SelectField from "../components/ui/SelectField.jsx";
import Button from "../components/ui/Button.jsx";
import EmptyState from "../components/ui/EmptyState.jsx";
import Pagination from "../components/ui/Pagination.jsx";
import TrainerCard from "../components/TrainerCard.jsx";
import useDebounced from "../hooks/useDebounced.js";
import { searchTrainers } from "../services/matchingService.js";
import { getSkills } from "../services/profileService.js";
import { errorMessage } from "../services/api.js";
import { MIN_REVIEWS_FOR_FILTER } from "../utils/reviews.js";

const EMPTY = { min_rating: "", q: "", skill_id: "", location: "", mode: "", min_experience: "", max_fee: "", language: "",
  available_from: "", available_to: "", verified_only: false, has_certifications: false };

export default function TrainerSearch() {
  const [params] = useSearchParams();
  const [filters, setFilters] = useState({ ...EMPTY, q: params.get("q") || "" });
  const [page, setPage] = useState(1);
  const [open, setOpen] = useState(false);
  const debounced = useDebounced(filters);
  const skills = useQuery({ queryKey: ["skills"], queryFn: getSkills });
  const q = useQuery({ queryKey: ["trainer-search", debounced, page], queryFn: () => searchTrainers({ ...debounced, page }), placeholderData: keepPreviousData });
  const set = (k) => (ev) => { setFilters({ ...filters, [k]: ev.target.type === "checkbox" ? ev.target.checked : ev.target.value }); setPage(1); };
  const active = Object.values(filters).filter(Boolean).length;
  const datesIncomplete = !!filters.available_from !== !!filters.available_to;

  return (
    <AppLayout>
      <h1 className="mb-5 text-3xl font-extrabold">Find a trainer</h1>
      <div className="mb-4 flex gap-2">
        <div className="flex-1"><Field label="Search" placeholder="Name or headline" value={filters.q} onChange={set("q")} /></div>
        <Button variant="secondary" className="mt-7 md:hidden" aria-expanded={open} onClick={() => setOpen(!open)}>
          <SlidersHorizontal size={16} /> Filters{active ? ` (${active})` : ""}
        </Button>
      </div>
      <section aria-label="Filters" className={`${open ? "grid" : "hidden"} mb-6 gap-4 rounded-card bg-white p-5 shadow-card sm:grid-cols-2 md:grid md:grid-cols-4`}>
        <SelectField label="Skill" value={filters.skill_id} onChange={set("skill_id")} options={(skills.data || []).map((s) => [s.id, s.name])} />
        <Field label="Location" value={filters.location} onChange={set("location")} />
        <SelectField label="Training mode" value={filters.mode} onChange={set("mode")} options={[["ONLINE", "Online"], ["OFFLINE", "Offline"], ["HYBRID", "Hybrid"]]} />
        <Field label="Minimum experience (years)" type="number" min="0" value={filters.min_experience} onChange={set("min_experience")} />
        <Field label="Maximum fee per day (₹)" type="number" min="0" value={filters.max_fee} onChange={set("max_fee")} />
        <Field label="Language" value={filters.language} onChange={set("language")} />
        <SelectField label={`Minimum rating (${MIN_REVIEWS_FOR_FILTER}+ reviews)`} value={filters.min_rating} onChange={set("min_rating")} options={[["4.5", "4.5 and above"], ["4", "4 and above"], ["3", "3 and above"]]} />
        <Field label="Available from" type="date" value={filters.available_from} onChange={set("available_from")} />
        <Field label="Available to" type="date" value={filters.available_to} onChange={set("available_to")} hint={datesIncomplete ? "Set both dates to filter by availability" : undefined} />
        <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={filters.verified_only} onChange={set("verified_only")} /> Verified only</label>
        <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={filters.has_certifications} onChange={set("has_certifications")} /> Has certifications</label>
        <Button variant="secondary" onClick={() => { setFilters(EMPTY); setPage(1); }}>Clear filters</Button>
      </section>

      {q.isLoading && <p role="status" className="text-steel">Searching trainers...</p>}
      {q.isError && <p role="alert" className="text-danger">{errorMessage(q.error)}</p>}
      {q.data?.items.length === 0 && (
        <EmptyState title="No trainers found" text={active ? "Try removing a filter to see more trainers." : "Trainers appear here once they complete their profiles."} />
      )}
      <div className="grid gap-4 md:grid-cols-2">{q.data?.items.map((t) => <TrainerCard key={t.id} t={t} />)}</div>
      {q.data && <Pagination page={page} pageSize={q.data.page_size} total={q.data.total} onChange={setPage} />}
    </AppLayout>
  );
}
