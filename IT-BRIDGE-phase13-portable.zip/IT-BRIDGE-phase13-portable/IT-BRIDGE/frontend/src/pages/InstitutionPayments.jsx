import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { keepPreviousData, useQuery } from "@tanstack/react-query";
import AppLayout from "../layouts/AppLayout.jsx";
import Badge from "../components/ui/Badge.jsx";
import Button from "../components/ui/Button.jsx";
import EmptyState from "../components/ui/EmptyState.jsx";
import Pagination from "../components/ui/Pagination.jsx";
import SandboxBanner from "../components/SandboxBanner.jsx";
import { InstitutionPaymentCard } from "../components/PaymentSummaryCard.jsx";
import { myPayments, paymentsSummary } from "../services/paymentService.js";
import { errorMessage } from "../services/api.js";
import { formatPaise, listPollInterval, paymentStatus, refundText, REVIEW_NOTICE } from "../utils/payments.js";

const TABS = [["", "All"], ["SUCCEEDED", "Paid"], ["PENDING", "Awaiting payment"], ["PROCESSING", "Processing"], ["FAILED", "Failed"]];
const date = (iso) => (iso ? String(iso).slice(0, 10) : "");

export function PaymentRow({ p }) {
  const st = paymentStatus(p.status);
  return (
    <li className="rounded-card bg-white p-4 shadow-card" data-testid="payment-row">
      <div className="flex flex-wrap items-start justify-between gap-2">
        <div>
          <p className="font-bold"><Link to={`/trainings/${p.training_id}`} className="hover:text-span-dark">{p.training_title || `Training ${p.training_id}`}</Link></p>
          <p className="text-xs text-steel">Attempt {p.attempt_no} · started {date(p.created_at)}{p.paid_at ? ` · paid ${date(p.paid_at)}` : ""}</p>
        </div>
        <div className="text-right"><p className="text-lg font-extrabold">{formatPaise(p.amount_paise)}</p><Badge tone={st.tone}>{st.label}</Badge></div>
      </div>
      {p.status === "FAILED" && p.failure_reason && <p className="mt-2 text-xs text-steel">{p.failure_reason}</p>}
      {refundText(p.refund) && <p className="mt-2 text-xs text-steel">{refundText(p.refund)}</p>}
      {p.under_review && <p className="mt-2 text-xs text-steel">{REVIEW_NOTICE}</p>}
      <div className="mt-2 flex flex-wrap gap-3 text-sm">
        {p.invoice_number && <Link className="font-semibold text-span-dark underline" to={`/institution/payments/${p.id}/invoice`}>Invoice {p.invoice_number}</Link>}
        {(p.status === "PENDING" || p.status === "PROCESSING") && <Link className="font-semibold text-span-dark underline" to={`/trainings/${p.training_id}`}>Open payment</Link>}
      </div>
    </li>
  );
}

/** A paged list with loading, error and empty states. `q` is a react-query result of myPayments. */
export function PaymentList({ q, page, onPage, filtered = false }) {
  if (q.isLoading) return <p role="status" className="text-steel">Loading payments...</p>;
  if (q.isError) return (
    <div role="alert" className="text-danger"><p>{errorMessage(q.error)}</p><Button variant="secondary" className="mt-3" onClick={() => q.refetch()}>Try again</Button></div>
  );
  if (!q.data) return null;
  if (q.data.items.length === 0) {
    return <EmptyState title={filtered ? "No payments with this status" : "No payments yet"}
      text={filtered ? "Try another tab." : "Payments for your trainings appear here, together with their invoices."}
      action={!filtered && <Button as={Link} to="/institution/trainings">View trainings</Button>} />;
  }
  return (
    <>
      <ul className="space-y-3">{q.data.items.map((p) => <PaymentRow key={p.id} p={p} />)}</ul>
      <Pagination page={page} pageSize={q.data.page_size} total={q.data.total} onChange={onPage} />
    </>
  );
}

export default function InstitutionPayments() {
  const [status, setStatus] = useState("");
  const [page, setPage] = useState(1);
  const summary = useQuery({ queryKey: ["payments-summary"], queryFn: paymentsSummary, retry: false });
  const [polls, setPolls] = useState(0);
  const q = useQuery({ queryKey: ["payments", status, page], queryFn: () => myPayments(page, status), placeholderData: keepPreviousData,
    refetchInterval: (query) => listPollInterval(query.state.data?.items, polls) });   // only while a payment on this page is still open, and not forever
  const open = q.data?.items?.some((p) => p.status === "PENDING" || p.status === "PROCESSING");
  useEffect(() => { setPolls((n) => (open ? n + 1 : 0)); }, [q.dataUpdatedAt, !!open]);
  return (
    <AppLayout>
      <h1 className="mb-1 text-3xl font-extrabold">Payments</h1>
      <p className="mb-4 text-sm text-steel">Your payment attempts and invoices. Only you can see them.</p>
      <SandboxBanner show={!!summary.data?.sandbox} className="mb-4" />
      <InstitutionPaymentCard q={summary} banner={false} />
      <div role="tablist" aria-label="Filter by status" className="mb-6 mt-6 flex gap-2 overflow-x-auto">
        {TABS.map(([value, label]) => (
          <button key={label} role="tab" aria-selected={status === value} onClick={() => { setStatus(value); setPage(1); }}
            className={`whitespace-nowrap rounded-full border px-4 py-2 text-sm font-semibold ${status === value ? "border-span bg-span-soft text-span-dark" : "border-line bg-white text-steel"}`}>{label}</button>
        ))}
      </div>
      <PaymentList q={q} page={page} onPage={setPage} filtered={status !== ""} />
    </AppLayout>
  );
}
