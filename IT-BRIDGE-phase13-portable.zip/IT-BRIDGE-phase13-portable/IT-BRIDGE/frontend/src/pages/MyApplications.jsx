import { Link } from "react-router-dom";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import AppLayout from "../layouts/AppLayout.jsx";
import Button from "../components/ui/Button.jsx";
import EmptyState from "../components/ui/EmptyState.jsx";
import StatusBadge from "../components/StatusBadge.jsx";
import ContactBox from "../components/ContactBox.jsx";
import { money } from "../components/RequirementCard.jsx";
import { myApplications, myHiringRequests, respondHiring, withdrawApplication } from "../services/applicationService.js";
import { errorMessage } from "../services/api.js";

const WITHDRAWABLE = ["APPLIED", "UNDER_REVIEW", "SHORTLISTED", "INTERVIEW"];

export default function MyApplications() {
  const qc = useQueryClient();
  const apps = useQuery({ queryKey: ["my-applications"], queryFn: myApplications });
  const hires = useQuery({ queryKey: ["my-hiring"], queryFn: myHiringRequests });
  const refresh = () => { qc.invalidateQueries({ queryKey: ["my-applications"] }); qc.invalidateQueries({ queryKey: ["my-hiring"] }); };
  const withdraw = useMutation({ mutationFn: withdrawApplication, onSuccess: refresh });
  const respond = useMutation({ mutationFn: ({ id, action }) => respondHiring(id, action), onSuccess: refresh });
  const error = withdraw.error || respond.error;
  const hireByApp = Object.fromEntries((hires.data || []).map((h) => [h.application_id, h]));

  return (
    <AppLayout>
      <h1 className="mb-6 text-3xl font-extrabold">Your applications</h1>
      {error && <p role="alert" className="mb-4 rounded-ctl bg-red-50 p-3 text-sm text-danger">{errorMessage(error)}</p>}
      {apps.isLoading && <p role="status" className="text-steel">Loading applications...</p>}
      {apps.isError && <p role="alert" className="text-danger">{errorMessage(apps.error)}</p>}
      {apps.data?.length === 0 && (
        <EmptyState title="No applications yet" text="Find a training opportunity that fits your skills and apply in a minute."
          action={<Button as={Link} to="/trainer/opportunities">Browse opportunities</Button>} />
      )}
      <div className="space-y-4">
        {apps.data?.map((a) => {
          const h = hireByApp[a.id];
          return (
            <article key={a.id} className="rounded-card bg-white p-5 shadow-card">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <h2 className="text-lg font-bold"><Link to={`/requirements/${a.requirement_id}`} className="hover:text-span-dark">{a.requirement.title}</Link></h2>
                  <p className="text-sm text-steel">{a.requirement.institution_name} · {a.requirement.location} · starts {a.requirement.start_date}</p>
                </div>
                <StatusBadge status={a.status} />
              </div>
              {a.proposed_fee != null && <p className="mt-2 text-sm">Your proposed fee: {money(a.proposed_fee)}</p>}
              {a.status === "INTERVIEW" && a.interview_at && <p className="mt-2 text-sm font-semibold">Interview: {new Date(a.interview_at).toLocaleString([], { dateStyle: "medium", timeStyle: "short" })}</p>}
              {h && h.status === "PENDING" && (
                <div className="mt-4 rounded-ctl border border-signal bg-signal-soft p-4 text-sm">
                  <p className="font-bold">Hiring request from {h.institution_name}</p>
                  <p className="mt-1">Fee {money(h.agreed_fee)} · {h.start_date} to {h.end_date} · {h.sessions} sessions</p>
                  {h.terms && <p className="mt-1">Terms: {h.terms}</p>}
                  <div className="mt-3 flex gap-2">
                    <Button className="!py-2" disabled={respond.isPending} onClick={() => respond.mutate({ id: h.id, action: "accept" })}>Accept</Button>
                    <Button variant="secondary" className="!py-2" disabled={respond.isPending}
                      onClick={() => window.confirm("Decline this hiring request?") && respond.mutate({ id: h.id, action: "decline" })}>Decline</Button>
                  </div>
                </div>
              )}
              {h?.status === "ACCEPTED" && <><p className="mt-3 text-sm font-semibold text-ok">You accepted this training for {money(h.agreed_fee)}.</p><ContactBox contact={h.contact} /></>}
              {h && ["DECLINED", "CANCELLED"].includes(h.status) && <p className="mt-3 text-sm text-steel">Hiring request {h.status.toLowerCase()}.</p>}
              {a.requirement.status === "FILLED" && a.status !== "SELECTED" && <p className="mt-2 text-sm text-steel">This requirement has been filled.</p>}
              {WITHDRAWABLE.includes(a.status) && (
                <Button variant="secondary" className="mt-4 !py-2" disabled={withdraw.isPending}
                  onClick={() => window.confirm("Withdraw this application?") && withdraw.mutate(a.id)}>Withdraw application</Button>
              )}
            </article>
          );
        })}
      </div>
    </AppLayout>
  );
}
