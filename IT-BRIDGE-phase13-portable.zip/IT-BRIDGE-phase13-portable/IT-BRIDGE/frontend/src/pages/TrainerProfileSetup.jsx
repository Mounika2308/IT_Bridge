import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import Field from "../components/ui/Field.jsx";
import TextArea from "../components/ui/TextArea.jsx";
import SelectField from "../components/ui/SelectField.jsx";
import Button from "../components/ui/Button.jsx";
import ProgressBar from "../components/ui/ProgressBar.jsx";
import Logo from "../components/Logo.jsx";
import { getSkills, getTrainerProfile, saveTrainerProfile } from "../services/profileService.js";
import { trainerStepSchemas, splitList } from "../schemas/profile.js";
import { errorMessage } from "../services/api.js";

const STEPS = ["About you", "Expertise", "Preferences"];
const STEP_FIELDS = [
  ["headline", "about", "location", "experience_years"],
  ["skill_ids", "languages", "education", "certifications"],
  ["training_mode", "expected_fee", "availability"],
];

export default function TrainerProfileSetup() {
  const nav = useNavigate();
  const qc = useQueryClient();
  const [step, setStep] = useState(0);
  const [serverError, setServerError] = useState("");
  const profile = useQuery({ queryKey: ["trainer-profile"], queryFn: getTrainerProfile });
  const skills = useQuery({ queryKey: ["skills"], queryFn: getSkills });
  const [completion, setCompletion] = useState(0);

  const { register, handleSubmit, reset, watch, setValue, formState: { errors, isSubmitting } } = useForm({
    resolver: (values, ctx, opts) => zodResolver(trainerStepSchemas[step])(values, ctx, opts),
    defaultValues: { skill_ids: [] },
  });

  useEffect(() => {
    const p = profile.data;
    if (!p) return;
    setCompletion(p.completion);
    reset({
      headline: p.headline ?? "", about: p.about ?? "", location: p.location ?? "",
      experience_years: p.experience_years ?? "", skill_ids: p.skills.map((s) => s.id),
      languages: p.languages.join(", "), education: p.education.join(", "),
      certifications: p.certifications.join(", "), training_mode: p.training_mode ?? "",
      expected_fee: p.expected_fee ?? "", availability: p.availability ?? "",
    });
  }, [profile.data, reset]);

  const selected = watch("skill_ids") || [];
  const toggleSkill = (id) =>
    setValue("skill_ids", selected.includes(id) ? selected.filter((x) => x !== id) : [...selected, id], { shouldValidate: true });

  const onSubmit = async (values) => {
    setServerError("");
    const payload = {};
    STEP_FIELDS[step].forEach((f) => { payload[f] = values[f]; });
    if (step === 0 || step === 2) {
      if ("experience_years" in payload) payload.experience_years = Number(payload.experience_years);
      if ("expected_fee" in payload) payload.expected_fee = Number(payload.expected_fee);
    }
    if (step === 1) {
      payload.languages = splitList(values.languages);
      payload.education = splitList(values.education);
      payload.certifications = splitList(values.certifications);
    }
    try {
      const saved = await saveTrainerProfile(payload); // saved per step so progress is never lost
      setCompletion(saved.completion);
      qc.invalidateQueries({ queryKey: ["trainer-profile"] });
      if (step < STEPS.length - 1) setStep(step + 1);
      else nav("/trainer", { replace: true });
    } catch (e) { setServerError(errorMessage(e)); }
  };

  if (profile.isLoading) return <p className="p-10 text-center text-steel" role="status">Loading your profile...</p>;
  if (profile.isError) return <p className="p-10 text-center text-danger" role="alert">{errorMessage(profile.error)}</p>;

  return (
    <main className="mx-auto max-w-xl px-5 py-8">
      <div className="mb-6"><Logo /></div>
      <h1 className="text-3xl font-extrabold">Build your trainer profile</h1>
      <p className="mb-5 mt-1 text-steel">Step {step + 1} of {STEPS.length}: {STEPS[step]}</p>
      <div className="mb-6"><ProgressBar value={completion} /></div>

      <form onSubmit={handleSubmit(onSubmit)} noValidate className="space-y-4 rounded-card bg-white p-6 shadow-card">
        {serverError && <p role="alert" className="rounded-ctl bg-red-50 p-3 text-sm text-danger">{serverError}</p>}

        {step === 0 && (<>
          <Field label="Professional headline" error={errors.headline?.message} {...register("headline")} />
          <TextArea label="About you" error={errors.about?.message} {...register("about")} />
          <Field label="City" error={errors.location?.message} {...register("location")} />
          <Field label="Years of experience" type="number" min="0" inputMode="numeric" error={errors.experience_years?.message} {...register("experience_years")} />
        </>)}

        {step === 1 && (<>
          <fieldset>
            <legend className="mb-2 text-sm font-semibold">Skills you teach</legend>
            {skills.isLoading && <p className="text-sm text-steel">Loading skills...</p>}
            {skills.isError && <p className="text-sm text-danger">Could not load skills. Refresh to try again.</p>}
            <div className="flex flex-wrap gap-2">
              {skills.data?.map((s) => (
                <label key={s.id} className={`cursor-pointer rounded-full border px-3.5 py-2 text-sm ${selected.includes(s.id) ? "border-span bg-span-soft font-semibold" : "border-line"}`}>
                  <input type="checkbox" className="sr-only" checked={selected.includes(s.id)} onChange={() => toggleSkill(s.id)} />
                  {s.name}
                </label>
              ))}
            </div>
            {errors.skill_ids && <p role="alert" className="mt-1 text-xs text-danger">{errors.skill_ids.message}</p>}
          </fieldset>
          <Field label="Languages" hint="Separate with commas" error={errors.languages?.message} {...register("languages")} />
          <Field label="Education" hint="Separate with commas" {...register("education")} />
          <Field label="Certifications" hint="Separate with commas. File uploads come in a later phase." {...register("certifications")} />
        </>)}

        {step === 2 && (<>
          <SelectField label="Training mode" error={errors.training_mode?.message} {...register("training_mode")}
            options={[["ONLINE", "Online"], ["OFFLINE", "Offline"], ["HYBRID", "Hybrid"]]} />
          <Field label="Expected fee per day" type="number" min="0" inputMode="numeric" error={errors.expected_fee?.message} {...register("expected_fee")} />
          <TextArea label="Availability" rows={3} hint="For example: weekdays after 4 pm, weekends full day" error={errors.availability?.message} {...register("availability")} />
        </>)}

        <div className="flex gap-3 pt-2">
          {step > 0 && <Button type="button" variant="secondary" onClick={() => setStep(step - 1)}>Back</Button>}
          <Button type="submit" className="flex-1" disabled={isSubmitting}>
            {isSubmitting ? "Saving..." : step === STEPS.length - 1 ? "Finish profile" : "Save and continue"}
          </Button>
        </div>
      </form>
    </main>
  );
}
