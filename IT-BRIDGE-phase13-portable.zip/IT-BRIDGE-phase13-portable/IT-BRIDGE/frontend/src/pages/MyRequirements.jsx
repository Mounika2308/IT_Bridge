import { useState } from "react";
import { Link } from "react-router-dom";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import AppLayout from "../layouts/AppLayout.jsx";
import Button from "../components/ui/Button.jsx";
import EmptyState from "../components/ui/EmptyState.jsx";
import Pagination from "../components/ui/Pagination.jsx";
import RequirementCard from "../components/RequirementCard.jsx";
import { closeRequirement, myRequirements } from "../services/requirementService.js";
import { errorMessage } from "../services/api.js";

export default function MyRequirements() {
  const [page, setPage] = useState(1);
  const qc = useQueryClient();
  const q = useQuery({ queryKey: ["my-requirements", page], queryFn: () => myRequirements(page) });
  const close = useMutation({
    mutationFn: closeRequirement,
    onSuccess: () => qc.invalidateQueries({ queryKey: ["my-requirements"] }),
  });

  return (
    <AppLayout>
      <div className="mb-6 flex items-center justify-between">
        <h1 className="text-3xl font-extrabold">Your requirements</h1>
        <Button as={Link} to="/institution/requirements/new">Post a requirement</Button>
      </div>
      {close.isError && <p role="alert" className="mb-4 rounded-ctl bg-red-50 p-3 text-sm text-danger">{errorMessage(close.error)}</p>}
      {q.isLoading && <p role="status" className="text-steel">Loading requirements...</p>}
      {q.isError && <p role="alert" className="text-danger">{errorMessage(q.error)}</p>}
      {q.data?.items.length === 0 && (
        <EmptyState title="No requirements yet" text="Post your first requirement and trainers can start applying."
          action={<Button as={Link} to="/institution/requirements/new">Post a requirement</Button>} />
      )}
      <div className="grid gap-4 md:grid-cols-2">
        {q.data?.items.map((r) => (
          <RequirementCard key={r.id} r={r} to={`/requirements/${r.id}`} actions={r.status === "OPEN" && (<>
            <Button as={Link} to={`/institution/requirements/${r.id}/applications`} className="!py-2">Applications</Button>
            <Button as={Link} to={`/institution/requirements/${r.id}/matches`} variant="secondary" className="!py-2">Find trainers</Button>
            <Button as={Link} to={`/institution/requirements/${r.id}/edit`} variant="secondary" className="!py-2">Edit</Button>
            <Button variant="secondary" className="!py-2" disabled={close.isPending}
              onClick={() => window.confirm("Close this requirement? Trainers will no longer see it.") && close.mutate(r.id)}>Close</Button>
          </>)} />
        ))}
      </div>
      {q.data && <Pagination page={page} pageSize={q.data.page_size} total={q.data.total} onChange={setPage} />}
    </AppLayout>
  );
}
