import { describe, expect, it } from "vitest";
import { MIN_REVIEWS_FOR_FILTER, allRated, categoryLabel, commentInfo, fieldErrors, filterNote, formatRating, pendingText, ratingLine, reasonText, reviewCountText, reviewPayload, submitState } from "./reviews.js";

const CATS = ["communication", "professionalism", "coordination"];
const ALL = { communication: 4, professionalism: 5, coordination: 3 };

describe("review wording", () => {
  it("uses singular and plural correctly", () => {
    expect(reviewCountText(0)).toBe("No reviews yet");
    expect(reviewCountText(1)).toBe("1 review");
    expect(reviewCountText(2)).toBe("2 reviews");
    expect(pendingText(0)).toBe("No reviews waiting");
    expect(pendingText(1)).toBe("1 review waiting");
    expect(pendingText(3)).toBe("3 reviews waiting");
  });
  it("shows ratings with one decimal everywhere, and nothing misleading without reviews", () => {
    expect(formatRating(4)).toBe("4.0");
    expect(formatRating(4.6)).toBe("4.6");
    expect(formatRating(null)).toBe("");
    expect(ratingLine(4, 3)).toBe("4.0 from 3 reviews");
    expect(ratingLine(5, 1)).toBe("5.0 from 1 review");
    expect(ratingLine(null, 0)).toBe("No reviews yet");
    expect(ratingLine(0, 0)).toBe("No reviews yet");
  });
  it("explains the two-review rule for a profile with a single review, and only then", () => {
    expect(MIN_REVIEWS_FOR_FILTER).toBe(2);
    expect(filterNote(1)).toContain("2 reviews");
    expect(filterNote(0)).toBe(null);
    expect(filterNote(2)).toBe(null);
  });
  it("labels categories and explains every reason a review is not possible", () => {
    expect(categoryLabel("technical_knowledge")).toBe("Technical knowledge");
    expect(reasonText("ACTIVE")).toContain("still in progress");
    expect(reasonText("CANCELLED")).toContain("cancelled");
    expect(reasonText("ALREADY_REVIEWED")).toContain("cannot be changed");
    expect(reasonText("SUSPENDED")).toContain("Suspended");
    expect(reasonText("ACTIVE", "Server text")).toBe("Server text");
    expect(reasonText(null)).toBe(null);
  });
});

describe("comment rules", () => {
  it("counts the trimmed length", () => {
    expect(commentInfo("  hello  ")).toEqual({ trimmed: "hello", length: 5, remaining: 1995, tooLong: false, blank: false });
  });
  it("flags whitespace-only text but not an empty box", () => {
    expect(commentInfo("   ").blank).toBe(true);
    expect(commentInfo("").blank).toBe(false);
  });
  it("allows exactly the limit after trimming and flags one more", () => {
    expect(commentInfo(` ${"x".repeat(2000)} `).tooLong).toBe(false);
    expect(commentInfo("x".repeat(2001)).tooLong).toBe(true);
    expect(commentInfo("x".repeat(2001)).remaining).toBe(-1);
    expect(commentInfo("x".repeat(11), 10).tooLong).toBe(true);        // the limit comes from the server
  });
  it("sends a trimmed comment, or null when empty", () => {
    expect(reviewPayload(ALL, "  Great  ")).toEqual({ ratings: ALL, comment: "Great" });
    expect(reviewPayload(ALL, "")).toEqual({ ratings: ALL, comment: null });
  });
});

describe("submit button state", () => {
  const base = { ratings: ALL, categories: CATS, comment: "" };
  it("needs every category rated with a whole number from 1 to 5", () => {
    expect(allRated(ALL, CATS)).toBe(true);
    expect(allRated({ ...ALL, coordination: undefined }, CATS)).toBe(false);
    expect(allRated({ ...ALL, coordination: 0 }, CATS)).toBe(false);
    expect(allRated({ ...ALL, coordination: 6 }, CATS)).toBe(false);
    expect(allRated({ ...ALL, coordination: 3.5 }, CATS)).toBe(false);
    expect(allRated({}, [])).toBe(false);
    expect(submitState({ ...base, ratings: {} })).toEqual({ enabled: false, hint: "Rate every category to submit." });
  });
  it("enables a complete, valid form", () => {
    expect(submitState(base)).toEqual({ enabled: true, hint: null });
    expect(submitState({ ...base, comment: "Good" }).enabled).toBe(true);
  });
  it("blocks blank and over-long comments with a reason", () => {
    expect(submitState({ ...base, comment: "   " })).toEqual({ enabled: false, hint: "Write a comment or leave it empty." });
    expect(submitState({ ...base, comment: "x".repeat(2003) }).hint).toContain("by 3 characters");
  });
  it("blocks a second submission while one is in flight and after it succeeded", () => {
    expect(submitState({ ...base, pending: true }).enabled).toBe(false);
    expect(submitState({ ...base, done: true }).enabled).toBe(false);
  });
});

describe("backend validation errors", () => {
  const err = (status, data) => ({ response: { status, data: { success: false, message: "Validation failed", data } } });
  it("turns a 422 into field messages", () => {
    expect(fieldErrors(err(422, { comment: "Value error, Write a comment or leave it empty", "ratings.communication": "Input should be a valid integer" })))
      .toEqual({ comment: "Write a comment or leave it empty", ratings: "Input should be a valid integer" });
  });
  it("ignores other errors and missing responses", () => {
    expect(fieldErrors(err(409, null))).toEqual({});
    expect(fieldErrors(err(422, null))).toEqual({});
    expect(fieldErrors(null)).toEqual({});
    expect(fieldErrors(new Error("network"))).toEqual({});
  });
});
