/** Pure helpers behind the notification bell, the notifications page and the live hook, so they can be tested without a browser. */

export const ago = (iso, now = Date.now()) => {
  const s = Math.max(1, Math.round((now - new Date(iso)) / 1000));
  if (s < 60) return "just now";
  if (s < 3600) return `${Math.floor(s / 60)} min ago`;
  if (s < 86400) return `${Math.floor(s / 3600)} h ago`;
  return `${Math.floor(s / 86400)} d ago`;
};

/** The in-app route a notification opens. Only same-app paths are followed ("/x", never "//host" or "https://..."). */
export const notificationTarget = (n) => (typeof n?.link === "string" && /^\/(?!\/)/.test(n.link) ? n.link : null);

/** Refetch the bell list, the page list and the unread badge. */
export const refreshNotifications = (qc) => {
  qc.invalidateQueries({ queryKey: ["notifications"] });
  qc.invalidateQueries({ queryKey: ["notif-count"] });
};

/**
 * Reacts to one WebSocket frame.
 *  - "ready": the socket is authenticated. Refresh right away, because anything created while the socket was down
 *    (a reconnect after a network drop) was never pushed, and polling is switched off while connected.
 *  - "notification": show the toast and refresh.
 */
export const handleSocketMessage = (raw, { qc, setConnected, setToast, resetRetry }) => {
  let msg;
  try { msg = typeof raw === "string" ? JSON.parse(raw) : raw; } catch { return; }
  if (msg?.type === "ready") { setConnected(true); resetRetry(); refreshNotifications(qc); }
  else if (msg?.type === "notification" && msg.data) { setToast(msg.data); refreshNotifications(qc); }
};

/** Clicking a notification marks it read, closes the panel and opens its deep link, if it has one. */
export const openNotification = (n, { markRead, close, navigate }) => {
  if (!n.is_read) markRead(n.id);
  close();
  const to = notificationTarget(n);
  if (to) navigate(to);
};

/** Words for the three states of an in-app list. */
export const emptyText = (unreadOnly) => (unreadOnly
  ? "You are all caught up."
  : "Updates about applications, interviews, hiring, trainings, sessions and reviews will appear here.");
