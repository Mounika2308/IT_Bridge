/** Pure helpers for reviews and ratings, so the wording and the rules can be tested without a browser. */

/** The minimum-rating search filter only counts profiles with at least this many reviews (the API enforces the same number). */
export const MIN_REVIEWS_FOR_FILTER = 2;
export const DEFAULT_COMMENT_MAX = 2000;

export const reviewCountText = (n) => (n === 1 ? "1 review" : n > 1 ? `${n} reviews` : "No reviews yet");

/** "4.0": always one decimal, so the same rating reads the same on the card, the profile and the dashboard. */
export const formatRating = (rating) => (typeof rating === "number" ? rating.toFixed(1) : "");

export const hasRating = (rating, count) => count > 0 && typeof rating === "number";

/** A short line for a rating and its review count, or the honest empty text. */
export const ratingLine = (rating, count) => (hasRating(rating, count) ? `${formatRating(rating)} from ${reviewCountText(count)}` : "No reviews yet");

/** Explains why a profile with a rating may be missing from the rating filter. */
export const filterNote = (count) => (count > 0 && count < MIN_REVIEWS_FOR_FILTER
  ? `Counted in the rating filter once it has ${MIN_REVIEWS_FOR_FILTER} reviews.` : null);

export const categoryLabel = (key) => key.replace(/_/g, " ").replace(/^./, (c) => c.toUpperCase());

/** What the comment box needs: trimmed text, how many characters are left, and whether it is acceptable. */
export const commentInfo = (comment, max = DEFAULT_COMMENT_MAX) => {
  const trimmed = comment.trim();
  return { trimmed, length: trimmed.length, remaining: max - trimmed.length, tooLong: trimmed.length > max, blank: comment.length > 0 && trimmed.length === 0 };
};

export const allRated = (ratings, categories) => categories.length > 0 && categories.every((c) => Number.isInteger(ratings[c]) && ratings[c] >= 1 && ratings[c] <= 5);

/** Can the Submit button be pressed, and if not, what to tell the user. Backend validation stays authoritative. */
export const submitState = ({ ratings, categories, comment, max = DEFAULT_COMMENT_MAX, pending = false, done = false }) => {
  const info = commentInfo(comment, max);
  if (done) return { enabled: false, hint: null };
  if (pending) return { enabled: false, hint: null };
  if (!allRated(ratings, categories)) return { enabled: false, hint: "Rate every category to submit." };
  if (info.blank) return { enabled: false, hint: "Write a comment or leave it empty." };
  if (info.tooLong) return { enabled: false, hint: `Shorten the comment by ${-info.remaining} characters.` };
  return { enabled: true, hint: null };
};

/** The payload sent to the API: comment trimmed, and null when empty. */
export const reviewPayload = (ratings, comment) => ({ ratings, comment: comment.trim() || null });

/** Field-level messages from a 422 response ({"success": false, "message": "Validation failed", "data": {"comment": "..."}}). */
export const fieldErrors = (error) => {
  const data = error?.response?.status === 422 ? error.response.data?.data : null;
  if (!data || typeof data !== "object") return {};
  const out = {};
  for (const [key, msg] of Object.entries(data)) out[key.split(".")[0]] = String(msg).replace(/^Value error, /, "");
  return out;
};

/** Why a review cannot be written right now (the API sends the reason; this is the wording for each). */
export const REASON_TEXT = {
  ACTIVE: "This training is still in progress. Reviews open once the institution marks it completed.",
  CANCELLED: "This training was cancelled, so it cannot be reviewed.",
  SUSPENDED: "Suspended accounts cannot submit reviews.",
  ALREADY_REVIEWED: "You have already reviewed this training. Reviews cannot be changed after they are submitted.",
};
export const reasonText = (reason, apiText) => apiText || REASON_TEXT[reason] || null;

export const pendingText = (n) => (n === 0 ? "No reviews waiting" : n === 1 ? "1 review waiting" : `${n} reviews waiting`);
