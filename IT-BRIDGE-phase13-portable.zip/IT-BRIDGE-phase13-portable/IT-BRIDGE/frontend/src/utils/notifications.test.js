import { describe, expect, it } from "vitest";
import { ago, emptyText, handleSocketMessage, notificationTarget, openNotification, refreshNotifications } from "./notifications.js";

const fakeClient = () => { const keys = []; return { keys, invalidateQueries: ({ queryKey }) => keys.push(queryKey[0]) }; };
const ctx = (qc) => { const log = { connected: [], toasts: [], resets: 0 }; return { log, args: { qc, setConnected: (v) => log.connected.push(v), setToast: (t) => log.toasts.push(t), resetRetry: () => { log.resets++; } } }; };

describe("deep links", () => {
  it("follows in-app paths for every kind of event", () => {
    for (const link of ["/trainer/applications", "/institution/requirements/7/applications", "/trainings/12", "/requirements/4"])
      expect(notificationTarget({ link })).toBe(link);
  });
  it("never follows an external or protocol-relative link, and tolerates a missing one", () => {
    for (const link of ["https://evil.example/x", "//evil.example/x", "javascript:alert(1)", "", null, undefined])
      expect(notificationTarget({ link })).toBe(null);
    expect(notificationTarget(null)).toBe(null);
  });
});

describe("opening a notification", () => {
  const run = (n) => { const calls = []; openNotification(n, { markRead: (id) => calls.push(["read", id]), close: () => calls.push(["close"]), navigate: (to) => calls.push(["go", to]) }); return calls; };
  it("marks an unread notification read, closes the panel and navigates to its link", () => {
    expect(run({ id: 5, is_read: false, link: "/trainings/3" })).toEqual([["read", 5], ["close"], ["go", "/trainings/3"]]);
  });
  it("does not mark an already read notification again", () => {
    expect(run({ id: 5, is_read: true, link: "/trainings/3" })).toEqual([["close"], ["go", "/trainings/3"]]);
  });
  it("only closes when there is no link", () => {
    expect(run({ id: 6, is_read: false, link: null })).toEqual([["read", 6], ["close"]]);
  });
});

describe("live updates", () => {
  it("refreshes the list and the unread count as soon as a reconnected socket is ready", () => {
    const qc = fakeClient(); const { log, args } = ctx(qc);
    handleSocketMessage(JSON.stringify({ type: "ready" }), args);
    expect(qc.keys).toEqual(["notifications", "notif-count"]);
    expect(log.connected).toEqual([true]);
    expect(log.resets).toBe(1);                           // backoff starts over after a good connection
    expect(log.toasts).toHaveLength(0);                   // a reconnect is not a new notification
  });
  it("shows a toast and refreshes for a pushed notification", () => {
    const qc = fakeClient(); const { log, args } = ctx(qc);
    handleSocketMessage(JSON.stringify({ type: "notification", data: { id: 9, title: "Interview scheduled" } }), args);
    expect(log.toasts).toEqual([{ id: 9, title: "Interview scheduled" }]);
    expect(qc.keys).toEqual(["notifications", "notif-count"]);
  });
  it("ignores malformed frames and unknown types", () => {
    const qc = fakeClient(); const { log, args } = ctx(qc);
    handleSocketMessage("not json", args); handleSocketMessage(JSON.stringify({ type: "pong" }), args); handleSocketMessage(JSON.stringify({ type: "notification" }), args);
    expect(qc.keys).toHaveLength(0); expect(log.toasts).toHaveLength(0); expect(log.connected).toHaveLength(0);
  });
  it("refreshNotifications invalidates both the lists and the badge", () => {
    const qc = fakeClient(); refreshNotifications(qc);
    expect(qc.keys).toEqual(["notifications", "notif-count"]);
  });
});

describe("text", () => {
  it("formats ages", () => {
    const now = Date.parse("2030-01-01T12:00:00Z");
    expect(ago("2030-01-01T11:59:50Z", now)).toBe("just now");
    expect(ago("2030-01-01T11:30:00Z", now)).toBe("30 min ago");
    expect(ago("2030-01-01T09:00:00Z", now)).toBe("3 h ago");
    expect(ago("2029-12-30T12:00:00Z", now)).toBe("2 d ago");
  });
  it("has an empty message for both the full and the unread-only list", () => {
    expect(emptyText(true)).toContain("all caught up");
    expect(emptyText(false)).toContain("interviews");
  });
});
