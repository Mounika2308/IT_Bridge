import { describe, expect, it } from "vitest";
import {
  COMMISSION_NOTE, INVOICE_NOT_TAX_NOTE, LIST_POLL_MS, MAX_POLLS, POLL_MS, SANDBOX_BANNER, amountState, anyOpen, keepKeyAfter, listPollInterval, bpsToPercent, earningNote, earningStatus, errorCode, formatPaise, isOpen, keyHolder,
  feeDue, newIdempotencyKey, paiseToInput, paidPercent, paidSoFar, payState, paymentStatus, pollInterval, refundText, rupeesToPaise, shouldPoll, statusText, trainingFeeLine,
} from "./payments.js";

// Expected strings below were produced by the backend's format_inr (payment_rules.py) for the same inputs, so the two sides read the same.
const BACKEND_VECTORS = [[0, "₹0"], [1, "₹0.01"], [5, "₹0.05"], [99, "₹0.99"], [100, "₹1"], [150, "₹1.50"], [1000, "₹10"], [10000, "₹100"], [99900, "₹999"],
  [100000, "₹1,000"], [123456, "₹1,234.56"], [9999999, "₹99,999.99"], [10000000, "₹1,00,000"], [12345678, "₹1,23,456.78"], [123456789, "₹12,34,567.89"],
  [1000000000, "₹1,00,00,000"], [-250, "-₹2.50"], [-100000, "-₹1,000"], [100000000000, "₹1,00,00,00,000"]];

describe("money formatting", () => {
  it("matches the backend's Indian digit grouping for every vector", () => {
    for (const [paise, text] of BACKEND_VECTORS) expect(formatPaise(paise)).toBe(text);
  });
  it("never invents a value for something that is not whole paise", () => {
    expect(formatPaise(10.5)).toBe("—");
    expect(formatPaise(NaN)).toBe("—");
    expect(formatPaise(undefined)).toBe("—");
    expect(formatPaise("100")).toBe("—");
    expect(formatPaise(null)).toBe("—");
  });
  it("shows decimals only when there are paise", () => {
    expect(formatPaise(10000)).toBe("₹100");
    expect(formatPaise(10001)).toBe("₹100.01");
  });
});

describe("parsing what a person typed", () => {
  it("turns rupees into integer paise using string maths", () => {
    expect(rupeesToPaise("1500")).toBe(150000);
    expect(rupeesToPaise("1,500.50")).toBe(150050);
    expect(rupeesToPaise("₹100")).toBe(10000);
    expect(rupeesToPaise("0.5")).toBe(50);
    expect(rupeesToPaise("10.5")).toBe(1050);
    expect(rupeesToPaise(" 12 ")).toBe(1200);
    expect(rupeesToPaise("0.07")).toBe(7);
    expect(rupeesToPaise("19.99")).toBe(1999);   // 19.99 * 100 is 1998.9999999999998 with floats; this must be exact
    expect(rupeesToPaise("1.15")).toBe(115);
  });
  it("rejects anything that is not a plain amount of rupees and at most two decimals", () => {
    for (const bad of ["", "abc", "1.234", "-5", "1e3", "1.", ".5", "1,2,3x", "12 34", "0x10", "Infinity", "9999999999999"]) expect(rupeesToPaise(bad)).toBeNull();
    expect(rupeesToPaise(100)).toBeNull();
    expect(rupeesToPaise(undefined)).toBeNull();
  });
  it("round-trips for the input box", () => {
    for (const paise of [100, 150, 12345, 99999900]) expect(rupeesToPaise(paiseToInput(paise))).toBe(paise);
    expect(paiseToInput(15000)).toBe("150");
    expect(paiseToInput(15050)).toBe("150.50");
    expect(paiseToInput(-1)).toBe("");
    expect(paiseToInput(1.5)).toBe("");
  });
});

describe("amount validation (the server stays authoritative)", () => {
  it("is silent while the box is empty", () => {
    expect(amountState("", 10000)).toEqual({ ok: false, paise: null, hint: null });
    expect(amountState("   ", 10000).hint).toBeNull();
  });
  it("explains each way an amount can be wrong", () => {
    expect(amountState("abc", 10000).hint).toContain("Enter an amount in rupees");
    expect(amountState("0", 10000).hint).toBe("Enter an amount above zero.");
    expect(amountState("100.01", 10000).hint).toBe("That is more than the ₹100 still due.");
    expect(amountState("0.50", 10000).hint).toBe("The smallest payment is ₹1.");
  });
  it("accepts up to exactly what is still due, and never more", () => {
    expect(amountState("100", 10000)).toEqual({ ok: true, paise: 10000, hint: null });
    expect(amountState("99.99", 10000).ok).toBe(true);
    expect(amountState("100.01", 10000).ok).toBe(false);
  });
  it("lets the last few paise be paid even though they are below the usual minimum", () => {
    expect(amountState("0.50", 50)).toEqual({ ok: true, paise: 50, hint: null });
    expect(amountState("0.49", 50).ok).toBe(false);
  });
});

describe("statuses and honest wording", () => {
  it("labels every payment status, and does not crash on an unknown one", () => {
    expect(paymentStatus("SUCCEEDED").label).toBe("Paid");
    expect(paymentStatus("PENDING").label).toBe("Awaiting payment");
    expect(paymentStatus("PROCESSING").label).toBe("Processing");
    expect(paymentStatus("FAILED").tone).toBe("danger");
    expect(paymentStatus("CANCELLED").label).toBe("Cancelled");
    expect(paymentStatus("EXPIRED").label).toBe("Expired");
    expect(paymentStatus("WEIRD").label).toBe("WEIRD");
    expect(paymentStatus(undefined).label).toBe("Unknown");
  });
  it("only a SUCCEEDED status from the server reads as paid", () => {
    for (const status of ["PENDING", "PROCESSING", "FAILED", "CANCELLED", "EXPIRED"]) expect(statusText({ status })).not.toContain("confirmed");
    expect(statusText({ status: "SUCCEEDED" })).toContain("Payment confirmed");
  });
  it("tells the user not to pay again while a payment is processing", () => {
    const t = statusText({ status: "PROCESSING" });
    expect(t).toContain("Do not pay again");
    expect(t).toContain("checks again automatically");
  });
  it("says nothing was charged for failed, cancelled and expired attempts", () => {
    expect(statusText({ status: "FAILED", failure_reason: "Card declined" })).toContain("Card declined");
    for (const status of ["FAILED", "CANCELLED", "EXPIRED"]) expect(statusText({ status })).toContain("Nothing was charged");
  });
  it("marks sandbox payments as not real money", () => {
    expect(statusText({ status: "PENDING", sandbox: true })).toContain("sandbox: no real money");
    expect(statusText({ status: "PENDING", sandbox: false })).not.toContain("sandbox");
    expect(SANDBOX_BANNER).toContain("no real money");
  });
  it("describes refunds", () => {
    expect(refundText(null)).toBeNull();
    expect(refundText({ status: "SUCCEEDED", credit_note_number: "ITB-CN-2030-000001" })).toContain("ITB-CN-2030-000001");
    expect(refundText({ status: "SUCCEEDED" })).toBe("Refunded in full.");
    expect(refundText({ status: "PENDING" })).toBe("A refund is in progress.");
    expect(statusText({ status: "SUCCEEDED", refund: { status: "SUCCEEDED" } })).toBe("Paid, then fully refunded.");
  });
  it("knows which statuses are still open", () => {
    expect(isOpen("PENDING")).toBe(true);
    expect(isOpen("PROCESSING")).toBe(true);
    for (const s of ["SUCCEEDED", "FAILED", "CANCELLED", "EXPIRED", undefined]) expect(isOpen(s)).toBe(false);
  });
});

describe("polling until the backend confirms", () => {
  it("polls only while a payment is open", () => {
    expect(shouldPoll({ status: "PENDING" })).toBe(true);
    expect(shouldPoll({ status: "PROCESSING" })).toBe(true);
    for (const status of ["SUCCEEDED", "FAILED", "CANCELLED", "EXPIRED"]) expect(shouldPoll({ status })).toBe(false);
    expect(shouldPoll(null)).toBe(false);
    expect(shouldPoll(undefined)).toBe(false);
  });
  it("stops after a limit so an abandoned tab does not ask forever", () => {
    expect(shouldPoll({ status: "PENDING" }, MAX_POLLS - 1)).toBe(true);
    expect(shouldPoll({ status: "PENDING" }, MAX_POLLS)).toBe(false);
    expect(pollInterval({ status: "PROCESSING" }, 0)).toBe(POLL_MS);
    expect(pollInterval({ status: "PROCESSING" }, MAX_POLLS)).toBe(false);
    expect(pollInterval({ status: "SUCCEEDED" }, 0)).toBe(false);
  });
});

describe("idempotency keys", () => {
  it("generates keys the backend accepts, and different ones each time", () => {
    const seen = new Set();
    for (let i = 0; i < 500; i++) {
      const k = newIdempotencyKey();
      expect(/^[A-Za-z0-9_.:-]{8,80}$/.test(k)).toBe(true);
      seen.add(k);
    }
    expect(seen.size).toBe(500);
  });
  it("reuses one key while the same request is repeated, so a double click or a retry cannot create two payments", () => {
    let n = 0;
    const h = keyHolder(() => `key-${++n}-abcdefgh`);
    const first = h.forAmount(5000);
    expect(h.forAmount(5000)).toBe(first);
    expect(h.forAmount(5000)).toBe(first);
    expect(n).toBe(1);
  });
  it("uses a different key for a different amount, and a fresh one after the attempt was accepted", () => {
    let n = 0;
    const h = keyHolder(() => `key-${++n}-abcdefgh`);
    const a = h.forAmount(5000);
    const b = h.forAmount(7000);
    expect(b === a).toBe(false);
    h.reset();
    expect(h.peek()).toBeNull();
    expect(h.forAmount(7000) === b).toBe(false);
  });
});

describe("pay button state", () => {
  const summary = (over = {}) => ({ can_pay: true, remaining_paise: 10000, block_message: null, ...over });
  it("is enabled for a valid amount", () => expect(payState({ summary: summary(), amountText: "50" })).toEqual({ enabled: true, hint: null }));
  it("is disabled while a request is being sent, which prevents a second submission", () => expect(payState({ summary: summary(), amountText: "50", busy: true }).enabled).toBe(false));
  it("is disabled with the server's reason when payment is not possible", () => {
    const s = payState({ summary: summary({ can_pay: false, block_message: "The agreed fee has been paid in full." }), amountText: "50" });
    expect(s.enabled).toBe(false);
    expect(s.hint).toBe("The agreed fee has been paid in full.");
  });
  it("is disabled for an invalid amount, and before the summary has loaded", () => {
    expect(payState({ summary: summary(), amountText: "999" }).enabled).toBe(false);
    expect(payState({ summary: summary(), amountText: "" }).enabled).toBe(false);
    expect(payState({ summary: null, amountText: "50" }).enabled).toBe(false);
  });
});

describe("summaries and notes", () => {
  it("builds the fee line and an integer percentage", () => {
    expect(trainingFeeLine({ fee_paise: 1000000, collected_paise: 250000 })).toBe("₹2,500 of ₹10,000 paid");
    expect(trainingFeeLine({ fee_paise: 0, collected_paise: 0 })).toBe("No fee: nothing to pay.");
    expect(paidPercent({ fee_paise: 300, collected_paise: 100 })).toBe(33);
    expect(paidPercent({ fee_paise: 300, collected_paise: 300 })).toBe(100);
    expect(paidPercent({ fee_paise: 0, collected_paise: 0 })).toBe(0);
    expect(paidPercent(null)).toBe(0);
  });
  it("counts only settled money towards the fee while an over-cap payment is on hold awaiting its refund", () => {
    const held = { fee_paise: 10000, collected_paise: 12000, settled_paise: 6000, remaining_paise: 0, due_paise: 4000 };
    expect(paidSoFar(held)).toBe(6000);
    expect(feeDue(held)).toBe(4000);
    expect(trainingFeeLine(held)).toBe("₹60 of ₹100 paid");
    expect(paidPercent(held)).toBe(60);
  });
  it("falls back to the held figures when the server sends no settled/due fields", () => {
    const old = { fee_paise: 300, collected_paise: 100, remaining_paise: 200 };
    expect([paidSoFar(old), feeDue(old), paidPercent(old)]).toEqual([100, 200, 33]);
    expect([paidSoFar(null), feeDue(null)]).toEqual([0, 0]);
  });
  it("shows commission rates without floating-point noise", () => {
    expect(bpsToPercent(1000)).toBe("10%");
    expect(bpsToPercent(1250)).toBe("12.5%");
    expect(bpsToPercent(1205)).toBe("12.05%");
    expect(bpsToPercent(0)).toBe("0%");
    expect(bpsToPercent(undefined)).toBe("");
  });
  it("explains each earning state to the trainer without promising a payout it cannot make", () => {
    expect(earningStatus("AVAILABLE").label).toBe("Available");
    expect(earningNote({ status: "PENDING" })).toContain("marked completed");
    expect(earningNote({ status: "AVAILABLE" })).toContain("does not collect bank or UPI");
    expect(earningNote({ status: "PAID", payout_reference: "BATCH-1" })).toContain("BATCH-1");
    expect(earningNote({ status: "REFUNDED" })).toContain("was refunded");
    expect(earningNote({ status: "PENDING", on_hold: true })).toContain("reviewing");
    expect(earningNote(null)).toBeNull();
  });
  it("keeps the placeholder-commission and not-a-tax-invoice notes", () => {
    expect(COMMISSION_NOTE).toContain("placeholder");
    expect(INVOICE_NOT_TAX_NOTE).toContain("not a GST or tax invoice");
  });
  it("reads the error code the API sends", () => {
    expect(errorCode({ response: { data: { data: { code: "OVER_FEE" } } } })).toBe("OVER_FEE");
    expect(errorCode({})).toBeNull();
    expect(errorCode(null)).toBeNull();
  });
});

describe("payment history polling", () => {
  const item = (status) => ({ status });
  it("polls the list only while one of its payments is still open, and not forever", () => {
    expect(anyOpen([item("SUCCEEDED"), item("PENDING")])).toBe(true);
    expect(anyOpen([item("SUCCEEDED"), item("FAILED")])).toBe(false);
    expect(anyOpen([])).toBe(false);
    expect(anyOpen(undefined)).toBe(false);
    expect(listPollInterval([item("PROCESSING")], 0)).toBe(LIST_POLL_MS);
    expect(listPollInterval([item("SUCCEEDED")], 0)).toBe(false);
    expect(listPollInterval([item("PROCESSING")], MAX_POLLS)).toBe(false);
  });
});

describe("keeping the idempotency key after a failed start", () => {
  it("keeps it when the outcome is unknown, so repeating the request cannot create a second payment", () => {
    expect(keepKeyAfter({ request: {} })).toBe(true);                       // no answer at all (network error)
    expect(keepKeyAfter({ response: { status: 500 } })).toBe(true);
    expect(keepKeyAfter({ response: { status: 502 } })).toBe(true);
    expect(keepKeyAfter(new Error("x"))).toBe(true);
  });
  it("drops it after a definite refusal, because nothing was created and the next try is a new request", () => {
    for (const status of [400, 403, 404, 409, 422]) expect(keepKeyAfter({ response: { status } })).toBe(false);
  });
});
