/** Pure helpers for payments, invoices and earnings (Phase 13), so wording and rules can be tested without a browser.
 *  Every amount in the API is an integer number of paise. Nothing here uses floating-point arithmetic for money. */

export const SANDBOX_BANNER = "Sandbox mode: no real money is being processed. Payments here are simulated for development and testing.";

/** Mirrors backend `format_inr`: Indian digit grouping, decimals only when there are paise. 1234567 -> "₹12,345.67", 10000 -> "₹100". */
export const formatPaise = (paise) => {
  if (!Number.isSafeInteger(paise)) return "—";
  const sign = paise < 0 ? "-" : "";
  const abs = Math.abs(paise);
  const rupees = Math.floor(abs / 100);
  const rest = abs % 100;
  const digits = String(rupees);
  let head = digits.slice(0, -3);
  const tail = digits.slice(-3);
  const groups = [];
  while (head.length > 2) { groups.unshift(head.slice(-2)); head = head.slice(0, -2); }
  if (head) groups.unshift(head);
  const text = groups.length ? `${groups.join(",")},${tail}` : tail;
  return `${sign}₹${text}${rest ? `.${String(rest).padStart(2, "0")}` : ""}`;
};

/** Parses what a person typed ("1500", "1,500.50") into integer paise using string maths only. Returns null when it is not a valid amount. */
export const rupeesToPaise = (text) => {
  if (typeof text !== "string") return null;
  const t = text.trim().replace(/,/g, "").replace(/^₹/, "");
  const m = /^(\d{1,12})(?:\.(\d{1,2}))?$/.exec(t);
  if (!m) return null;
  const paise = Number(m[1]) * 100 + Number((m[2] || "").padEnd(2, "0") || 0);
  return Number.isSafeInteger(paise) ? paise : null;
};

/** Plain digits for an input box: 15000 -> "150", 15050 -> "150.50". */
export const paiseToInput = (paise) => (Number.isSafeInteger(paise) && paise >= 0 ? `${Math.floor(paise / 100)}${paise % 100 ? `.${String(paise % 100).padStart(2, "0")}` : ""}` : "");

export const MIN_PAYMENT_PAISE = 100;

/** Is this amount acceptable to send? The server stays authoritative (fee cap, one in flight, ...). */
export const amountState = (text, remainingPaise) => {
  if (text.trim() === "") return { ok: false, paise: null, hint: null };
  const paise = rupeesToPaise(text);
  if (paise === null) return { ok: false, paise: null, hint: "Enter an amount in rupees, for example 1500 or 1500.50." };
  if (paise <= 0) return { ok: false, paise, hint: "Enter an amount above zero." };
  if (paise > remainingPaise) return { ok: false, paise, hint: `That is more than the ${formatPaise(remainingPaise)} still due.` };
  if (paise < Math.min(MIN_PAYMENT_PAISE, remainingPaise)) return { ok: false, paise, hint: `The smallest payment is ${formatPaise(Math.min(MIN_PAYMENT_PAISE, remainingPaise))}.` };
  return { ok: true, paise, hint: null };
};

// ---------- statuses ----------
export const PAYMENT_STATUS = {
  PENDING: { label: "Awaiting payment", tone: "signal" },
  PROCESSING: { label: "Processing", tone: "span" },
  SUCCEEDED: { label: "Paid", tone: "ok" },
  FAILED: { label: "Failed", tone: "danger" },
  CANCELLED: { label: "Cancelled", tone: "steel" },
  EXPIRED: { label: "Expired", tone: "steel" },
};
export const paymentStatus = (s) => PAYMENT_STATUS[s] || { label: s || "Unknown", tone: "steel" };

export const EARNING_STATUS = {
  PENDING: { label: "Pending completion", tone: "signal" },
  AVAILABLE: { label: "Available", tone: "span" },
  PAID: { label: "Paid out", tone: "ok" },
  REFUNDED: { label: "Refunded", tone: "steel" },
};
export const earningStatus = (s) => EARNING_STATUS[s] || { label: s || "Unknown", tone: "steel" };

export const isOpen = (status) => status === "PENDING" || status === "PROCESSING";

/** The honest sentence for a payment's state. The browser never decides a payment succeeded: only the server's status counts. */
export const statusText = (p) => {
  if (!p) return "";
  const sandbox = p.sandbox ? " (sandbox: no real money)" : "";
  switch (p.status) {
    case "PENDING": return `Waiting for the payment to be completed${sandbox}. This page checks again automatically.`;
    case "PROCESSING": return `The payment provider is still processing this payment${sandbox}. Do not pay again. This page checks again automatically.`;
    case "SUCCEEDED": return p.refund?.status === "SUCCEEDED" ? "Paid, then fully refunded." : `Payment confirmed${sandbox}.`;
    case "FAILED": return `The payment failed${p.failure_reason ? `: ${p.failure_reason}` : ""}. Nothing was charged. You can try again.`;
    case "CANCELLED": return "This payment was cancelled. Nothing was charged.";
    case "EXPIRED": return "This payment attempt expired before it was completed. Nothing was charged. You can try again.";
    default: return "";
  }
};

export const refundText = (refund) => {
  if (!refund) return null;
  if (refund.status === "SUCCEEDED") return refund.credit_note_number ? `Refunded in full (credit note ${refund.credit_note_number}).` : "Refunded in full.";
  if (refund.status === "FAILED") return "A refund is being looked into by an administrator.";
  return "A refund is in progress.";
};

export const REVIEW_NOTICE = "This payment is being reviewed by an administrator. Nothing needs to be done on your side.";

// ---------- polling ----------
export const POLL_MS = 4000;
export const MAX_POLLS = 150; // about ten minutes; after that the page stops asking and says so

/** Keep asking the server only while something is in flight, and stop after a limit so a stuck tab does not poll forever. */
export const shouldPoll = (payment, polls = 0) => !!payment && isOpen(payment.status) && polls < MAX_POLLS;
export const pollInterval = (payment, polls = 0) => (shouldPoll(payment, polls) ? POLL_MS : false);

/** For a list of payments: ask again only while one of them is still open, and only for a limited time. */
export const anyOpen = (items) => Array.isArray(items) && items.some((p) => isOpen(p.status));
export const LIST_POLL_MS = 10000;
export const listPollInterval = (items, polls = 0) => (anyOpen(items) && polls < MAX_POLLS ? LIST_POLL_MS : false);

// ---------- idempotency ----------
const randomPart = () => {
  const c = typeof globalThis !== "undefined" ? globalThis.crypto : undefined;
  if (c?.randomUUID) return c.randomUUID();
  return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 12)}`;
};
/** A new key for a NEW payment attempt. Reuse the same key when the same request is repeated (double click, retry after a network error). */
export const newIdempotencyKey = () => `pay-${randomPart()}`.slice(0, 80);

/** Holds the key for the attempt in progress: the same key until the attempt is accepted, then a fresh one. */
export const keyHolder = (make = newIdempotencyKey) => {
  let key = null;
  let amount = null;
  return {
    /** The key for this amount. A different amount is a different request, so it gets a different key. */
    forAmount(paise) { if (key === null || amount !== paise) { key = make(); amount = paise; } return key; },
    reset() { key = null; amount = null; },
    peek: () => key,
  };
};

/** After a failed start request: keep the idempotency key only when the outcome is unknown (no answer, or a server error). Repeating the
 *  same request is then safe, it cannot create a second payment. A definite refusal (4xx) means nothing was created: the next try gets a fresh key. */
export const keepKeyAfter = (error) => !error?.response || error.response.status >= 500;

/** Can the Pay button be pressed? `busy` covers the request being sent; `payment` is the in-flight attempt, if any. */
export const payState = ({ summary, amountText, busy = false }) => {
  if (!summary) return { enabled: false, hint: null };
  if (busy) return { enabled: false, hint: null };
  if (!summary.can_pay) return { enabled: false, hint: summary.block_message || null };
  const a = amountState(amountText, summary.remaining_paise);
  return { enabled: a.ok, hint: a.hint };
};

/** Error code the API sent (PaymentError carries data.code), if any. */
export const errorCode = (error) => error?.response?.data?.data?.code || null;

// ---------- simple tables ----------
export const trainingFeeLine = (s) => {
  if (!s) return "";
  if (s.fee_paise === 0) return "No fee: nothing to pay.";
  return `${formatPaise(paidSoFar(s))} of ${formatPaise(s.fee_paise)} paid`;
};

/** Money that counts towards the agreed fee. `settled_paise` excludes an over-cap payment that is on hold awaiting its refund; older responses without it fall back to what is held. */
export const paidSoFar = (s) => (s && Number.isInteger(s.settled_paise) ? s.settled_paise : s ? s.collected_paise : 0);

/** What of the agreed fee is still unpaid (`due_paise`; falls back to `remaining_paise`). It can be above zero while a payment is on hold awaiting its refund. */
export const feeDue = (s) => (s && Number.isInteger(s.due_paise) ? s.due_paise : s ? s.remaining_paise : 0);

/** Share paid, as a whole-number percentage computed with integers only. */
export const paidPercent = (s) => (s && s.fee_paise > 0 ? Math.min(100, Math.floor((paidSoFar(s) * 100) / s.fee_paise)) : 0);

export const earningNote = (e) => {
  if (!e) return null;
  if (e.status === "REFUNDED") return "The institution's payment was refunded, so this earning was cancelled.";
  if (e.on_hold) return "An administrator is reviewing this payment. It will not be paid out until the review is finished.";
  if (e.status === "PENDING") return "Becomes available when the training is marked completed.";
  if (e.status === "AVAILABLE") return "Available. An administrator records the payout; IT BRIDGE does not collect bank or UPI details.";
  if (e.status === "PAID") return e.payout_reference ? `Payout recorded (reference ${e.payout_reference}).` : "Payout recorded.";
  return null;
};

export const COMMISSION_NOTE = "The commission rate shown is a development placeholder and may change before real payments are enabled.";
export const bpsToPercent = (bps) => (Number.isInteger(bps) ? `${Math.floor(bps / 100)}${bps % 100 ? `.${String(bps % 100).padStart(2, "0").replace(/0$/, "")}` : ""}%` : "");

export const INVOICE_NOT_TAX_NOTE = "This is an IT BRIDGE platform invoice. It is not a GST or tax invoice.";
