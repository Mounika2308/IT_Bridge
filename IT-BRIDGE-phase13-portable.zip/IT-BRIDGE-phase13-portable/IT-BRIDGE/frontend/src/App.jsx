import { Routes, Route } from "react-router-dom";
import { AuthProvider } from "./context/AuthContext.jsx";
import ProtectedRoute from "./routes/ProtectedRoute.jsx";
import Landing from "./pages/Landing.jsx";
import Login from "./pages/Login.jsx";
import Register from "./pages/Register.jsx";
import Home from "./pages/Home.jsx";
import MyRequirements from "./pages/MyRequirements.jsx";
import RequirementForm from "./pages/RequirementForm.jsx";
import Opportunities from "./pages/Opportunities.jsx";
import RequirementDetail from "./pages/RequirementDetail.jsx";
import TrainerSearch from "./pages/TrainerSearch.jsx";
import TrainerPublicProfile from "./pages/TrainerPublicProfile.jsx";
import RequirementMatches from "./pages/RequirementMatches.jsx";
import MyApplications from "./pages/MyApplications.jsx";
import RequirementApplications from "./pages/RequirementApplications.jsx";
import Trainings from "./pages/Trainings.jsx";
import TrainingDetail from "./pages/TrainingDetail.jsx";
import CalendarPage from "./pages/CalendarPage.jsx";
import Notifications from "./pages/Notifications.jsx";
import NotificationSettings from "./pages/NotificationSettings.jsx";
import InstitutionPublicProfile from "./pages/InstitutionPublicProfile.jsx";
import TrainerProfileSetup from "./pages/TrainerProfileSetup.jsx";
import InstitutionProfileSetup from "./pages/InstitutionProfileSetup.jsx";
import InstitutionPayments from "./pages/InstitutionPayments.jsx";
import InvoiceView from "./pages/InvoiceView.jsx";
import TrainerEarnings from "./pages/TrainerEarnings.jsx";

export default function App() {
  return (
    <AuthProvider>
      <Routes>
        <Route path="/" element={<Landing />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route element={<ProtectedRoute roles={["TRAINER"]} />}><Route path="/trainer" element={<Home title="Trainer dashboard" />} /><Route path="/trainer/profile" element={<TrainerProfileSetup />} /><Route path="/trainer/opportunities" element={<Opportunities />} /><Route path="/trainer/applications" element={<MyApplications />} /><Route path="/trainer/trainings" element={<Trainings />} /><Route path="/trainer/calendar" element={<CalendarPage />} /><Route path="/trainer/earnings" element={<TrainerEarnings />} /></Route>
        <Route element={<ProtectedRoute roles={["INSTITUTION"]} />}><Route path="/institution" element={<Home title="Institution dashboard" />} /><Route path="/institution/profile" element={<InstitutionProfileSetup />} /><Route path="/institution/requirements" element={<MyRequirements />} /><Route path="/institution/trainers" element={<TrainerSearch />} /><Route path="/institution/trainings" element={<Trainings />} /><Route path="/institution/calendar" element={<CalendarPage />} /><Route path="/institution/payments" element={<InstitutionPayments />} /><Route path="/institution/payments/:id/invoice" element={<InvoiceView />} /><Route path="/institution/requirements/:id/applications" element={<RequirementApplications />} /><Route path="/institution/requirements/:id/matches" element={<RequirementMatches />} /><Route path="/institution/requirements/new" element={<RequirementForm />} /><Route path="/institution/requirements/:id/edit" element={<RequirementForm />} /></Route>
        <Route element={<ProtectedRoute roles={["ADMIN"]} />}><Route path="/admin" element={<Home title="Admin dashboard" />} /></Route>
        <Route element={<ProtectedRoute />}><Route path="/requirements/:id" element={<RequirementDetail />} /><Route path="/notifications" element={<Notifications />} /><Route path="/notifications/settings" element={<NotificationSettings />} /><Route path="/trainers/:id" element={<TrainerPublicProfile />} /><Route path="/institutions/:id" element={<InstitutionPublicProfile />} /><Route path="/trainings/:id" element={<TrainingDetail />} /></Route>
        <Route path="*" element={<main className="p-10 text-center"><h1 className="text-2xl font-bold">Page not found</h1></main>} />
      </Routes>
    </AuthProvider>
  );
}
