import { createContext, useContext, useState, useCallback } from "react";
import * as svc from "../services/authService.js";
import { session } from "../services/api.js";

const AuthContext = createContext(null);
export const useAuth = () => useContext(AuthContext);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => session.get()?.user ?? null);
  const login = useCallback(async (p) => setUser(await svc.login(p)), []);
  const register = useCallback(async (p) => setUser(await svc.register(p)), []);
  const logout = useCallback(() => { svc.logout(); setUser(null); }, []);
  return <AuthContext.Provider value={{ user, login, register, logout }}>{children}</AuthContext.Provider>;
}
