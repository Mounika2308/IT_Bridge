import { Link } from "react-router-dom";
import Logo from "../components/Logo.jsx";

export default function AuthLayout({ title, subtitle, children }) {
  return (
    <main className="mx-auto flex min-h-screen max-w-md flex-col justify-center px-5 py-10">
      <Link to="/" className="mb-8 self-start" aria-label="IT BRIDGE home"><Logo /></Link>
      <h1 className="text-3xl font-extrabold">{title}</h1>
      <p className="mb-6 mt-1 text-steel">{subtitle}</p>
      <div className="rounded-card bg-white p-6 shadow-card">{children}</div>
    </main>
  );
}
