import { Link } from "react-router-dom";
import { useAuth } from "../context/AuthContext.jsx";
import Logo from "../components/Logo.jsx";
import Button from "../components/ui/Button.jsx";
import NotificationBell from "../components/NotificationBell.jsx";

const NAV = {
  TRAINER: [["/trainer", "Dashboard"], ["/trainer/opportunities", "Opportunities"], ["/trainer/applications", "Applications"], ["/trainer/trainings", "Trainings"], ["/trainer/earnings", "Earnings"], ["/trainer/calendar", "Calendar"], ["/trainer/profile", "My profile"]],
  INSTITUTION: [["/institution", "Dashboard"], ["/institution/requirements", "Requirements"], ["/institution/trainers", "Find trainers"], ["/institution/trainings", "Trainings"], ["/institution/payments", "Payments"], ["/institution/calendar", "Calendar"], ["/institution/profile", "Profile"]],
  ADMIN: [["/admin", "Dashboard"]],
};

export default function AppLayout({ children }) {
  const { user, logout } = useAuth();
  return (
    <div>
      <header className="border-b border-line bg-white print:hidden">
        <div className="mx-auto flex max-w-5xl flex-wrap items-center justify-between gap-3 px-5 py-3">
          <Link to="/" aria-label="IT BRIDGE home"><Logo /></Link>
          <nav aria-label="Main" className="order-3 flex w-full gap-1 overflow-x-auto sm:order-none sm:w-auto">
            {NAV[user.role].map(([to, label]) => (
              <Link key={to} to={to} className="whitespace-nowrap rounded-ctl px-3 py-2 text-sm font-semibold text-steel hover:bg-paper hover:text-ink">{label}</Link>
            ))}
          </nav>
          <div className="flex items-center gap-2"><NotificationBell /><Button variant="secondary" onClick={logout} as="a" href="/" className="!py-2">Log out</Button></div>
        </div>
      </header>
      <main className="mx-auto max-w-5xl px-5 py-8">{children}</main>
    </div>
  );
}
