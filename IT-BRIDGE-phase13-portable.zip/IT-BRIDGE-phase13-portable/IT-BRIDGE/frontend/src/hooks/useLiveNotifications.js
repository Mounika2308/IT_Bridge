import { useEffect, useRef, useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { session } from "../services/api.js";
import { handleSocketMessage } from "../utils/notifications.js";

const WS_URL = (import.meta.env.VITE_API_URL || "http://localhost:8000/api/v1")
  .replace(/\/api\/v1$/, "").replace(/^http/, "ws") + "/ws/notifications";

/** Keeps one WebSocket open while signed in. Reconnects with backoff and refreshes the list and badge as soon as the new socket is ready;
 *  `connected` lets callers fall back to polling. The token is sent in the first message, never in the URL. */
export default function useLiveNotifications(enabled) {
  const qc = useQueryClient();
  const [connected, setConnected] = useState(false);
  const [toast, setToast] = useState(null);
  const retry = useRef(0);

  useEffect(() => {
    if (!enabled) return undefined;
    let ws, timer, stopped = false;

    const open = () => {
      ws = new WebSocket(WS_URL);
      ws.onopen = () => ws.send(JSON.stringify({ token: session.get()?.access_token }));
      ws.onmessage = (ev) => handleSocketMessage(ev.data, { qc, setConnected, setToast, resetRetry: () => { retry.current = 0; } });
      ws.onclose = () => {
        setConnected(false);
        if (stopped) return;
        timer = setTimeout(open, Math.min(30000, 1000 * 2 ** retry.current++));
      };
    };
    open();
    const ping = setInterval(() => ws?.readyState === 1 && ws.send("ping"), 30000);
    return () => { stopped = true; clearTimeout(timer); clearInterval(ping); ws?.close(); };
  }, [enabled, qc]);

  useEffect(() => {
    if (!toast) return undefined;
    const t = setTimeout(() => setToast(null), 6000);
    return () => clearTimeout(t);
  }, [toast]);

  return { connected, toast, dismiss: () => setToast(null) };
}
