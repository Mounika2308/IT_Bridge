import { Link } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { trainingSummary } from "../services/trainingService.js";
import { useAuth } from "../context/AuthContext.jsx";

export default function TrainingSummary() {
  const { user } = useAuth();
  const q = useQuery({ queryKey: ["training-summary"], queryFn: trainingSummary });
  if (q.isLoading) return <p role="status" className="mt-6 text-sm text-steel">Loading trainings...</p>;
  if (q.isError) return <p role="alert" className="mt-6 text-sm text-danger">Could not load your trainings overview. <button className="underline" onClick={() => q.refetch()}>Try again</button></p>;
  const base = user.role === "TRAINER" ? "/trainer/trainings" : "/institution/trainings";
  const cards = [["Active", q.data.active], ["Upcoming", q.data.upcoming], ["In progress", q.data.in_progress], ["Completed", q.data.completed]];
  return (
    <section aria-label="Trainings overview" className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-4">
      {cards.map(([label, n]) => (
        <Link key={label} to={base} className="rounded-card bg-white p-4 shadow-card hover:border-span">
          <p className="text-2xl font-extrabold">{n}</p><p className="text-sm text-steel">{label} trainings</p>
        </Link>
      ))}
    </section>
  );
}
