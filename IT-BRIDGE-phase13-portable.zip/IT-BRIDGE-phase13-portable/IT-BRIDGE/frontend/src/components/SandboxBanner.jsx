import { SANDBOX_BANNER } from "../utils/payments.js";

/** Always shown wherever payments are shown while the server runs the sandbox provider. It moves no real money. */
export default function SandboxBanner({ show = true, className = "" }) {
  if (!show) return null;
  return (
    <p role="note" data-testid="sandbox-banner" className={`rounded-ctl border border-signal bg-signal-soft p-3 text-sm font-semibold text-ink print:hidden ${className}`}>
      {SANDBOX_BANNER}
    </p>
  );
}
