import { useEffect, useRef, useState } from "react";
import { Link } from "react-router-dom";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import Badge from "./ui/Badge.jsx";
import Button from "./ui/Button.jsx";
import Field from "./ui/Field.jsx";
import ProgressBar from "./ui/ProgressBar.jsx";
import SandboxBanner from "./SandboxBanner.jsx";
import { cancelPayment, simulateSandbox, startPayment, trainingPaymentSummary } from "../services/paymentService.js";
import { errorMessage } from "../services/api.js";
import {
  COMMISSION_NOTE, MAX_POLLS, REVIEW_NOTICE, amountState, bpsToPercent, earningNote, earningStatus, feeDue, formatPaise, keepKeyAfter, keyHolder, paiseToInput, paidPercent,
  payState, paymentStatus, pollInterval, refundText, statusText, trainingFeeLine,
} from "../utils/payments.js";

/** Every query that shows money. Invalidated after anything that can change it. */
export const PAYMENT_QUERY_KEYS = ["training-payment", "payments", "payments-summary", "earnings", "earnings-summary"];

export function AttemptRow({ p }) {
  const st = paymentStatus(p.status);
  return (
    <li className="flex flex-wrap items-center justify-between gap-2 rounded-ctl border border-line p-3 text-sm">
      <span><strong>{formatPaise(p.amount_paise)}</strong> <span className="text-steel">· attempt {p.attempt_no}</span></span>
      <span className="flex items-center gap-2">
        <Badge tone={st.tone}>{st.label}</Badge>
        {p.invoice_number && <Link className="font-semibold text-span-dark underline" to={`/institution/payments/${p.id}/invoice`}>Invoice {p.invoice_number}</Link>}
      </span>
      {refundText(p.refund) && <span className="w-full text-xs text-steel">{refundText(p.refund)}</span>}
    </li>
  );
}

/** The payment that is open right now: its honest status, what the user may do, and the sandbox controls. */
export function InProgress({ p, sandbox, pollingStopped, busy, onCancel, onSimulate, onRefresh }) {
  const st = paymentStatus(p.status);
  return (
    <div className="rounded-ctl border border-line bg-paper p-4" data-testid="in-progress">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <p className="font-semibold">{formatPaise(p.amount_paise)} <span className="font-normal text-steel">· attempt {p.attempt_no}</span></p>
        <Badge tone={st.tone}>{st.label}</Badge>
      </div>
      <p role="status" className="mt-2 text-sm" data-testid="status-text">{statusText(p)}</p>
      {pollingStopped && (
        <p className="mt-2 text-sm text-steel" data-testid="polling-stopped">
          This page stopped checking automatically. <button type="button" className="font-semibold text-span-dark underline" onClick={onRefresh}>Check now</button>
        </p>
      )}
      {sandbox && (
        <div className="mt-3" data-testid="sandbox-controls">
          <p className="mb-2 text-xs font-semibold text-steel">Sandbox only: choose what the simulated provider reports. No real money moves.</p>
          <div className="flex flex-wrap gap-2">
            <Button className="!py-2" disabled={busy} onClick={() => onSimulate("success")}>Simulate successful payment</Button>
            <Button variant="secondary" className="!py-2" disabled={busy} onClick={() => onSimulate("processing")}>Simulate processing</Button>
            <Button variant="secondary" className="!py-2" disabled={busy} onClick={() => onSimulate("fail")}>Simulate failure</Button>
          </div>
        </div>
      )}
      {p.status === "PENDING" && <Button variant="secondary" className="mt-3 !py-2" disabled={busy} onClick={onCancel}>Cancel this payment</Button>}
    </div>
  );
}

export function TrainerEarnings({ items, sandbox }) {
  if (!items || items.length === 0) return <p className="text-sm text-steel" data-testid="no-earnings">No payment has been received for this training yet. Your earning appears here once the institution pays.</p>;
  return (
    <div>
      <ul className="space-y-3">
        {items.map((e) => {
          const st = earningStatus(e.status);
          return (
            <li key={e.id} className="rounded-ctl border border-line p-3 text-sm">
              <div className="flex items-center justify-between gap-2"><span className="font-semibold">Net to you: {formatPaise(e.net_paise)}</span><Badge tone={st.tone}>{st.label}</Badge></div>
              <p className="mt-1 text-xs text-steel">Paid by institution {formatPaise(e.gross_paise)} − platform commission {formatPaise(e.commission_paise)} ({bpsToPercent(e.commission_bps)})</p>
              {earningNote(e) && <p className="mt-1 text-xs text-steel">{earningNote(e)}</p>}
            </li>
          );
        })}
      </ul>
      {sandbox && <p className="mt-2 text-xs text-steel">{COMMISSION_NOTE}</p>}
    </div>
  );
}

/** The whole panel as a pure function of its props, so every state can be rendered in a test. */
export function PaymentPanel({ summary, amountText, onAmount, busy = false, error, onPay, onCancel, onSimulate, onRefresh, pollingStopped = false }) {
  const s = summary;
  const institution = s.viewer_role === "INSTITUTION";
  const pay = payState({ summary: s, amountText, busy });
  const amount = amountState(amountText, s.remaining_paise);
  const open = institution ? s.in_progress : null;
  return (
    <section className="rounded-card bg-white p-6 shadow-card" aria-label="Payment">
      <h2 className="mb-3 text-lg font-bold">Payment</h2>
      <SandboxBanner show={s.sandbox} className="mb-4" />
      {s.fee_paise === 0 ? (
        <p className="text-sm text-steel" data-testid="no-fee">This training has no fee, so there is nothing to pay.</p>
      ) : (
        <div className="space-y-1">
          <ProgressBar value={paidPercent(s)} label={trainingFeeLine(s)} />
          {feeDue(s) > 0 && <p className="text-xs text-steel" data-testid="still-due">{formatPaise(feeDue(s))} still due</p>}
        </div>
      )}
      {s.under_review && <p role="status" className="mt-3 rounded-ctl bg-signal-soft p-3 text-sm" data-testid="under-review">{REVIEW_NOTICE}</p>}
      {error && <p role="alert" className="mt-3 rounded-ctl bg-red-50 p-3 text-sm text-danger">{error}</p>}

      {!institution && <div className="mt-4"><TrainerEarnings items={s.earnings} sandbox={s.sandbox} /></div>}

      {institution && open && (
        <div className="mt-4"><InProgress p={open} sandbox={s.sandbox} pollingStopped={pollingStopped} busy={busy} onCancel={onCancel} onSimulate={onSimulate} onRefresh={onRefresh} /></div>
      )}

      {institution && !open && s.can_pay && (
        <form className="mt-4 space-y-3" noValidate onSubmit={(e) => { e.preventDefault(); if (pay.enabled) onPay(amount.paise); }}>
          <Field label="Amount to pay (₹)" inputMode="decimal" autoComplete="off" value={amountText} error={amount.hint || undefined} onChange={(e) => onAmount(e.target.value)}
            hint="You can pay the full amount or part of it. The total can never exceed the agreed fee." />
          <Button type="submit" disabled={!pay.enabled}>{busy ? "Starting payment..." : s.sandbox ? "Start sandbox payment" : "Pay"}</Button>
        </form>
      )}
      {institution && !open && !s.can_pay && s.fee_paise > 0 && s.block_message && <p className="mt-4 text-sm text-steel" data-testid="blocked">{s.block_message}</p>}
      {!institution && !s.enabled && <p className="mt-3 text-sm text-steel">Payments are not enabled on this server.</p>}

      {institution && s.attempts && s.attempts.length > 0 && (
        <div className="mt-5">
          <h3 className="mb-2 text-sm font-bold">Recent payment attempts</h3>
          <ul className="space-y-2">{s.attempts.map((p) => <AttemptRow key={p.id} p={p} />)}</ul>
          <Link to="/institution/payments" className="mt-2 inline-block text-sm font-semibold text-span-dark underline">All payments</Link>
        </div>
      )}
    </section>
  );
}

export default function PaymentSection({ trainingId }) {
  const qc = useQueryClient();
  const [amount, setAmount] = useState(null);       // null = not edited yet: show what is still due
  const [polls, setPolls] = useState(0);
  const keys = useRef(keyHolder());
  const sending = useRef(false);

  const q = useQuery({
    queryKey: ["training-payment", trainingId],
    queryFn: () => trainingPaymentSummary(trainingId),
    retry: false,
    refetchInterval: (query) => pollInterval(query.state.data?.in_progress, polls),
  });
  const inProgress = q.data?.in_progress;
  useEffect(() => { setPolls((n) => (inProgress ? n + 1 : 0)); }, [q.dataUpdatedAt, !!inProgress]);

  const refresh = () => Promise.all(PAYMENT_QUERY_KEYS.map((key) => qc.invalidateQueries({ queryKey: [key] })));
  const start = useMutation({
    mutationFn: (paise) => startPayment(trainingId, paise, keys.current.forAmount(paise)),   // same key if this exact request is repeated
    // Returning the refresh keeps the button busy until the server's new state has arrived, so there is no moment where Pay looks free again.
    onSuccess: async () => { keys.current.reset(); setAmount(null); setPolls(0); await refresh(); sending.current = false; },
    onError: (error) => { sending.current = false; if (!keepKeyAfter(error)) keys.current.reset(); },   // outcome unknown: keep the key, a repeat cannot double-charge
  });
  const cancel = useMutation({ mutationFn: (id) => cancelPayment(id), onSuccess: refresh });
  const sim = useMutation({ mutationFn: ({ id, outcome }) => simulateSandbox(id, outcome), onSuccess: () => { setPolls(0); return refresh(); } });

  if (q.isLoading) return <section className="rounded-card bg-white p-6 shadow-card"><h2 className="mb-2 text-lg font-bold">Payment</h2><p role="status" className="text-sm text-steel">Loading payment details...</p></section>;
  if (q.isError) return <section className="rounded-card bg-white p-6 shadow-card"><h2 className="mb-2 text-lg font-bold">Payment</h2><p role="alert" className="text-sm text-danger">{errorMessage(q.error)}</p></section>;
  const s = q.data;
  const text = amount ?? paiseToInput(s.remaining_paise);
  const busy = start.isPending || cancel.isPending || sim.isPending;
  const failure = start.error || cancel.error || sim.error;

  return (
    <PaymentPanel summary={s} amountText={text} onAmount={setAmount} busy={busy} error={failure ? errorMessage(failure) : null}
      pollingStopped={!!inProgress && polls >= MAX_POLLS} onRefresh={() => { setPolls(0); q.refetch(); }}
      onPay={(paise) => { if (sending.current || start.isPending) return; sending.current = true; start.mutate(paise); }}
      onCancel={() => inProgress && !cancel.isPending && cancel.mutate(inProgress.id)}
      onSimulate={(outcome) => inProgress && !sim.isPending && sim.mutate({ id: inProgress.id, outcome })} />
  );
}
