import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Bell } from "lucide-react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import useLiveNotifications from "../hooks/useLiveNotifications.js";
import { listNotifications, markAllRead, markRead, unreadCount } from "../services/notificationService.js";
import { ago, openNotification, refreshNotifications } from "../utils/notifications.js";
import { errorMessage } from "../services/api.js";

export { ago };

/** The dropdown's list: loading, error, empty and rows. Rows show the title, the message (with interview date and time) and the age. */
export function NotificationList({ list, onOpen }) {
  return (
    <ul className="max-h-80 overflow-y-auto">
      {list.isLoading && <li className="p-4 text-sm text-steel" role="status">Loading...</li>}
      {list.isError && <li className="p-4 text-sm text-danger" role="alert">{errorMessage(list.error)}</li>}
      {list.data?.items.length === 0 && <li className="p-4 text-sm text-steel">No notifications yet.</li>}
      {list.data?.items.map((n) => (
        <li key={n.id}>
          <button onClick={() => onOpen(n)} data-unread={n.is_read ? "false" : "true"} className={`w-full border-b border-line px-4 py-3 text-left text-sm hover:bg-paper ${n.is_read ? "" : "bg-span-soft/50"}`}>
            <span className="block font-semibold">{n.title}</span>
            {n.body && <span className="block text-steel">{n.body}</span>}
            <span className="text-xs text-steel">{ago(n.created_at)}</span>
          </button>
        </li>
      ))}
    </ul>
  );
}

export default function NotificationBell() {
  const qc = useQueryClient();
  const nav = useNavigate();
  const [open, setOpen] = useState(false);
  const { connected, toast, dismiss } = useLiveNotifications(true);
  const count = useQuery({ queryKey: ["notif-count"], queryFn: unreadCount, refetchInterval: connected ? false : 60000 });
  const list = useQuery({ queryKey: ["notifications", "bell"], queryFn: () => listNotifications(1), enabled: open });
  const refresh = () => refreshNotifications(qc);
  const read = useMutation({ mutationFn: markRead, onSuccess: refresh });
  const readAll = useMutation({ mutationFn: markAllRead, onSuccess: refresh });
  const unread = count.data || 0;

  const go = (n) => { dismiss(); openNotification(n, { markRead: read.mutate, close: () => setOpen(false), navigate: nav }); };

  return (
    <div className="relative">
      <button onClick={() => setOpen(!open)} aria-label={`Notifications${unread ? `, ${unread} unread` : ""}`} aria-expanded={open}
        className="relative rounded-ctl p-2 text-steel hover:bg-paper hover:text-ink">
        <Bell size={20} />
        {unread > 0 && <span className="absolute -right-0.5 -top-0.5 min-w-[18px] rounded-full bg-danger px-1 text-center text-[11px] font-bold leading-[18px] text-white">{unread > 9 ? "9+" : unread}</span>}
      </button>
      {open && (
        <div role="dialog" aria-label="Notifications" className="absolute right-0 z-20 mt-2 w-[min(92vw,22rem)] rounded-card border border-line bg-white shadow-card">
          <div className="flex items-center justify-between border-b border-line px-4 py-3">
            <span className="font-bold">Notifications</span>
            {unread > 0 && <button className="text-xs font-semibold text-span-dark" onClick={() => readAll.mutate()}>Mark all read</button>}
          </div>
          <NotificationList list={list} onOpen={go} />
          <Link to="/notifications" onClick={() => setOpen(false)} className="block px-4 py-3 text-center text-sm font-semibold text-span-dark">See all</Link>
        </div>
      )}
      {toast && (
        <div role="status" className="fixed bottom-4 right-4 z-30 w-[min(92vw,20rem)] rounded-card border border-line bg-white p-4 shadow-card">
          <button onClick={() => go(toast)} className="text-left"><span className="block font-bold">{toast.title}</span>
            {toast.body && <span className="text-sm text-steel">{toast.body}</span>}</button>
          <button onClick={dismiss} aria-label="Dismiss" className="absolute right-2 top-1 text-steel">×</button>
        </div>
      )}
    </div>
  );
}
