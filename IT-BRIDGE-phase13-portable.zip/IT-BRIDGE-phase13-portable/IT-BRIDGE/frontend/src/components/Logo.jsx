export default function Logo() {
  return (
    <span className="flex items-center gap-2 font-display text-xl font-extrabold text-ink">
      <svg width="30" height="30" viewBox="0 0 30 30" aria-hidden="true">
        <circle cx="5" cy="21" r="3.5" fill="#12263A" />
        <circle cx="25" cy="21" r="3.5" fill="#F2A93B" />
        <path d="M5 21 Q15 3 25 21" fill="none" stroke="#0E7C86" strokeWidth="3" strokeLinecap="round" />
      </svg>
      IT BRIDGE
    </span>
  );
}
