import { Check, Minus, X } from "lucide-react";

const icon = {
  full: <Check size={16} className="mt-0.5 shrink-0 text-ok" aria-label="Matched" />,
  partial: <Minus size={16} className="mt-0.5 shrink-0 text-signal" aria-label="Partly matched" />,
  none: <X size={16} className="mt-0.5 shrink-0 text-danger" aria-label="Not matched" />,
};

export function ScoreBadge({ score }) {
  const tone = score >= 80 ? "bg-green-50 text-ok" : score >= 50 ? "bg-signal-soft text-ink" : "bg-paper text-steel";
  return <span className={`rounded-full px-3 py-1 text-sm font-bold ${tone}`}>{score}% match</span>;
}

export default function MatchBreakdown({ factors }) {
  return (
    <ul className="space-y-2 text-sm">
      {factors.map((f) => (
        <li key={f.key} className="flex gap-2">
          {icon[f.status]}
          <span className="flex-1"><strong>{f.label}:</strong> {f.detail}</span>
          <span className="text-xs text-steel">{f.points}/{f.weight}</span>
        </li>
      ))}
    </ul>
  );
}
