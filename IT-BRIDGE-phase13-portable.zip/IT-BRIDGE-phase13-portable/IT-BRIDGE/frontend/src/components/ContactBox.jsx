export default function ContactBox({ contact }) {
  if (!contact) return null;
  return (
    <div className="mt-3 rounded-ctl bg-green-50 p-3 text-sm">
      <p className="font-semibold">Contact details shared</p>
      <p>{contact.name} · <a className="text-span-dark underline" href={`mailto:${contact.email}`}>{contact.email}</a>{contact.phone ? ` · ${contact.phone}` : ""}</p>
    </div>
  );
}
