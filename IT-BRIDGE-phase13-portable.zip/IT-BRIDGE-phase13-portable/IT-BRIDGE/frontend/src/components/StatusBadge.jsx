import Badge from "./ui/Badge.jsx";

const TONES = { FILLED: "span", IN_PROGRESS: "ok", UPCOMING: "span", ENDED: "signal", ACTIVE: "ok", COMPLETED: "span", SELECTED: "ok", ACCEPTED: "ok", SHORTLISTED: "span", INTERVIEW: "span", UNDER_REVIEW: "span",
  APPLIED: "span", PENDING: "signal", REJECTED: "signal", WITHDRAWN: "signal", DECLINED: "signal", CANCELLED: "signal" };
const label = (s) => s.charAt(0) + s.slice(1).toLowerCase().replace("_", " ");

export default function StatusBadge({ status }) {
  return <Badge tone={TONES[status] || "span"}>{label(status)}</Badge>;
}
