import { Link } from "react-router-dom";
import { MapPin, Users, Clock, CalendarDays, BadgeCheck } from "lucide-react";
import Badge from "./ui/Badge.jsx";

export const money = (n) => `₹${Number(n).toLocaleString("en-IN")}`;
const tone = { OPEN: "ok", FILLED: "span", CLOSED: "signal", EXPIRED: "signal" };
const modeLabel = { ONLINE: "Online", OFFLINE: "Offline", HYBRID: "Hybrid" };

export default function RequirementCard({ r, to, actions }) {
  return (
    <article className="rounded-card bg-white p-5 shadow-card">
      <div className="flex items-start justify-between gap-3">
        <div>
          <h3 className="text-lg font-bold leading-snug"><Link to={to} className="hover:text-span-dark">{r.title}</Link></h3>
          <p className="mt-0.5 flex items-center gap-1 text-sm text-steel">
            {r.institution_name}{r.institution_verified && <BadgeCheck size={15} className="text-span" aria-label="Verified institution" />}
          </p>
        </div>
        <Badge tone={tone[r.status]}>{r.status.charAt(0) + r.status.slice(1).toLowerCase()}</Badge>
      </div>
      <p className="mt-3 text-sm font-semibold">{r.technology} · {money(r.budget_min)} to {money(r.budget_max)}</p>
      <ul className="mt-3 grid grid-cols-2 gap-y-2 text-sm text-steel">
        <li className="flex items-center gap-1.5"><MapPin size={15} />{r.location} ({modeLabel[r.mode]})</li>
        <li className="flex items-center gap-1.5"><Users size={15} />{r.student_count} students</li>
        <li className="flex items-center gap-1.5"><Clock size={15} />{r.duration_days} days, {r.sessions} sessions</li>
        <li className="flex items-center gap-1.5"><CalendarDays size={15} />Starts {r.start_date}</li>
      </ul>
      <p className="mt-3 text-xs text-steel">Apply by {r.application_deadline}</p>
      {actions && <div className="mt-4 flex flex-wrap gap-2">{actions}</div>}
    </article>
  );
}
