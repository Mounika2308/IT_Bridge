export default function EmptyState({ title, text, action }) {
  return (
    <div className="rounded-card border border-dashed border-line bg-white p-10 text-center">
      <h3 className="text-lg font-bold">{title}</h3>
      <p className="mx-auto mb-4 mt-1 max-w-sm text-sm text-steel">{text}</p>
      {action}
    </div>
  );
}
