const tones = { ok: "bg-green-50 text-ok", span: "bg-span-soft text-span-dark", signal: "bg-signal-soft text-ink", danger: "bg-red-50 text-danger", steel: "bg-paper text-steel" };
export default function Badge({ tone = "span", children }) {
  return <span className={`rounded-full px-2.5 py-1 text-xs font-semibold ${tones[tone] || tones.span}`}>{children}</span>;
}
