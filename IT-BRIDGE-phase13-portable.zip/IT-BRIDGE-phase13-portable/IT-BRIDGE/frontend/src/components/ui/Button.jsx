const variants = {
  primary: "bg-span text-white hover:bg-span-dark",
  secondary: "bg-white text-ink border border-line hover:border-ink",
  accent: "bg-signal text-ink hover:brightness-95",
};
export default function Button({ variant = "primary", as: Tag = "button", className = "", ...p }) {
  return (
    <Tag
      className={`inline-flex items-center justify-center gap-2 rounded-ctl px-5 py-3 text-sm font-semibold transition-colors disabled:opacity-50 ${variants[variant]} ${className}`}
      {...p}
    />
  );
}
