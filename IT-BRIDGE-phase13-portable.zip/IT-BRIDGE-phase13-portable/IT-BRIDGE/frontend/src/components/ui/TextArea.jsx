import { forwardRef, useId } from "react";

const TextArea = forwardRef(function TextArea({ label, error, hint, rows = 4, ...props }, ref) {
  const id = useId();
  return (
    <div>
      <label htmlFor={id} className="mb-1.5 block text-sm font-semibold">{label}</label>
      <textarea id={id} ref={ref} rows={rows} aria-invalid={!!error}
        className={`w-full rounded-ctl border bg-white px-3.5 py-3 text-sm ${error ? "border-danger" : "border-line"} focus:border-span`} {...props} />
      {hint && !error && <p className="mt-1 text-xs text-steel">{hint}</p>}
      {error && <p role="alert" className="mt-1 text-xs text-danger">{error}</p>}
    </div>
  );
});
export default TextArea;
