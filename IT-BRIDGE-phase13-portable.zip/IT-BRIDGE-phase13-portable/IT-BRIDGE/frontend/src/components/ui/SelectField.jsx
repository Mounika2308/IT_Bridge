import { forwardRef, useId } from "react";

const SelectField = forwardRef(function SelectField({ label, error, options, ...props }, ref) {
  const id = useId();
  return (
    <div>
      <label htmlFor={id} className="mb-1.5 block text-sm font-semibold">{label}</label>
      <select id={id} ref={ref} aria-invalid={!!error}
        className={`w-full rounded-ctl border bg-white px-3.5 py-3 text-sm ${error ? "border-danger" : "border-line"} focus:border-span`} {...props}>
        <option value="">Select</option>
        {options.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
      </select>
      {error && <p role="alert" className="mt-1 text-xs text-danger">{error}</p>}
    </div>
  );
});
export default SelectField;
