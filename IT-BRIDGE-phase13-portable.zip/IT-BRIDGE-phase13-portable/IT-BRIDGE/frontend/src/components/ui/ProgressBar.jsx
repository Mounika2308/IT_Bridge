export default function ProgressBar({ value, label = "Profile completion" }) {
  return (
    <div>
      <div className="mb-1.5 flex justify-between text-sm font-semibold">
        <span>{label}</span><span>{value}%</span>
      </div>
      <div role="progressbar" aria-label={label} aria-valuenow={value} aria-valuemin={0} aria-valuemax={100}
        className="h-2.5 overflow-hidden rounded-full bg-line">
        <div className="h-full rounded-full bg-span transition-[width] duration-300" style={{ width: `${value}%` }} />
      </div>
    </div>
  );
}
