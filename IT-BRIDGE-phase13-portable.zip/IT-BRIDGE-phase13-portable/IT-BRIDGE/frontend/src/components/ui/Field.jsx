import { forwardRef, useId } from "react";

const Field = forwardRef(function Field({ label, error, hint, className = "", ...props }, ref) {
  const id = useId();
  return (
    <div className={className}>
      <label htmlFor={id} className="mb-1.5 block text-sm font-semibold">{label}</label>
      <input
        id={id}
        ref={ref}
        aria-invalid={!!error}
        aria-describedby={error ? `${id}-e` : undefined}
        className={`w-full rounded-ctl border bg-white px-3.5 py-3 text-sm ${error ? "border-danger" : "border-line"} focus:border-span`}
        {...props}
      />
      {hint && !error && <p className="mt-1 text-xs text-steel">{hint}</p>}
      {error && <p id={`${id}-e`} role="alert" className="mt-1 text-xs text-danger">{error}</p>}
    </div>
  );
});
export default Field;
