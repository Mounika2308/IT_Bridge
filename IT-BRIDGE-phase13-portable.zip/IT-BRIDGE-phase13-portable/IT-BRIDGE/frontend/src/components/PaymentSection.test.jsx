import { renderToStaticMarkup } from "react-dom/server";
import { MemoryRouter } from "react-router-dom";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { describe, expect, it, vi } from "vitest";

// useAuth() is null without an AuthProvider, so pages that call it need this mock under real vitest. The role can be switched per test.
vi.mock("../context/AuthContext.jsx", () => ({ useAuth: () => ({ user: { role: globalThis.__role || "TRAINER", full_name: "Test User" } }) }));
vi.mock("../layouts/AppLayout.jsx", () => ({ default: ({ children }) => children }));

import PaymentSection, { AttemptRow, PaymentPanel } from "./PaymentSection.jsx";
import { InstitutionPaymentCard, PaymentDashboardCard, TrainerEarningsCard } from "./PaymentSummaryCard.jsx";
import SandboxBanner from "./SandboxBanner.jsx";
import InstitutionPayments, { PaymentList, PaymentRow } from "../pages/InstitutionPayments.jsx";
import TrainerEarnings, { EarningRow, EarningsList } from "../pages/TrainerEarnings.jsx";
import { InvoiceDocument } from "../pages/InvoiceView.jsx";
import Home from "../pages/Home.jsx";
import Landing from "../pages/Landing.jsx";

const noop = () => {};
const html = (el, qc = new QueryClient()) => renderToStaticMarkup(<QueryClientProvider client={qc}><MemoryRouter>{el}</MemoryRouter></QueryClientProvider>);
const button = (h, label) => h.match(new RegExp(`<button[^>]*>${label}</button>`))?.[0] ?? "";
const disabled = (h, label) => { const b = button(h, label); expect(b).not.toBe(""); return /\sdisabled(=""|\s|>)/.test(b); };

const payment = (over = {}) => ({ id: 7, training_id: 5, training_title: "Python workshop", attempt_no: 1, amount_paise: 1000000, currency: "INR", status: "PENDING", failure_reason: null,
  created_at: "2030-03-01T10:00:00Z", paid_at: null, expires_at: null, sandbox: true, under_review: false, invoice_number: null, refund: null, ...over });
const summary = (over = {}) => ({ training_id: 5, currency: "INR", fee_paise: 1000000, collected_paise: 0, remaining_paise: 1000000, enabled: true, sandbox: true, sandbox_notice: "x",
  viewer_role: "INSTITUTION", under_review: false, can_pay: true, block_reason: null, block_message: null, in_progress: null, attempts: [], ...over });
const panel = (s, over = {}) => html(<PaymentPanel summary={s} amountText="10000" onAmount={noop} onPay={noop} onCancel={noop} onSimulate={noop} onRefresh={noop} {...over} />);

describe("sandbox banner", () => {
  it("says plainly that no real money is processed, and only when asked to show", () => {
    expect(html(<SandboxBanner />)).toContain("no real money");
    expect(html(<SandboxBanner show={false} />)).toBe("");
  });
});

describe("payment panel: starting a payment", () => {
  it("shows the sandbox banner, the fee, what is due and an enabled button for a valid amount", () => {
    const h = panel(summary());
    expect(h).toContain('data-testid="sandbox-banner"');
    expect(h).toContain("₹0 of ₹10,000 paid");
    expect(h).toContain("₹10,000 still due");
    expect(disabled(h, "Start sandbox payment")).toBe(false);
  });
  it("does not show a sandbox banner or sandbox wording for a non-sandbox provider", () => {
    const h = panel(summary({ sandbox: false }));
    expect(h).not.toContain("sandbox-banner");
    expect(button(h, "Pay")).not.toBe("");
  });
  it("disables the button and says so while the request is being sent (duplicate-submission guard)", () => {
    const h = panel(summary(), { busy: true });
    expect(disabled(h, "Starting payment...")).toBe(true);
  });
  it("disables the button and explains an amount above what is due", () => {
    const h = panel(summary(), { amountText: "10000.01" });
    expect(disabled(h, "Start sandbox payment")).toBe(true);
    expect(h).toContain("That is more than the ₹10,000 still due.");
  });
  it("disables the button for an empty or unreadable amount", () => {
    expect(disabled(panel(summary(), { amountText: "" }), "Start sandbox payment")).toBe(true);
    expect(disabled(panel(summary(), { amountText: "ten" }), "Start sandbox payment")).toBe(true);
  });
  it("shows an error from the server", () => expect(panel(summary(), { error: "Cannot reach the server. Check your connection." })).toContain('role="alert"'));
});

describe("payment panel: processing, honestly", () => {
  it("a pending payment says it is waiting, offers sandbox controls and cancel, and hides the pay form", () => {
    const h = panel(summary({ can_pay: false, block_reason: "IN_PROGRESS", block_message: "A payment for this training is already in progress.", in_progress: payment() }));
    expect(h).toContain("Waiting for the payment to be completed");
    expect(h).toContain("Awaiting payment");
    expect(h).toContain('data-testid="sandbox-controls"');
    expect(h).toContain("No real money moves");
    expect(h).toContain("Simulate successful payment");
    expect(h).toContain("Cancel this payment");
    expect(h).not.toContain("Start sandbox payment");
    expect(h).not.toContain("Payment confirmed");
  });
  it("a processing payment tells the user not to pay again and cannot be cancelled", () => {
    const h = panel(summary({ can_pay: false, in_progress: payment({ status: "PROCESSING" }) }));
    expect(h).toContain("Do not pay again");
    expect(h).not.toContain("Cancel this payment");
    expect(h).not.toContain("Payment confirmed");
  });
  it("never shows the pay form next to an open payment, even if a stale summary still says can_pay", () => {
    const h = panel(summary({ can_pay: true, in_progress: payment() }));
    expect(h).toContain('data-testid="in-progress"');
    expect(h).not.toContain("Start sandbox payment");
    expect(h).not.toContain("Amount to pay");
  });
  it("an institution never sees the trainer's earnings block", () => {
    expect(panel(summary())).not.toContain("no-earnings");
    expect(panel(summary())).not.toContain("Net to you");
  });
  it("sandbox controls never appear when the provider is not the sandbox", () => {
    const h = panel(summary({ sandbox: false, can_pay: false, in_progress: payment({ sandbox: false }) }));
    expect(h).not.toContain("sandbox-controls");
    expect(h).not.toContain("Simulate");
  });
  it("controls are disabled while another request is running", () => {
    const h = panel(summary({ can_pay: false, in_progress: payment() }), { busy: true });
    expect(disabled(h, "Simulate successful payment")).toBe(true);
    expect(disabled(h, "Cancel this payment")).toBe(true);
  });
  it("says the page stopped checking after the poll limit and offers a manual check", () => {
    const s = summary({ can_pay: false, in_progress: payment({ status: "PROCESSING" }) });
    expect(panel(s, { pollingStopped: true })).toContain('data-testid="polling-stopped"');
    expect(panel(s, { pollingStopped: false })).not.toContain("polling-stopped");
  });
});

describe("payment panel: failure, success and special states", () => {
  it("after a failure nothing is open, the failure is listed, and the user can try again", () => {
    const h = panel(summary({ attempts: [payment({ status: "FAILED", failure_reason: "Declined" })] }));
    expect(h).toContain("Failed");
    expect(h).toContain("Start sandbox payment");
    expect(h).not.toContain("in-progress");
  });
  it("after full payment: 100%, the server's reason, an invoice link and no form", () => {
    const h = panel(summary({ collected_paise: 1000000, remaining_paise: 0, can_pay: false, block_reason: "FULLY_PAID", block_message: "The agreed fee has been paid in full.",
      attempts: [payment({ status: "SUCCEEDED", invoice_number: "ITB-2030-000001" })] }));
    expect(h).toContain("₹10,000 of ₹10,000 paid");
    expect(h).toContain("The agreed fee has been paid in full.");
    expect(h).toContain('href="/institution/payments/7/invoice"');
    expect(h).toContain("ITB-2030-000001");
    expect(h).not.toContain("Start sandbox payment");
  });
  it("an over-cap payment on hold awaiting refund is NOT shown as paid in full, and the amount still due is shown", () => {
    const msg = "A payment for this training is on hold until an administrator refunds it, so a new payment cannot be started yet. ₹4,000 of the agreed fee is still due and can be paid once that refund is complete.";
    const h = panel(summary({ collected_paise: 1400000, settled_paise: 600000, remaining_paise: 0, due_paise: 400000, can_pay: false, block_reason: "AWAITING_REFUND", block_message: msg }));
    expect(h).toContain("₹6,000 of ₹10,000 paid");
    expect(h).toContain("₹4,000 still due");
    expect(h).toContain(msg);
    expect(h).not.toContain("paid in full");
    expect(h).not.toContain("Start sandbox payment");
  });
  it("a partly paid training shows what is left", () => {
    const h = panel(summary({ collected_paise: 333333, remaining_paise: 666667 }));
    expect(h).toContain("₹3,333.33 of ₹10,000 paid");
    expect(h).toContain("₹6,666.67 still due");
  });
  it("a refunded payment says so", () => {
    expect(html(<AttemptRow p={payment({ status: "SUCCEEDED", refund: { status: "SUCCEEDED", credit_note_number: "ITB-CN-2030-000001" } })} />)).toContain("Refunded in full (credit note ITB-CN-2030-000001).");
  });
  it("a free training has nothing to pay and no form", () => {
    const h = panel(summary({ fee_paise: 0, remaining_paise: 0, can_pay: false, block_reason: "NO_FEE", block_message: "This training has no fee, so there is nothing to pay." }));
    expect(h).toContain('data-testid="no-fee"');
    expect(h).not.toContain("Start sandbox payment");
    expect(h).not.toContain("role=\"progressbar\"");
  });
  it("shows the server's reason when payment is blocked", () => {
    const h = panel(summary({ can_pay: false, block_reason: "TRAINING_CANCELLED", block_message: "This training was cancelled, so it cannot be paid for." }));
    expect(h).toContain('data-testid="blocked"');
    expect(h).toContain("This training was cancelled");
  });
  it("shows that payments are not enabled", () => {
    expect(panel(summary({ enabled: false, sandbox: false, can_pay: false, block_reason: "DISABLED", block_message: "Payments are not enabled on this server." }))).toContain("Payments are not enabled on this server.");
  });
  it("tells the institution a payment is under review, without any commission figure", () => {
    const h = panel(summary({ under_review: true }));
    expect(h).toContain('data-testid="under-review"');
    expect(h).not.toContain("ommission");
  });
});

describe("payment panel: the trainer's view", () => {
  const earning = (over = {}) => ({ id: 1, training_id: 5, gross_paise: 1000000, commission_paise: 100000, net_paise: 900000, commission_bps: 1000, status: "PENDING", payout_reference: null, on_hold: false, ...over });
  const trainer = (over = {}) => summary({ viewer_role: "TRAINER", can_pay: undefined, attempts: undefined, in_progress: undefined, earnings: [earning()], ...over });
  it("shows gross, commission and net, the placeholder note, and no way to pay", () => {
    const h = panel(trainer());
    expect(h).toContain("Net to you: ₹9,000");
    expect(h).toContain("platform commission ₹1,000 (10%)");
    expect(h).toContain("development placeholder");
    expect(h).not.toContain("Start sandbox payment");
    expect(h).not.toContain("Simulate");
    expect(h).not.toContain("Cancel this payment");
  });
  it("says honestly when nothing has been received", () => {
    expect(panel(trainer({ earnings: [] }))).toContain('data-testid="no-earnings"');
  });
  it("shows an earning that became available or was paid out", () => {
    expect(panel(trainer({ earnings: [earning({ status: "AVAILABLE" })] }))).toContain("Available");
    expect(panel(trainer({ earnings: [earning({ status: "PAID", payout_reference: "BATCH-7" })] }))).toContain("BATCH-7");
  });
});

describe("payment section (with data from the server)", () => {
  const cached = (data) => { const qc = new QueryClient(); qc.setQueryData(["training-payment", "5"], data); return qc; };
  it("shows loading before the server has answered", () => expect(html(<PaymentSection trainingId="5" />)).toContain("Loading payment details..."));
  it("renders the server's summary, with the amount box pre-filled with what is still due", () => {
    const h = html(<PaymentSection trainingId="5" />, cached(summary()));
    expect(h).toContain("Amount to pay");
    expect(h).toContain('value="10000"');
    expect(h).toContain("₹10,000 still due");
  });
  it("shows an in-flight payment from the server and no pay form", () => {
    const h = html(<PaymentSection trainingId="5" />, cached(summary({ can_pay: false, in_progress: payment({ status: "PROCESSING" }) })));
    expect(h).toContain("Do not pay again");
    expect(h).not.toContain("Start sandbox payment");
  });
});

describe("institution payment history", () => {
  const page = (items, total = items.length) => ({ data: { items, total, page: 1, page_size: 10 } });
  it("shows loading, an error with retry, and the empty states", () => {
    expect(html(<PaymentList q={{ isLoading: true }} page={1} onPage={noop} />)).toContain("Loading payments...");
    const err = html(<PaymentList q={{ isError: true, error: new Error("x") }} page={1} onPage={noop} />);
    expect(err).toContain('role="alert"'); expect(err).toContain("Try again");
    expect(html(<PaymentList q={page([])} page={1} onPage={noop} />)).toContain("No payments yet");
    expect(html(<PaymentList q={page([])} page={1} onPage={noop} filtered />)).toContain("No payments with this status");
  });
  it("lists payments with formatted amounts, status badges and links", () => {
    const h = html(<PaymentList q={page([payment({ status: "SUCCEEDED", invoice_number: "ITB-2030-000001", paid_at: "2030-03-02T00:00:00Z" }), payment({ id: 8, status: "FAILED", failure_reason: "Declined", amount_paise: 12345 })])} page={1} onPage={noop} />);
    expect(h).toContain("₹10,000"); expect(h).toContain("₹123.45");
    expect(h).toContain("Paid"); expect(h).toContain("Failed"); expect(h).toContain("Declined");
    expect(h).toContain('href="/institution/payments/7/invoice"');
    expect(h).toContain('href="/trainings/5"');
  });
  it("links an open payment back to its training", () => expect(html(<PaymentRow p={payment()} />)).toContain("Open payment"));
  it("shows pagination only when there is more than one page", () => {
    expect(html(<PaymentList q={page([payment()], 25)} page={2} onPage={noop} />)).toContain("Page 2 of 3");
    expect(html(<PaymentList q={page([payment()], 3)} page={1} onPage={noop} />)).not.toContain("Pagination");
  });
  it("the page shows its title and the card from the server's summary", () => {
    globalThis.__role = "INSTITUTION";
    const qc = new QueryClient();
    qc.setQueryData(["payments-summary"], { paid_paise: 2000000, refunded_paise: 500000, net_paid_paise: 1500000, in_progress: 1, attempts: 4, enabled: true, sandbox: true });
    qc.setQueryData(["payments", "", 1], { items: [payment()], total: 1, page: 1, page_size: 10 });
    const h = html(<InstitutionPayments />, qc);
    expect(h).toContain("Payments"); expect(h).toContain("₹15,000"); expect(h).toContain("₹5,000");
    expect((h.match(/data-testid="sandbox-banner"/g) || []).length).toBe(1);
    globalThis.__role = "TRAINER";
  });
});

describe("trainer earnings", () => {
  const earning = (over = {}) => ({ id: 1, training_id: 5, training_title: "Python workshop", gross_paise: 1000000, commission_paise: 100000, net_paise: 900000, commission_bps: 1000, currency: "INR",
    status: "AVAILABLE", available_at: null, paid_at: null, payout_reference: null, on_hold: false, sandbox: true, created_at: "2030-03-02T00:00:00Z", ...over });
  const page = (items, total = items.length) => ({ data: { items, total, page: 1, page_size: 10 } });
  it("shows gross, commission, net and the status of each earning", () => {
    const h = html(<EarningRow e={earning()} />);
    expect(h).toContain("₹10,000"); expect(h).toContain("₹1,000"); expect(h).toContain("₹9,000"); expect(h).toContain("Commission (10%)"); expect(h).toContain("Available");
  });
  it("never shows the paying institution or provider details", () => {
    const h = html(<EarningRow e={earning()} />);
    expect(h).not.toContain("provider"); expect(h).not.toContain("institution_id"); expect(h).not.toContain("payer");
  });
  it("shows loading, error, empty and paged states", () => {
    expect(html(<EarningsList q={{ isLoading: true }} page={1} onPage={noop} />)).toContain("Loading earnings...");
    expect(html(<EarningsList q={{ isError: true, error: new Error("x") }} page={1} onPage={noop} />)).toContain("Try again");
    expect(html(<EarningsList q={page([])} page={1} onPage={noop} />)).toContain("No earnings yet");
    expect(html(<EarningsList q={page([])} page={1} onPage={noop} filtered />)).toContain("No earnings with this status");
    expect(html(<EarningsList q={page([earning()], 21)} page={1} onPage={noop} />)).toContain("Page 1 of 3");
  });
  it("a refunded earning is explained and a paid one shows its reference", () => {
    expect(html(<EarningRow e={earning({ status: "REFUNDED" })} />)).toContain("was refunded");
    expect(html(<EarningRow e={earning({ status: "PAID", payout_reference: "BATCH-7" })} />)).toContain("BATCH-7");
  });
  it("the page says that no bank or UPI details are collected and shows the placeholder-commission note", () => {
    globalThis.__role = "TRAINER";
    const qc = new QueryClient();
    qc.setQueryData(["earnings-summary"], { pending_paise: 100, available_paise: 900000, paid_paise: 0, refunded_paise: 0, commission_paise: 100000, count: 1, commission_is_placeholder: true, enabled: true, sandbox: true });
    qc.setQueryData(["earnings", "", 1], { items: [earning()], total: 1, page: 1, page_size: 10 });
    const h = html(<TrainerEarnings />, qc);
    expect(h).toContain("does not collect bank or UPI details"); expect(h).toContain("development placeholder");
    expect((h.match(/data-testid="sandbox-banner"/g) || []).length).toBe(1);
  });
});

describe("dashboard cards", () => {
  it("institution card shows net paid, refunded and in-progress counts, and links to the history", () => {
    const h = html(<InstitutionPaymentCard q={{ data: { net_paid_paise: 1500000, refunded_paise: 500000, in_progress: 2, enabled: true, sandbox: true } }} />);
    expect(h).toContain("₹15,000"); expect(h).toContain("₹5,000"); expect(h).toContain('href="/institution/payments"'); expect(h).toContain("sandbox-banner");
  });
  it("trainer card shows pending, available and paid out, and links to the earnings", () => {
    const h = html(<TrainerEarningsCard q={{ data: { pending_paise: 100, available_paise: 250050, paid_paise: 0, commission_is_placeholder: true, sandbox: true } }} />);
    expect(h).toContain("₹1"); expect(h).toContain("₹2,500.50"); expect(h).toContain('href="/trainer/earnings"'); expect(h).toContain("development placeholder");
  });
  it("cards handle loading and errors", () => {
    expect(html(<InstitutionPaymentCard q={{ isLoading: true }} />)).toContain("Loading payments...");
    expect(html(<TrainerEarningsCard q={{ isError: true, error: new Error("x") }} />)).toContain('role="alert"');
  });
  it("the dashboard shows the right card per role and nothing for an admin", () => {
    const qc = new QueryClient();
    qc.setQueryData(["payments-summary"], { net_paid_paise: 100, refunded_paise: 0, in_progress: 0, enabled: true, sandbox: false });
    qc.setQueryData(["earnings-summary"], { pending_paise: 0, available_paise: 0, paid_paise: 0, commission_is_placeholder: false, sandbox: false });
    expect(html(<PaymentDashboardCard role="INSTITUTION" />, qc)).toContain("Payment history and invoices");
    expect(html(<PaymentDashboardCard role="TRAINER" />, qc)).toContain("Earnings in detail");
    expect(html(<PaymentDashboardCard role="ADMIN" />, qc)).toBe("");
  });
  it("is part of the institution and trainer dashboards, not the admin one", () => {
    const qc = new QueryClient();
    qc.setQueryData(["payments-summary"], { net_paid_paise: 100, refunded_paise: 0, in_progress: 0, enabled: true, sandbox: false });
    qc.setQueryData(["earnings-summary"], { pending_paise: 0, available_paise: 0, paid_paise: 0, commission_is_placeholder: false, sandbox: false });
    globalThis.__role = "INSTITUTION"; expect(html(<Home title="D" />, qc)).toContain("Payment history and invoices");
    globalThis.__role = "TRAINER"; expect(html(<Home title="D" />, qc)).toContain("Earnings in detail");
    globalThis.__role = "ADMIN"; const admin = html(<Home title="D" />, qc);
    expect(admin).not.toContain("Payment history"); expect(admin).not.toContain("Earnings in detail");
    globalThis.__role = "TRAINER";
  });
});

describe("invoice display", () => {
  const inv = (over = {}) => ({ number: "ITB-2030-000001", issued_at: "2030-03-02T10:00:00Z", amount_paise: 1234567, currency: "INR", payment_id: 7, training_id: 5, paid_at: "2030-03-02T09:59:00Z",
    billed_to: { name: "Sunrise College", location: "Pune" }, issued_by: "IT BRIDGE (platform)", trainer_name: "Asha Rao", description: "Training fee: Python workshop",
    training: { title: "Python workshop", technology: "Python", start_date: "2030-03-01", end_date: "2030-03-10" }, sandbox: false, notice: "This is an IT BRIDGE platform invoice. It is not a GST or tax invoice.",
    sandbox_notice: null, credit_note: null, ...over });
  it("shows the number, parties, training, amount and the not-a-tax-invoice notice", () => {
    const h = html(<InvoiceDocument inv={inv()} />);
    expect(h).toContain("ITB-2030-000001"); expect(h).toContain("Sunrise College"); expect(h).toContain("Pune"); expect(h).toContain("Asha Rao"); expect(h).toContain("Python workshop");
    expect(h).toContain("₹12,345.67"); expect(h).toContain("2030-03-02"); expect(h).toContain("not a GST or tax invoice"); expect(h).toContain("IT BRIDGE (platform)");
  });
  it("never shows commission or the trainer's net to the institution", () => {
    const h = html(<InvoiceDocument inv={inv()} />);
    expect(h).not.toContain("ommission"); expect(h).not.toContain("Net to"); expect(h).not.toContain("net_paise");
  });
  it("marks a sandbox invoice as having no financial value", () => {
    expect(html(<InvoiceDocument inv={inv({ sandbox: true, sandbox_notice: "SANDBOX: no real money was processed." })} />)).toContain("no real money was processed");
    expect(html(<InvoiceDocument inv={inv()} />)).not.toContain("invoice-sandbox");
  });
  it("shows a credit note for a refund and keeps the original invoice figures", () => {
    const h = html(<InvoiceDocument inv={inv({ credit_note: { number: "ITB-CN-2030-000001", amount_paise: 1234567, issued_at: "2030-03-05T00:00:00Z" } })} />);
    expect(h).toContain('data-testid="credit-note"'); expect(h).toContain("ITB-CN-2030-000001"); expect(h).toContain("The invoice above is unchanged");
    expect(h).toContain("ITB-2030-000001");
  });
  it("is hidden from print only where it should be: the page chrome, not the document", () => {
    const h = html(<InvoiceDocument inv={inv()} />);
    expect(h).toContain("print:shadow-none");
    expect(h).not.toMatch(/print:hidden[^"]*"[^>]*data-testid="invoice"/);
  });
});

describe("landing page", () => {
  it("no longer claims secure payments, and says real payments are not enabled", () => {
    const h = html(<Landing />);
    expect(h).not.toContain("Secure payments");
    expect(h).toContain("Real online payments are not enabled yet");
  });
});
