import { Link } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import SandboxBanner from "./SandboxBanner.jsx";
import { earningsSummary, paymentsSummary } from "../services/paymentService.js";
import { errorMessage } from "../services/api.js";
import { COMMISSION_NOTE, formatPaise } from "../utils/payments.js";

const Shell = ({ label, children }) => <section aria-label={label} className="mt-6 rounded-card bg-white p-5 shadow-card">{children}</section>;

/** Dashboard card for an institution. `q` is a react-query result of paymentsSummary. */
export function InstitutionPaymentCard({ q, banner = true }) {
  if (q.isLoading) return <Shell label="Payments"><p role="status" className="text-sm text-steel">Loading payments...</p></Shell>;
  if (q.isError) return <Shell label="Payments"><p role="alert" className="text-sm text-danger">{errorMessage(q.error)}</p></Shell>;
  if (!q.data) return null;
  const d = q.data;
  return (
    <Shell label="Payments">
      <h2 className="text-lg font-bold">Payments</h2>
      <SandboxBanner show={banner && d.sandbox} className="mt-3" />
      {!d.enabled && <p className="mt-2 text-sm text-steel">Payments are not enabled on this server.</p>}
      <dl className="mt-3 grid grid-cols-2 gap-3 text-sm sm:grid-cols-3">
        <div><dt className="text-xs text-steel">Paid</dt><dd className="text-xl font-extrabold" data-testid="paid">{formatPaise(d.net_paid_paise)}</dd></div>
        <div><dt className="text-xs text-steel">Refunded</dt><dd className="text-xl font-extrabold" data-testid="refunded">{formatPaise(d.refunded_paise)}</dd></div>
        <div><dt className="text-xs text-steel">In progress</dt><dd className="text-xl font-extrabold" data-testid="in-progress-count">{d.in_progress}</dd></div>
      </dl>
      <Link to="/institution/payments" className="mt-3 inline-block text-sm font-semibold text-span-dark underline">Payment history and invoices</Link>
    </Shell>
  );
}

/** Dashboard card for a trainer. `q` is a react-query result of earningsSummary. */
export function TrainerEarningsCard({ q, banner = true }) {
  if (q.isLoading) return <Shell label="Earnings"><p role="status" className="text-sm text-steel">Loading earnings...</p></Shell>;
  if (q.isError) return <Shell label="Earnings"><p role="alert" className="text-sm text-danger">{errorMessage(q.error)}</p></Shell>;
  if (!q.data) return null;
  const d = q.data;
  return (
    <Shell label="Earnings">
      <h2 className="text-lg font-bold">Earnings</h2>
      <SandboxBanner show={banner && d.sandbox} className="mt-3" />
      <dl className="mt-3 grid grid-cols-2 gap-3 text-sm sm:grid-cols-3">
        <div><dt className="text-xs text-steel">Pending completion</dt><dd className="text-xl font-extrabold" data-testid="pending">{formatPaise(d.pending_paise)}</dd></div>
        <div><dt className="text-xs text-steel">Available</dt><dd className="text-xl font-extrabold" data-testid="available">{formatPaise(d.available_paise)}</dd></div>
        <div><dt className="text-xs text-steel">Paid out</dt><dd className="text-xl font-extrabold" data-testid="paid-out">{formatPaise(d.paid_paise)}</dd></div>
      </dl>
      {d.commission_is_placeholder && <p className="mt-2 text-xs text-steel">{COMMISSION_NOTE}</p>}
      <Link to="/trainer/earnings" className="mt-3 inline-block text-sm font-semibold text-span-dark underline">Earnings in detail</Link>
    </Shell>
  );
}

export function PaymentDashboardCard({ role }) {
  const inst = role === "INSTITUTION";
  const pay = useQuery({ queryKey: ["payments-summary"], queryFn: paymentsSummary, enabled: inst, retry: false });
  const earn = useQuery({ queryKey: ["earnings-summary"], queryFn: earningsSummary, enabled: role === "TRAINER", retry: false });
  if (inst) return <InstitutionPaymentCard q={pay} />;
  if (role === "TRAINER") return <TrainerEarningsCard q={earn} />;
  return null;
}
