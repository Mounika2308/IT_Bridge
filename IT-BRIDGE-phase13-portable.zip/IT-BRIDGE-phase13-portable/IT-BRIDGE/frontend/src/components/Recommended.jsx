import { Link } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { getRecommendations } from "../services/matchingService.js";
import { ScoreBadge } from "./MatchBreakdown.jsx";

export default function Recommended() {
  const q = useQuery({ queryKey: ["recommendations"], queryFn: getRecommendations });
  if (q.isLoading) return <p role="status" className="mt-6 text-sm text-steel">Finding opportunities for you...</p>;
  if (q.isError) return null;
  return (
    <section className="mt-6 rounded-card bg-white p-5 shadow-card">
      <h2 className="mb-3 text-lg font-bold">Recommended for you</h2>
      {q.data.length === 0 ? (
        <p className="text-sm text-steel">Add your skills to your profile to see opportunities that fit you.</p>
      ) : (
        <ul className="divide-y divide-line">
          {q.data.map((r) => (
            <li key={r.requirement_id} className="flex items-center justify-between gap-3 py-3">
              <div>
                <Link to={`/requirements/${r.requirement_id}`} className="font-semibold hover:text-span-dark">{r.title}</Link>
                <p className="text-xs text-steel">{r.institution_name} · {r.location} · starts {r.start_date}</p>
              </div>
              <ScoreBadge score={r.score} />
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}
