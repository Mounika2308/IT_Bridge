import { renderToStaticMarkup } from "react-dom/server";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { describe, expect, it } from "vitest";
import SessionCard from "./SessionCard.jsx";

const training = (over = {}) => ({ status: "ACTIVE", student_count: 60, start_date: "2020-01-01", end_date: "2099-12-31", ...over });
const session = (over = {}) => ({ id: 1, title: "Day 1", session_date: "2099-06-01", start_time: "10:00", end_time: "12:00", status: "SCHEDULED", notes: null, attendance: null, ...over });
const render = (s, role = "TRAINER", t = training()) => renderToStaticMarkup(<QueryClientProvider client={new QueryClient()}><ul><SessionCard s={s} role={role} training={t} /></ul></QueryClientProvider>);
const button = (html, label) => html.match(new RegExp(`<button[^>]*>${label}</button>`))?.[0] ?? "";
// The CSS class contains "disabled:opacity-50", so check the real HTML attribute, and make sure the button is there at all.
const isDisabled = (html, label) => { const b = button(html, label); expect(b).not.toBe(""); return /\sdisabled(=""|\s|>)/.test(b); };

describe("SessionCard", () => {
  it("disables Start, Mark completed and Record attendance while the session is in the future", () => {
    const html = render(session());
    for (const label of ["Start", "Mark completed", "Record attendance"]) expect(isDisabled(html, label)).toBe(true);
    expect(html).toContain("Available from 10:00 on 2099-06-01");
  });

  it("enables them once the session has started", () => {
    const html = render(session({ session_date: "2020-06-01" }));
    for (const label of ["Start", "Mark completed", "Record attendance"]) expect(isDisabled(html, label)).toBe(false);
  });

  it("gives the institution no start, complete, attendance or notes actions", () => {
    const html = render(session({ session_date: "2020-06-01" }), "INSTITUTION");
    for (const label of ["Start", "Mark completed", "Record attendance", "Add notes"]) expect(button(html, label)).toBe("");
    expect(button(html, "Reschedule")).not.toBe("");
  });

  it("hides every action on a completed training and shows the notes", () => {
    const html = render(session({ session_date: "2020-06-01", status: "COMPLETED", notes: "Covered loops", attendance: { total_students: 60, present: 45, absent: 15, percent: 75 } }), "TRAINER", training({ status: "COMPLETED" }));
    for (const label of ["Start", "Mark completed", "Edit attendance", "Edit notes", "Cancel", "Reschedule"]) expect(button(html, label)).toBe("");
    expect(html).toContain("Covered loops");
    expect(html).toContain("45 of 60 present (75%)");
  });

  it("does not offer Cancel for a session that has attendance", () => {
    const html = render(session({ session_date: "2020-06-01", attendance: { total_students: 60, present: 1, absent: 1, percent: 50 } }));
    expect(button(html, "Cancel")).toBe("");
    expect(button(html, "Edit attendance")).not.toBe("");
  });

  it("notes that no attendance was recorded for a past session in an ended training", () => {
    expect(render(session({ session_date: "2020-06-01" }), "TRAINER", training({ status: "COMPLETED" }))).toContain("No attendance was recorded");
  });
});
