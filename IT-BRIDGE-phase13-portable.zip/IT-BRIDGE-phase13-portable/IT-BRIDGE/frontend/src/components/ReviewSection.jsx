import { useState } from "react";
import { Link } from "react-router-dom";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import Button from "./ui/Button.jsx";
import Pagination from "./ui/Pagination.jsx";
import TextArea from "./ui/TextArea.jsx";
import { Stars, StarInput, pretty } from "./Stars.jsx";
import { submitReview, trainingReviews } from "../services/reviewService.js";
import { errorMessage } from "../services/api.js";
import { commentInfo, DEFAULT_COMMENT_MAX, fieldErrors, filterNote, formatRating, hasRating, pendingText, reasonText, reviewCountText, reviewPayload, submitState } from "../utils/reviews.js";

/** Stars, the rating with one decimal and the review count; or the honest "No reviews yet". */
export function RatingSummary({ rating, count, completed, size = 16 }) {
  if (!hasRating(rating, count)) return <span className="text-steel">No reviews yet</span>;
  return (
    <span className="inline-flex flex-wrap items-center gap-2" title={filterNote(count) || undefined}>
      <Stars value={rating} size={size} /><strong>{formatRating(rating)}</strong><span className="text-steel">({reviewCountText(count)})</span>
      {completed > 0 && <span className="text-steel">· {completed} completed {completed === 1 ? "training" : "trainings"}</span>}
    </span>
  );
}

export function ReviewCard({ r }) {
  return (
    <li className="rounded-card border border-line bg-white p-4">
      <div className="flex items-center justify-between gap-3">
        <span className="font-semibold">{r.reviewer}</span>
        <span className="flex items-center gap-2 text-sm"><Stars value={r.overall} /> {formatRating(r.overall)}</span>
      </div>
      {r.comment && <p className="mt-2 whitespace-pre-line text-sm">{r.comment}</p>}
      <p className="mt-2 text-xs text-steel">{Object.entries(r.ratings).map(([k, v]) => `${pretty(k)} ${v}`).join(" · ")}</p>
    </li>
  );
}

/** A paged list of reviews with loading, error and empty states. `q` is a react-query result; `empty` is the text for no reviews. */
export function ReviewList({ q, page, onPage, empty = "No reviews yet." }) {
  if (q.isLoading) return <p role="status" className="text-sm text-steel">Loading reviews...</p>;
  if (q.isError) return <p role="alert" className="text-sm text-danger">{errorMessage(q.error)}</p>;
  if (!q.data) return null;
  if (q.data.items.length === 0) return <p className="text-sm text-steel">{empty}</p>;
  return (
    <>
      <ul className="space-y-3">{q.data.items.map((r) => <ReviewCard key={r.id} r={r} />)}</ul>
      <Pagination page={page} pageSize={q.data.page_size} total={q.data.total} onChange={onPage} />
    </>
  );
}

/** The form itself. Pure of data fetching so every state can be rendered and tested. */
export function ReviewForm({ categories, ratings, comment, max = DEFAULT_COMMENT_MAX, pending, done, errors = {}, message, onRate, onComment, onSubmit }) {
  if (done) return <p role="status" className="mt-5 rounded-ctl bg-green-50 p-3 text-sm font-semibold text-green-800">Thank you. Your review was submitted. Reviews cannot be changed after they are submitted.</p>;
  const info = commentInfo(comment, max), state = submitState({ ratings, categories, comment, max, pending });
  return (
    <form className="mt-5 space-y-3 border-t border-line pt-5" onSubmit={(e) => { e.preventDefault(); if (state.enabled) onSubmit(); }} noValidate>
      <h3 className="font-bold">Leave your review</h3>
      {message && <p role="alert" className="rounded-ctl bg-red-50 p-3 text-sm text-danger">{message}</p>}
      {categories.map((c) => <StarInput key={c} label={pretty(c)} value={ratings[c] || 0} onChange={(v) => onRate(c, v)} />)}
      {errors.ratings && <p role="alert" className="text-xs text-danger">{errors.ratings}</p>}
      <TextArea label="Comment (optional)" rows={3} value={comment} onChange={(e) => onComment(e.target.value)} error={errors.comment || (info.tooLong ? `The comment is ${info.length - max} characters too long.` : info.blank ? "Write a comment or leave it empty." : undefined)} />
      <p className={`text-xs ${info.tooLong ? "text-danger" : "text-steel"}`} aria-live="polite" data-testid="comment-counter">{info.length} / {max}</p>
      <Button type="submit" disabled={!state.enabled}>{pending ? "Submitting..." : "Submit review"}</Button>
      {state.hint && <p className="text-xs text-steel">{state.hint}</p>}
    </form>
  );
}

export default function ReviewSection({ trainingId, status }) {
  const qc = useQueryClient();
  const [ratings, setRatings] = useState({});
  const [comment, setComment] = useState("");
  const [done, setDone] = useState(false);
  const reviewable = status === "COMPLETED";
  const q = useQuery({ queryKey: ["training-reviews", trainingId], queryFn: () => trainingReviews(trainingId), enabled: reviewable });
  const send = useMutation({
    mutationFn: () => submitReview(trainingId, reviewPayload(ratings, comment)),
    onSuccess: () => {
      setDone(true);
      for (const key of ["training-reviews", "reviews-me", "trainer-reviews", "institution-reviews", "trainer", "trainers"]) qc.invalidateQueries({ queryKey: [key] });
    },
  });

  if (!reviewable) {
    const text = reasonText(status === "CANCELLED" ? "CANCELLED" : "ACTIVE");
    return <section className="rounded-card bg-white p-6 shadow-card"><h2 className="mb-2 text-lg font-bold">Reviews</h2><p className="text-sm text-steel">{text}</p></section>;
  }
  if (q.isLoading) return <p role="status" className="text-sm text-steel">Loading reviews...</p>;
  if (q.isError) return <p role="alert" className="text-sm text-danger">{errorMessage(q.error)}</p>;
  const { reviews, categories, can_review, reason, reason_text, comment_max_length } = q.data;
  const errors = fieldErrors(send.error);
  const general = send.isError && Object.keys(errors).length === 0 ? errorMessage(send.error) : send.isError ? "Check the highlighted fields and try again." : null;

  return (
    <section className="rounded-card bg-white p-6 shadow-card">
      <h2 className="mb-3 text-lg font-bold">Reviews</h2>
      {reviews.length === 0 && <p className="text-sm text-steel">No reviews yet.</p>}
      <ul className="space-y-3">{reviews.map((r) => <ReviewCard key={r.id} r={r} />)}</ul>
      {(can_review || done) ? (
        <ReviewForm categories={categories} ratings={ratings} comment={comment} max={comment_max_length} pending={send.isPending} done={done} errors={errors} message={general}
          onRate={(c, v) => setRatings({ ...ratings, [c]: v })} onComment={setComment} onSubmit={() => !send.isPending && send.mutate()} />
      ) : (
        <p className="mt-4 text-sm text-steel" data-testid="not-reviewable">{reasonText(reason, reason_text)}</p>
      )}
    </section>
  );
}

/** Dashboard card: own rating and the trainings that still wait for this user's review. `q` is a react-query result of myReviewSummary. */
export function ReviewSummaryCard({ q }) {
  if (q.isLoading) return <section className="mt-6 rounded-card bg-white p-5 shadow-card"><p role="status" className="text-sm text-steel">Loading your ratings...</p></section>;
  if (q.isError) return <section className="mt-6 rounded-card bg-white p-5 shadow-card"><p role="alert" className="text-sm text-danger">{errorMessage(q.error)}</p></section>;
  if (!q.data) return null;
  const d = q.data;
  return (
    <section className="mt-6 rounded-card bg-white p-5 shadow-card" aria-label="Your ratings and reviews">
      <h2 className="text-lg font-bold">Your ratings</h2>
      <p className="mt-2 text-sm"><RatingSummary rating={d.rating} count={d.review_count} completed={d.completed_trainings} /></p>
      <p className="mt-3 text-sm font-semibold" data-testid="pending-count">{pendingText(d.my_pending_reviews)}</p>
      {d.pending.length > 0 && (
        <ul className="mt-2 space-y-1 text-sm">
          {d.pending.map((p) => <li key={p.training_id}><Link className="font-semibold text-span-dark" to={`/trainings/${p.training_id}`}>Review: {p.title}</Link></li>)}
        </ul>
      )}
      {d.my_pending_reviews === 0 && d.review_count === 0 && <p className="mt-2 text-xs text-steel">Ratings appear here once a completed training has been reviewed.</p>}
    </section>
  );
}
