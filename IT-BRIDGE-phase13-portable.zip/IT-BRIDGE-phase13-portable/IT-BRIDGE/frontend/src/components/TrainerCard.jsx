import { Link } from "react-router-dom";
import { BadgeCheck, MapPin, Briefcase } from "lucide-react";
import Badge from "./ui/Badge.jsx";
import { Stars } from "./Stars.jsx";
import { filterNote, formatRating, hasRating } from "../utils/reviews.js";
import { money } from "./RequirementCard.jsx";

const modeLabel = { ONLINE: "Online", OFFLINE: "Offline", HYBRID: "Hybrid" };

export default function TrainerCard({ t, extra, children }) {
  return (
    <article className="rounded-card bg-white p-5 shadow-card">
      <div className="flex items-start justify-between gap-3">
        <div>
          <h3 className="flex items-center gap-1 text-lg font-bold">
            <Link to={`/trainers/${t.id}`} className="hover:text-span-dark">{t.full_name}</Link>
            {t.verified && <BadgeCheck size={17} className="text-span" aria-label="Verified trainer" />}
          </h3>
          <p className="text-sm text-steel">{t.headline}</p>
        </div>
        {extra}
      </div>
      <ul className="mt-3 flex flex-wrap gap-x-4 gap-y-1 text-sm text-steel">
        {t.location && <li className="flex items-center gap-1"><MapPin size={14} />{t.location}</li>}
        {t.experience_years != null && <li className="flex items-center gap-1"><Briefcase size={14} />{t.experience_years} years</li>}
        {t.training_mode && <li>{modeLabel[t.training_mode]}</li>}
        {t.expected_fee != null && <li>{money(t.expected_fee)} per day</li>}
        {hasRating(t.rating, t.review_count) && <li className="flex items-center gap-1" title={filterNote(t.review_count) || undefined}><Stars value={t.rating} size={14} />{formatRating(t.rating)} ({t.review_count})</li>}
        {t.completed_trainings > 0 && <li>{t.completed_trainings} completed</li>}
      </ul>
      <div className="mt-3 flex flex-wrap gap-1.5">{t.skills.map((s) => <Badge key={s.id}>{s.name}</Badge>)}</div>
      {children}
    </article>
  );
}
