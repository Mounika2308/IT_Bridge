import { Star } from "lucide-react";

export function Stars({ value, size = 16 }) {
  return (
    <span className="inline-flex items-center gap-0.5" role="img" aria-label={`${value} out of 5 stars`}>
      {[1, 2, 3, 4, 5].map((i) => (
        <Star key={i} size={size} className={value >= i - 0.25 ? "fill-signal text-signal" : "text-line"} />
      ))}
    </span>
  );
}

export function StarInput({ label, value, onChange }) {
  return (
    <fieldset className="flex flex-wrap items-center justify-between gap-2">
      <legend className="sr-only">{label}</legend>
      <span className="text-sm font-semibold" aria-hidden="true">{label}</span>
      <div className="flex gap-1">
        {[1, 2, 3, 4, 5].map((i) => (
          <label key={i} className="cursor-pointer">
            <input type="radio" name={label} className="peer sr-only" checked={value === i} onChange={() => onChange(i)} aria-label={`${i} star${i > 1 ? "s" : ""}`} />
            <Star size={26} className={`${value >= i ? "fill-signal text-signal" : "text-line"} peer-focus-visible:outline peer-focus-visible:outline-2 peer-focus-visible:outline-span`} />
          </label>
        ))}
      </div>
    </fieldset>
  );
}

export const pretty = (k) => k.replace(/_/g, " ").replace(/^./, (c) => c.toUpperCase());
