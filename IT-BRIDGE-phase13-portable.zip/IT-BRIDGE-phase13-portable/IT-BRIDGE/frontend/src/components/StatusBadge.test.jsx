import { renderToStaticMarkup } from "react-dom/server";
import { describe, expect, it } from "vitest";
import StatusBadge from "./StatusBadge.jsx";

const html = (status) => renderToStaticMarkup(<StatusBadge status={status} />);

describe("StatusBadge", () => {
  it("shows readable labels for every training phase", () => {
    expect(html("UPCOMING")).toContain("Upcoming");
    expect(html("IN_PROGRESS")).toContain("In progress");
    expect(html("ENDED")).toContain("Ended");
    expect(html("COMPLETED")).toContain("Completed");
    expect(html("CANCELLED")).toContain("Cancelled");
  });

  it("labels a requirement that has its trainer as Filled", () => {
    expect(html("FILLED")).toContain("Filled");
    expect(html("OPEN")).toContain("Open");
  });

  it("uses the success tone while a training is running and a warning tone once it has ended", () => {
    expect(html("IN_PROGRESS")).toContain("text-ok");
    expect(html("ENDED")).toContain("bg-signal-soft");
  });
});
