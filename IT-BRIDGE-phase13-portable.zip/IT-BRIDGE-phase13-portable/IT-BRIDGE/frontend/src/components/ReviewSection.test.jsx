import { renderToStaticMarkup } from "react-dom/server";
import { MemoryRouter } from "react-router-dom";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { describe, expect, it, vi } from "vitest";
// useAuth() is null without an AuthProvider, so pages that call it need this mock under real vitest. The role can be switched per test.
vi.mock("../context/AuthContext.jsx", () => ({ useAuth: () => ({ user: { role: globalThis.__role || "TRAINER", full_name: "Test User" } }) }));
vi.mock("../layouts/AppLayout.jsx", () => ({ default: ({ children }) => children }));

import ReviewSection, { RatingSummary, ReviewCard, ReviewForm, ReviewList, ReviewSummaryCard } from "./ReviewSection.jsx";
import InstitutionPublicProfile from "../pages/InstitutionPublicProfile.jsx";
import TrainerPublicProfile from "../pages/TrainerPublicProfile.jsx";
import Home from "../pages/Home.jsx";
import TrainerCard from "./TrainerCard.jsx";

const CATS = ["communication", "professionalism", "coordination"];
const noop = () => {};
const T5 = "/trainings/5";
const rev = (over = {}) => ({ id: 1, direction: "TRAINER_TO_INSTITUTION", reviewer: "Asha", overall: 4, ratings: { communication: 4, professionalism: 5, coordination: 3 }, comment: "Well organised", created_at: "2030-01-01T00:00:00Z", ...over });
const page = (items, total = items.length) => ({ data: { items, total, page: 1, page_size: 10 } });
const html = (el, qc = new QueryClient()) => renderToStaticMarkup(<QueryClientProvider client={qc}><MemoryRouter>{el}</MemoryRouter></QueryClientProvider>);
const button = (h, label) => h.match(new RegExp(`<button[^>]*>${label}</button>`))?.[0] ?? "";
const disabled = (h, label) => { const b = button(h, label); expect(b).not.toBe(""); return /\sdisabled(=""|\s|>)/.test(b); };
const form = (over = {}) => html(<ReviewForm categories={CATS} ratings={{}} comment="" pending={false} done={false} onRate={noop} onComment={noop} onSubmit={noop} {...over} />);
const filled = { communication: 4, professionalism: 5, coordination: 3 };

describe("rating summary", () => {
  it("shows no stars and no number for a profile without reviews", () => {
    const h = html(<RatingSummary rating={null} count={0} />);
    expect(h).toContain("No reviews yet");
    expect(h).not.toContain("<strong>");
  });
  it("uses singular and plural and one decimal", () => {
    expect(html(<RatingSummary rating={4} count={1} completed={1} />)).toContain("(1 review)");
    expect(html(<RatingSummary rating={4} count={1} completed={1} />)).toContain("1 completed training<");
    const h = html(<RatingSummary rating={4} count={3} completed={2} />);
    expect(h).toContain("<strong>4.0</strong>"); expect(h).toContain("(3 reviews)"); expect(h).toContain("2 completed trainings");
  });
  it("tells a single-review profile why it is not yet in the rating filter", () => {
    expect(html(<RatingSummary rating={5} count={1} />)).toContain("Counted in the rating filter once it has 2 reviews.");
    expect(html(<RatingSummary rating={5} count={2} />)).not.toContain("Counted in the rating filter");
  });
});

describe("review list", () => {
  it("shows loading, error and empty states", () => {
    expect(html(<ReviewList q={{ isLoading: true }} page={1} onPage={noop} />)).toContain("Loading reviews...");
    expect(html(<ReviewList q={{ isError: true, error: new Error("x") }} page={1} onPage={noop} />)).toContain('role="alert"');
    expect(html(<ReviewList q={page([])} page={1} onPage={noop} empty="This trainer has no reviews yet." />)).toContain("This trainer has no reviews yet.");
  });
  it("shows reviews with their categories, and pagination controls when there is more than one page", () => {
    const h = html(<ReviewList q={page([rev(), rev({ id: 2, reviewer: "Ravi", comment: null })], 25)} page={1} onPage={noop} />);
    expect(h).toContain("Well organised"); expect(h).toContain("Communication 4 · Professionalism 5 · Coordination 3");
    expect(h).toContain("Page 1 of 3");
    expect(disabled(h, "Previous")).toBe(true); expect(disabled(h, "Next")).toBe(false);
    expect(html(<ReviewList q={page([rev()], 1)} page={1} onPage={noop} />)).not.toContain("Pagination");
    expect(disabled(html(<ReviewList q={{ data: { items: [rev()], total: 25, page: 3, page_size: 10 } }} page={3} onPage={noop} />), "Next")).toBe(true);
  });
  it("does not show edit or delete controls on a review", () => {
    const h = html(<ul><ReviewCard r={rev()} /></ul>);
    expect(h).not.toMatch(/edit|delete|remove/i);
  });
});

describe("review form", () => {
  it("shows a character counter for the trimmed comment against the limit", () => {
    expect(form({ comment: "  hello  " })).toContain(">5 / 2000<");
    expect(form({ comment: "x".repeat(10), max: 8 })).toContain("10 / 8");
  });
  it("disables Submit until every category is rated, and explains why", () => {
    const h = form();
    expect(disabled(h, "Submit review")).toBe(true); expect(h).toContain("Rate every category to submit.");
    expect(disabled(form({ ratings: filled }), "Submit review")).toBe(false);
  });
  it("blocks over-long and blank comments", () => {
    const long = form({ ratings: filled, comment: "x".repeat(2003) });
    expect(disabled(long, "Submit review")).toBe(true); expect(long).toContain("The comment is 3 characters too long.");
    const blank = form({ ratings: filled, comment: "   " });
    expect(disabled(blank, "Submit review")).toBe(true); expect(blank).toContain("Write a comment or leave it empty.");
  });
  it("prevents a second click while submitting", () => {
    const h = form({ ratings: filled, pending: true });
    expect(disabled(h, "Submitting...")).toBe(true);
  });
  it("shows the server's field errors and a general message", () => {
    const h = form({ ratings: filled, errors: { comment: "The comment can be at most 2000 characters", ratings: "Each rating must be a whole number from 1 to 5" }, message: "Check the highlighted fields and try again." });
    expect(h).toContain("The comment can be at most 2000 characters"); expect(h).toContain("Each rating must be a whole number"); expect(h).toContain("Check the highlighted fields");
  });
  it("replaces the form with a success message after submitting, with no way to edit", () => {
    const h = form({ done: true });
    expect(h).toContain("Thank you. Your review was submitted."); expect(h).toContain("cannot be changed");
    expect(h).not.toContain("<form"); expect(h).not.toContain("Submit review");
  });
});

describe("review section on a training", () => {
  const data = (over) => { const qc = new QueryClient(); qc.setQueryData(["training-reviews", "7"], { reviews: [], categories: CATS, can_review: true, reason: null, reason_text: null, comment_max_length: 2000, ...over }); return qc; };
  const section = (status, qc) => html(<ReviewSection trainingId="7" status={status} />, qc);
  it("explains that an active training cannot be reviewed yet, and offers no form", () => {
    const h = section("ACTIVE");
    expect(h).toContain("still in progress"); expect(h).not.toContain("<form");
  });
  it("explains that a cancelled training cannot be reviewed", () => {
    const h = section("CANCELLED");
    expect(h).toContain("was cancelled, so it cannot be reviewed"); expect(h).not.toContain("<form");
  });
  it("shows loading while a completed training's reviews load", () => {
    expect(section("COMPLETED")).toContain("Loading reviews...");
  });
  it("shows the form for an eligible user, with the empty state for no reviews", () => {
    const h = section("COMPLETED", data({}));
    expect(h).toContain("No reviews yet."); expect(h).toContain("Leave your review"); expect(h.match(/type="radio"/g)).toHaveLength(15);
  });
  it("says why an already-reviewed or suspended user cannot review, instead of hiding the form silently", () => {
    expect(section("COMPLETED", data({ can_review: false, reason: "ALREADY_REVIEWED", reviews: [rev()] }))).toContain("You have already reviewed this training.");
    const h = section("COMPLETED", data({ can_review: false, reason: "SUSPENDED" }));
    expect(h).toContain("Suspended accounts cannot submit reviews."); expect(h).not.toContain("<form");
  });
});

describe("dashboards", () => {
  const card = (q) => html(<ReviewSummaryCard q={q} />);
  it("shows loading and error states", () => {
    expect(card({ isLoading: true })).toContain("Loading your ratings...");
    expect(card({ isError: true, error: new Error("x") })).toContain('role="alert"');
  });
  it("shows an empty state for a new user without inventing a rating", () => {
    const h = card({ data: { rating: null, review_count: 0, completed_trainings: 0, my_pending_reviews: 0, pending: [] } });
    expect(h).toContain("No reviews yet"); expect(h).toContain("No reviews waiting"); expect(h).toContain("Ratings appear here once");
  });
  it("shows the rating and the trainings waiting for a review, with links", () => {
    const h = card({ data: { rating: 4.6, review_count: 3, completed_trainings: 4, my_pending_reviews: 2, pending: [{ training_id: 5, title: "Python" }, { training_id: 6, title: "Java" }] } });
    expect(h).toContain("<strong>4.6</strong>"); expect(h).toContain("(3 reviews)"); expect(h).toContain("2 reviews waiting");
    expect(h).toContain(`href="${T5}"`); expect(h).toContain("Review: Java");
    expect(card({ data: { rating: null, review_count: 0, completed_trainings: 1, my_pending_reviews: 1, pending: [{ training_id: 9, title: "Go" }] } })).toContain("1 review waiting");
  });
  it("is part of both the trainer and the institution dashboard, fed by the server's summary", () => {
    for (const role of ["TRAINER", "INSTITUTION"]) {
      globalThis.__role = role;
      const qc = new QueryClient();
      qc.setQueryData(["reviews-me"], { rating: 4, review_count: 2, completed_trainings: 2, my_pending_reviews: 1, pending: [{ training_id: 3, title: "Python" }] });
      const h = html(<Home title="Dashboard" />, qc);
      expect(h).toContain("Your ratings"); expect(h).toContain("1 review waiting"); expect(h).toContain("(2 reviews)");
    }
    globalThis.__role = "ADMIN";
    expect(html(<Home title="Admin" />)).not.toContain("Your ratings");
    globalThis.__role = "TRAINER";
  });
});

describe("institution reviews page", () => {
  const inst = (over = {}) => { const qc = new QueryClient(); qc.setQueryData(["institution-reviews", undefined, 1], { items: [rev()], total: 1, page: 1, page_size: 10, institution_name: "Sunrise College", verified: true, rating: 4, review_count: 1, completed_trainings: 2, ...over }); return qc; };
  it("shows the institution's name, rating, and the trainers' reviews", () => {
    const h = html(<InstitutionPublicProfile />, inst());
    expect(h).toContain("Sunrise College"); expect(h).toContain("Verified"); expect(h).toContain("<strong>4.0</strong>"); expect(h).toContain("(1 review)");
    expect(h).toContain("Well organised"); expect(h).toContain("Reviews from trainers");
    expect(h).not.toMatch(/@|phone|email/i);
  });
  it("shows the honest empty state, and pagination for many reviews", () => {
    expect(html(<InstitutionPublicProfile />, inst({ items: [], total: 0, rating: null, review_count: 0 }))).toContain("No trainer has reviewed this institution yet.");
    expect(html(<InstitutionPublicProfile />, inst({ total: 35 }))).toContain("Page 1 of 4");
  });
  it("shows loading", () => {
    expect(html(<InstitutionPublicProfile />)).toContain("Loading...");
  });
});

describe("trainer profile and cards", () => {
  const trainer = { id: 1, full_name: "Asha", headline: "Python trainer", verified: true, rating: 4.5, review_count: 11, completed_trainings: 1, about: "", skills: [], languages: [], education: [], certifications: [], experience_years: 5, location: "Pune", training_mode: "OFFLINE", expected_fee: 4000 };
  const profile = (over = {}, reviewsData = { items: [rev({ direction: "INSTITUTION_TO_TRAINER", reviewer: "Sunrise" })], total: 11, page: 1, page_size: 10 }) => {
    const qc = new QueryClient(); qc.setQueryData(["trainer", undefined], { ...trainer, ...over }); qc.setQueryData(["trainer-reviews", undefined, 1], reviewsData); return html(<TrainerPublicProfile />, qc);
  };
  it("pages through the trainer's reviews and uses correct wording", () => {
    const h = profile();
    expect(h).toContain("(11 reviews)"); expect(h).toContain("1 completed training<"); expect(h).toContain("Page 1 of 2"); expect(h).toContain("Sunrise");
  });
  it("says 1 review, not 1 reviews, and handles a trainer without reviews", () => {
    expect(profile({ review_count: 1, rating: 5 })).toContain("(1 review)");
    const none = profile({ rating: null, review_count: 0 }, { items: [], total: 0, page: 1, page_size: 10 });
    expect(none).toContain("No reviews yet"); expect(none).toContain("This trainer has no reviews yet.");
  });
  it("shows the rating on a trainer card with one decimal, only when there are reviews", () => {
    const card = (t) => html(<TrainerCard t={{ ...trainer, skills: [], ...t }} />);
    expect(card({ rating: 4, review_count: 3 })).toContain("4.0 (3)");
    expect(card({ rating: null, review_count: 0 })).not.toContain("(0)");
    expect(card({ rating: 5, review_count: 1 })).toContain("Counted in the rating filter once it has 2 reviews.");
  });
});
