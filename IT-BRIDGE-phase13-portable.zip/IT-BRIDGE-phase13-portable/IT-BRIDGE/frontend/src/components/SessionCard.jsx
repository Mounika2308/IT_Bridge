import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import Button from "./ui/Button.jsx";
import Field from "./ui/Field.jsx";
import TextArea from "./ui/TextArea.jsx";
import StatusBadge from "./StatusBadge.jsx";
import { attendanceSchema, fieldErrors, hasStarted, notesSchema, sessionSchema } from "../schemas/training.js";
import { saveAttendance, saveSessionNotes, setSessionStatus, updateSession } from "../services/trainingService.js";
import { errorMessage } from "../services/api.js";

export default function SessionCard({ s, role, training }) {
  const qc = useQueryClient();
  const [panel, setPanel] = useState(null); // "reschedule" | "attendance" | "notes"
  const [errors, setErrors] = useState({});
  const [form, setForm] = useState({ session_date: s.session_date, start_time: s.start_time, end_time: s.end_time });
  const [att, setAtt] = useState({ total_students: s.attendance?.total_students ?? training.student_count, present: s.attendance?.present ?? "", absent: s.attendance?.absent ?? "" });
  const [notes, setNotes] = useState(s.notes ?? "");

  const trainer = role === "TRAINER";
  const active = training.status === "ACTIVE";
  const started = hasStarted(s);
  const live = active && !["COMPLETED", "CANCELLED"].includes(s.status);
  const cancelled = s.status === "CANCELLED";
  const waiting = `Available from ${s.start_time} on ${s.session_date}`;

  const done = () => { setPanel(null); setErrors({}); qc.invalidateQueries({ queryKey: ["training"] }); qc.invalidateQueries({ queryKey: ["trainings"] }); qc.invalidateQueries({ queryKey: ["calendar"] }); };
  const status = useMutation({ mutationFn: (st) => setSessionStatus(s.id, st), onSuccess: done });
  const resched = useMutation({ mutationFn: () => updateSession(s.id, form), onSuccess: done });
  const attend = useMutation({ mutationFn: () => saveAttendance(s.id, { total_students: Number(att.total_students), present: Number(att.present), absent: Number(att.absent) }), onSuccess: done });
  const saveNotes = useMutation({ mutationFn: () => saveSessionNotes(s.id, notes.trim() || null), onSuccess: done });
  const error = status.error || resched.error || attend.error || saveNotes.error;

  const submit = (schema, values, mutation) => {
    const e = fieldErrors(schema, values);
    setErrors(e);
    if (!Object.keys(e).length) mutation.mutate();
  };
  const toggle = (name) => { setErrors({}); setPanel(panel === name ? null : name); };

  return (
    <li className="rounded-card border border-line bg-white p-4">
      <div className="flex items-start justify-between gap-3">
        <div>
          <p className="font-bold">{s.title}</p>
          <p className="text-sm text-steel">{s.session_date} · {s.start_time} to {s.end_time}</p>
        </div>
        <StatusBadge status={s.status} />
      </div>
      {s.attendance && <p className="mt-2 text-sm">Attendance: {s.attendance.present} of {s.attendance.total_students} present ({s.attendance.percent}%)</p>}
      {!active && s.status === "SCHEDULED" && started && !s.attendance && <p className="mt-2 text-xs text-steel">No attendance was recorded for this session.</p>}
      {s.notes && <p className="mt-2 whitespace-pre-line text-sm"><strong>Notes:</strong> {s.notes}</p>}
      {error && <p role="alert" className="mt-2 text-sm text-danger">{errorMessage(error)}</p>}

      <div className="mt-3 flex flex-wrap gap-2">
        {live && s.status === "SCHEDULED" && <Button variant="secondary" className="!py-2" onClick={() => toggle("reschedule")}>Reschedule</Button>}
        {live && trainer && s.status === "SCHEDULED" && <Button variant="secondary" className="!py-2" disabled={!started || status.isPending} title={started ? undefined : waiting} onClick={() => status.mutate("ONGOING")}>Start</Button>}
        {live && trainer && <Button className="!py-2" disabled={!started || status.isPending} title={started ? undefined : waiting} onClick={() => status.mutate("COMPLETED")}>Mark completed</Button>}
        {active && trainer && !cancelled && <Button variant="secondary" className="!py-2" disabled={!started} title={started ? undefined : waiting} onClick={() => toggle("attendance")}>{s.attendance ? "Edit attendance" : "Record attendance"}</Button>}
        {active && trainer && !cancelled && <Button variant="secondary" className="!py-2" onClick={() => toggle("notes")}>{s.notes ? "Edit notes" : "Add notes"}</Button>}
        {live && !s.attendance && <Button variant="secondary" className="!py-2" disabled={status.isPending} onClick={() => window.confirm("Cancel this session?") && status.mutate("CANCELLED")}>Cancel</Button>}
      </div>

      {panel === "reschedule" && (
        <div className="mt-3 grid gap-3 sm:grid-cols-3">
          <Field label="Date" type="date" min={training.start_date} max={training.end_date} value={form.session_date} error={errors.session_date} onChange={(e) => setForm({ ...form, session_date: e.target.value })} />
          <Field label="Start" type="time" value={form.start_time} error={errors.start_time} onChange={(e) => setForm({ ...form, start_time: e.target.value })} />
          <Field label="End" type="time" value={form.end_time} error={errors.end_time} onChange={(e) => setForm({ ...form, end_time: e.target.value })} />
          <Button className="!py-2 sm:col-span-3" disabled={resched.isPending} onClick={() => submit(sessionSchema(training), { ...form, title: s.title }, resched)}>Save new time</Button>
        </div>
      )}
      {panel === "attendance" && (
        <div className="mt-3 grid gap-3 sm:grid-cols-3">
          <Field label="Total students" type="number" min="1" max={training.student_count} value={att.total_students} error={errors.total_students} onChange={(e) => setAtt({ ...att, total_students: e.target.value })} />
          <Field label="Present" type="number" min="0" value={att.present} error={errors.present} onChange={(e) => setAtt({ ...att, present: e.target.value })} />
          <Field label="Absent" type="number" min="0" value={att.absent} error={errors.absent} onChange={(e) => setAtt({ ...att, absent: e.target.value })} />
          <p className="text-xs text-steel sm:col-span-3">This training has {training.student_count} students.</p>
          <Button className="!py-2 sm:col-span-3" disabled={attend.isPending} onClick={() => submit(attendanceSchema(training.student_count), att, attend)}>Save attendance</Button>
        </div>
      )}
      {panel === "notes" && (
        <div className="mt-3 space-y-3">
          <TextArea label="Session notes" rows={3} value={notes} error={errors.notes} onChange={(e) => setNotes(e.target.value)} />
          <Button className="!py-2" disabled={saveNotes.isPending} onClick={() => submit(notesSchema, { notes }, saveNotes)}>Save notes</Button>
        </div>
      )}
    </li>
  );
}
