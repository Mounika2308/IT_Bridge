import { renderToStaticMarkup } from "react-dom/server";
import { MemoryRouter } from "react-router-dom";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { describe, expect, it } from "vitest";
import NotificationBell, { NotificationList } from "./NotificationBell.jsx";

const n = (over = {}) => ({ id: 1, type: "INTERVIEW_SCHEDULED", title: "Interview scheduled", body: "Python workshop: Mon 05 Jan 2099, 14:30", link: "/trainer/applications",
  is_read: false, created_at: new Date(Date.now() - 5 * 60000).toISOString(), ...over });

const bell = (count) => {
  const qc = new QueryClient();
  if (count !== undefined) qc.setQueryData(["notif-count"], count);
  return renderToStaticMarkup(<QueryClientProvider client={qc}><MemoryRouter><NotificationBell /></MemoryRouter></QueryClientProvider>);
};
const list = (state) => renderToStaticMarkup(<NotificationList list={state} onOpen={() => {}} />);

describe("NotificationBell", () => {
  it("shows the unread count on the badge and in the accessible name", () => {
    const html = bell(3);
    expect(html).toContain('aria-label="Notifications, 3 unread"');
    expect(html).toContain(">3</span>");
  });
  it("caps the badge at 9+", () => {
    expect(bell(25)).toContain(">9+</span>");
  });
  it("shows no badge when everything is read", () => {
    const html = bell(0);
    expect(html).toContain('aria-label="Notifications"');
    expect(html).not.toContain("rounded-full bg-danger");
  });
  it("starts closed, so the list is not fetched or shown", () => {
    expect(bell(2)).toContain('aria-expanded="false"');
    expect(bell(2)).not.toContain('role="dialog"');
  });
});

describe("NotificationList", () => {
  it("shows the title, the message with the interview date and time, and the age", () => {
    const html = list({ data: { items: [n()] } });
    expect(html).toContain("Interview scheduled");
    expect(html).toContain("Mon 05 Jan 2099, 14:30");
    expect(html).toContain("5 min ago");
  });
  it("marks unread rows and leaves read rows plain", () => {
    const html = list({ data: { items: [n(), n({ id: 2, is_read: true })] } });
    expect(html.match(/data-unread="true"/g)).toHaveLength(1);
    expect(html.match(/data-unread="false"/g)).toHaveLength(1);
  });
  it("renders every important event type with its own title and message", () => {
    const events = [
      ["APPLICATION_RECEIVED", "New application received", "Asha applied to Python trainer"],
      ["APPLICATION_WITHDRAWN", "Application withdrawn", "Asha withdrew from Python trainer"],
      ["HIRING_REQUEST", "You have a hiring request", "Sunrise College wants to hire you for Python trainer"],
      ["TRAINING_CREATED", "Your training is confirmed", "Python workshop with Sunrise College, 2099-03-01 to 2099-03-10"],
      ["REQUIREMENT_FILLED", "Requirement filled", "Python trainer has found its trainer."],
      ["REQUIREMENT_REOPENED", "Requirement reopened", "Python trainer is open again."],
      ["INTERVIEW_REMINDER", "Interview coming up", "Python trainer: Tue 06 Jan 2099, 10:00"],
    ];
    const html = list({ data: { items: events.map(([type, title, body], i) => n({ id: i + 1, type, title, body })) } });
    for (const [, title, body] of events) { expect(html).toContain(title); expect(html).toContain(body); }
  });
  it("shows loading, error and empty states", () => {
    expect(list({ isLoading: true })).toContain("Loading...");
    expect(list({ isError: true, error: new Error("boom") })).toContain('role="alert"');
    expect(list({ data: { items: [] } })).toContain("No notifications yet.");
  });
});
