import { describe, expect, it } from "vitest";
import { attendanceSchema, fieldErrors, hasStarted, interviewSchema, notesSchema, plannedSessionsSchema, sessionSchema, startsAt } from "./training.js";

const training = { start_date: "2030-03-01", end_date: "2030-03-10", student_count: 60 };
const now = new Date("2030-03-02T10:00:00");
const ok = { title: "Day 1", session_date: "2030-03-05", start_time: "10:00", end_time: "12:00" };
const errs = (v, t = training) => fieldErrors(sessionSchema(t, now), v);

describe("session scheduling validation", () => {
  it("accepts a valid future session", () => expect(errs(ok)).toEqual({}));
  it("requires a title, date and times", () => {
    const e = errs({ title: " ", session_date: "", start_time: "", end_time: "" });
    expect(Object.keys(e).sort()).toEqual(["end_time", "session_date", "start_time", "title"]);
  });
  it("rejects dates outside the training", () => {
    expect(errs({ ...ok, session_date: "2030-02-28" }).session_date).toMatch(/between/);
    expect(errs({ ...ok, session_date: "2030-03-11" }).session_date).toMatch(/between/);
  });
  it("rejects an end time that is not after the start", () => {
    expect(errs({ ...ok, end_time: "10:00" }).end_time).toMatch(/after the start/);
    expect(errs({ ...ok, end_time: "09:00" }).end_time).toMatch(/after the start/);
  });
  it("rejects a start that has already passed", () => {
    expect(errs({ ...ok, session_date: "2030-03-02", start_time: "09:00", end_time: "10:00" }).start_time).toMatch(/already passed/);
    expect(errs({ ...ok, session_date: "2030-03-02", start_time: "10:30", end_time: "11:00" })).toEqual({});
  });
});

describe("attendance validation", () => {
  const e = (v) => fieldErrors(attendanceSchema(60), v);
  it("accepts valid headcounts, including fewer students than enrolled", () => {
    expect(e({ total_students: "60", present: "45", absent: "15" })).toEqual({});
    expect(e({ total_students: 50, present: 30, absent: 20 })).toEqual({});
  });
  it("rejects a total above the student count", () => expect(e({ total_students: 61, present: 1, absent: 1 }).total_students).toMatch(/between 1 and 60/));
  it("rejects present plus absent above the total", () => expect(e({ total_students: 60, present: 40, absent: 21 }).absent).toMatch(/cannot exceed/));
  it("rejects negative, empty and fractional values", () => {
    expect(e({ total_students: 60, present: -1, absent: 0 }).present).toBeTruthy();
    expect(e({ total_students: 60, present: "", absent: 0 }).present).toBeTruthy();
    expect(e({ total_students: 60, present: 1.5, absent: 0 }).present).toBeTruthy();
  });
});

describe("other schedule helpers", () => {
  it("knows when a session has started (used to disable Start, Complete and Attendance)", () => {
    const s = { session_date: "2030-03-05", start_time: "10:00" };
    expect(startsAt(s).getHours()).toBe(10);
    expect(hasStarted(s, new Date("2030-03-05T09:59:00"))).toBe(false);
    expect(hasStarted(s, new Date("2030-03-05T10:00:00"))).toBe(true);
  });
  it("planned sessions cannot go below what is already scheduled", () => {
    const e = (n, scheduled) => fieldErrors(plannedSessionsSchema(scheduled), { planned_sessions: n });
    expect(e(2, 3).planned_sessions).toMatch(/from 3/);
    expect(e(3, 3)).toEqual({});
    expect(e(0, 0).planned_sessions).toBeTruthy();
    expect(e(1001, 0).planned_sessions).toBeTruthy();
  });
  it("interviews need a date that is not in the past", () => {
    const e = (v) => fieldErrors(interviewSchema(now), { interview_at: v });
    expect(e("")).toHaveProperty("interview_at");
    expect(e("2030-03-01T10:00")).toHaveProperty("interview_at");
    expect(e("2030-03-03T10:00")).toEqual({});
  });
  it("notes are limited to 1000 characters", () => {
    expect(notesSchema.safeParse({ notes: "x".repeat(1000) }).success).toBe(true);
    expect(notesSchema.safeParse({ notes: "x".repeat(1001) }).success).toBe(false);
  });
});
