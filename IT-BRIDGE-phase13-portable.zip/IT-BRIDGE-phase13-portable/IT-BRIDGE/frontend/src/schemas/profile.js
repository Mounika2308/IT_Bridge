import { z } from "zod";

const num = (min, max, msg) =>
  z.preprocess((v) => (v === "" || v == null ? undefined : Number(v)),
    z.number({ invalid_type_error: msg, required_error: msg }).int(msg).min(min, msg).max(max, msg));

export const trainerStepSchemas = [
  z.object({
    headline: z.string().min(5, "Add a short headline, e.g. Python trainer with 6 years of experience").max(160),
    about: z.string().min(30, "Write at least 30 characters about your teaching").max(2000),
    location: z.string().min(2, "Enter your city"),
    experience_years: num(0, 60, "Enter years of experience (0-60)"),
  }),
  z.object({
    skill_ids: z.array(z.number()).min(1, "Pick at least one skill"),
    languages: z.string().min(2, "Enter at least one language, separated by commas"),
    education: z.string().optional(),
    certifications: z.string().optional(),
  }),
  z.object({
    training_mode: z.enum(["ONLINE", "OFFLINE", "HYBRID"], { errorMap: () => ({ message: "Choose a training mode" }) }),
    expected_fee: num(0, 10000000, "Enter your expected fee per day"),
    availability: z.string().min(3, "Tell institutions when you are available").max(300),
  }),
];

export const institutionSchema = z.object({
  institution_name: z.string().min(2, "Enter the institution name"),
  institution_type: z.enum(["ENGINEERING_COLLEGE", "DEGREE_COLLEGE", "TRAINING_INSTITUTE", "SCHOOL", "OTHER"],
    { errorMap: () => ({ message: "Choose a type" }) }),
  location: z.string().min(2, "Enter the city"),
  about: z.string().max(2000).optional(),
  website: z.string().url("Enter a full link starting with https://").optional().or(z.literal("")),
});

export const splitList = (s) => (s || "").split(/[,\n]/).map((x) => x.trim()).filter(Boolean);

const posInt = (min, max, msg) =>
  z.preprocess((v) => (v === "" || v == null ? undefined : Number(v)),
    z.number({ invalid_type_error: msg, required_error: msg }).int(msg).min(min, msg).max(max, msg));

export const requirementSchema = z.object({
  title: z.string().min(5, "Give the requirement a clear title").max(160),
  technology: z.string().min(1, "Enter the technology or course"),
  category_id: z.preprocess((v) => (v === "" || v == null ? null : Number(v)), z.number().nullable()),
  description: z.string().min(30, "Describe the training in at least 30 characters").max(4000),
  skill_ids: z.array(z.number()).min(1, "Pick at least one skill"),
  student_count: posInt(1, 100000, "Enter the number of students"),
  student_level: z.enum(["BEGINNER", "INTERMEDIATE", "ADVANCED"], { errorMap: () => ({ message: "Choose a level" }) }),
  duration_days: posInt(1, 730, "Enter the duration in days"),
  sessions: posInt(1, 1000, "Enter the number of sessions"),
  location: z.string().min(2, "Enter the city"),
  mode: z.enum(["ONLINE", "OFFLINE", "HYBRID"], { errorMap: () => ({ message: "Choose a mode" }) }),
  start_date: z.string().min(1, "Choose a start date"),
  end_date: z.string().min(1, "Choose an end date"),
  preferred_experience_years: posInt(0, 60, "Enter 0 or more years"),
  budget_min: posInt(0, 100000000, "Enter the minimum budget"),
  budget_max: posInt(0, 100000000, "Enter the maximum budget"),
  application_deadline: z.string().min(1, "Choose a deadline"),
  additional_requirements: z.string().max(2000).optional(),
}).superRefine((d, ctx) => {
  const issue = (path, message) => ctx.addIssue({ code: "custom", path: [path], message });
  if (d.end_date && d.start_date && d.end_date < d.start_date) issue("end_date", "End date must be on or after the start date");
  if (d.application_deadline && d.start_date && d.application_deadline > d.start_date) issue("application_deadline", "Deadline must be on or before the start date");
  if (d.budget_max < d.budget_min) issue("budget_max", "Maximum must be at least the minimum");
});
