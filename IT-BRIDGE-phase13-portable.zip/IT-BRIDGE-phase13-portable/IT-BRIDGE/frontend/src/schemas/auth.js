import { z } from "zod";

export const loginSchema = z.object({
  email: z.string().email("Enter a valid email address"),
  password: z.string().min(1, "Enter your password"),
});

export const registerSchema = z.object({
  role: z.enum(["TRAINER", "INSTITUTION"]),
  full_name: z.string().min(2, "Enter your full name"),
  institution_name: z.string().optional(),
  email: z.string().email("Enter a valid email address"),
  phone: z.string().regex(/^\+?[0-9 \-]{7,15}$/, "Enter a valid phone number").optional().or(z.literal("")),
  password: z.string().min(8, "Use at least 8 characters")
    .refine((v) => /[A-Za-z]/.test(v) && /\d/.test(v), "Use letters and numbers"),
}).refine((d) => d.role !== "INSTITUTION" || (d.institution_name || "").trim().length > 1, {
  path: ["institution_name"],
  message: "Enter the institution name",
});
