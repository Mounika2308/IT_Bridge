import { z } from "zod";

/** Client-side checks that mirror the backend rules so people see problems before submitting.
 *  The backend stays authoritative: every rule here is enforced again on the server. */

export const startsAt = (s) => new Date(`${s.session_date}T${s.start_time}`);
export const hasStarted = (s, now = new Date()) => startsAt(s) <= now;

/** Runs a schema and returns { field: first message } (empty object when valid). */
export const fieldErrors = (schema, values) => {
  const r = schema.safeParse(values);
  return r.success ? {} : Object.fromEntries(r.error.issues.map((i) => [i.path[0], i.message]).reverse());
};

const whole = (min, max, msg) =>
  z.preprocess((v) => (v === "" || v == null ? undefined : Number(v)),
    z.number({ invalid_type_error: msg, required_error: msg }).int(msg).min(min, msg).max(max, msg));

export const sessionSchema = (training, now = new Date()) =>
  z.object({
    title: z.string().trim().min(2, "Enter a title (at least 2 characters)").max(120, "Keep the title under 120 characters"),
    session_date: z.string().min(1, "Choose a date"),
    start_time: z.string().min(1, "Choose a start time"),
    end_time: z.string().min(1, "Choose an end time"),
  }).superRefine((v, ctx) => {
    const bad = (path, message) => ctx.addIssue({ code: "custom", path: [path], message });
    if (v.session_date && (v.session_date < training.start_date || v.session_date > training.end_date)) {
      bad("session_date", `Pick a date between ${training.start_date} and ${training.end_date}`);
    }
    if (v.start_time && v.end_time && v.end_time <= v.start_time) bad("end_time", "End time must be after the start time");
    if (v.session_date && v.start_time && new Date(`${v.session_date}T${v.start_time}`) < now) bad("start_time", "That time has already passed");
  });

export const attendanceSchema = (studentCount) =>
  z.object({
    total_students: whole(1, studentCount, `Total must be between 1 and ${studentCount}`),
    present: whole(0, studentCount, "Enter a number of 0 or more"),
    absent: whole(0, studentCount, "Enter a number of 0 or more"),
  }).superRefine((v, ctx) => {
    if (v.present + v.absent > v.total_students) ctx.addIssue({ code: "custom", path: ["absent"], message: "Present plus absent cannot exceed the total" });
  });

export const notesSchema = z.object({ notes: z.string().max(1000, "Notes can be up to 1000 characters") });

export const plannedSessionsSchema = (alreadyScheduled) =>
  z.object({ planned_sessions: whole(Math.max(1, alreadyScheduled), 1000, `Enter a number from ${Math.max(1, alreadyScheduled)} (sessions already scheduled) to 1000`) });

export const interviewSchema = (now = new Date()) =>
  z.object({ interview_at: z.string().min(1, "Choose a date and time").refine((v) => new Date(v) >= now, "The interview cannot be in the past") });
