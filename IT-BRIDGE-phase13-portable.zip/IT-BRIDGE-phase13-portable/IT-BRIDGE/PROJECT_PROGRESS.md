# Project progress (audit of the actual repository)

**How to read this.** "Code complete" means implemented end to end (UI, API, service, database) and wired correctly according to
`scripts/audit_integration.py`. Four things have really run as of 2026-10-10 (re-run for Phase 13B.2): real **pytest** on the test files that need no FastAPI/SQLAlchemy (383 passed on the three baseline files, plus 60 passed / 111 skipped on the two start-up files), real **Pydantic** request validation, SQL against a real **PostgreSQL 16.15** server (through `psql`, 110 checks), and zod-backed frontend tests on a custom shim (187); `docker compose config` also parses the compose file (static only). The full backend pytest suite (FastAPI, SQLAlchemy), `alembic upgrade/downgrade/check`, real Vitest, the Vite build and `docker compose up` have **never been executed**: the 13B.2 acceptance attempt re-confirmed that this environment has no FastAPI/SQLAlchemy/Alembic/psycopg2/pydantic-settings/Vitest/Vite/jsdom, no package index and no Docker daemon. Nothing below is "execution verified" except what a verification section lists as PASSED, and each says what it does not prove.

## Phase table (your numbering)
| Phase | Status | Notes |
|---|---|---|
| 1 Foundation | COMPLETED (not run) | Monorepo, FastAPI, config, Docker (migrations + seed on start), Alembic `0001` + `0002`. Redis provisioned but unused. No CI/CD. |
| 2 Design system and landing | PARTIALLY COMPLETED | Tokens, Button, Badge, Field, TextArea, SelectField, ProgressBar, Pagination, EmptyState, StatusBadge, Logo, landing page. Missing: Modal, Table, Tabs, Toast, Tooltip, Skeleton, ErrorState, ConfirmDialog, landing statistics. |
| 3 Authentication | PARTIALLY COMPLETED | Register, login, refresh, `/me`, bcrypt, JWT, role guards, inactive-user block. Missing: password reset, email verification, server-side logout/revocation, rate limiting. |
| 4 Profiles | PARTIALLY COMPLETED | Trainer and institution profiles with multi-step completion. Missing: uploads, multiple preferred locations, institution contact fields. |
| 5 Skills and categories | PARTIALLY COMPLETED | Seeded lists, public listing, admin-only create. No admin edit screens. |
| 6 Training requirements | COMPLETED (not run) | Create, edit, close, expiry (platform timezone), validation on both sides, paginated lists. Lifecycle OPEN, FILLED, CLOSED, EXPIRED (derived) completed in Checkpoint C. |
| 7 Discovery and matching | COMPLETED (not run), no distance filter | Trainer and opportunity search, deterministic explainable matching, stored scores, weights API (no admin screen). |
| 8 Applications and hiring | COMPLETED (not run) | Apply, withdraw, re-apply, ranked review list, enforced transitions, hire, accept/decline/cancel, contact shared only after acceptance. Phase 10 added interview date/time to the INTERVIEW step. Checkpoint C: the trainer's acceptance fills the requirement and locks the other applications. |
| **9 Training management** | **COMPLETE** (statically and logic-verified; pytest, vitest, build, PostgreSQL not run) | See the Phase 9 section below. |
| **10 Sessions, attendance, calendar** | **COMPLETE** (statically and logic-verified; pytest, vitest, build, PostgreSQL not run) | See the Phase 10 sections below. |
| **Checkpoint C** (stabilization and integration review of Phases 9 and 10) | **COMPLETE** | Requirement lifecycle fixed and verified, stale documentation corrected. See the Checkpoint C section. |
| **11 Notifications** | **COMPLETE** (statically and logic-verified; pytest, vitest, build, PostgreSQL not run) | See the Phase 11 section below. Real email, SMS and WhatsApp are NOT implemented. |
| **12 Reviews and ratings** | **COMPLETE** (statically and logic-verified; pytest, vitest, build, PostgreSQL not run) | See the Phase 12 section below. No moderation screen. |
| **13 Payments, invoices, trainer earnings** | **SANDBOX-ONLY. FINAL ACCEPTANCE BLOCKED (13B.2): required dependencies are not available here. NOT production payment ready** (real pytest on the pure rule and start-up-guard tests, 110 SQL checks on real PostgreSQL via psql, custom harnesses for the rest; the full pytest/API/Alembic/PostgreSQL-integration/Vitest/Vite/Docker runs are BLOCKED) | See the Phase 13, 13B.1 and 13B.2 sections below. No real money can move. |
| **14** | **NOT STARTED** | Waiting for instruction. |


Not built: a real payment provider (Phase 13 is a sandbox), admin and verification screens, analytics, chat, uploads, Celery jobs, CI/CD, rate limiting.

## Phase 13 (Payments, invoices and trainer earnings): SANDBOX ONLY, remediated and stabilized
Built from the stabilized Phase 12 tree, then remediated after an independent review (this section describes the remediated state of `IT-BRIDGE-phase13-stabilized.zip`; the 13B.1 to 13B.4 changes that followed are in the sub-sections below; the newest archive is `IT-BRIDGE-phase13b4-stabilized.zip`, which differs from 13b3 only in documentation).
**Nothing here collects real money, and none of it may be described as production payment ready.** Payments are sandbox-only and stay off unless an operator opts in twice (below).

### Decisions (approved) and how they are implemented
| Decision | Implementation |
|---|---|
| 1 Integer paise | `BigInteger` columns, `payment_rules.py` uses ints only; `verify_payments.py` fails on any float, Decimal or `/` in the payment modules |
| 2 10% placeholder | `PLATFORM_COMMISSION_BPS=1000`, snapshotted per payment, a training keeps the rate of its first money; production + payments enabled refuses to start unless `PAYMENT_COMMISSION_CONFIRMED=true` |
| 3 Institution pays the fee, commission from the trainer's share | `net = amount - commission`, half-up integer rounding; instalments capped by the fee; the final commission is computed when a payment succeeds (`settle_commission`) so late successes and refunds cannot make the total drift |
| 4 Earnings AVAILABLE on completion, payout recorded | `PENDING -> AVAILABLE` when the training is COMPLETED (zero hold), `PAID` only by `POST /admin/earnings/{id}/payout` (reference text only; account numbers and UPI ids refused) |
| 5 Full refunds, admin only | `POST /admin/payments/{id}/refund`, two-phase, idempotent, refused after payout; credit note instead of editing the invoice |
| 6 Cancelled after payment | flagged `TRAINING_CANCELLED` for review (also when another flag exists), no automatic refund, records kept |
| 7 Platform invoices, not tax invoices | stated on every invoice; tax treatment needs professional accounting advice |

### Remediation (review findings -> fix -> regression test)
| # | Defect | Fix | Regression test(s) |
|---|---|---|---|
| B1 | An over-cap payment counted as settled money, so a later legitimate payment could be flagged over-cap (fee 100: A 60 ok, B 60 expired, C 40 open, B late success flagged, C then wrongly flagged) | The cap basis is `settled_totals()`: money of SUCCEEDED payments **with a recorded commission** (an over-cap success has none). `collected_paise` stays "money held" and only blocks new attempts | `test_payment_rules.py::Ledger` (7, incl. a negative control); `test_payments_phase13.py` B1 tests (4: C not flagged, totals, invoices, earning, commission, and after B is refunded) |
| B2 | One `needs_review` + one `review_reason` per payment: resolving one reason hid another | Table `payment_review_flags` (migration 0006): one row per reason, partial unique index `uq_review_flag_open (payment_id, reason) WHERE resolved_at IS NULL`; `payments.needs_review/review_reason` are a summary written only by `sync_review_state`; `rules.pick_flag` demands a named reason when several are open; OVER_CAP cannot be closed before a refund; the payment-level note/reviewer are set only when the last flag closes; each resolution is audited. Admin only | `pick_flag` rule tests; `test_payments_phase13.py` B2 tests (10: three flags, resolved one at a time, payment stays queued, reason required, over-cap needs refund, resolution fields, authorization) |
| C1 | `.env.example` shipped `PAYMENTS_ENABLED=true`; the simulator needed no explicit opt-in | `.env.example` has `PAYMENTS_ENABLED=false` and `PAYMENT_SANDBOX_ENABLED=false`. `rules.sandbox_usable` needs the payments switch, an implemented provider, the explicit opt-in **and** ENVIRONMENT in (development, test). `config_problems` / `core/payment_guard` fail closed: a missing or unknown ENVIRONMENT (13B.1: whether or not payments are enabled; there is no default), sandbox in production, an unconfirmed commission, and (13B.1) a weak/example webhook secret in production even with payments disabled all refuse to start | `test_payment_rules.py` config/sandbox tests; `test_payment_guard_unit.py`; `test_startup_hermetic.py`; `test_payments_phase13.py` boot tests (missing ENVIRONMENT, missing secret, opt-in, production, disabled) |
| N1 | A notification failure rolled back a valid settlement, refund or payout | `notification_service.notify_event_safe` runs the dispatch in a SAVEPOINT; on failure only the notification is lost (logged, returns False, queued pushes dropped); the push listeners ignore nested transactions. Used by settlement, flagging, refund, payout and the training hooks | `test_payments_phase13.py`: 8 test functions / 11 cases on SQLite (settlement x2, flagging, refund x2, payout x2, unflushed changes, no-failure control, two push-timing tests; counted from the source). **SQLite does not prove PostgreSQL savepoint behaviour**: `test_postgres_notifications.py` (13B.1, 6 functions / 8 cases, PostgreSQL) covers that and is **NOT RUN**; `verify_session_rules.py` |
| S1 | Landing page claimed "spending trends" | Card now says "Payment and earnings summaries ... Trend analytics are not available yet." | `verify_payments.py` section 7 (static text check of `Landing.jsx`) |
| S2 | Provider order id longer than the column failed after the provider call | `rules.valid_order_id` (max 80 characters) is checked before the insert; a failure answers 502 PROVIDER_ERROR "Nothing was charged" and is logged | rule tests; API tests |
| S3 | Reconcile always took the first 200 open attempts by id, so attempts that kept failing or staying open could occupy the window forever | Ordered by `updated_at, id`; every examined attempt is touched, including after an exception, so a stuck one rotates to the back | `test_payments_phase13.py` reconcile-rotation test |
| S4 | Hardening (found while reviewing S1/B1): a pending earning that can never be promoted (its payment has a refund, or the hold has certainly not elapsed) could fill the 500-row promotion window and starve earnings behind it | `promote_available` now filters those rows **in SQL** (`NOT EXISTS` refund; with no training row, `completed_at` at least a day short of the hold) so they cannot occupy the window. The Python-level refund check inside the loop already existed in the original Phase 13 and is unchanged: it is what skips a refunded payment's earning, and the conditional `UPDATE ... WHERE status = 'PENDING'` still stops a double promotion | 2 promotion tests (`test_an_earning_whose_refund_is_still_pending_is_not_promoted`, `test_promotion_ignores_earnings_inside_the_hold_and_still_reaches_those_behind_them`) |
| S5 | Downgrades 0005/0006 silently dropped financial tables | `_refuse_to_discard`: an online downgrade refuses while a financial table holds a row, unless `ITB_ALLOW_FINANCIAL_DOWNGRADE=I_UNDERSTAND_DATA_WILL_BE_DESTROYED` is set. Without the override an offline (`--sql`) downgrade is refused too. **With the override set the check returns first, so `alembic downgrade --sql` DOES emit the destructive DDL.** 0006 also refuses to upgrade if a `needs_review` row has no `review_reason` | `check_migrations_static.py` (guard replay); `test_migrations_postgres.py` (13B.1: full-schema snapshot before/after the refused downgrade; written, NOT run) |
| S6 | Invoice immutability and cross-table consistency were conventions only | Migration 0007 (**PostgreSQL only**). **Rejects every UPDATE/DELETE:** `invoices`, `payment_transactions`. **`payments`:** identity columns cannot change (all other columns, `status` included, can). **Checked at INSERT only:** invoices, trainer earnings, platform commissions, refunds (full only) and ledger rows against their own payment. **NOT immutable:** commissions, earnings, refunds, webhook events, review flags, invoice counters, payment statuses (hand-written SQL can edit or delete them; only CHECK/FK/UNIQUE apply). The payer is not validated against any child. Not available on SQLite. See the matrix in README and the 0007 docstring | `verify_postgres_sql.py` groups C (the triggers) and F (the documented non-protections, 13B.1), via psql, **not Alembic**; `test_postgres_concurrency.py` trigger tests (written, NOT run) |
| S7 | The worker waited only for the backend to *start* (plus `sleep 15`), not for migrations to finish | Backend health check; the worker `depends_on` it being healthy (no sleep); a migrations-first comment (README: run `alembic upgrade head` before anything else) | YAML parse only (docker is BLOCKED) |

### What was built
| Area | Status |
|---|---|
| Migrations `0005_payments_invoices_earnings` (eight tables), `0006_payment_review_flags` (flags table + backfill), `0007_financial_integrity_triggers` (PostgreSQL-only triggers). `ON DELETE RESTRICT`, CHECK/UNIQUE, partial unique indexes, scoped idempotency keys | COMPLETE. 0005/0006 executed only on SQLite (strict) and 0001-0007 DDL on real PostgreSQL through psql. **Alembic itself has not run.** |
| Pure rules (`payment_rules.py`), provider abstraction and sandbox, trusted path `handle_webhook -> process_event`, reconciliation, expiry, PROCESSING timeout | COMPLETE (sandbox only) |
| Invoices, earnings, admin refund/payout/review, training hooks | COMPLETE. **Service code has never run under SQLAlchemy** |
| Notifications: seven types, stable dedupe keys, failures isolated by a SAVEPOINT | COMPLETE (isolation untested on a real SQLAlchemy session) |
| Frontend: payment panel, institution payments, trainer earnings, printable invoice, dashboard cards, nav, routes, sandbox banner, polling, duplicate-submission guard | COMPLETE |
| Tests written | `test_payment_rules.py` 101 functions (376 cases); `test_payments_phase13.py` 140 functions (the webhook-handler matrix is one function with 24 cases); `test_migrations_postgres.py` 4; `test_postgres_concurrency.py` 11; `test_postgres_notifications.py` 6; `test_payment_guard_unit.py` 8 functions (54 cases); `test_startup_hermetic.py` 15 functions (117 cases, 111 of them skipped without the app's dependencies); shared matrix definition `tests/webhook_secret_matrix.py`; frontend `utils/payments.test.js`, `components/PaymentSection.test.jsx` |
| `tools/frontend-shim/` | Portable stop-gap (not Vitest, not Vite). Replaces the stale `frontend-check-shim.zip` |

### Phase 13B.4 provisioned acceptance execution (this archive: `IT-BRIDGE-phase13b4-stabilized.zip`): BLOCKED BY EGRESS POLICY
**Decision: no final acceptance is claimed; Phase 13 is NOT stable.** Candidate `IT-BRIDGE-phase13b3-stabilized.zip` (SHA-256 `d58568cc71bf50c3a3cd5b361b41eedbf8e33c88bcdc11d1f6c8700adf65e610`); Phase 12 baseline `IT-BRIDGE-phase12-stabilized.zip` still `f60c33babb4009ce433fc2dd28b3297604055858b558058fbfa70757ff4aad0c`. The code is unchanged from 13B.3; this archive differs only in these documents.
**Why nothing new could run:** the environment is still not provisioned and the dependencies could not be fetched.
- `python3.12 -m venv` worked, but `pip install -r backend/requirements.txt` failed: `Failed to establish a new connection: [Errno -2] Name or service not known` ... `ERROR: No matching distribution found for fastapi`. (`getent hosts pypi.org registry.npmjs.org files.pythonhosted.org` returns nothing.)
- Through the session's agent proxy (the documented route) a `curl` to `https://pypi.org/simple/fastapi/` and to `https://registry.npmjs.org/vitest` answered `CONNECT tunnel failed, response 403`; the proxy status endpoint records `connect_rejected ... policy denial` for `pypi.org:443` and `registry.npmjs.org:443`. That is an organisation egress-policy denial, so it was not retried or routed around (the proxy variable was kept; only `NO_PROXY` was unset for those two probes so that the request reached the proxy). Nothing was downloaded or installed, and the probe venv was deleted.
- **Needed to unblock:** allow `pypi.org`, `files.pythonhosted.org` and `registry.npmjs.org` for the session (or provide a mirror / pre-built wheelhouse and `node_modules`), plus a Docker daemon.
- **Pins and lockfile:** not created. Versions can only be pinned after a verified green run; guessed pins would be fabricated. `requirements.txt` is still unpinned and `frontend/` still has no lockfile. Procedure after the first green run: `pip freeze` into a pinned requirements file, `npm install` then commit `package-lock.json`, switch the Dockerfile to `npm ci`, and re-run.

**13B.4 matrix** (all commands run from a clean extraction of the 13b3 archive; PASS means it executed):

| Check | Command | Result |
|---|---|---|
| Full backend pytest incl. API tests | `cd backend && pytest -q -p no:cacheprovider` | **BLOCKED** (`No module named 'fastapi'` at `tests/conftest.py:12`) |
| Alembic upgrade / downgrade / drift | `python3 -c "import alembic"` (outside `backend/`) | **BLOCKED** (`No module named 'alembic'`) |
| PG migration-refusal atomicity | `tests/test_migrations_postgres.py` | **BLOCKED** |
| PG notification SAVEPOINT isolation | `tests/test_postgres_notifications.py` | **BLOCKED** |
| PG concurrency | `tests/test_postgres_concurrency.py` | **BLOCKED** |
| Real Vitest incl. `notificationService.test.js` | `cd frontend && npm test` | **BLOCKED** (no `node_modules`; vitest, vite, axios, react-router-dom, @tanstack/react-query not installed) |
| Real Vite build | `cd frontend && npm run build` | **BLOCKED** |
| Production webhook-secret start-up tests | `tests/test_startup_hermetic.py -rs` | **6 passed, 111 SKIPPED** (needs fastapi, pydantic_settings, sqlalchemy): the skipped cells are **NOT RUN**, not passed |
| Secret matrix, fee-cap, review-flag, refund, earnings rules as pure logic | `pytest --noconftest -p no:cacheprovider -q tests/test_matching.py tests/test_payment_guard_unit.py tests/test_payment_rules.py tests/test_static_integrity.py tests/test_startup_hermetic.py` | **PASS** 443 passed, 111 skipped (the skips are the row above). Not the API |
| API-level payment / review / notification regressions | `tests/test_payments_phase13.py` and the other API files | **BLOCKED** |
| PostgreSQL 16.15 SQL-level checks (psql only; NOT Alembic, NOT the app) | `PGHOST=127.0.0.1 PGPORT=54334 PGUSER=postgres python3 -I scripts/verify_postgres_sql.py` | **PASS** 110 / 0 |
| Static / SQLite scripts | `python3 -I scripts/<name>.py` | **PASS**: `check_migrations_static` 0 problems, `verify_payments` 140/0 (SQLite), `verify_payment_schemas` 46/0, `verify_session_rules` 25/0, `audit_integration` 0 problems |
| Frontend shim | `ITB_SHIM_MODULES=/opt/npm-tools/node_modules node tools/frontend-shim/shim.mjs test` | **PASS in the shim only**: 187 / 0 (**NOT Vitest, NOT Vite**) |
| Docker Compose static validation | `docker compose config -q` (scratch copy, `.env` from `.env.example`) | **PASS** (static only) |
| Docker runtime | `docker info` / `docker compose up --build` | **BLOCKED** (`failed to connect to the docker API at unix:///var/run/docker.sock`) |

**Defects:** none new found in this run (nothing new could execute). Open items from 13B.3 remain: the `notificationService.test.js` mock fix is unverified under real Vitest; the stand-alone `outbox` and `reminders` workers do not run the start-up guard; dependencies are unpinned.

### Phase 13B.3 provisioned runtime acceptance (archive `IT-BRIDGE-phase13b3-stabilized.zip`): STILL BLOCKED
**Decision: Phase 13 is NOT stable and NOT accepted.** The environment used for 13B.3 is not provisioned. Candidate checked: `IT-BRIDGE-phase13b2-stabilized.zip`, SHA-256 `5f31c5fa0a046fdb43bd0d94d8564c9b31f7a5b9acd1214c11a58cd44c559ab5`, and the working tree was byte-identical to it (`diff -rq`, 227 files) before any change. The approved baseline `IT-BRIDGE-phase12-stabilized.zip` still hashes to `f60c33babb4009ce433fc2dd28b3297604055858b558058fbfa70757ff4aad0c`.
No network access and no package installation were attempted or used (the only look at package sources was a read-only listing of the local pip and npm caches: neither holds any required package). No real payment credential exists anywhere in the tree; `.env.example` still ships `PAYMENTS_ENABLED=false` and `PAYMENT_SANDBOX_ENABLED=false`.

**The only change: one real defect found by reading the tests against the real libraries, fixed without weakening any assertion.** `frontend/src/services/notificationService.test.js` read `globalThis.__calls` and `globalThis.__apiData`, which only the stop-gap shim's fake axios (`tools/frontend-shim/stubs/axios.js`) defines. Under real Vitest `calls()` is `undefined`, so `calls().length = 0` in `beforeEach` would throw and all 5 tests would fail; with real axios nothing would be recorded and `api.get` would try to reach `localhost:8000`. The test now carries its own `vi.mock("axios", ...)` recorder (same recorded shape, same 5 assertions, unchanged). **This fix is verified only in the shim (the shim ignores `vi.mock` and uses its stub), NOT in real Vitest.** No other file changed apart from these three documents. No backend code changed.

**Matrix (this run).** PASS means it really executed; the tool is named so a harness is never mistaken for the real thing.

| # | Required item | Command / how | Result |
|---|---|---|---|
| 1 | Full backend pytest incl. all API tests | `cd backend && pytest -q -p no:cacheprovider` | **BLOCKED**: `ImportError while loading conftest ... tests/conftest.py:12: from fastapi.testclient import TestClient  ModuleNotFoundError: No module named 'fastapi'`. With `--noconftest`, 19 of 26 test files fail at collection: sqlalchemy (8), pydantic_settings (7), fastapi (2), alembic (2). **No API test executed in this run.** |
| 2 | Alembic upgrade / downgrade / drift on PostgreSQL | `tests/test_migrations_postgres.py`, `alembic upgrade head`, `alembic check` | **BLOCKED**: alembic, sqlalchemy and a PostgreSQL driver (psycopg2/psycopg) are not installed |
| 3 | PostgreSQL migration-refusal atomicity | `tests/test_migrations_postgres.py` | **BLOCKED** (same). The SQL-level substitute (row 9) is NOT equivalent |
| 4 | PostgreSQL notification SAVEPOINT isolation | `tests/test_postgres_notifications.py` | **BLOCKED** (needs sqlalchemy, fastapi, psycopg2) |
| 5 | PostgreSQL concurrency (5 service scenarios) | `tests/test_postgres_concurrency.py` | **BLOCKED** (same). Not covered by row 9 |
| 6 | Real Vitest | `cd frontend && npm test` | **BLOCKED**: `frontend/node_modules` absent; vitest, vite, @vitejs/plugin-react, react-router-dom, @tanstack/react-query, axios are not installed anywhere |
| 7 | Real Vite production build | `cd frontend && npm run build` | **BLOCKED** (same) |
| 8a | Docker Compose static validation | `docker compose config -q` on a scratch copy with `.env` copied from `.env.example` | **PASS** (static parse only) |
| 8b | Docker runtime | `docker compose up --build` | **BLOCKED**: `failed to connect to the docker API at unix:///var/run/docker.sock: no such file or directory` (client 29.8.2 and Compose v5.5.1 installed, no daemon) |
| 9 | PostgreSQL 16.15 SQL-level checks (psql only; NOT Alembic, NOT SQLAlchemy, NOT the app) | `PGHOST=127.0.0.1 PGPORT=54333 PGUSER=postgres python3 -I scripts/verify_postgres_sql.py` on a throw-away server | **PASS** 110 / 0 failed |
| 10 | Production webhook-secret start-up tests | `tests/test_startup_hermetic.py` | **PARTLY RAN, mostly SKIPPED**: 6 passed, **111 skipped** (no fastapi/pydantic_settings/sqlalchemy; a skip is not a pass). The 30-cell decision matrix itself ran as pure logic in `test_payment_rules.py` and `test_payment_guard_unit.py` (row 11) |
| 11 | Pure-logic pytest (real pytest 9.1.1, `--noconftest`) | `pytest --noconftest -p no:cacheprovider -q tests/test_matching.py tests/test_payment_guard_unit.py tests/test_payment_rules.py tests/test_static_integrity.py tests/test_startup_hermetic.py` | **PASS** 443 passed (6 + 54 + 376 + 1 + 6), 111 skipped. This covers the fee-cap, review-flag, refund, earnings and config rules as functions; it is NOT the API |
| 12 | Regression tests for fee caps, review flags, refunds, earnings, notification handling through the API | `tests/test_payments_phase13.py` (140 functions) | **BLOCKED** (conftest). Rule-level coverage only, via rows 11 and 13 |
| 13 | Static / SQLite scripts | `python3 -I scripts/<name>.py` | **PASS**: `check_migrations_static` 0 problems; `verify_payments` 140 / 0 (SQLite, NOT PostgreSQL); `verify_payment_schemas` 46 / 0 (real Pydantic 2.13.5, request models only); `verify_session_rules` 25 / 0; `audit_integration` 0 problems, 79 routes; `python3 -m compileall` clean |
| 14 | Frontend shim (stop-gap) | `ITB_SHIM_MODULES=/opt/npm-tools/node_modules node tools/frontend-shim/shim.mjs check` and `... test` | **PASS in the shim only**: 187 passed, 0 failed (**NOT Vitest, NOT Vite**; react-router, react-query, axios, auth and layout are stubs) |

**Environment consistency across the API and the workers (read from the code; not run).** `docker-compose.yml` gives `backend` and `worker` the same `env_file: .env`. `main.py`, `app.workers.payments` and `app.workers.loop` all call `assert_safe_payment_config()`. **Gap:** the stand-alone `app.workers.outbox` and `app.workers.reminders` entry points (documented for cron) do **not** call it, so run on their own they would start with a missing or unknown `ENVIRONMENT` that the API refuses. They never touch payment tables or the provider, so the impact is limited, but it is an inconsistency. It was left unchanged because it cannot be tested here; the proposed fix is the same two lines the payment worker has, plus a hermetic test.

**Manifest findings.** `backend/requirements.txt` pins nothing (13 bare names) and `frontend/package.json` has no lockfile (the Dockerfile uses `npm install`), so "the declared versions" are ranges and two provisioned machines can resolve differently. Commit a lockfile and pin the backend (`pip freeze` from the first green run) as part of unblocking. `@testing-library/react` is declared but no test imports it; no test needs jsdom (all render with `react-dom/server`), so the default Node environment is what real Vitest will use.

**To unblock (needs authorization to install or a provisioned machine):** Python 3.11+ with `pip install -r backend/requirements.txt`; Node 20+ with `cd frontend && npm install` (then commit the lockfile and use `npm ci`); a PostgreSQL 16 database whose name contains `test` in `ITB_TEST_DATABASE_URL`; a Docker daemon. Then run the exact sequence in "Verification on a fully provisioned machine" below and report every failure before building anything new. Expect fixes: the Phase 13 service layer, its API tests, Alembic 0005-0007 and the frontend toolchain on Phase 13 code have not run in any environment used for Phase 13.

### Phase 13B.2 final acceptance and security gate (archive `IT-BRIDGE-phase13b2-stabilized.zip`)
**Configuration decision (the only code change):** `ENVIRONMENT=production` now refuses to start if `PAYMENT_WEBHOOK_SECRET` is missing, empty, weak or a known example value, **regardless of `PAYMENTS_ENABLED`** (`rules.config_problems`; it replaces the 13B.1 behaviour in which production + payments disabled + an empty secret still started). The request-handler check (`rules.webhook_secret_usable` in `handle_webhook`) is kept as defence in depth and now also applies to an unknown environment. Development and test accept any secret, including none. Tests: the 30-cell matrix (production/development/test x payments on/off x missing/empty/weak/example/valid; `tests/webhook_secret_matrix.py`) runs as rule tests (PASS), against the real guard (PASS), in child processes with and without a disagreeing `.env` (NOT RUN) and against the webhook handler through the API (24 cells, NOT RUN). Existing assertions that encoded the old decision were changed deliberately, not weakened: "production, payments off, no secret starts" is now "is refused"; the production boot tests now supply a strong secret where they only mean to test something else. Two mutation checks (restricting the new refusal to `enabled`; removing the handler check) fail 11 and 24 tests as they should.

**Final acceptance: BLOCKED.** Exact commands and results are in the matrix below. The environment has no FastAPI, SQLAlchemy, Alembic, psycopg2/psycopg, pydantic-settings, httpx, Vitest, Vite, jsdom or Docker daemon, and no package index. (To confirm that, `pip download sqlalchemy` and `npm view vitest` / `npx` were tried; they failed with no network route and nothing was downloaded or installed.) A PostgreSQL 16.15 server is available, so the SQL-level checks run, but they are not Alembic and not the application.

| # | Required test | Command | Result |
|---|---|---|---|
| 1 | Full backend pytest incl. API tests | `cd backend && pytest -q -p no:cacheprovider` | **BLOCKED**: `ImportError while loading conftest '.../tests/conftest.py'. tests/conftest.py:12: from fastapi.testclient import TestClient  E ModuleNotFoundError: No module named 'fastapi'` |
| 2 | Alembic upgrade / downgrade / drift on PostgreSQL | `python3 -m alembic --version` (from a directory without the project's `alembic/` folder) | **BLOCKED**: `No module named alembic`; no `alembic` executable |
| 3 | Both PostgreSQL integration-test files (+ the notification file) | `ITB_TEST_DATABASE_URL=postgresql+psycopg2://postgres@127.0.0.1:54332/itbridge_test pytest -q -p no:cacheprovider tests/test_migrations_postgres.py tests/test_postgres_concurrency.py tests/test_postgres_notifications.py` (a PostgreSQL 16.15 server WAS running) | **NOT RUN / BLOCKED**: same conftest `ModuleNotFoundError: fastapi`; with `--noconftest`: `ImportError: cannot import name 'command' from 'alembic'`, `No module named 'fastapi'`, `No module named 'sqlalchemy'`. Downgrade-refusal atomicity and notification SAVEPOINT isolation remain **unverified** |
| 4 | Real Vitest | `cd frontend && npx vitest run` | **BLOCKED**: `frontend/node_modules` does not exist; vitest, vite, jsdom, @testing-library/react, react-router-dom, @tanstack/react-query are not resolvable; `npx` has no network route |
| 5 | Real Vite build | `cd frontend && npm run build` | **BLOCKED**: same (vite and @vitejs/plugin-react not installed) |
| 6a | Docker Compose static validation | `docker compose config` on a scratch copy with `.env` copied from `.env.example` | **PASS** (parses and resolves; services db, redis, backend, worker, frontend; `ENVIRONMENT: development`, payments and sandbox off). Static only |
| 6b | Docker runtime | `docker compose up --build -d` | **BLOCKED**: `failed to connect to the docker API at unix:///var/run/docker.sock ... no such file or directory` (Docker client 29.8.2 and Compose v5.5.1 are installed, no daemon) |
| 7 | Re-run of what can run | see "Phase 13 verification results" | **PASS** (383 + 60 pytest, 110 psql SQL checks, 140/0, 0, 0, 25/25, 46/46 scripts, 187 shim tests, 119 files compile) |

**Decision: blocked.** The sandbox-only code is as far along as this environment can take it, but it is not "stable": the service layer, the API tests, Alembic, the PostgreSQL integration tests and the frontend toolchain have never run. Treat the first full run on a provisioned machine ("Verification on a fully provisioned machine" below) as the real acceptance test. **Behaviour change:** every production deployment must now set a strong `PAYMENT_WEBHOOK_SECRET` even while payments are disabled, or it will not start.

### Phase 13B.1 acceptance-gap remediation (this archive: `IT-BRIDGE-phase13b1-stabilized.zip`)
Scope: only the documentation, configuration and test gaps of the independent 13B review. No new product feature, no provider, no money movement. Phase 12's baseline archive hash is unchanged.
| Req | Gap | What changed | Evidence (and its limits) |
|---|---|---|---|
| A | Docs called commissions, refunds, earnings, flags, events and payment statuses immutable | Docs now carry a four-way matrix (rejects UPDATE/DELETE / identity-frozen / INSERT-only checks / still editable) in the 0007 docstring, README, ARCHITECTURE and S6. **No trigger was added**: every documented invariant is either enforced or no longer claimed | `verify_postgres_sql.py` group F runs the "still editable" statements on real PostgreSQL 16 (in rolled-back transactions): PASS. Via psql, not Alembic |
| B | Missing `ENVIRONMENT` was detected through pydantic-settings `model_fields_set` (fail-open if absent) | `Settings.environment` has **no default** (`""`). `rules.environment_kind` maps anything but development/test/production(prod) to `unknown`, which `config_problems` refuses **whether or not payments are enabled**. No pydantic internals are used. `.env.example` and the test conftest set `ENVIRONMENT=development` | Guard logic: `test_payment_rules.py`, `test_payment_guard_unit.py` PASS under real pytest. Real `Settings()` loading: `test_startup_hermetic.py` **NOT RUN** (pydantic-settings is not installed) |
| C | Production + payments disabled + the public example webhook secret started, and the endpoint accepted it | 13B.1: production refused a set-but-weak/example secret at start-up regardless of `PAYMENTS_ENABLED`, and `handle_webhook` treats a weak/empty secret in production as "not configured" (503). **13B.1 had left production + payments disabled + an EMPTY secret startable; 13B.2 closed that (below).** | Superseded by the 13B.2 matrix tests |
| D | The downgrade-refusal test only checked `invoice_counters` and `payments` | It now compares a full snapshot (tables, columns, indexes, constraints, triggers, functions with definitions, revision) before and after the refused `alembic downgrade 0004`, names the financial tables, `payment_review_flags`, all eight 0007 triggers (and that they are enabled), the `itb_*` functions and both partial unique indexes, then runs the override downgrade | **NOT RUN** (no Alembic / SQLAlchemy / psycopg2). The snapshot SQL itself was executed on PostgreSQL 16 through psql (it parses and returns rows). A psql check of the transactional-DDL premise passes but is **not equivalent** to an Alembic run |
| E | No PostgreSQL test of the notification SAVEPOINT | `tests/test_postgres_notifications.py`: settlement / refund / payout with a database error in the notification write (read back through a separate connection), flagging, a direct `Session` test with a real PostgreSQL "value too long" error (outer transaction still usable, caller's change commits, no push queued), a later notification on the same session, and a control showing the same failure without a SAVEPOINT destroys the transaction | **NOT RUN** (no SQLAlchemy / psycopg2). SQLite does not prove PostgreSQL savepoint behaviour |
| F | Boot tests ran in `backend/` and inherited the shell | `tests/boot_env.py` runs the app in an empty temp cwd with every `Settings` variable scrubbed (list parsed from `config.py`) and an optional explicit `.env`; `test_startup_hermetic.py` runs every start-up case with and without a `.env` that disagrees with each variable the case sets, and proves the helper's isolation; `test_payments_phase13.py::_boot` uses it. App-level cases skip (never pass) without the dependencies, and every "refused" case asserts the guard's own message | Helper mechanics: 6 PASS under real pytest. App start-up cases: 41 **NOT RUN**. The case table is also evaluated against the real guard code (23 PASS) |
| G | Four wrong statements; misleading "paid in full" | Corrected here, in README and in ARCHITECTURE: `promote_available` (S4), the override and offline `--sql` (S5, README, ARCHITECTURE), notification test counts (N1), "ledger immutability" (S6). Over-cap money on hold now gives `AWAITING_REFUND` with the amount still due (summary adds `settled_paise`, `due_paise`; the panel shows settled money as paid); "paid in full" only when settled money reaches the fee. Cap rules untouched | Rule tests (PASS); frontend shim tests (187 PASS, not Vitest); API tests `test_money_on_hold...` and `test_the_fully_paid_message_is_unchanged...` **NOT RUN** |

**Behaviour changes to be aware of:** (1) every deployment must set `ENVIRONMENT`; a missing value now stops the API and the payment worker even with payments disabled (the standalone notification-outbox and reminder workers do not run the guard). (2) Production no longer starts with the `.env.example` webhook secret. (3) The payment summary has two new fields and a new `block_reason`.

**Status of Phase 13: sandbox baseline only, blocked pending runtime verification.** It is not fully acceptance-tested: the whole FastAPI/SQLAlchemy service layer, Alembic and every PostgreSQL integration test have still never run.

### Phase 13 verification results (what actually ran, 2026-10-10)
**PASSED. Read the "what it is" column: only the first row is a real test framework.**
| Command | Result | What it is, and what it does NOT prove |
|---|---|---|
| `pytest -q --noconftest -p no:cacheprovider tests/test_payment_rules.py tests/test_matching.py tests/test_static_integrity.py` (real pytest 9.1.1) | **383 passed** (376 + 6 + 1) | Real pytest, but only the files that need no FastAPI/SQLAlchemy. Pure rules, including the 30-cell webhook-secret matrix. Was 238 before 13B.1 and 290 after it |
| `pytest -q --noconftest -p no:cacheprovider tests/test_payment_guard_unit.py tests/test_startup_hermetic.py` (real pytest) | **60 passed, 111 skipped** | The guard tests run the REAL `payment_guard.py` / `payment_rules.py` against an injected stand-in for `app.core.config` (incl. the 30-cell matrix); they do **not** prove that pydantic-settings loads the same values. The 6 passed are the child-process helper mechanics. The 111 skipped (app start-up cases, incl. 60 matrix cells) need fastapi, pydantic-settings, SQLAlchemy: **NOT RUN, not passed** |
| `python scripts/verify_payments.py` | **140/140** | Constraints on strict SQLite + `ast` wiring checks. SQLite, not PostgreSQL; does not run the services |
| `PGHOST=127.0.0.1 PGPORT=54332 PGUSER=postgres python scripts/verify_postgres_sql.py` | **110/110** on **PostgreSQL 16.15** | Real server, driven through `psql`: constraints, partial unique indexes, 0006 backfill, 0007 triggers, the documented NON-protections, fee-cap SQL, a transactional-DDL check, concurrent probes. **Not Alembic, not SQLAlchemy, not the app.** The DDL check proves PostgreSQL's premise only, not that Alembic runs the downgrade in one transaction |
| `python scripts/check_migrations_static.py` | 0 problems | Replays migrations on SQLite through a recording stub; compares with the models by text; replays the downgrade guards |
| `python scripts/audit_integration.py` | 0 problems (79 routes) | Static |
| `python scripts/verify_session_rules.py` | 25/25 | AST-extracted functions run against test doubles |
| `python scripts/verify_payment_schemas.py` | 46/46 (real Pydantic 2.13.5) | Real Pydantic request validation; not FastAPI |
| `node tools/frontend-shim/shim.mjs check` / `test` | 83/83 parse and bundle; **187 passed, 0 failed, 0 blocked** (real zod) | A custom harness with stubs for router/query/axios/auth. **Not Vitest, not Vite, no jsdom** |
| `compile()` of every `.py` | 119 Python files, 0 errors | Syntax only |

**FAILED**: nothing in the final runs. During development my own mistakes were caught and fixed (wrong test expectations, a missing `training` argument in the SQL harness, a stub-DDL id default, three bugs found by an independent code review: the push listeners firing on SAVEPOINT release, reconcile not touching a still-open attempt after `process_event`, and a non-final resolve overwriting the payment-level resolution fields).

**BLOCKED (not executed, so not verified)**
| Check | Exact command | Exact error / reason |
|---|---|---|
| Full backend suite and the 139-function payment API suite | `cd backend && pytest -q -p no:cacheprovider` | `ImportError while loading conftest '.../backend/tests/conftest.py'. tests/conftest.py:12: in <module> from fastapi.testclient import TestClient  E ModuleNotFoundError: No module named 'fastapi'` |
| Everything importing SQLAlchemy / FastAPI / psycopg2 / pydantic_settings / httpx | `python3 -c "import sqlalchemy"` etc. | `ModuleNotFoundError: No module named '...'` for each of the five |
| Installing them | `pip download pytest-asyncio -d /tmp/pipchk2 --no-deps -q` | `Failed to establish a new connection: [Errno -2] Name or service not known` / `No matching distribution found`; the proxy status listed the package index as blocked. `npm view vitest version` timed out |
| Alembic `upgrade head`, `downgrade`, `alembic check` (drift) on PostgreSQL 16 | `ITB_TEST_DATABASE_URL=... pytest tests/test_migrations_postgres.py` | Alembic and SQLAlchemy are not installed. (A PostgreSQL 16 server **is** available here; only the Python side is missing) |
| PostgreSQL concurrency tests through the app | `ITB_TEST_DATABASE_URL=... pytest tests/test_postgres_concurrency.py` | Same. Only the SQL-level mirrors in `verify_postgres_sql.py` ran |
| Hermetic app start-up tests (real `Settings()`, real `import app.main`) | `cd backend && pytest tests/test_startup_hermetic.py -rs` | 41 cases SKIPPED: `needs ['fastapi', 'pydantic_settings', 'sqlalchemy']`. Not passed |
| PostgreSQL notification SAVEPOINT tests | `ITB_TEST_DATABASE_URL=... pytest tests/test_postgres_notifications.py` | NOT RUN: no SQLAlchemy / psycopg2 (a PostgreSQL 16 server is available) |
| Real Vitest, Vite build | `cd frontend && npm ci && npm test && npm run build` | No package access; vitest, vite, jsdom not installed |
| Docker compose | `docker compose up --build` | No Docker daemon |
| SQLAlchemy 2.0 SAVEPOINT behaviour on PostgreSQL (used by `notify_event_safe` and the push listeners) | `ITB_TEST_DATABASE_URL=... pytest tests/test_postgres_notifications.py` | Written (13B.1), **NOT RUN**: no SQLAlchemy / psycopg2. SQLite cannot stand in for it. (The old dependency on pydantic-settings `model_fields_set` was removed in 13B.1; there is nothing left to verify there except that `Settings()` reads `ENVIRONMENT` from the environment, which `test_startup_hermetic.py` checks and which is NOT RUN here.) |

The 139 API tests, the new PostgreSQL tests and all service code (`payment_service`, `invoice_service`, `earning_service`, `payment_admin_service`, the routes, `notify_event_safe`) have been written, compiled, name-checked and reviewed by an independent reader, **but never executed**. Treat the first full run as the real test.

### Known limitations of Phase 13 (read before relying on any of it)
**Financial / policy (not invented here; each needs a business decision)**
- **Commission is a placeholder** (10%); invoices are **not GST/tax invoices**; marketplace invoicing and tax need professional advice.
- **Earnings of a cancelled training:** the payment is flagged `TRAINING_CANCELLED`; the earning stays PENDING and is never made AVAILABLE. What happens to it (refund, partial payment, forfeit) is undecided.
- **Unresolved review cases** have no timeout or escalation. A payment with an open flag still exists and its money is held; only OVER_CAP is blocked from closing before a refund.
- `AMOUNT_MISMATCH`, `CURRENCY_MISMATCH` and `DUPLICATE_CHARGE` can be recorded, flagged and marked resolved, but an administrator has no tool to settle the money in the app; it is handled at the provider.
- No partial refunds; no refund after a payout is recorded; no payout execution; payouts are recorded by hand; no admin dashboard (APIs only).
**Provider / integration**
- No real provider. The sandbox `fetch_status` knows nothing, so reconciliation against real provider behaviour is untested; the webhook format is this project's own.
- The provider-side order is not cancelled when an attempt is cancelled or expires. `create_order` runs under the training row lock.
- Reconcile looks at up to 200 open attempts per run (rotating by `updated_at`); earnings promotion looks at 500.
**Consistency / platform**
- **Only invoices and the ledger (`payment_transactions`) are immutable, and only through database triggers on PostgreSQL (migration 0007).** Payment identity columns are frozen; five child tables are checked at INSERT; commissions, earnings, refunds, webhook events, review flags, invoice counters and payment statuses remain editable by hand-written SQL (matrix in README / the 0007 docstring). On SQLite none of it exists. 0007 was validated by hand-built DDL on PostgreSQL 16, **not** by Alembic, and is a strict precondition before any real provider.
- Notification isolation covers the payment, refund, payout and training complete/cancel-notice paths. Still unprotected plain `notify_event` calls: training date-change notices, the requirement-reopened notice on cancel, and `notify_waiting_applicants`. A failure there still rolls back that (non-financial) training transaction.
- A notification that fails is logged and lost; it is never retried or reported as delivered.
- `under_review` is visible to payers and trainers as a plain yes/no.
- Tests use `autoflush=True`, production sessions use `False` (one test covers the unflushed case). pysqlite's SAVEPOINT behaviour differs from psycopg2's, so notification isolation must be confirmed on PostgreSQL (`test_postgres_notifications.py`, NOT RUN).
- The 0006 backfill skips already-resolved legacy payments that carry no resolver (nothing to attribute). Downgrades of 0005/0006 refuse unless explicitly overridden (development databases only; export first); with the override set, an offline `--sql` downgrade emits the destructive DDL. 0007's upgrade is not idempotent (`CREATE TRIGGER` without `OR REPLACE`).
- Four frontend test files mock `useAuth` and `AppLayout` with `vi.mock`; that was only exercised in the shim (where `vi.mock` is a no-op), not in real Vitest. 13B.3 fixed one shim-only dependency (`notificationService.test.js`); there may be others that only a real run will show.
- The stand-alone `app.workers.outbox` and `app.workers.reminders` entry points do not run the start-up guard (13B.3).
- Dependencies are unpinned and the frontend has no lockfile (13B.3).

### Verification on a fully provisioned machine (exact steps)
    # 0. services: PostgreSQL 16 with an empty database whose NAME CONTAINS "test", Docker, Node 20, Python 3.11+
    cd backend && pip install -r requirements.txt pytest
    export ITB_TEST_DATABASE_URL=postgresql+psycopg2://itbridge:itbridge@localhost:5432/itbridge_test     # WIPED by the tests
    pytest -q -p no:cacheprovider                                   # whole suite incl. the 139 payment API tests; PG tests SKIP (not pass) without the variable
    pytest -q tests/test_migrations_postgres.py tests/test_postgres_concurrency.py tests/test_postgres_notifications.py tests/test_startup_hermetic.py -rs    # confirm none are skipped
    DATABASE_URL=$ITB_TEST_DATABASE_URL alembic upgrade head && alembic check     # then: ITB_ALLOW_FINANCIAL_DOWNGRADE=I_UNDERSTAND_DATA_WILL_BE_DESTROYED alembic downgrade base (test DB only)
    PGHOST=... PGUSER=postgres python ../scripts/verify_postgres_sql.py           # SQL-level checks, exit code 2 = BLOCKED
    python ../scripts/verify_payments.py; python ../scripts/check_migrations_static.py; python ../scripts/audit_integration.py
    python ../scripts/verify_session_rules.py; python ../scripts/verify_payment_schemas.py
    cd ../frontend && npm ci && npm test && npm run build
    cd .. && docker compose up --build                              # migrations run before the worker starts
Report any failure before building anything new. Expect to fix things: the service code has never run.

## Phase 12 (Reviews and ratings), implemented on the existing review system
The Phase 1 review model, endpoints and form were extended, not replaced. No schema change and no migration (existing review rows are untouched).

| Area | Status |
|---|---|
| Validation: `StrictInt` ratings (booleans, floats, strings refused) plus the same check in the service; trimmed comments, blank refused, 2,000 characters after trimming | COMPLETE. The 422 body carries field-level messages that the form shows |
| Eligibility: participants only (404 for others), COMPLETED only (409 with a reason for ACTIVE and CANCELLED), inactive or suspended accounts refused (403), duplicates refused by the service and the unique constraint | COMPLETE. No edit and no delete, by decision |
| Rating rules: one rounding function (half up, one decimal), `min_rating` filters on the displayed value and needs 2+ reviews, hidden reviews excluded, no rating for no reviews | COMPLETE. Documented in `review_service.py` and the README |
| Batching: `reviews_out` does two lookups for a whole page instead of up to two per review | COMPLETE (query counts not measured, tests not run) |
| `GET /institutions/{id}/reviews` and `/institutions/:id` page; link from the requirement page | COMPLETE. Name, verified flag, rating, reviews; no contact details; suspended or inactive institutions are 404 |
| `GET /reviews/me` (rating summary and `my_pending_reviews`, derived in SQL) and the dashboard card on both dashboards | COMPLETE |
| Notifications: dedupe keys on `REVIEW_REQUEST` and `REVIEW_RECEIVED`; `REVIEW_REMINDER` (3 days, once per participant, skips reviewers and blocked accounts, 14-day window, hourly job); `notify_event_safe` so an unbuildable notification cannot undo a review | COMPLETE. Same registry, outbox and preferences as Phase 11 |
| Frontend: field errors, trimmed comment with counter, success message, reasons for ineligible trainings, duplicate-click guard, plural wording, paged review lists, institution reviews, dashboard card | COMPLETE |

**Known limitations**
- Only the institution can complete a training, so a trainer cannot review until it does (Phase 9 rule, unchanged). The reminder goes out only after completion.
- No moderation: `is_hidden` is honoured everywhere but nothing sets it. No reporting of reviews. Suspension hides a profile's public reviews page but keeps the rows.
- `min_rating` decides in Python for the trainers whose SQL average passes a rounding margin, so it reads one row per rated trainer; fine at this scale.
- A notification that cannot be built is skipped and logged. Database failures while creating it still roll the whole review back, by design (the session would be unusable).
- The reviewer's display name is shown (a trainer's full name on institution reviews), as already on public trainer profiles.

### Phase 12 verification results (what actually ran)
**PASSED (executed; custom harnesses, not the real test frameworks)**
- `scripts/verify_session_rules.py`: 24 of 24. Seven new Phase 12 checks (review rating rules, submit rules including booleans, floats, blanks, duplicates, constraint race and notification target, pending-review SQL equivalent, reminder logic, `notify_event_safe`) plus the 17 earlier checks. Eight mutations (booleans accepted, suspended allowed, no dedupe key, banker's rounding, no two-review threshold, blank comment accepted, reviewers reminded, no 3-day delay) each failed the matching check.
- `check_migrations_static.py`: 0 problems (no migration was added). `audit_integration.py`: 0 problems. `py_compile` on all 98 Python files.
- Frontend through the esbuild shim: 73 of 73 files parse, `main.jsx` bundles. 101 cases defined, 91 passed, 10 blocked (below). 41 are new Phase 12 cases; six mutations each failed the matching cases.

**BLOCKED (not executed)**
- Backend pytest: 209 tests, 28 functions (36 cases with parametrisation) in the new `test_reviews_phase12.py`, plus one assertion updated in `test_reviews.py`. FastAPI, SQLAlchemy, Pydantic, Alembic and pytest cannot be installed here.
- Pydantic `StrictInt` rejecting booleans and the field-level 422 body are therefore **untested**; the service-level `type(v) is int` check is what the harness verified.
- SQL behaviour of the rating filter's `HAVING`, the pending-review query and the reminder's date window (checked only by shape and an equivalent SQLite query), concurrent submits, PostgreSQL, `docker compose up`, real vitest and the Vite build, and the 10 zod-dependent cases in `schemas/training.test.js`.

### Phase 12 stabilization review (read-only, 2026-10-09)
The saved `IT-BRIDGE-phase12.zip` is byte-identical to the working tree, and the Phase 11 zip to the saved Phase 11 snapshot. Against Phase 11: 27 files modified (including these docs, `.env.example` and the verification script), 5 added, none deleted, no migration; every modified file is a Phase 12 file. The review read the whole review path (schema, service, API, worker, notification hooks, both public pages, the form) and re-ran every available check with the same results as above (harness 24 of 24, migrations 0 problems, audit 0 problems, shim 73 of 73 parse, 91 of 101 cases pass). Extra, ad hoc and not kept in the repo: a name-resolution and import-cycle scan of `backend/app` (0 problems; it was shown to fail on an injected undefined name and cycle), and the 10 `schemas/training.test.js` failures were reproduced on the unmodified Phase 11 tree with the same shim, so they come from the zod stub and not from Phase 12. **Nothing was confirmed as a bug that blocks closing Phase 12.** Two small gaps, recorded and left unfixed on purpose (the review changed no code):
- `for_training` computes `can_review` from the *visible* reviews, while the duplicate check in `submit` and the pending count count hidden ones too. If a review of the viewer's own were ever hidden, the form would be offered and the submit would answer 409. Phase 11 behaved the same way; it cannot happen today because nothing sets `is_hidden`. Fix it together with the moderation work.
- `test_no_registered_type_is_dead_and_no_emitted_type_is_unregistered` only follows calls to `notify_event`, not `notify_event_safe`, so a misspelt type passed to `notify_event_safe` would be skipped and logged at runtime and not caught by that test. `REVIEW_RECEIVED` is registered and covered by `test_review_notifications_carry_dedupe_keys`.

## Phase 11 (Notifications), implemented on the existing foundation
The existing table, `notify()`, transaction-safe creation, read/unread, pagination, unread count, WebSocket delivery, reconnecting hook, bell, page and dedupe were kept and extended.

| Area | Status |
|---|---|
| Type registry (`services/notification_types.py`, 27 types, title/body/link/email/mandatory) | COMPLETE. Types that were never emitted were removed; a check fails if one is registered but not emitted or emitted but not registered |
| Events: application received / status / withdrawn; interview scheduled, updated, reminder (date and time); hiring request / accepted / declined / cancelled; requirement filled / reopened / closed; training created / dates / link / completed / cancelled / reminder; session scheduled / rescheduled / cancelled / reminder; review requested / received | COMPLETE. No payment, attendance or plain status-change noise |
| Preferences (in-app, email; default on; `mandatory` flag; extensible channel list) | COMPLETE. Table `notification_preferences`, `GET/PUT /notifications/preferences`, settings page. No SMS or WhatsApp control |
| Outbox (`notification_deliveries`: PENDING, SENT, FAILED, SKIPPED; attempts, backoff, dedupe, SKIP LOCKED) and worker | COMPLETE. Preferences, active account and verified email are checked again at send time. Stored errors have addresses stripped |
| Providers | DEVELOPMENT console provider only. Logs a delivery id, never an address, and says NOT SENT. An unknown `EMAIL_PROVIDER` raises. **No real delivery exists** |
| Scheduling | COMPLETE: `workers/outbox.py`, `workers/reminders.py --kind`, `workers/loop.py`, a compose `worker` service, cron lines in the README |
| WebSocket | Reconnect refreshes the list and badge immediately (frontend). Activity is re-checked before every message and the socket closes with 4403. Token stays in the first message. Per-user limit 5 kept. Single process |
| Frontend | Bell with a list component (loading, error, empty), page with settings link, settings page (`/notifications/settings`), safe deep links (same-app paths only), shared helpers in `utils/notifications.js` |

**Database**: migration `0004` adds `notification_preferences` and `notification_deliveries`. It is additive. Existing notification rows keep their old type strings (`SYSTEM`, `HIRING_RESPONSE`, `SESSION_UPDATE`, `TRAINING_UPDATE`); nothing reads the type for behaviour, so they still display. Downgrade drops the two tables and loses their rows.

**Known limitations**
- Real email, SMS, WhatsApp: not implemented. Nothing sets `email_verified` (except the seeded admin), so no ordinary user would receive an email even with a real provider. A verification flow is needed first.
- The WebSocket manager is per process. A socket of a deactivated user is closed when its next message arrives (or when `disconnect_user` is called, which nothing calls yet because there is no admin deactivation screen).
- Reminders for interviews use the platform timezone; the time shown is the platform time, not the viewer's.
- The in-app switch can silence every in-app notification today because no type is `mandatory`.
- Email addresses are never logged at INFO, but a WARNING for a failed delivery contains the redacted provider error.
- Multiple reminder runs at the very same instant on PostgreSQL could hit the unique dedupe constraint once; the loser's run fails and the next run succeeds (no duplicate is ever stored).

### Phase 11 verification results (what actually ran)
**PASSED (executed)**
- `scripts/verify_session_rules.py`: 19 logic checks (12 from earlier phases, 7 new): registry (renders, no dead types, email set, deep links match React routes, type length), outbox worker (send, skip for inactive / unverified / switched off / no address, retry with backoff, give up, idempotent, no address in stored errors), console provider, notify dedupe and preferences, delivery isolation (only workers reach a provider), interview reminders, and the real WebSocket manager under asyncio. Mutation controls (dedupe off, in-app preference ignored, socket limit raised, reschedule key, verified-email rule) each made the matching check fail.
- `scripts/check_migrations_static.py`: migrations 0001 to 0004 replayed on a stub and compared with all 21 model tables (179 columns, types, nullability, indexes): 0 problems. 0001 to 0003 also run on real SQLite; 0004 was **not** run on SQLite or PostgreSQL.
- `scripts/audit_integration.py`: 0 problems.
- `py_compile` over every backend, test, migration and script file.
- Frontend through the esbuild shim: 69 of 69 files parse, `main.jsx` bundles; 60 test cases defined, 50 run and passed in the shim, 10 blocked (below). New: 16 notification helper and service cases, 17 bell, page and settings cases.

**BLOCKED (not executed)**
- Backend pytest (181 tests, of which 49 are new or updated notification tests): FastAPI, SQLAlchemy, Pydantic, Alembic and pytest cannot be installed here (the package index is not reachable).
- `alembic upgrade head` on PostgreSQL, `docker compose up`.
- vitest itself, `npm run build` (Vite), and the 10 cases in `schemas/training.test.js` that need the real zod package (the shim only stubs zod, so they fail for that reason alone; Phase 10 already listed them as blocked on zod).
- Real WebSocket endpoint behaviour (`test_notification_ws.py`), HTTP authorization and ORM queries.

## Checkpoint after Phase 8 (stabilization)
A static audit of Phases 1 to 8 found and fixed: missing Alembic revisions, a Docker stack that never ran migrations, dead landing-page links,
dashboards without navigation, unlogged server errors, framework 404/405 responses outside the standard error format, deadlines judged in server
UTC instead of the platform timezone, and cross-module use of private matching helpers. It is a checkpoint, not a replacement for Phase 8.

## Phase 9 (Training management)
**What Phase 9 added**
- Training created only from an *accepted* hiring request, in the trainer's accept transaction. The service now refuses any other hiring status and a second training for the same request.
- The training stores a snapshot of what was agreed: technology, mode, location, description and the hiring terms, plus the existing title, dates, agreed fee, student count and planned sessions. Editing the requirement later never changes an agreed training.
- Online details: an optional `https` meeting link for ONLINE and HYBRID trainings, editable by either party while active.
- Lifecycle: stored status ACTIVE, COMPLETED, CANCELLED (kept as they were; no separate PENDING state is needed because "pending" is the hiring request). A derived `phase` is shown to users: UPCOMING, IN_PROGRESS, ENDED (end date passed, not yet closed), COMPLETED, CANCELLED.
- Transition rules: complete (institution only) needs the training to have started; cancel (either party) from ACTIVE; COMPLETED and CANCELLED are final and read-only; the start date of a started training is fixed and an upcoming one cannot be moved into the past.
- Paginated, status-filtered list (`/trainings/mine`) and a summary endpoint for dashboard cards.
- Frontend: Trainings list (status tabs, pagination, loading/error with retry/empty states), detail page with overview, meeting link editing and an "ended" notice, dashboard counts. Trainer and institution share the same pages with role-specific actions.

**API** (all authenticated, TRAINER or INSTITUTION who is a party; others get 404, admins 403, inactive users 403)
| Method and path | Change |
|---|---|
| GET /trainings/mine?page&page_size&status | **changed**: now paginated `{items,total,page,page_size}`, status filter, new fields |
| GET /trainings/summary | **new**: active, upcoming, in_progress, completed, cancelled |
| GET /trainings/{id} | changed: adds technology, mode, location, description, terms, meeting_link, phase, requirement_id |
| PATCH /trainings/{id}/details | **new**: set or clear the meeting link |
| PATCH /trainings/{id}/dates | changed: new date rules |
| POST /trainings/{id}/complete | changed: refused before the start date |
| POST /trainings/{id}/cancel | unchanged |

**Database** (migration `0002_training_snapshot`): adds `technology`, `mode`, `location`, `description`, `terms`, `meeting_link` to `trainings`; existing rows are backfilled from their requirement and hiring request, then the four required columns become NOT NULL. It is hand-written and has never been run.

**Tests added** (`backend/tests/test_training_lifecycle.py`, 19 tests): snapshot and snapshot independence, hiring terms copied, no training from pending/cancelled/declined hiring, duplicate creation refused, phases, start-before-complete rule, pagination and status filter, summary counts, authorization (outsiders, unauthenticated, inactive users, admin), missing training 404s, read-only completed/cancelled trainings, date rules, meeting link rules. Existing tests were adapted to the paginated list and the start rule. Frontend: `StatusBadge.test.jsx`, `Trainings.test.jsx` (vitest, react-dom/server).

**Known limitations**: the Trainings page is only unit-tested for its loading state and tabs; there are no browser tests. Skills of a requirement are not snapshotted (technology is). A suspended (verification) trainer keeps existing trainings. Admins cannot see or intervene in trainings.

Phase 10 followed this phase and is complete (see its section); the requirement left open after a hire was fixed in Checkpoint C.


## Phase 10 (Sessions, attendance, calendar), implemented on the existing code
**Bugs fixed**
- Completing a training no longer cancels sessions that happened. A started session with attendance becomes COMPLETED and keeps its attendance in progress and averages; only sessions that never started are cancelled; a past session with no attendance is left exactly as it was. Cancelling a training follows the same rule.
- Explicit nulls in `PATCH /sessions/{id}` now return 422 instead of 500.
- The progress bar is back on the Trainings list.
- Attendance can no longer be edited after a training is completed or cancelled (read-only, as in Phase 9).

**New behaviour**
- Sessions: new sessions and reschedules cannot be in the past (date and time); start and complete wait for the scheduled start time (platform clock); attendance waits for the start; double-booking is checked on date and time overlap across all of the trainer's active trainings (touching times are fine); a session with attendance cannot be cancelled.
- Attendance: `present + absent <= total_students <= training.student_count`; negative, non-integer and empty values are rejected; re-saving updates the same row.
- Session notes: a `notes` column on the session itself, written by the trainer (read by both parties), no longer inside attendance. Existing attendance notes are copied over by the migration.
- Planned sessions: the institution can change the count; it cannot go below the non-cancelled sessions already created.
- Interviews: moving an application to INTERVIEW requires a future date and time (`interview_at`); the institution can reschedule; interviews appear on both parties' calendars while the application is in the INTERVIEW stage.
- Calendar: events carry training phase, session status and times, mode, location and the meeting link (online and hybrid only), and are always limited to the caller's own trainings, applications and requirements.
- Performance: the training list and the calendar load related rows in a fixed number of queries; list items no longer include contact details.

**API changes**: new `PUT /sessions/{id}/notes` (trainer) and `PATCH /trainings/{id}/planned-sessions` (institution). Changed: `PATCH /applications/{id}/status` accepts and (for INTERVIEW) requires `interview_at`; application responses include `interview_at`; attendance requests no longer accept `notes` and attendance responses no longer return it; session responses include `notes`; training list items no longer include `contact`; calendar events gain `phase`, `mode`, `location`, `meeting_link` and a new `INTERVIEW` type.

**Database** (migration `0003_sessions_notes_interviews`): `training_sessions.notes`, `applications.interview_at`. `attendance.notes` is kept but deprecated. Hand-written, never run.

**Frontend**: Zod validation for session scheduling, rescheduling, attendance, planned sessions, notes and interviews (`schemas/training.js`); Start, Mark completed and Attendance are disabled until the session starts; no Cancel once attendance exists; notes editor; planned-sessions control; interview scheduling and rescheduling with a date-time picker; interview shown to the trainer; calendar shows phase, mode, location and an "Join online" link; progress bar restored.

**Tests added**: `backend/tests/test_phase10_sessions.py` (30 tests: ONGOING and invalid transitions, cancellation, past creation, explicit nulls, date/time validation, trainer overlap, re-saving attendance, attendance authorization, student-count cap, attendance after completion, completion and cancellation preserving history, notes, planned sessions, calendar phase/privacy/range, interviews, progress in the list, query counts that do not grow with the data). The existing status-transition test was adapted to interview scheduling. Frontend (vitest): `schemas/training.test.js`, `SessionCard.test.jsx`, and extra cases in `Trainings.test.jsx` (progress-bar regression).

**Known limitations**: time of day uses the platform timezone (`APP_TIMEZONE`), not each user's; the browser decides what "started" means for disabled buttons, the server decides for real. Double-booking and the planned-session count are application checks, not database constraints. Interviews have a start time only (no duration or location) and no reminder. A past session without attendance in a completed training stays SCHEDULED. Matching still treats a trainer's whole training range as busy rather than individual sessions. The month grid is the only calendar view. Session logic stays inside `training_service.py` (about 350 lines): splitting it would need a lazy import to avoid a cycle, so it was left alone.

## Checkpoint C (stabilization and integration review of Phases 9 and 10): COMPLETE
**Reviewed**: the whole Requirement, Application, Interview, Hiring, Training, Sessions, Attendance, Progress, Completion and history chain; authorization and privacy; API consistency; frontend/backend contracts; migrations; documentation; dead code; duplicate logic; query hot spots; security sanity.
**Result**: the chain is logically sound end to end except one gap, now fixed. No frontend/backend contract mismatches, no regressions from earlier phases.

**Fixed**
- **Requirement lifecycle.** Stored statuses are now OPEN, FILLED, CLOSED; EXPIRED is still derived (OPEN past its application deadline).
  - The hiring request is sent by the institution and **accepted by the trainer**. That acceptance creates the training and, in the same transaction, sets the requirement to **FILLED**.
  - FILLED: new applications are refused ("already been filled"); another hire is refused; the other applications cannot be moved (shortlist, interview, reject), because the server refuses every institution action on an application of a FILLED or CLOSED requirement. Those applications are not destroyed or rejected, so they are intact if the requirement reopens. A trainer may still withdraw their own application. A FILLED requirement cannot be edited. The institution may still close it manually.
  - The selected trainer's flow (hiring ACCEPTED, training, sessions, attendance, completion) is unchanged; completing a training never changes the requirement.
  - **Cancelling the training before its start date reopens the requirement** (back to OPEN, which shows as EXPIRED if the deadline has passed, so no new applications but the institution can continue with its existing applicants). Cancelling on or after the start date does **not** reopen it, and neither does a manually CLOSED requirement. Either party's cancellation counts.
  - Concurrency: the requirement row is locked (`SELECT ... FOR UPDATE`) in apply, hire, accept and training cancel, so two simultaneous actions cannot both succeed; a second accept that slips through is cancelled with a 409; the unique constraints (one training per hiring request, one application per trainer and requirement) remain the last line of defence. The lock itself needs PostgreSQL to be exercised; SQLite ignores it.
- **Stale documentation**: removed the outdated "Left for Phase 10" statement and the "requirement stays OPEN" limitation; status table now shows Phases 9 and 10 and Checkpoint C complete and Phase 11 not started.

**API and data changes**: no migration (the status column is a string; FILLED fits). Application responses gain `requirement_status`. New audit actions REQUIREMENT_FILLED and REQUIREMENT_REOPENED. Error messages for FILLED are explicit ("already been filled", "no longer open"). Editing a filled requirement now returns 409.

**Tests**: `backend/tests/test_requirement_lifecycle.py` (16 tests: accept fills; declined or cancelled hiring does not; filled rejects applications and hires; non-selected applications locked and intact; selected flow unchanged; cancel before start reopens (trainer and institution); cancel after start does not; manual close not reopened; closed and expired behaviour unchanged; unauthorized users; status not settable through the form; duplicate accept and cancel; a second accept that slipped through). One Phase 9 test was adapted (editing a filled requirement is now refused). Harness: lifecycle check added to `scripts/verify_session_rules.py`.

**Known limitations of this fix**: the application behind a cancelled training stays SELECTED as history, so that trainer cannot re-apply to the same requirement, and the same trainer cannot be re-hired on it (new applications from other trainers can). Applications of a FILLED requirement show their old status to trainers, with a "requirement has been filled" note. Accepting a hire still does not check the trainer's availability.

**Deliberately not done** (as instructed): deleting unused `ApiResponse` and `Role`, the redundant `hiring_request` field, eager loading, pagination redesign, interview notification text, availability check at hire, rate limiting, security headers, token storage, refresh rotation, server-side logout, per-user timezones, Celery.

## Phase 10 close-out: verification results
Environment: no Python packages (no FastAPI, SQLAlchemy, Pydantic, Alembic, pytest), no vitest, zod, Vite or Docker, and no network. `esbuild`, `react` and `react-dom` happen to be installed globally and were used. Nothing below was run on PostgreSQL or through HTTP.

### PASSED (executed, with what each covers and what it does not)
| Check | Result | Scope |
|---|---|---|
| `python scripts/audit_integration.py` | 0 problems, 59 routes | Every frontend API call, in-app link and relative import matches a real route; static, no running app |
| `python -m py_compile` (backend app, tests, migrations, scripts) | pass | Syntax only |
| Matching engine tests (outside pytest) | 6 of 6 | Pure Python engine |
| `python scripts/check_migrations_static.py` | 0 problems | Replays migrations 0001 to 0003 up and down against a recording stub: 19 tables and 160 columns match the models (types, nullability, indexes), downgrades leave nothing behind. Then runs the chain on a real SQLite 3.45 database with sample rows: the 0002 snapshot backfill, the 0003 session-notes backfill, the new columns and the downgrades behave correctly. Not run: PostgreSQL, Alembic itself, NOT NULL changes, constraint names |
| `python scripts/verify_session_rules.py` | 12 of 12 | Runs the REAL service functions (extracted from the source) against test doubles: create/reschedule (range, order, past to the minute, overlap), planned count, start/complete time rules and transitions, cancel blocked by attendance, attendance (roles, start time, student-count cap, read-only trainings, re-save in place, percentage), notes, planned-session floor, completion and cancellation preserving held sessions and attendance, phase, progress and attendance maths, list payload without contact details, calendar phase/mode/location/meeting link, meeting-link rules, interview scheduling, the requirement lifecycle (apply, change_status and hire guards, accept fills, cancel before the start reopens), and the double-booking predicate in equivalent SQL on SQLite. Not run: ORM statements, Pydantic validation, HTTP |
| Frontend syntax (esbuild) | 63 of 63 files parse | Includes every JSX file |
| Frontend whole-app bundle (esbuild) | OK | All internal imports and named exports resolve; 7 uninstalled packages left external |
| Component tests via a mini test shim (`StatusBadge`, `Trainings`, `SessionCard` test files, unmodified) | 14 of 14 | Real components rendered with react-dom/server; router, query client, icons, axios and zod replaced by stubs, so library behaviour is not tested. Covers: progress bar on every card (regression), phase/mode/location, empty and loading states, Start/Complete/Attendance disabled until the session starts, institution has no trainer actions, no actions on a completed training, no Cancel with attendance |
| `hasStarted`/`startsAt` from the real `schemas/training.js` | 5 assertions | zod stubbed |

**Controls (proof the checks can fail).** Temporarily breaking production code made the right check fail each time, and each file was then restored and diffed identical: removing the read-only check in `record_attendance`; reintroducing the "cancel every SCHEDULED session" bug in completion; removing the student-count cap; breaking the 0003 backfill SQL; changing a model column length (schema drift); removing the start-time rule in `SessionCard`.

### FAILED
No outstanding failures. Failures found during the close-out and resolved: the `SessionCard` test I wrote asserted on the word "disabled", which is always present in the button's CSS class, so one assertion failed and the one above it passed for the wrong reason. This was a defect in the test; it now checks the real HTML attribute and that the button exists. No production code was changed to satisfy any check.

### HARNESS / TOOLING ERRORS (not project errors, all corrected in the harness)
`import.meta.env` is Vite-only (defined for the plain bundler); the migration stub did not accept `UniqueConstraint(name=...)` and did not understand bare type classes such as `sa.Integer` (46 false type mismatches); a regex that assumed one `op.execute` layout (two harness failures); an incomplete test double for `SessionIn` in `create_session`; shell command substitution had swallowed backticked text in a documentation update (the docs were repaired and re-checked); a bash-only construct run in `sh`.

### BLOCKED (could not be executed here)
- The backend pytest suite (140 tests: 30 in `test_phase10_sessions.py`, 16 in `test_requirement_lifecycle.py`) and `tests/test_migrations.py`: need FastAPI, SQLAlchemy, Pydantic, Alembic, pytest.
- Pydantic request validation: explicit nulls returning 422, negative or fractional attendance, the https-only meeting-link pattern, time parsing. Covered only by pytest tests that have not run.
- HTTP-level authorization, the ORM queries (overlap query, eager loading, query counts that must not grow), WebSockets.
- `alembic upgrade head` on PostgreSQL and `docker compose up`.
- vitest (27 cases defined: 14 were run through the shim; the 13 in `schemas/training.test.js` need real zod), `npm run build` (Vite), browser behaviour.

**First thing to do on a machine with packages:** `cd backend && pytest`, `cd frontend && npm test && npm run build`, `docker compose up --build`, and send back any failure. Delete `scripts/check_migrations_static.py` and `scripts/verify_session_rules.py` only after pytest and `alembic check` pass; they are interim checks, not replacements.
