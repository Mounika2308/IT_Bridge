from datetime import date
from typing import Literal

from pydantic import BaseModel, Field, model_validator


class SkillOut(BaseModel):
    id: int
    name: str
    category: str | None = None
    model_config = {"from_attributes": True}


class SkillIn(BaseModel):
    name: str = Field(min_length=1, max_length=80)
    category: str | None = Field(default=None, max_length=80)


class TrainerProfileIn(BaseModel):
    headline: str | None = Field(default=None, max_length=160)
    about: str | None = Field(default=None, max_length=2000)
    location: str | None = Field(default=None, max_length=120)
    experience_years: int | None = Field(default=None, ge=0, le=60)
    training_mode: Literal["ONLINE", "OFFLINE", "HYBRID"] | None = None
    expected_fee: int | None = Field(default=None, ge=0, le=10_000_000)
    availability: str | None = Field(default=None, max_length=300)
    languages: list[str] | None = Field(default=None, max_length=15)
    education: list[str] | None = Field(default=None, max_length=15)
    certifications: list[str] | None = Field(default=None, max_length=30)
    skill_ids: list[int] | None = Field(default=None, max_length=50)


class TrainerProfileOut(BaseModel):
    """Private view for the owner."""
    headline: str | None
    about: str | None
    location: str | None
    experience_years: int | None
    training_mode: str | None
    expected_fee: int | None
    availability: str | None
    languages: list[str]
    education: list[str]
    certifications: list[str]
    skills: list[SkillOut]
    verification_status: str
    completion: int


class TrainerPublicOut(BaseModel):
    """Public view: no email, phone or other contact details."""
    id: int
    full_name: str
    headline: str | None
    about: str | None
    location: str | None
    experience_years: int | None
    training_mode: str | None
    expected_fee: int | None
    languages: list[str]
    education: list[str]
    certifications: list[str]
    skills: list[SkillOut]
    verified: bool
    rating: float | None = None
    review_count: int = 0
    completed_trainings: int = 0


class InstitutionProfileIn(BaseModel):
    institution_name: str | None = Field(default=None, min_length=2, max_length=200)
    institution_type: Literal["ENGINEERING_COLLEGE", "DEGREE_COLLEGE", "TRAINING_INSTITUTE", "SCHOOL", "OTHER"] | None = None
    location: str | None = Field(default=None, max_length=120)
    about: str | None = Field(default=None, max_length=2000)
    website: str | None = Field(default=None, max_length=200, pattern=r"^https?://\S+$")


class InstitutionProfileOut(BaseModel):
    institution_name: str
    institution_type: str | None
    location: str | None
    about: str | None
    website: str | None
    verification_status: str
    model_config = {"from_attributes": True}


class BusyPeriodIn(BaseModel):
    start_date: date
    end_date: date
    reason: str | None = Field(default=None, max_length=120)

    @model_validator(mode="after")
    def order(self):
        if self.end_date < self.start_date:
            raise ValueError("End date must be on or after the start date")
        return self
