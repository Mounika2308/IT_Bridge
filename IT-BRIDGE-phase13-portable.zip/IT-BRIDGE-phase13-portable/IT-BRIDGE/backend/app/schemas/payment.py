from typing import Literal

from pydantic import BaseModel, Field, StrictInt, field_validator


class PaymentCreateIn(BaseModel):
    """The amount is explicit and in paise. StrictInt: true/false, 100.5 and "100" are rejected. The server still enforces the fee cap."""
    amount_paise: StrictInt = Field(gt=0, le=10_000_000_000_000)


class RefundIn(BaseModel):
    reason: str | None = Field(default=None, max_length=300)


class PayoutIn(BaseModel):
    reference: str = Field(min_length=3, max_length=80, description="Your own reference, for example a batch name. Never a bank account number or UPI id")


ReviewReason = Literal["LATE_SUCCESS", "OVER_CAP", "DUPLICATE_CHARGE", "AMOUNT_MISMATCH", "CURRENCY_MISMATCH", "TRAINING_CANCELLED", "STUCK_PROCESSING", "REFUND_STUCK"]


class ReviewResolveIn(BaseModel):
    """`reason` names the open flag being resolved. It may be left out only while the payment has exactly one open flag."""
    note: str = Field(min_length=3, max_length=500)
    reason: ReviewReason | None = None

    @field_validator("note", mode="before")
    @classmethod
    def _trim(cls, v):
        return v.strip() if isinstance(v, str) else v


SandboxOutcome = Literal["success", "fail", "processing"]
PaymentStatus = Literal["PENDING", "PROCESSING", "SUCCEEDED", "FAILED", "CANCELLED", "EXPIRED"]
EarningStatus = Literal["PENDING", "AVAILABLE", "PAID", "REFUNDED"]
