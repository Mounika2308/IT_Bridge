from pydantic import BaseModel, model_validator


class PreferencesIn(BaseModel):
    in_app: bool | None = None
    email: bool | None = None

    @model_validator(mode="after")
    def at_least_one_and_no_nulls(self):
        if not self.model_fields_set:
            raise ValueError("Provide in_app and/or email")
        for name in self.model_fields_set:
            if getattr(self, name) is None:
                raise ValueError(f"{name} cannot be null")
        return self
