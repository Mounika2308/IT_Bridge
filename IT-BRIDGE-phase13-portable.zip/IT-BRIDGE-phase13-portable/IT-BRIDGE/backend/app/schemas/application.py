from datetime import date, datetime
from typing import Literal
from zoneinfo import ZoneInfo

from pydantic import BaseModel, Field, model_validator

from app.core.config import settings


class ApplyIn(BaseModel):
    cover_note: str | None = Field(default=None, max_length=2000)
    proposed_fee: int | None = Field(default=None, ge=0, le=100_000_000)


class StatusIn(BaseModel):
    status: Literal["UNDER_REVIEW", "SHORTLISTED", "INTERVIEW", "REJECTED"]
    interview_at: datetime | None = None   # required for INTERVIEW, forbidden otherwise

    @model_validator(mode="after")
    def interview_rules(self):
        if self.status == "INTERVIEW":
            if self.interview_at is None:
                raise ValueError("interview_at is required when scheduling an interview")
            if self.interview_at.tzinfo is not None:  # store platform-local wall-clock time
                self.interview_at = self.interview_at.astimezone(ZoneInfo(settings.app_timezone)).replace(tzinfo=None)
        elif self.interview_at is not None:
            raise ValueError("interview_at is only allowed together with status INTERVIEW")
        return self


class HireIn(BaseModel):
    agreed_fee: int = Field(ge=0, le=100_000_000)
    start_date: date | None = None
    end_date: date | None = None
    terms: str | None = Field(default=None, max_length=2000)

    @model_validator(mode="after")
    def order(self):
        if self.start_date and self.end_date and self.end_date < self.start_date:
            raise ValueError("End date must be on or after the start date")
        return self
