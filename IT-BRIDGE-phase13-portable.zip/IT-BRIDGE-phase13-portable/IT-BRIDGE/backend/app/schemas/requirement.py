from datetime import date
from typing import Literal

from pydantic import BaseModel, Field, model_validator

from app.schemas.profile import SkillOut

Mode = Literal["ONLINE", "OFFLINE", "HYBRID"]


class CategoryIn(BaseModel):
    name: str = Field(min_length=1, max_length=80)


class CategoryOut(BaseModel):
    id: int
    name: str
    model_config = {"from_attributes": True}


class RequirementIn(BaseModel):
    title: str = Field(min_length=5, max_length=160)
    technology: str = Field(min_length=1, max_length=80)
    category_id: int | None = None
    description: str = Field(min_length=30, max_length=4000)
    skill_ids: list[int] = Field(min_length=1, max_length=20)
    student_count: int = Field(ge=1, le=100_000)
    student_level: Literal["BEGINNER", "INTERMEDIATE", "ADVANCED"]
    duration_days: int = Field(ge=1, le=730)
    sessions: int = Field(ge=1, le=1000)
    location: str = Field(min_length=2, max_length=120)
    mode: Mode
    start_date: date
    end_date: date
    preferred_experience_years: int = Field(default=0, ge=0, le=60)
    budget_min: int = Field(ge=0, le=100_000_000)
    budget_max: int = Field(ge=0, le=100_000_000)
    application_deadline: date
    additional_requirements: str | None = Field(default=None, max_length=2000)

    @model_validator(mode="after")
    def check_dates_and_budget(self):
        if self.end_date < self.start_date:
            raise ValueError("End date must be on or after the start date")
        if self.application_deadline > self.start_date:
            raise ValueError("Application deadline must be on or before the start date")
        if self.budget_max < self.budget_min:
            raise ValueError("Maximum budget must be at least the minimum budget")
        return self


class RequirementOut(BaseModel):
    id: int
    title: str
    technology: str
    category: CategoryOut | None
    description: str
    skills: list[SkillOut]
    student_count: int
    student_level: str
    duration_days: int
    sessions: int
    location: str
    mode: str
    start_date: date
    end_date: date
    preferred_experience_years: int
    budget_min: int
    budget_max: int
    application_deadline: date
    additional_requirements: str | None
    status: str          # OPEN | CLOSED | EXPIRED (derived from the deadline)
    institution_name: str
    institution_id: int | None = None   # lets a trainer open the institution's public reviews
    institution_verified: bool
    is_owner: bool = False
    institution_rating: float | None = None
    institution_review_count: int = 0
