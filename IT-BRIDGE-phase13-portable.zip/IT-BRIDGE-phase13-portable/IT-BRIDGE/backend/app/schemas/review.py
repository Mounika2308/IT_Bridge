from pydantic import BaseModel, Field, StrictInt, field_validator

COMMENT_MAX_LENGTH = 2000


class ReviewIn(BaseModel):
    # StrictInt: true/false, 4.0 and "4" are rejected, only whole JSON numbers pass. The service repeats the check and the 1 to 5 range.
    ratings: dict[str, StrictInt] = Field(description="Category name to a whole-number score from 1 to 5")
    comment: str | None = Field(default=None, max_length=COMMENT_MAX_LENGTH)

    @field_validator("comment", mode="before")
    @classmethod
    def _trim(cls, v):
        """Trimmed before the length limit is applied. A comment is either absent or has visible text."""
        if isinstance(v, str):
            v = v.strip()
            if not v:
                raise ValueError("Write a comment or leave it empty")
        return v
