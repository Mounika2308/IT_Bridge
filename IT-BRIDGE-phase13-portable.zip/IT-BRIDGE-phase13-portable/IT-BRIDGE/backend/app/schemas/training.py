from datetime import date, time
from typing import Literal

from pydantic import BaseModel, Field, model_validator


class SessionIn(BaseModel):
    title: str = Field(min_length=2, max_length=120)
    session_date: date
    start_time: time
    end_time: time

    @model_validator(mode="after")
    def order(self):
        if self.end_time <= self.start_time:
            raise ValueError("End time must be after the start time")
        return self


class SessionUpdateIn(BaseModel):
    title: str | None = Field(default=None, min_length=2, max_length=120)
    session_date: date | None = None
    start_time: time | None = None
    end_time: time | None = None

    @model_validator(mode="after")
    def no_explicit_nulls(self):
        # A field may be left out, but sending null for it is invalid (it used to reach the database as a 500).
        for name in self.model_fields_set:
            if getattr(self, name) is None:
                raise ValueError(f"{name} cannot be null")
        return self


class SessionNotesIn(BaseModel):
    notes: str | None = Field(default=None, max_length=1000)


class PlannedSessionsIn(BaseModel):
    planned_sessions: int = Field(ge=1, le=1000)


class SessionStatusIn(BaseModel):
    status: Literal["ONGOING", "COMPLETED", "CANCELLED"]


class AttendanceIn(BaseModel):
    total_students: int = Field(ge=1, le=100_000)
    present: int = Field(ge=0, le=100_000)
    absent: int = Field(ge=0, le=100_000)

    @model_validator(mode="after")
    def totals(self):
        if self.present + self.absent > self.total_students:
            raise ValueError("Present plus absent cannot exceed total students")
        return self


class TrainingDatesIn(BaseModel):
    start_date: date
    end_date: date

    @model_validator(mode="after")
    def order(self):
        if self.end_date < self.start_date:
            raise ValueError("End date must be on or after the start date")
        return self


class TrainingDetailsIn(BaseModel):
    meeting_link: str | None = Field(default=None, max_length=300, pattern=r"^https://\S+$")


class CancelIn(BaseModel):
    reason: str | None = Field(default=None, max_length=500)
