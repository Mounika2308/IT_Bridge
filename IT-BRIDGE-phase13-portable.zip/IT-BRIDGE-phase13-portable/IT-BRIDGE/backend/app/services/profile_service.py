from fastapi import HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models.user import Skill, TrainerProfile, User
from app.services import review_service
from app.schemas.profile import (InstitutionProfileIn, InstitutionProfileOut, SkillOut,
                                 TrainerProfileIn, TrainerProfileOut, TrainerPublicOut)

COMPLETION_FIELDS = ["headline", "about", "location", "experience_years", "training_mode",
                     "expected_fee", "availability", "languages", "education", "skills"]


def completion_percent(p: TrainerProfile) -> int:
    filled = 0
    for f in COMPLETION_FIELDS:
        v = getattr(p, f)
        if v not in (None, "", [], 0) or (f in ("experience_years", "expected_fee") and v is not None):
            filled += 1
    return round(filled * 100 / len(COMPLETION_FIELDS))


def _clean_list(items: list[str]) -> list[str]:
    seen, out = set(), []
    for i in items:
        i = i.strip()
        if i and i.lower() not in seen:
            seen.add(i.lower())
            out.append(i[:120])
    return out


def trainer_out(p: TrainerProfile) -> TrainerProfileOut:
    return TrainerProfileOut(
        headline=p.headline, about=p.about, location=p.location,
        experience_years=p.experience_years, training_mode=p.training_mode,
        expected_fee=p.expected_fee, availability=p.availability,
        languages=p.languages or [], education=p.education or [], certifications=p.certifications or [],
        skills=[SkillOut.model_validate(s) for s in p.skills],
        verification_status=p.verification_status, completion=completion_percent(p),
    )


def update_trainer(db: Session, user: User, data: TrainerProfileIn) -> TrainerProfileOut:
    p = user.trainer_profile
    changes = data.model_dump(exclude_unset=True)
    skill_ids = changes.pop("skill_ids", None)
    for key, value in changes.items():
        if key in ("languages", "education", "certifications") and value is not None:
            value = _clean_list(value)
        setattr(p, key, value)
    if skill_ids is not None:
        skills = list(db.scalars(select(Skill).where(Skill.id.in_(skill_ids), Skill.is_active.is_(True))))
        if len(skills) != len(set(skill_ids)):
            raise HTTPException(422, "One or more skills do not exist")
        p.skills = skills
    db.commit()
    return trainer_out(p)


def trainer_public(db: Session, profile_id: int) -> TrainerPublicOut:
    p = db.get(TrainerProfile, profile_id)
    if not p or not p.user.is_active or p.verification_status == "SUSPENDED":
        raise HTTPException(404, "Trainer not found")
    return TrainerPublicOut(
        id=p.id, full_name=p.user.full_name, headline=p.headline, about=p.about, location=p.location,
        experience_years=p.experience_years, training_mode=p.training_mode, expected_fee=p.expected_fee,
        languages=p.languages or [], education=p.education or [], certifications=p.certifications or [],
        skills=[SkillOut.model_validate(s) for s in p.skills],
        verified=p.verification_status == "VERIFIED", **review_service.trainer_stats(db, [p.id])[p.id],
    )


def update_institution(db: Session, user: User, data: InstitutionProfileIn) -> InstitutionProfileOut:
    p = user.institution_profile
    for key, value in data.model_dump(exclude_unset=True).items():
        if key == "institution_name" and not value:
            continue
        setattr(p, key, value)
    db.commit()
    return InstitutionProfileOut.model_validate(p)
