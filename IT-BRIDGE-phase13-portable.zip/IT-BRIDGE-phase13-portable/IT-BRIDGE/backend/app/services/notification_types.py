"""The single source of truth for notification types. Pure Python, no imports from the app.

Every notification is created through a type listed here, so titles, deep links and email eligibility cannot drift apart across
the code base. `notify()` refuses a type that is not registered. To add an event: add one entry here, then emit it with
`notify_event(db, user_id, "YOUR_TYPE", **context)`.

Fields
  title      str.format template for the title
  body       optional str.format template for the message
  link       default deep link (a React route) as a str.format template; a caller may override it per recipient
  email      eligible for external email. Still subject to the user's email preference, a verified address and a provider
  mandatory  cannot be switched off by the in-app preference. No type is mandatory today: the app has no security or
             account-critical notification yet. The flag exists so such a type can never be muted when one is added.
Every type is delivered in-app (subject to the preference unless mandatory); SMS and WhatsApp are not implemented.
"""
from dataclasses import dataclass


@dataclass(frozen=True)
class NotificationType:
    key: str
    title: str
    body: str | None = None
    link: str | None = None
    email: bool = False
    mandatory: bool = False


TRAINER_APPS = "/trainer/applications"
INST_APPS = "/institution/requirements/{requirement_id}/applications"
TRAINING = "/trainings/{training_id}"
INST_PAYMENTS = "/institution/payments"
TRAINER_EARNINGS = "/trainer/earnings"

TYPES: dict[str, NotificationType] = {t.key: t for t in (
    # applications
    NotificationType("APPLICATION_RECEIVED", "New application received", "{trainer} applied to {requirement}", INST_APPS),
    NotificationType("APPLICATION_UPDATE", "Application under review", "{requirement}", TRAINER_APPS),
    NotificationType("APPLICATION_SHORTLISTED", "You were shortlisted", "{requirement}", TRAINER_APPS, email=True),
    NotificationType("APPLICATION_REJECTED", "Application rejected", "{requirement}", TRAINER_APPS),
    NotificationType("APPLICATION_WITHDRAWN", "Application withdrawn", "{trainer} withdrew from {requirement}", INST_APPS),
    # interviews
    NotificationType("INTERVIEW_SCHEDULED", "Interview scheduled", "{requirement}: {when}", TRAINER_APPS, email=True),
    NotificationType("INTERVIEW_UPDATED", "Interview rescheduled", "{requirement}: now {when}", TRAINER_APPS, email=True),
    NotificationType("INTERVIEW_REMINDER", "Interview coming up", "{requirement}: {when}", TRAINER_APPS, email=True),
    # hiring
    NotificationType("HIRING_REQUEST", "You have a hiring request", "{institution} wants to hire you for {requirement}", TRAINER_APPS, email=True),
    NotificationType("HIRING_ACCEPTED", "Hiring request accepted", "{trainer} accepted: {requirement}", TRAINING, email=True),
    NotificationType("HIRING_DECLINED", "Hiring request declined", "{trainer} declined: {requirement}", INST_APPS),
    NotificationType("HIRING_CANCELLED", "Hiring request cancelled", "{requirement}", TRAINER_APPS),
    # requirements (no private information about other trainers is ever included)
    NotificationType("REQUIREMENT_FILLED", "Requirement filled", "{requirement} has found its trainer. Your application can no longer be processed.", TRAINER_APPS),
    NotificationType("REQUIREMENT_REOPENED", "Requirement reopened", "{requirement} is open again.", "/requirements/{requirement_id}"),
    NotificationType("REQUIREMENT_CLOSED", "Requirement closed", "{requirement}", TRAINER_APPS),
    # training
    NotificationType("TRAINING_CREATED", "Your training is confirmed", "{title} with {institution}, {start} to {end}", TRAINING, email=True),
    NotificationType("TRAINING_DATES_CHANGED", "Training dates changed", "{title}: now {start} to {end}", TRAINING, email=True),
    NotificationType("TRAINING_LINK_CHANGED", "Meeting link {action}", "{title}", TRAINING),          # never carries the link itself
    NotificationType("TRAINING_COMPLETED", "Training completed", "{title}", TRAINING),
    NotificationType("TRAINING_CANCELLED", "Training cancelled", "{title}{reason}", TRAINING, email=True),
    NotificationType("TRAINING_REMINDER", "Training starts tomorrow: {title}", None, TRAINING),
    # sessions
    NotificationType("SESSION_SCHEDULED", "Session scheduled: {session}", "{when}", TRAINING),
    NotificationType("SESSION_RESCHEDULED", "Session rescheduled: {session}", "Now {when}", TRAINING),
    NotificationType("SESSION_CANCELLED", "Session cancelled: {session}", "{when}", TRAINING),
    NotificationType("SESSION_REMINDER", "Session tomorrow: {session}", "{title}, {time}", TRAINING, email=True),
    # reviews
    NotificationType("REVIEW_REQUEST", "Share your feedback", "How was the training: {title}?", TRAINING, email=True),
    NotificationType("REVIEW_REMINDER", "Reminder: review {title}", "Your review helps others. It only takes a minute.", TRAINING, email=True),
    NotificationType("REVIEW_RECEIVED", "You received a new review", "{score} out of 5 for {title}", TRAINING),
    # payments (Phase 13). Amounts arrive pre-formatted ("Rs 1,00,000"); the sandbox provider moves no real money.
    NotificationType("PAYMENT_SUCCEEDED", "Payment received", "{amount} for {title}", INST_PAYMENTS, email=True),
    NotificationType("PAYMENT_FAILED", "Payment did not go through", "{amount} for {title}. You can try again.", INST_PAYMENTS),
    NotificationType("PAYMENT_RECEIVED", "The institution has paid for your training", "{title}. Your earning is recorded and becomes available when the training is completed.", TRAINER_EARNINGS, email=True),
    NotificationType("PAYMENT_REFUNDED", "Payment refunded", "{amount} for {title}", INST_PAYMENTS, email=True),
    NotificationType("EARNING_AVAILABLE", "Earning available", "{amount} for {title}", TRAINER_EARNINGS),
    NotificationType("PAYOUT_RECORDED", "Payout recorded", "{amount} for {title}", TRAINER_EARNINGS, email=True),
    NotificationType("PAYMENT_NEEDS_REVIEW", "Payment needs review", "{title}: {reason}", "/admin"),
)}


def render(key: str, link: str | None = None, **ctx) -> dict:
    """Title, body and deep link for an event. Raises ValueError for an unregistered type and KeyError for a missing field."""
    spec = TYPES.get(key)
    if spec is None:
        raise ValueError(f"Unknown notification type {key!r}. Register it in notification_types.py")
    return {"title": spec.title.format(**ctx), "body": spec.body.format(**ctx) if spec.body else None,
            "link": link or (spec.link.format(**ctx) if spec.link else None)}


def fmt_when(dt) -> str:
    """A date and time for people, e.g. 'Thu 07 Mar 2030, 14:30' (platform-local wall-clock time)."""
    return dt.strftime("%a %d %b %Y, %H:%M")
