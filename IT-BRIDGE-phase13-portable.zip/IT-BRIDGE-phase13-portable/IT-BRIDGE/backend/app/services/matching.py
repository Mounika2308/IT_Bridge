"""Deterministic, explainable matching engine. Pure functions: no database access, no AI.

Every factor returns a ratio between 0 and 1, which is multiplied by its configurable weight.
The full breakdown is returned (and stored) so a score is never a black box.
"""

DEFAULT_WEIGHTS = {"skill": 40, "experience": 15, "location": 15, "availability": 15, "mode": 10, "budget": 5}
LABELS = {"skill": "Skills", "experience": "Experience", "location": "Location",
          "availability": "Availability", "mode": "Training mode", "budget": "Budget"}


def _same_city(a, b) -> bool:
    return bool(a and b and a.strip().lower() == b.strip().lower())


def _skill(req, tr):
    needed = {s.id: s.name for s in req.skills}
    have = {s.id for s in tr.skills}
    hit = [n for i, n in needed.items() if i in have]
    miss = [n for i, n in needed.items() if i not in have]
    ratio = len(hit) / len(needed) if needed else 0
    detail = f"{', '.join(hit)} matched" if hit else "No required skills matched"
    if miss and hit:
        detail += f"; missing {', '.join(miss)}"
    return ratio, detail


def _experience(req, tr):
    exp, want = tr.experience_years, req.preferred_experience_years or 0
    if exp is None:
        return 0, "Experience not provided"
    if want == 0:
        return 1, f"{exp} years of experience (no minimum asked)"
    ratio = min(1, exp / want)
    return ratio, f"{exp} years experience vs {want} preferred"


def _location(req, tr):
    if req.mode == "ONLINE":
        return 1, "Online training, location does not matter"
    if _same_city(req.location, tr.location):
        return 1, f"Based in {tr.location}"
    if tr.location:
        return 0, f"Based in {tr.location}, training is in {req.location}"
    return 0, "Trainer location not provided"


def _availability(req, busy):
    clash = [b for b in busy if b.start_date <= req.end_date and b.end_date >= req.start_date]
    if clash:
        return 0, "Unavailable on some of the requested dates"
    if busy:
        return 1, "Available on the requested dates"
    return 1, "No conflicting dates on record"


def _mode(req, tr):
    m = tr.training_mode
    if not m:
        return 0, "Training mode not provided"
    if m == req.mode or m == "HYBRID":
        return 1, f"{req.mode.title()} training supported"
    if req.mode == "HYBRID":
        return 0.5, f"Supports {m.lower()} only, hybrid requested"
    return 0, f"Prefers {m.lower()}, {req.mode.lower()} requested"


def _budget(req, tr):
    if tr.expected_fee is None:
        return 0, "Expected fee not provided"
    cost = tr.expected_fee * req.duration_days
    if cost <= req.budget_max:
        return 1, f"Estimated cost {cost:,} fits the budget"
    if cost <= req.budget_max * 1.2:
        return 0.5, f"Estimated cost {cost:,} is slightly above budget"
    return 0, f"Estimated cost {cost:,} exceeds budget"


def compute_match(req, tr, busy, weights=None) -> dict:
    w = {**DEFAULT_WEIGHTS, **(weights or {})}
    results = {"skill": _skill(req, tr), "experience": _experience(req, tr), "location": _location(req, tr),
               "availability": _availability(req, busy), "mode": _mode(req, tr), "budget": _budget(req, tr)}
    factors, total = [], 0.0
    for key in DEFAULT_WEIGHTS:
        ratio, detail = results[key]
        points = ratio * w[key]
        total += points
        factors.append({"key": key, "label": LABELS[key], "weight": w[key], "points": round(points, 1),
                        "status": "full" if ratio >= 1 else "partial" if ratio > 0 else "none", "detail": detail})
    return {"score": round(total), "factors": factors}
