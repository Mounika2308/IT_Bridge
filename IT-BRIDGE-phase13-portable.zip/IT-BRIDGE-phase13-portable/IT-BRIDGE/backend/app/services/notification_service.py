import logging
from datetime import datetime, timezone

from sqlalchemy import event, func, select, update
from sqlalchemy.orm import Session

from app.models.notification import Notification, NotificationDelivery
from app.models.user import User
from app.services import delivery_service, notification_preferences
from app.services.notification_types import TYPES, render
from app.services.realtime import manager

log = logging.getLogger("itbridge.notifications")


def _handled(db: Session, user_id: int, dedupe_key: str) -> bool:
    """True if this keyed notification was already processed, whether it produced an in-app row, an outbox row, or both."""
    return bool(db.scalar(select(Notification.id).where(Notification.user_id == user_id, Notification.dedupe_key == dedupe_key))
                or db.scalar(select(NotificationDelivery.id).where(NotificationDelivery.user_id == user_id, NotificationDelivery.dedupe_key == dedupe_key)))


def _dispatch(db: Session, user_id: int, type_: str, title: str, body: str | None, link: str | None, dedupe_key: str | None):
    """Creates the in-app row and/or the outbox row for one recipient, inside the caller's transaction.
    Returns (notification or None, anything_created)."""
    spec = TYPES.get(type_)
    if spec is None:
        raise ValueError(f"Unknown notification type {type_!r}. Register it in notification_types.py")
    if dedupe_key and _handled(db, user_id, dedupe_key):
        return None, False
    prefs = notification_preferences.get(db, user_id)
    note, queued = None, False
    if prefs["in_app"] or spec.mandatory:
        note = Notification(user_id=user_id, type=type_, title=title[:160], body=(body or None) and body[:500], link=link, dedupe_key=dedupe_key)
        db.add(note)
        db.flush()
        db.info.setdefault("pending_push", []).append((user_id, serialize(note)))
    if spec.email and prefs["email"]:
        delivery_service.enqueue(db, user_id, "email", type_, title, body, link, dedupe_key)
        queued = True
    return note, note is not None or queued


def notify(db: Session, user_id: int, type_: str, title: str, body: str | None = None, link: str | None = None,
           dedupe_key: str | None = None) -> Notification | None:
    """Low-level creation. Prefer notify_event. Returns the in-app row, or None when it was deduplicated or the recipient
    switched in-app notifications off. Real-time push and external delivery never happen here: the push is sent after the
    transaction commits, email is sent later by the outbox worker."""
    return _dispatch(db, user_id, type_, title, body, link, dedupe_key)[0]


def notify_event(db: Session, user_id: int, type_: str, *, link: str | None = None, dedupe_key: str | None = None, **ctx) -> bool:
    """Creates a notification from the registry. Returns True if anything was created for this recipient."""
    r = render(type_, link, **ctx)
    return _dispatch(db, user_id, type_, r["title"], r["body"], r["link"], dedupe_key)[1]


def notify_event_safe(db: Session, user_id: int, type_: str, *, link: str | None = None, dedupe_key: str | None = None, **ctx) -> bool:
    """notify_event for callers whose main transaction must never fail because of a notification (payments, refunds, payouts, reviews).

    The whole notification (building it, the preference lookup, the in-app row, the outbox row) runs inside a SAVEPOINT. Any failure, including a
    database error, rolls back to that savepoint only: the caller's financial changes stay in the session and are committed (or rolled back) by the
    caller as before, and the failure is logged with its traceback. Nothing is claimed as delivered: False is returned, no real-time push is queued for
    the failed notification, and no row exists for it.

    Pending work is flushed first so a failed notification can never take the caller's unflushed changes down with it (pysqlite begins its transaction
    lazily, so the SAVEPOINT must not be the first statement). A failure of the flush itself is the caller's own fault and is NOT swallowed.
    Only Exception is caught: KeyboardInterrupt and SystemExit propagate."""
    db.flush()
    pushed = len(db.info.get("pending_push", []))
    try:
        with db.begin_nested():
            r = render(type_, link, **ctx)
            return _dispatch(db, user_id, type_, r["title"], r["body"], r["link"], dedupe_key)[1]
    except Exception:
        queue = db.info.get("pending_push")
        if queue is not None:
            del queue[pushed:]  # no push for a notification that was rolled back
        log.exception("notification %s for user %s failed and was skipped; the surrounding change was kept and nothing was delivered", type_, user_id)
        return False


def serialize(n: Notification) -> dict:
    created = n.created_at or datetime.now(timezone.utc)
    return {"id": n.id, "type": n.type, "title": n.title, "body": n.body, "link": n.link, "is_read": bool(n.is_read),
            "created_at": created.isoformat()}


@event.listens_for(Session, "after_commit")
def _push_after_commit(session: Session):
    if session.in_nested_transaction():
        return          # releasing a SAVEPOINT (notify_event_safe) is not a commit: nothing is durable yet, so nothing is pushed
    for user_id, payload in session.info.pop("pending_push", []):
        manager.push(user_id, payload)


@event.listens_for(Session, "after_rollback")
def _drop_on_rollback(session: Session):
    if session.in_nested_transaction():
        return          # a rolled-back SAVEPOINT only discards its own push (notify_event_safe truncates the queue); earlier notifications stay queued
    session.info.pop("pending_push", None)


def list_for(db: Session, user: User, page: int, page_size: int, unread_only: bool) -> dict:
    base = select(Notification).where(Notification.user_id == user.id)
    if unread_only:
        base = base.where(Notification.is_read.is_(False))
    total = db.scalar(select(func.count()).select_from(base.subquery()))
    rows = db.scalars(base.order_by(Notification.created_at.desc(), Notification.id.desc())
                      .offset((page - 1) * page_size).limit(page_size))
    return {"items": [serialize(n) for n in rows], "total": total, "page": page, "page_size": page_size,
            "unread": unread_count(db, user)}


def unread_count(db: Session, user: User) -> int:
    return db.scalar(select(func.count()).select_from(Notification)
                     .where(Notification.user_id == user.id, Notification.is_read.is_(False))) or 0


def mark_read(db: Session, user: User, nid: int) -> bool:
    n = db.get(Notification, nid)
    if not n or n.user_id != user.id:
        return False
    n.is_read = True
    db.commit()
    return True


def mark_all_read(db: Session, user: User) -> None:
    db.execute(update(Notification).where(Notification.user_id == user.id, Notification.is_read.is_(False)).values(is_read=True))
    db.commit()
