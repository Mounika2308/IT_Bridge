
from fastapi import HTTPException
from app.core.clock import today
from sqlalchemy import func, or_, select
from sqlalchemy.orm import Session

from app.models.requirement import TrainingRequirement
from app.models.user import Skill, User
from app.schemas.profile import SkillOut
from app.schemas.requirement import CategoryOut, RequirementIn, RequirementOut


def effective_status(r: TrainingRequirement) -> str:
    if r.status == "OPEN" and r.application_deadline < today():
        return "EXPIRED"
    return r.status


def to_out(r: TrainingRequirement, viewer: User) -> RequirementOut:
    inst = r.institution
    return RequirementOut(
        id=r.id, title=r.title, technology=r.technology,
        category=CategoryOut.model_validate(r.category) if r.category else None,
        description=r.description, skills=[SkillOut.model_validate(s) for s in r.skills],
        student_count=r.student_count, student_level=r.student_level, duration_days=r.duration_days,
        sessions=r.sessions, location=r.location, mode=r.mode, start_date=r.start_date, end_date=r.end_date,
        preferred_experience_years=r.preferred_experience_years, budget_min=r.budget_min, budget_max=r.budget_max,
        application_deadline=r.application_deadline, additional_requirements=r.additional_requirements,
        status=effective_status(r), institution_name=inst.institution_name, institution_id=inst.id,
        institution_verified=inst.verification_status == "VERIFIED", is_owner=inst.user_id == viewer.id,
    )


def _load_skills(db: Session, ids: list[int]) -> list[Skill]:
    skills = list(db.scalars(select(Skill).where(Skill.id.in_(ids), Skill.is_active.is_(True))))
    if len(skills) != len(set(ids)):
        raise HTTPException(422, "One or more skills do not exist")
    return skills


def _apply(r: TrainingRequirement, db: Session, data: RequirementIn):
    values = data.model_dump(exclude={"skill_ids"})
    for k, v in values.items():
        setattr(r, k, v)
    r.skills = _load_skills(db, data.skill_ids)


def create(db: Session, user: User, data: RequirementIn) -> RequirementOut:
    if data.start_date < today() or data.application_deadline < today():
        raise HTTPException(422, "Dates cannot be in the past")
    r = TrainingRequirement(institution_id=user.institution_profile.id)
    _apply(r, db, data)
    db.add(r)
    db.flush()
    from app.services.audit import audit
    audit(db, user, "REQUIREMENT_CREATED", "requirement", r.id)
    db.commit()
    return to_out(r, user)


def get_owned(db: Session, user: User, req_id: int) -> TrainingRequirement:
    r = db.get(TrainingRequirement, req_id)
    if not r or r.institution.user_id != user.id:
        raise HTTPException(404, "Requirement not found")
    return r


def update(db: Session, user: User, req_id: int, data: RequirementIn) -> RequirementOut:
    r = get_owned(db, user, req_id)
    if r.status != "OPEN":
        raise HTTPException(409, "A filled or closed requirement cannot be edited")
    _apply(r, db, data)
    db.commit()
    return to_out(r, user)


def close(db: Session, user: User, req_id: int) -> RequirementOut:
    from app.services.application_service import close_requirement_cleanup  # avoids a circular import
    from app.services.audit import audit
    r = get_owned(db, user, req_id)
    r.status = "CLOSED"
    close_requirement_cleanup(db, user, r.id)
    audit(db, user, "REQUIREMENT_CLOSED", "requirement", r.id)
    db.commit()
    return to_out(r, user)


def detail(db: Session, viewer: User, req_id: int) -> RequirementOut:
    r = db.get(TrainingRequirement, req_id)
    if not r:
        raise HTTPException(404, "Requirement not found")
    owner = r.institution.user_id == viewer.id
    if not owner and (r.status != "OPEN" or not r.institution.user.is_active):
        raise HTTPException(404, "Requirement not found")
    from app.services.review_service import institution_stats
    out = to_out(r, viewer)
    out.institution_rating, out.institution_review_count = institution_stats(db, r.institution_id)
    return out


def _page(db: Session, viewer: User, stmt, page: int, page_size: int) -> dict:
    total = db.scalar(select(func.count()).select_from(stmt.order_by(None).subquery()))
    rows = db.scalars(stmt.order_by(TrainingRequirement.created_at.desc(), TrainingRequirement.id.desc())
                      .offset((page - 1) * page_size).limit(page_size)).unique()
    return {"items": [to_out(r, viewer).model_dump(mode="json") for r in rows],
            "total": total, "page": page, "page_size": page_size}


def list_mine(db: Session, user: User, page: int, page_size: int) -> dict:
    stmt = select(TrainingRequirement).where(
        TrainingRequirement.institution_id == user.institution_profile.id)
    return _page(db, user, stmt, page, page_size)


def browse(db: Session, viewer: User, f: dict, page: int, page_size: int) -> dict:
    from app.models.user import InstitutionProfile
    R = TrainingRequirement
    stmt = (select(R).join(InstitutionProfile, InstitutionProfile.id == R.institution_id)
            .join(User, User.id == InstitutionProfile.user_id)
            .where(R.status == "OPEN", R.application_deadline >= today(), User.is_active.is_(True)))
    if f.get("q"):
        like = f"%{f['q'].strip()}%"
        stmt = stmt.where(or_(R.title.ilike(like), R.technology.ilike(like)))
    if f.get("skill_id"):
        stmt = stmt.where(R.skills.any(Skill.id == f["skill_id"]))
    if f.get("location"):
        stmt = stmt.where(R.location.ilike(f"%{f['location'].strip()}%"))
    if f.get("mode"):
        stmt = stmt.where(R.mode == f["mode"])
    if f.get("max_experience") is not None:      # trainer's own experience: hide roles needing more
        stmt = stmt.where(R.preferred_experience_years <= f["max_experience"])
    if f.get("min_budget") is not None:          # show roles that can pay at least this
        stmt = stmt.where(R.budget_max >= f["min_budget"])
    if f.get("start_after"):
        stmt = stmt.where(R.start_date >= f["start_after"])
    if f.get("max_duration") is not None:
        stmt = stmt.where(R.duration_days <= f["max_duration"])
    return _page(db, viewer, stmt, page, page_size)
