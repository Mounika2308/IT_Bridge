from sqlalchemy.orm import Session

from app.models.audit import AuditLog


def audit(db: Session, user, action: str, entity: str, entity_id: int | None = None, **details):
    """Add an audit row to the caller's transaction (committed together with the change itself)."""
    db.add(AuditLog(user_id=getattr(user, "id", None), action=action, entity=entity, entity_id=entity_id, details=details or None))
