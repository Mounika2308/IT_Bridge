from sqlalchemy.orm import Session

from app.core.security import (create_access_token, create_refresh_token, decode_token,
                               hash_password, verify_password)
from app.models.user import User
from app.repositories import user_repo
from app.schemas.auth import LoginIn, RegisterIn, TokenOut, UserOut


class AuthError(Exception):
    def __init__(self, message: str, status: int = 400):
        self.message, self.status = message, status


def _tokens(user: User) -> TokenOut:
    return TokenOut(
        access_token=create_access_token(user.id),
        refresh_token=create_refresh_token(user.id),
        user=UserOut.model_validate(user),
    )


def register(db: Session, data: RegisterIn) -> TokenOut:
    if user_repo.get_by_email(db, data.email):
        raise AuthError("An account with this email already exists", 409)
    if data.role == "INSTITUTION" and not data.institution_name:
        raise AuthError("Institution name is required", 422)
    user = User(
        email=data.email.lower(),
        password_hash=hash_password(data.password),
        full_name=data.full_name,
        phone=data.phone,
        role=data.role,
    )
    user_repo.create_user(db, user, data.institution_name)
    return _tokens(user)


def login(db: Session, data: LoginIn) -> TokenOut:
    user = user_repo.get_by_email(db, data.email)
    # Same message for unknown email and wrong password: no account enumeration.
    if not user or not verify_password(data.password, user.password_hash):
        raise AuthError("Invalid email or password", 401)
    if not user.is_active:
        raise AuthError("This account is deactivated", 403)
    return _tokens(user)


def refresh(db: Session, refresh_token: str) -> TokenOut:
    uid = decode_token(refresh_token, "refresh")
    user = user_repo.get_by_id(db, uid) if uid else None
    if not user or not user.is_active:
        raise AuthError("Invalid refresh token", 401)
    return _tokens(user)
