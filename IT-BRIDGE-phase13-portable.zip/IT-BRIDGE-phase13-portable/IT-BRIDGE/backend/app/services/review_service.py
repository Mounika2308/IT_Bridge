"""Reviews and ratings.

Policy (Phase 12)
  * One review per direction per COMPLETED training, enforced here and by the unique constraint. No editing, no deleting.
  * Only the training's own institution or trainer may review. Inactive or suspended accounts may not.
  * overall (per review)  = mean of the category scores, rounded half up to one decimal.
  * displayed rating      = mean of the stored `overall` values of the visible (not hidden) reviews, rounded half up to one decimal.
  * a profile with 0 reviews has rating None; with 1 review it shows that rating and count truthfully, but it is NOT included in the
    minimum-rating search filter, which needs at least MIN_REVIEWS_FOR_RATING_FILTER reviews and compares the same rounded value that is displayed.
"""
import logging
from decimal import ROUND_HALF_UP, Decimal

from fastapi import HTTPException
from sqlalchemy import exists, func, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.models.review import Review
from app.models.training import Training
from app.models.user import InstitutionProfile, TrainerProfile, User
from app.schemas.review import COMMENT_MAX_LENGTH, ReviewIn
from app.services.audit import audit
from app.services.notification_service import notify_event_safe

log = logging.getLogger("itbridge.reviews")

# Directions are named by who is being reviewed.
TRAINER_DIR = "INSTITUTION_TO_TRAINER"      # the trainer is reviewed (by the institution)
INSTITUTION_DIR = "TRAINER_TO_INSTITUTION"  # the institution is reviewed (by the trainer)
CATEGORIES = {
    TRAINER_DIR: ["technical_knowledge", "teaching_quality", "communication", "punctuality", "professionalism"],
    INSTITUTION_DIR: ["communication", "professionalism", "coordination"],
}
MIN_REVIEWS_FOR_RATING_FILTER = 2
PENDING_PREVIEW = 5


def round_rating(value: float) -> float:
    """The one rounding rule: half up to one decimal. Float noise (4.2499999999) is removed first, so 4.25 always shows as 4.3."""
    return float(Decimal(repr(round(float(value), 6))).quantize(Decimal("0.1"), rounding=ROUND_HALF_UP))


def _aggregate(db: Session, id_col, direction: str, ids: list[int]) -> dict[int, tuple[float, int]]:
    """id -> (displayed rating, visible review count) in one query. Hidden reviews never count."""
    if not ids:
        return {}
    rows = db.execute(select(id_col, func.avg(Review.overall), func.count())
                      .where(id_col.in_(ids), Review.direction == direction, Review.is_hidden.is_(False)).group_by(id_col))
    return {i: (round_rating(avg), n) for i, avg, n in rows}


def trainer_stats(db: Session, ids: list[int]) -> dict[int, dict]:
    out = {i: {"rating": None, "review_count": 0, "completed_trainings": 0} for i in ids}
    if not ids:
        return out
    for tid, (rating, n) in _aggregate(db, Review.trainer_id, TRAINER_DIR, ids).items():
        out[tid].update(rating=rating, review_count=n)
    done = db.execute(select(Training.trainer_id, func.count()).where(Training.trainer_id.in_(ids), Training.status == "COMPLETED")
                      .group_by(Training.trainer_id))
    for tid, n in done:
        out[tid]["completed_trainings"] = n
    return out


def institution_stats(db: Session, institution_id: int) -> tuple[float | None, int]:
    rating, n = _aggregate(db, Review.institution_id, INSTITUTION_DIR, [institution_id]).get(institution_id, (None, 0))
    return rating, n


def institution_summary(db: Session, institution_id: int) -> dict:
    """Same shape as the trainer summary."""
    rating, n = institution_stats(db, institution_id)
    done = db.scalar(select(func.count()).select_from(Training).where(Training.institution_id == institution_id, Training.status == "COMPLETED")) or 0
    return {"rating": rating, "review_count": n, "completed_trainings": done}


def trainer_ids_rated_at_least(db: Session, min_rating: float) -> list[int]:
    """Trainers for the minimum-rating filter: at least MIN_REVIEWS_FOR_RATING_FILTER visible reviews AND a displayed rating >= min_rating.
    SQL only narrows (with a margin for rounding); the decision is made with the same round_rating() that the profile displays."""
    rows = db.execute(select(Review.trainer_id, func.avg(Review.overall)).where(Review.direction == TRAINER_DIR, Review.is_hidden.is_(False))
                      .group_by(Review.trainer_id)
                      .having(func.count() >= MIN_REVIEWS_FOR_RATING_FILTER, func.avg(Review.overall) >= min_rating - 0.0501))
    return [tid for tid, avg in rows if round_rating(avg) >= min_rating]


def _profile_of(user: User):
    return user.trainer_profile if user.role == "TRAINER" else user.institution_profile if user.role == "INSTITUTION" else None


def cannot_review(user: User) -> bool:
    """True for an inactive account or a suspended trainer/institution profile."""
    p = _profile_of(user)
    return (not user.is_active) or (p is not None and p.verification_status == "SUSPENDED")


def _direction(user: User, t: Training) -> str:
    if user.role == "INSTITUTION" and user.institution_profile and user.institution_profile.id == t.institution_id:
        return TRAINER_DIR   # the institution reviews the trainer
    if user.role == "TRAINER" and user.trainer_profile and user.trainer_profile.id == t.trainer_id:
        return INSTITUTION_DIR
    raise HTTPException(404, "Training not found")


def reviews_out(db: Session, rows: list[Review]) -> list[dict]:
    """Serialises reviews with two lookups in total (not one per row). Shows the reviewer's display name only, no ids or contact details."""
    rows = list(rows)
    trainer_names = dict(db.execute(select(TrainerProfile.id, User.full_name).join(User, User.id == TrainerProfile.user_id)
                                    .where(TrainerProfile.id.in_(list({r.trainer_id for r in rows}))))) if rows else {}
    inst_names = dict(db.execute(select(InstitutionProfile.id, InstitutionProfile.institution_name)
                                 .where(InstitutionProfile.id.in_(list({r.institution_id for r in rows}))))) if rows else {}
    return [{"id": r.id, "direction": r.direction,
             "reviewer": inst_names.get(r.institution_id, "Institution") if r.direction == TRAINER_DIR else trainer_names.get(r.trainer_id, "Trainer"),
             "overall": r.overall, "ratings": r.ratings, "comment": r.comment, "created_at": r.created_at.isoformat()} for r in rows]


def review_out(r: Review, db: Session) -> dict:
    return reviews_out(db, [r])[0]


def _eligibility(t: Training, user: User, done: bool) -> str | None:
    """Why this user cannot review right now, or None. The API reports it so the UI never has to guess."""
    if t.status == "ACTIVE":
        return "ACTIVE"
    if t.status == "CANCELLED":
        return "CANCELLED"
    if cannot_review(user):
        return "SUSPENDED"
    return "ALREADY_REVIEWED" if done else None


REASON_TEXT = {
    "ACTIVE": "This training is still in progress. Reviews open once the institution marks it completed.",
    "CANCELLED": "This training was cancelled, so it cannot be reviewed.",
}


def _clean_payload(data: ReviewIn, cats: list[str]) -> str | None:
    """Authoritative validation, independent of the request schema. Returns the trimmed comment."""
    if set(data.ratings) != set(cats):
        raise HTTPException(422, f"Rate exactly these categories: {', '.join(cats)}")
    if any(type(v) is not int or not 1 <= v <= 5 for v in data.ratings.values()):  # type() is int: booleans and floats are refused
        raise HTTPException(422, "Each rating must be a whole number from 1 to 5")
    if data.comment is None:
        return None
    comment = data.comment.strip()
    if not comment:
        raise HTTPException(422, "Write a comment or leave it empty")
    if len(comment) > COMMENT_MAX_LENGTH:
        raise HTTPException(422, f"The comment can be at most {COMMENT_MAX_LENGTH} characters")
    return comment


def submit(db: Session, user: User, tid: int, data: ReviewIn) -> dict:
    t = db.get(Training, tid)
    if not t:
        raise HTTPException(404, "Training not found")
    direction = _direction(user, t)
    if cannot_review(user):
        raise HTTPException(403, "Suspended or inactive accounts cannot submit reviews")
    if t.status in REASON_TEXT:
        raise HTTPException(409, REASON_TEXT[t.status])
    if t.status != "COMPLETED":
        raise HTTPException(409, "Reviews open once the training is completed")
    cats = CATEGORIES[direction]
    comment = _clean_payload(data, cats)
    if db.scalar(select(Review.id).where(Review.training_id == tid, Review.direction == direction)):
        raise HTTPException(409, "You have already reviewed this training")
    r = Review(training_id=tid, direction=direction, reviewer_user_id=user.id, trainer_id=t.trainer_id, institution_id=t.institution_id,
               ratings=data.ratings, overall=round_rating(sum(data.ratings.values()) / len(cats)), comment=comment)
    db.add(r)
    try:
        db.flush()
    except IntegrityError:  # two simultaneous submits: the unique constraint is the final guard
        db.rollback()
        raise HTTPException(409, "You have already reviewed this training")
    audit(db, user, "REVIEW_SUBMITTED", "review", r.id, training_id=tid, direction=direction)
    target = t.trainer.user_id if direction == TRAINER_DIR else t.institution.user_id
    # In the same transaction as the review. A notification that cannot even be built is logged and skipped; it never undoes the review.
    notify_event_safe(db, target, "REVIEW_RECEIVED", dedupe_key=f"review-received:{r.id}", training_id=tid, title=t.title, score=r.overall)
    db.commit()
    return review_out(r, db)


def for_training(db: Session, user: User, tid: int) -> dict:
    t = db.get(Training, tid)
    if not t:
        raise HTTPException(404, "Training not found")
    mine = _direction(user, t)
    rows = list(db.scalars(select(Review).where(Review.training_id == tid, Review.is_hidden.is_(False)).order_by(Review.created_at)))
    reviews = reviews_out(db, rows)
    done = any(r.direction == mine for r in rows)
    reason = _eligibility(t, user, done)
    return {"reviews": reviews, "categories": CATEGORIES[mine], "can_review": reason is None, "reason": reason,
            "reason_text": REASON_TEXT.get(reason), "comment_max_length": COMMENT_MAX_LENGTH}


def _page(db: Session, base, page: int, page_size: int) -> tuple[list[dict], int]:
    total = db.scalar(select(func.count()).select_from(base.subquery()))
    rows = db.scalars(base.order_by(Review.created_at.desc(), Review.id.desc()).offset((page - 1) * page_size).limit(page_size))
    return reviews_out(db, list(rows)), total


def for_trainer(db: Session, trainer_id: int, page: int, page_size: int) -> dict:
    p = db.get(TrainerProfile, trainer_id)
    if not p or not p.user.is_active or p.verification_status == "SUSPENDED":
        raise HTTPException(404, "Trainer not found")
    items, total = _page(db, select(Review).where(Review.trainer_id == trainer_id, Review.direction == TRAINER_DIR, Review.is_hidden.is_(False)), page, page_size)
    return {"items": items, "total": total, "page": page, "page_size": page_size, **trainer_stats(db, [trainer_id])[trainer_id]}


def for_institution(db: Session, institution_id: int, page: int, page_size: int) -> dict:
    """Public institution reviews: the same visibility rules as the trainer side. Only the name and verified flag of the institution are returned."""
    p = db.get(InstitutionProfile, institution_id)
    if not p or not p.user.is_active or p.verification_status == "SUSPENDED":
        raise HTTPException(404, "Institution not found")
    items, total = _page(db, select(Review).where(Review.institution_id == institution_id, Review.direction == INSTITUTION_DIR, Review.is_hidden.is_(False)), page, page_size)
    return {"items": items, "total": total, "page": page, "page_size": page_size, "institution_name": p.institution_name,
            "verified": p.verification_status == "VERIFIED", **institution_summary(db, institution_id)}


def my_summary(db: Session, user: User) -> dict:
    """The signed-in user's own rating summary plus the completed trainings they have not reviewed yet (zero when they may not review)."""
    p = _profile_of(user)
    empty = {"rating": None, "review_count": 0, "completed_trainings": 0, "my_pending_reviews": 0, "pending": [], "can_review": False}
    if p is None:
        return empty
    is_trainer = user.role == "TRAINER"
    stats = trainer_stats(db, [p.id])[p.id] if is_trainer else institution_summary(db, p.id)
    mine = INSTITUTION_DIR if is_trainer else TRAINER_DIR           # the direction this user writes
    owner = Training.trainer_id if is_trainer else Training.institution_id
    can = not cannot_review(user)
    out = {**empty, **stats, "can_review": can}
    if can:
        pending = (select(Training.id, Training.title).where(owner == p.id, Training.status == "COMPLETED",
                   ~exists().where(Review.training_id == Training.id, Review.direction == mine)))
        out["my_pending_reviews"] = db.scalar(select(func.count()).select_from(pending.subquery())) or 0
        out["pending"] = [{"training_id": i, "title": title} for i, title in
                          db.execute(pending.order_by(Training.completed_at.desc(), Training.id.desc()).limit(PENDING_PREVIEW))]
    return out
