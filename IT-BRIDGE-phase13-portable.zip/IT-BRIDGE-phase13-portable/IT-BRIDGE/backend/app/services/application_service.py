from datetime import datetime, timezone

from fastapi import HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.clock import now
from app.models.application import Application, HiringRequest
from app.models.requirement import TrainingRequirement
from app.models.user import User
from app.schemas.application import ApplyIn, HireIn
from app.services import match_service, review_service
from app.services.audit import audit
from app.services.notification_service import notify_event
from app.services.notification_types import fmt_when
from app.services.matching import compute_match
from app.services.requirement_service import effective_status

ACTIVE = ("APPLIED", "UNDER_REVIEW", "SHORTLISTED", "INTERVIEW")
INSTITUTION_MOVES = {
    "APPLIED": {"UNDER_REVIEW", "SHORTLISTED", "REJECTED"},
    "UNDER_REVIEW": {"SHORTLISTED", "REJECTED"},
    "SHORTLISTED": {"INTERVIEW", "REJECTED"},
    "INTERVIEW": {"REJECTED", "INTERVIEW"},   # INTERVIEW -> INTERVIEW reschedules; SELECTED happens only through hire()
}
BLOCKING_HIRES = ("PENDING", "ACCEPTED")


def _now():
    return datetime.now(timezone.utc)


# ---------- trainer side ----------
def apply(db: Session, user: User, req_id: int, data: ApplyIn) -> Application:
    profile = user.trainer_profile
    if profile.verification_status in ("SUSPENDED", "REJECTED"):
        raise HTTPException(403, "Your trainer account cannot apply right now")
    if not profile.headline or not profile.skills:
        raise HTTPException(422, "Complete your profile (headline and skills) before applying")
    req = db.get(TrainingRequirement, req_id, with_for_update=True, populate_existing=True)  # row lock: an apply cannot slip in while the requirement is being filled
    if not req or not req.institution.user.is_active:
        raise HTTPException(404, "Requirement not found")
    state = effective_status(req)
    if state == "FILLED":
        raise HTTPException(409, "This requirement has already been filled")
    if state != "OPEN":
        raise HTTPException(409, "This requirement is no longer accepting applications")
    existing = db.scalar(select(Application).where(Application.requirement_id == req_id, Application.trainer_id == profile.id))
    if existing and existing.status != "WITHDRAWN":
        raise HTTPException(409, "You have already applied to this requirement")
    if existing:  # re-applying after a withdrawal reuses the row, so duplicates stay impossible
        existing.status, existing.cover_note, existing.proposed_fee = "APPLIED", data.cover_note, data.proposed_fee
        app = existing
    else:
        app = Application(requirement_id=req_id, trainer_id=profile.id, cover_note=data.cover_note, proposed_fee=data.proposed_fee)
        db.add(app)
    db.flush()
    audit(db, user, "APPLICATION_SUBMITTED", "application", app.id, requirement_id=req_id)
    notify_event(db, req.institution.user_id, "APPLICATION_RECEIVED", trainer=user.full_name, requirement=req.title, requirement_id=req_id)
    db.commit()
    return app


def withdraw(db: Session, user: User, app_id: int) -> Application:
    app = db.get(Application, app_id)
    if not app or app.trainer_id != user.trainer_profile.id:
        raise HTTPException(404, "Application not found")
    if app.status not in ACTIVE:
        raise HTTPException(409, f"A {app.status.lower()} application cannot be withdrawn")
    app.status = "WITHDRAWN"
    audit(db, user, "APPLICATION_WITHDRAWN", "application", app.id)
    notify_event(db, app.requirement.institution.user_id, "APPLICATION_WITHDRAWN", trainer=user.full_name, requirement=app.requirement.title, requirement_id=app.requirement_id)
    db.commit()
    return app


def list_for_trainer(db: Session, user: User) -> list[dict]:
    rows = db.scalars(select(Application).where(Application.trainer_id == user.trainer_profile.id)
                      .order_by(Application.created_at.desc()))
    return [application_out(db, a, "trainer") for a in rows]


# ---------- institution side ----------
def _owned_requirement(db: Session, user: User, req_id: int) -> TrainingRequirement:
    req = db.get(TrainingRequirement, req_id)
    if not req or req.institution.user_id != user.id:
        raise HTTPException(404, "Requirement not found")
    return req


def _owned_application(db: Session, user: User, app_id: int) -> Application:
    app = db.get(Application, app_id)
    if not app or app.requirement.institution.user_id != user.id:
        raise HTTPException(404, "Application not found")
    return app


def list_for_requirement(db: Session, user: User, req_id: int, status: str | None) -> list[dict]:
    req = _owned_requirement(db, user, req_id)
    stmt = select(Application).where(Application.requirement_id == req.id)
    if status:
        stmt = stmt.where(Application.status == status)
    apps = list(db.scalars(stmt.order_by(Application.created_at.desc())))
    weights = match_service.get_weights(db)
    busy = match_service.busy_map(db, [a.trainer_id for a in apps])
    stats = review_service.trainer_stats(db, [a.trainer_id for a in apps])
    out = []
    for a in apps:
        item = application_out(db, a, "institution")
        item["trainer"] = match_service.trainer_card(a.trainer, stats[a.trainer_id])
        item.update(compute_match(req, a.trainer, busy[a.trainer_id], weights))
        out.append(item)
    out.sort(key=lambda x: -x["score"])
    return out


def change_status(db: Session, user: User, app_id: int, new_status: str, interview_at: datetime | None = None) -> Application:
    app = _owned_application(db, user, app_id)
    if app.requirement.status in ("FILLED", "CLOSED"):  # EXPIRED (deadline passed) stays workable: the deadline only stops new applications
        raise HTTPException(409, "This requirement has already been filled" if app.requirement.status == "FILLED" else "This requirement is closed")
    if new_status not in INSTITUTION_MOVES.get(app.status, set()):
        raise HTTPException(409, f"Cannot move an application from {app.status} to {new_status}")
    if new_status == "INTERVIEW":
        if interview_at is None:
            raise HTTPException(422, "Choose a date and time for the interview")
        if interview_at < now():
            raise HTTPException(422, "The interview cannot be scheduled in the past")
        app.interview_at = interview_at
    old, app.status = app.status, new_status
    audit(db, user, "APPLICATION_STATUS_CHANGED", "application", app.id, old=old, new=new_status,
          interview_at=interview_at.isoformat() if interview_at else None)
    if new_status == "INTERVIEW":
        status_type = "INTERVIEW_UPDATED" if old == "INTERVIEW" else "INTERVIEW_SCHEDULED"
    else:
        status_type = {"SHORTLISTED": "APPLICATION_SHORTLISTED", "REJECTED": "APPLICATION_REJECTED"}.get(new_status, "APPLICATION_UPDATE")
    notify_event(db, app.trainer.user_id, status_type, requirement=app.requirement.title,
                 when=fmt_when(interview_at) if new_status == "INTERVIEW" else "")
    db.commit()
    return app


def hire(db: Session, user: User, app_id: int, data: HireIn) -> HiringRequest:
    app = _owned_application(db, user, app_id)
    req = db.get(TrainingRequirement, app.requirement_id, with_for_update=True, populate_existing=True)  # serialises concurrent hires for the same requirement
    if app.status not in ("SHORTLISTED", "INTERVIEW"):
        raise HTTPException(409, "Shortlist the trainer before sending a hiring request")
    if req.status == "FILLED":
        raise HTTPException(409, "This requirement has already been filled")
    if req.status != "OPEN":
        raise HTTPException(409, "This requirement is closed")
    trainer_user = app.trainer.user
    if not trainer_user.is_active or app.trainer.verification_status in ("SUSPENDED", "REJECTED"):
        raise HTTPException(409, "This trainer is no longer available")
    if db.scalar(select(HiringRequest.id).where(HiringRequest.requirement_id == req.id, HiringRequest.status.in_(BLOCKING_HIRES))):
        raise HTTPException(409, "A hiring request for this requirement is already in progress")
    start, end = data.start_date or req.start_date, data.end_date or req.end_date
    if end < start:
        raise HTTPException(422, "End date must be on or after the start date")
    hr = HiringRequest(application_id=app.id, requirement_id=req.id, trainer_id=app.trainer_id,
                       agreed_fee=data.agreed_fee, start_date=start, end_date=end, sessions=req.sessions, terms=data.terms)
    existing = db.scalar(select(HiringRequest).where(HiringRequest.application_id == app.id))
    if existing:  # a declined/cancelled request can be re-issued for the same application
        existing.agreed_fee, existing.start_date, existing.end_date = data.agreed_fee, start, end
        existing.terms, existing.status, existing.responded_at = data.terms, "PENDING", None
        hr = existing
    else:
        db.add(hr)
    app.status = "SELECTED"
    db.flush()
    audit(db, user, "TRAINER_SELECTED", "application", app.id, hiring_request_id=hr.id, agreed_fee=data.agreed_fee)
    notify_event(db, trainer_user.id, "HIRING_REQUEST", institution=req.institution.institution_name, requirement=req.title)
    db.commit()
    return hr


def notify_waiting_applicants(db: Session, req, type_: str, key: str) -> None:
    """Tells the applicants of a requirement who are still in play (never the selected trainer) that it was filled or reopened.
    The message names the requirement only, nothing about who was chosen."""
    for a in db.scalars(select(Application).where(Application.requirement_id == req.id, Application.status.in_(ACTIVE))):
        notify_event(db, a.trainer.user_id, type_, dedupe_key=key, requirement=req.title, requirement_id=req.id)


def close_requirement_cleanup(db: Session, user: User, req_id: int):
    """Closing a requirement rejects applications that were still in play. Does not commit."""
    for a in db.scalars(select(Application).where(Application.requirement_id == req_id, Application.status.in_(ACTIVE))):
        a.status = "REJECTED"
        audit(db, user, "APPLICATION_STATUS_CHANGED", "application", a.id, old="ACTIVE", new="REJECTED", reason="requirement closed")
        notify_event(db, a.trainer.user_id, "REQUIREMENT_CLOSED", requirement=a.requirement.title)
    for h in db.scalars(select(HiringRequest).where(HiringRequest.requirement_id == req_id, HiringRequest.status == "PENDING")):
        h.status = "CANCELLED"


# ---------- hiring responses ----------
def _hiring_for(db: Session, hid: int) -> HiringRequest:
    hr = db.get(HiringRequest, hid)
    if not hr:
        raise HTTPException(404, "Hiring request not found")
    return hr


def respond(db: Session, user: User, hid: int, accept: bool) -> HiringRequest:
    hr = _hiring_for(db, hid)
    if hr.trainer_id != user.trainer_profile.id:
        raise HTTPException(404, "Hiring request not found")
    if hr.status != "PENDING":
        raise HTTPException(409, f"This request is already {hr.status.lower()}")
    req = db.get(TrainingRequirement, hr.requirement_id, with_for_update=True, populate_existing=True) if accept else hr.requirement  # lock: two accepts cannot both fill it
    if req.status != "OPEN":
        hr.status = "CANCELLED"
        db.commit()
        raise HTTPException(409, "This requirement is no longer open")
    hr.status = "ACCEPTED" if accept else "DECLINED"
    hr.responded_at = _now()
    if not accept:
        hr.application.status = "WITHDRAWN"
    audit(db, user, "HIRING_ACCEPTED" if accept else "HIRING_DECLINED", "hiring_request", hr.id)
    if not accept:
        notify_event(db, req.institution.user_id, "HIRING_DECLINED", trainer=user.full_name, requirement=req.title, requirement_id=req.id)
    if accept:
        from app.services.training_service import create_for_hiring  # avoids a circular import
        t = create_for_hiring(db, hr)
        audit(db, user, "TRAINING_CREATED", "training", t.id)
        req.status = "FILLED"  # the requirement has its trainer; it reopens only if this training is cancelled before it starts
        audit(db, user, "REQUIREMENT_FILLED", "requirement", req.id, hiring_request_id=hr.id)
        notify_event(db, req.institution.user_id, "HIRING_ACCEPTED", trainer=user.full_name, requirement=req.title, training_id=t.id)
        notify_event(db, hr.trainer.user_id, "TRAINING_CREATED", title=req.title, institution=req.institution.institution_name,
                     start=str(hr.start_date), end=str(hr.end_date), training_id=t.id)
        notify_waiting_applicants(db, req, "REQUIREMENT_FILLED", f"requirement-filled:{req.id}:{hr.id}")
    db.commit()
    return hr


def cancel(db: Session, user: User, hid: int) -> HiringRequest:
    hr = _hiring_for(db, hid)
    if hr.requirement.institution.user_id != user.id:
        raise HTTPException(404, "Hiring request not found")
    if hr.status != "PENDING":
        raise HTTPException(409, "Only a pending request can be cancelled")
    hr.status = "CANCELLED"
    hr.application.status = "SHORTLISTED"  # the institution can pick another trainer or re-issue
    audit(db, user, "HIRING_CANCELLED", "hiring_request", hr.id)
    notify_event(db, hr.trainer.user_id, "HIRING_CANCELLED", requirement=hr.requirement.title)
    db.commit()
    return hr


def list_hiring(db: Session, user: User) -> list[dict]:
    if user.role == "TRAINER":
        stmt = select(HiringRequest).where(HiringRequest.trainer_id == user.trainer_profile.id)
    else:
        from app.models.requirement import TrainingRequirement as R
        stmt = select(HiringRequest).join(R, R.id == HiringRequest.requirement_id).where(R.institution_id == user.institution_profile.id)
    return [hiring_out(h, user) for h in db.scalars(stmt.order_by(HiringRequest.created_at.desc()))]


# ---------- serializers ----------
def hiring_out(h: HiringRequest, viewer: User) -> dict:
    out = {"id": h.id, "application_id": h.application_id, "requirement_id": h.requirement_id, "status": h.status,
           "title": h.requirement.title, "institution_name": h.requirement.institution.institution_name,
           "trainer_name": h.trainer.user.full_name, "agreed_fee": h.agreed_fee, "start_date": str(h.start_date),
           "end_date": str(h.end_date), "sessions": h.sessions, "terms": h.terms, "contact": None}
    if h.status in ("ACCEPTED", "COMPLETED"):  # contact details are shared only once both sides have committed
        other = h.requirement.institution.user if viewer.role == "TRAINER" else h.trainer.user
        out["contact"] = {"name": other.full_name, "email": other.email, "phone": other.phone}
    return out


def application_out(db: Session, a: Application, view: str) -> dict:
    r = a.requirement
    hr = db.scalar(select(HiringRequest).where(HiringRequest.application_id == a.id))
    out = {"id": a.id, "requirement_id": r.id, "requirement_status": effective_status(r), "status": a.status, "cover_note": a.cover_note,
           "interview_at": a.interview_at.isoformat() if a.interview_at and a.status == "INTERVIEW" else None,
           "proposed_fee": a.proposed_fee, "created_at": a.created_at.isoformat(),
           "hiring_request": {"id": hr.id, "status": hr.status, "agreed_fee": hr.agreed_fee, "terms": hr.terms,
                              "start_date": str(hr.start_date), "end_date": str(hr.end_date)} if hr else None}
    if view == "trainer":
        out["requirement"] = {"title": r.title, "institution_name": r.institution.institution_name, "location": r.location,
                              "start_date": str(r.start_date), "application_deadline": str(r.application_deadline),
                              "status": effective_status(r)}
    return out
