"""External delivery providers. Only a DEVELOPMENT console provider exists: it logs that a message would have been sent and
sends nothing. No real email, SMS or WhatsApp provider is integrated; a real one must implement `EmailProvider`, be selected with
EMAIL_PROVIDER and be configured and tested before anyone may claim email delivery works.
Recipient addresses never appear in INFO logs: only the idempotency key is logged."""
import logging
import re
from typing import Protocol

from app.core.config import settings

log = logging.getLogger("itbridge.notifications")


class DeliveryError(Exception):
    """A provider could not hand the message over right now. The outbox retries with backoff."""


class EmailProvider(Protocol):
    name: str

    def send(self, to: str, subject: str, body: str, *, idempotency_key: str) -> None:
        """Send one email. Must raise DeliveryError (or any Exception) on failure and must treat a repeated idempotency_key
        as the same message."""


class ConsoleEmailProvider:
    name = "console"

    def send(self, to: str, subject: str, body: str, *, idempotency_key: str) -> None:
        log.info("[email: DEV console provider, NOT SENT] delivery=%s", idempotency_key)


_PROVIDERS: dict[str, EmailProvider] = {"console": ConsoleEmailProvider()}
# Extension point: register a real provider here (SES, SendGrid...) and set EMAIL_PROVIDER. SMS and WhatsApp would get their own
# provider interface and a new channel value in the preferences and outbox tables.


def get_email_provider() -> EmailProvider:
    try:
        return _PROVIDERS[settings.email_provider]
    except KeyError:
        raise RuntimeError(f"EMAIL_PROVIDER={settings.email_provider!r} is not implemented. Only 'console' (development, sends nothing) exists")


_EMAIL = re.compile(r"[\w.+-]+@[\w-]+\.[\w.-]+")


def redact(text: str) -> str:
    """Strips email addresses from text that is stored or logged (error messages from providers often echo the recipient)."""
    return _EMAIL.sub("[email]", text or "")
