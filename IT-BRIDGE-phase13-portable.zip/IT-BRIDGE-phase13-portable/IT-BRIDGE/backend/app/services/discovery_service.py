from sqlalchemy import String, cast, func, or_, select
from sqlalchemy.orm import Session

from app.models.matching import TrainerBusyPeriod
from app.services import review_service
from app.models.user import Skill, TrainerProfile, User
from app.services.match_service import ELIGIBLE_STATUSES, trainer_card


def search_trainers(db: Session, f: dict, page: int, page_size: int) -> dict:
    T = TrainerProfile
    stmt = (select(T).join(User, User.id == T.user_id)
            .where(User.is_active.is_(True), T.verification_status.in_(ELIGIBLE_STATUSES), T.headline.is_not(None)))
    if f.get("q"):
        like = f"%{f['q'].strip()}%"
        stmt = stmt.where(or_(User.full_name.ilike(like), T.headline.ilike(like)))
    if f.get("skill_id"):
        stmt = stmt.where(T.skills.any(Skill.id == f["skill_id"]))
    if f.get("location"):
        stmt = stmt.where(T.location.ilike(f"%{f['location'].strip()}%"))
    if f.get("mode"):
        stmt = stmt.where(or_(T.training_mode == f["mode"], T.training_mode == "HYBRID"))
    if f.get("min_experience") is not None:
        stmt = stmt.where(T.experience_years >= f["min_experience"])
    if f.get("max_fee") is not None:
        stmt = stmt.where(T.expected_fee <= f["max_fee"])
    if f.get("verified_only"):
        stmt = stmt.where(T.verification_status == "VERIFIED")
    if f.get("has_certifications"):
        stmt = stmt.where(cast(T.certifications, String).not_in(["[]", "null"]))
    if f.get("language"):
        stmt = stmt.where(func.lower(cast(T.languages, String)).like(f"%{f['language'].strip().lower()}%"))
    if f.get("available_from") and f.get("available_to"):
        a, b = f["available_from"], f["available_to"]
        clash = select(TrainerBusyPeriod.trainer_id).where(TrainerBusyPeriod.start_date <= b, TrainerBusyPeriod.end_date >= a)
        stmt = stmt.where(T.id.not_in(clash))
    if f.get("min_rating") is not None:   # displayed (rounded) rating, and at least MIN_REVIEWS_FOR_RATING_FILTER reviews: see review_service
        stmt = stmt.where(T.id.in_(review_service.trainer_ids_rated_at_least(db, f["min_rating"])))
    total = db.scalar(select(func.count()).select_from(stmt.subquery()))
    rows = db.scalars(stmt.order_by((T.verification_status == "VERIFIED").desc(), T.experience_years.desc().nulls_last(), T.id)
                      .offset((page - 1) * page_size).limit(page_size))
    rows = list(rows)
    stats = review_service.trainer_stats(db, [p.id for p in rows])
    return {"items": [trainer_card(p, stats[p.id]) for p in rows], "total": total, "page": page, "page_size": page_size}
