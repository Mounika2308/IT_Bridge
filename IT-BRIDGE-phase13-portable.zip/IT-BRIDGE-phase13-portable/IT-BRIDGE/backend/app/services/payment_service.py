"""Payments (Phase 13): creating a payment attempt, the one trusted path by which a provider result changes it, reconciliation, and the
read models. The decisions themselves live in payment_rules.py (pure); this module reads rows, calls those rules and writes the result.

TRUST: a payment becomes SUCCEEDED only inside `process_event`, which is reached by `handle_webhook` (signature and timestamp verified)
and by `reconcile` (the provider was asked directly). The sandbox simulation builds a SIGNED event and calls `handle_webhook`: it has
no shortcut. No API lets a client set a status, an amount, a commission or an earning.

LOCKS: every state-changing path takes the training row FIRST and the payment row SECOND (SELECT ... FOR UPDATE), the refund and
payout paths then take the earning row. That fixed order is what prevents deadlocks. SQLite ignores FOR UPDATE, so none of this
concurrency behaviour is exercised by the SQLite-based tests; the database constraints (unique indexes) are the second line of defence.
"""
import logging
import time
from collections import defaultdict
from datetime import datetime, timedelta, timezone

from fastapi import HTTPException
from sqlalchemy import func, select, update
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.core.config import settings
from app.models.payment import (Invoice, Payment, PaymentRefund, PaymentReviewFlag, PaymentTransaction, PaymentWebhookEvent, PlatformCommission, TrainerEarning)
from app.models.training import Training
from app.models.user import InstitutionProfile, TrainerProfile, User
from app.services import invoice_service, payment_providers as providers, payment_rules as rules, training_service
from app.services.audit import audit
from app.services.notification_service import notify_event_safe

log = logging.getLogger("itbridge.payments")
SANDBOX_ENVIRONMENTS = rules.SANDBOX_ENVIRONMENTS
SANDBOX_NOTICE = "Sandbox mode: no real money is processed. Payments here are simulated for development and testing."


class PaymentError(HTTPException):
    """An HTTPException that also carries a stable machine-readable code in the response's `data`."""

    def __init__(self, status: int, code: str, message: str):
        super().__init__(status, message)
        self.data = {"code": code}


def refuse(r: rules.Refusal):
    raise PaymentError(r.status, r.code, r.message)


# ---------- small helpers ----------
def utcnow() -> datetime:
    return datetime.now(timezone.utc)


def aware(dt: datetime | None) -> datetime | None:
    """Datetimes read back from SQLite are naive UTC; PostgreSQL returns aware ones. Compare only after this."""
    return dt if dt is None or dt.tzinfo else dt.replace(tzinfo=timezone.utc)


def iso(dt: datetime | None) -> str | None:
    return dt.isoformat() if dt else None


def payments_on() -> bool:
    """Payments are switched on AND usable here (see rules.sandbox_usable): the sandbox needs the payments switch, the explicit sandbox opt-in
    (PAYMENT_SANDBOX_ENABLED) and a development or test environment. Anything else is OFF, so nothing is left half-working."""
    return rules.sandbox_usable(enabled=settings.payments_enabled, provider=settings.payment_provider,
                                sandbox_opt_in=settings.payment_sandbox_enabled, environment=settings.environment)


def sandbox_enabled() -> bool:
    """The sandbox provider is in use (banner shown) and its simulator is allowed (payments_on() already guarantees the opt-in and the environment)."""
    return payments_on() and settings.payment_provider in rules.SANDBOX_PROVIDERS


def lock_training(db: Session, tid: int) -> Training | None:
    return db.get(Training, tid, with_for_update=True, populate_existing=True)


def lock_payment(db: Session, pid: int) -> Payment | None:
    return db.get(Payment, pid, with_for_update=True, populate_existing=True)


def lock_training_row(db: Session, tid: int) -> None:
    """Takes the training lock WITHOUT refreshing the in-memory Training (the caller may hold unflushed changes to it)."""
    db.execute(select(Training.id).where(Training.id == tid).with_for_update())


def collected_paise(db: Session, training_id: int, exclude_payment_id: int | None = None) -> int:
    """Money HELD for a training: successful payments that have not been fully refunded, an over-cap payment waiting for its refund included.
    A refund still in progress counts as held. This blocks starting new attempts and is what the screens show. It is NOT the basis of the fee
    cap for provider events: see settled_totals."""
    refunded = select(PaymentRefund.payment_id).where(PaymentRefund.status == rules.R_SUCCEEDED)
    q = select(func.coalesce(func.sum(Payment.amount_paise), 0)).where(
        Payment.training_id == training_id, Payment.status == rules.SUCCEEDED, Payment.id.not_in(refunded))
    if exclude_payment_id is not None:
        q = q.where(Payment.id != exclude_payment_id)
    return int(db.scalar(q) or 0)


def settled_totals(db: Session, training_id: int, exclude_payment_id: int | None = None) -> tuple[int, int]:
    """(money, commission) already SETTLED for a training's live payments: those with a RECORDED commission (so not refunded and not over-cap).
    The money figure is the basis of the fee cap when a provider event arrives, so an over-cap payment can never make a later, legitimate
    payment look over-cap; the commission figure is the basis of the commission finalised at settlement."""
    q = (select(func.coalesce(func.sum(Payment.amount_paise), 0), func.coalesce(func.sum(PlatformCommission.amount_paise), 0))
         .select_from(Payment).join(PlatformCommission, PlatformCommission.payment_id == Payment.id)
         .where(Payment.training_id == training_id, Payment.status == rules.SUCCEEDED, PlatformCommission.status == rules.C_RECORDED))
    if exclude_payment_id is not None:
        q = q.where(Payment.id != exclude_payment_id)
    money, commission = db.execute(q).one()
    return int(money), int(commission)


def active_admins(db: Session) -> list[User]:
    return list(db.scalars(select(User).where(User.role == "ADMIN", User.is_active.is_(True))))


def account_blocked(user: User) -> bool:
    prof = user.institution_profile
    return (not user.is_active) or prof is None or prof.verification_status == "SUSPENDED"


def trainer_user_id(db: Session, trainer_id: int) -> int:
    return db.scalar(select(TrainerProfile.user_id).where(TrainerProfile.id == trainer_id))


# ---------- read models ----------
def payments_out(db: Session, rows: list[Payment], admin: bool = False) -> list[dict]:
    """Serialises payments with four batched lookups, not per row. Non-admin output never contains commission, net or review notes."""
    rows = list(rows)
    if not rows:
        return []
    ids, tids = [p.id for p in rows], list({p.training_id for p in rows})
    invoices = dict(db.execute(select(Invoice.payment_id, Invoice.number).where(Invoice.payment_id.in_(ids))).all())
    refunds = {r.payment_id: r for r in db.scalars(select(PaymentRefund).where(PaymentRefund.payment_id.in_(ids)))}
    titles = dict(db.execute(select(Training.id, Training.title).where(Training.id.in_(tids))).all())
    flags: dict[int, list[PaymentReviewFlag]] = defaultdict(list)
    if admin:
        for f in db.scalars(select(PaymentReviewFlag).where(PaymentReviewFlag.payment_id.in_(ids)).order_by(PaymentReviewFlag.id)):
            flags[f.payment_id].append(f)
    out = []
    for p in rows:
        r = refunds.get(p.id)
        d = {"id": p.id, "training_id": p.training_id, "training_title": titles.get(p.training_id), "attempt_no": p.attempt_no,
             "amount_paise": p.amount_paise, "currency": p.currency, "status": p.status, "failure_reason": p.failure_reason,
             "created_at": iso(p.created_at), "paid_at": iso(p.paid_at), "expires_at": iso(p.expires_at),
             "sandbox": p.provider in rules.SANDBOX_PROVIDERS, "under_review": bool(p.needs_review), "invoice_number": invoices.get(p.id),
             "refund": {"status": r.status, "completed_at": iso(r.completed_at), "credit_note_number": r.credit_note_number} if r else None}
        if admin:
            d.update({"institution_id": p.institution_id, "trainer_id": p.trainer_id, "payer_user_id": p.payer_user_id, "provider": p.provider,
                      "provider_order_id": p.provider_order_id, "commission_bps": p.commission_bps, "platform_fee_paise": p.platform_fee_paise,
                      "net_paise": p.net_paise, "review_reason": p.review_reason, "review_text": rules.REVIEW_TEXT.get(p.review_reason),
                      "review_note": p.review_note, "reviewed_by": p.reviewed_by, "reviewed_at": iso(p.reviewed_at),
                      "review_flags": [flag_out(f) for f in flags[p.id] if f.resolved_at is None],      # every OPEN reason, oldest first
                      "review_history": [flag_out(f) for f in flags[p.id] if f.resolved_at is not None],
                      "refund_attempts": r.attempts if r else None, "refund_error": r.last_error if r else None})
        out.append(d)
    return out


def flag_out(f: PaymentReviewFlag) -> dict:
    return {"id": f.id, "reason": f.reason, "text": rules.REVIEW_TEXT.get(f.reason), "note": f.note, "created_at": iso(f.created_at),
            "resolved_at": iso(f.resolved_at), "resolved_by": f.resolved_by, "resolution_note": f.resolution_note}


def _my_institution(user: User):
    prof = user.institution_profile
    if user.role != "INSTITUTION" or prof is None:
        raise HTTPException(403, "You do not have permission to do this")
    return prof


def get_payment(db: Session, user: User, pid: int) -> dict:
    prof = _my_institution(user)
    p = db.get(Payment, pid)
    if p is None or p.institution_id != prof.id:
        raise HTTPException(404, "Payment not found")
    return payments_out(db, [p])[0]


def list_payments(db: Session, user: User, page: int, page_size: int, status: str | None) -> dict:
    prof = _my_institution(user)
    stmt = select(Payment).where(Payment.institution_id == prof.id)
    if status:
        stmt = stmt.where(Payment.status == status)
    total = db.scalar(select(func.count()).select_from(stmt.subquery()))
    rows = db.scalars(stmt.order_by(Payment.created_at.desc(), Payment.id.desc()).offset((page - 1) * page_size).limit(page_size)).all()
    return {"items": payments_out(db, rows), "total": total, "page": page, "page_size": page_size}


def payment_summary(db: Session, user: User) -> dict:
    """Totals for the institution's dashboard card. Everything is in paise."""
    prof = _my_institution(user)
    paid = db.scalar(select(func.coalesce(func.sum(Payment.amount_paise), 0)).where(Payment.institution_id == prof.id, Payment.status == rules.SUCCEEDED)) or 0
    refunded = db.scalar(select(func.coalesce(func.sum(PaymentRefund.amount_paise), 0)).join(Payment, Payment.id == PaymentRefund.payment_id)
                         .where(Payment.institution_id == prof.id, PaymentRefund.status == rules.R_SUCCEEDED)) or 0
    open_ = db.scalar(select(func.count()).select_from(Payment).where(Payment.institution_id == prof.id, Payment.status.in_(rules.IN_FLIGHT))) or 0
    count = db.scalar(select(func.count()).select_from(Payment).where(Payment.institution_id == prof.id)) or 0
    return {"paid_paise": int(paid), "refunded_paise": int(refunded), "net_paid_paise": int(paid) - int(refunded), "in_progress": open_,
            "attempts": count, "enabled": payments_on(), "sandbox": sandbox_enabled(), "sandbox_notice": SANDBOX_NOTICE if sandbox_enabled() else None}


def training_summary(db: Session, user: User, tid: int) -> dict:
    """The payment block of TrainingDetail. Both parties see the fee and what has been paid; only the institution sees its payment attempts
    and whether it can pay, only the trainer sees its own earning. Anyone else gets 404 from get_training."""
    t, role = training_service.get_training(db, user, tid)
    fee, collected = rules.fee_paise(t.agreed_fee), collected_paise(db, t.id)
    settled = settled_totals(db, t.id)[0]
    in_flight = db.scalar(select(Payment).where(Payment.training_id == t.id, Payment.status.in_(rules.IN_FLIGHT)).order_by(Payment.id.desc()))
    # collected = money HELD (blocks new attempts; an over-cap payment waiting for its refund is included). settled = the part that counts towards the
    # agreed fee. due = what of the fee is still unpaid. They differ only while an over-cap payment awaits its refund.
    base = {"training_id": t.id, "currency": rules.CURRENCY, "fee_paise": fee, "collected_paise": collected, "remaining_paise": rules.remaining(fee, collected),
            "settled_paise": settled, "due_paise": rules.remaining(fee, settled),
            "enabled": payments_on(), "sandbox": sandbox_enabled(), "sandbox_notice": SANDBOX_NOTICE if sandbox_enabled() else None,
            "viewer_role": role, "under_review": bool(db.scalar(select(func.count()).select_from(Payment).where(Payment.training_id == t.id, Payment.needs_review.is_(True))))}
    if role == "INSTITUTION":
        why = rules.block_reason(enabled=payments_on(), account_blocked=account_blocked(user), training_status=t.status, fee=fee,
                                 collected=collected, in_flight=in_flight is not None, settled=settled)
        attempts = db.scalars(select(Payment).where(Payment.training_id == t.id).order_by(Payment.id.desc()).limit(5)).all()
        base.update({"can_pay": why is None, "block_reason": why, "block_message": rules.block_text(why, fee=fee, settled=settled) if why else None,
                     "in_progress": payments_out(db, [in_flight])[0] if in_flight else None, "attempts": payments_out(db, attempts)})
    else:
        from app.services import earning_service  # lazy: earning_service imports this module
        base["earnings"] = earning_service.for_training(db, t.id, user.trainer_profile.id)
    return base


# ---------- creating a payment attempt ----------
def _checkout(p: Payment) -> dict:
    return {"provider": p.provider, "order_id": p.provider_order_id, "sandbox": p.provider in rules.SANDBOX_PROVIDERS,
            "notice": SANDBOX_NOTICE if p.provider in rules.SANDBOX_PROVIDERS else None}


def _by_key(db: Session, payer_user_id: int, key: str) -> Payment | None:
    return db.scalar(select(Payment).where(Payment.payer_user_id == payer_user_id, Payment.idempotency_key == key))


def _replay(db: Session, existing: Payment, tid: int, amount: int) -> tuple[dict, bool]:
    if existing.request_fingerprint != rules.fingerprint(tid, amount):
        raise PaymentError(409, "IDEMPOTENCY_CONFLICT", "This Idempotency-Key was already used for a different payment request")
    return {**payments_out(db, [existing])[0], "checkout": _checkout(existing)}, False


def create_payment(db: Session, user: User, tid: int, amount_paise: int, key: str | None) -> tuple[dict, bool]:
    """Creates a PENDING payment attempt (or replays an identical earlier request). Returns (payment, created).
    Nothing here can mark a payment paid: the result of the attempt arrives later through process_event."""
    if not rules.valid_idempotency_key(key):
        raise PaymentError(422, "INVALID_IDEMPOTENCY_KEY", "Send an Idempotency-Key header of 8 to 80 letters, digits, '-', '_', '.' or ':'")
    prof = _my_institution(user)
    t0 = db.get(Training, tid)
    if t0 is None or t0.institution_id != prof.id:
        raise HTTPException(404, "Training not found")
    if not payments_on():
        refuse(rules.Refusal(503, "DISABLED", rules.BLOCK_TEXT["DISABLED"]))
    t = lock_training(db, tid)                                    # lock 1: serialises every payment decision for this training
    existing = _by_key(db, user.id, key)
    if existing:
        return _replay(db, existing, tid, amount_paise)
    fee, collected = rules.fee_paise(t.agreed_fee), collected_paise(db, t.id)
    in_flight = db.scalar(select(Payment.id).where(Payment.training_id == t.id, Payment.status.in_(rules.IN_FLIGHT))) is not None
    bad = rules.check_create(enabled=payments_on(), account_blocked=account_blocked(user), training_status=t.status, fee=fee,
                             collected=collected, in_flight=in_flight, amount=amount_paise, settled=settled_totals(db, t.id)[0])
    if bad:
        refuse(bad)
    try:
        provider = providers.get_provider()
    except providers.ProviderError:
        raise PaymentError(503, "PROVIDER_UNAVAILABLE", "The payment provider is not available")
    used = db.scalar(select(Payment.commission_bps).where(Payment.training_id == t.id, Payment.status == rules.SUCCEEDED).order_by(Payment.id).limit(1))
    bps = rules.choose_rate(used, settings.platform_commission_bps)
    commission, net = rules.split(collected, amount_paise, bps)
    attempt = (db.scalar(select(func.max(Payment.attempt_no)).where(Payment.training_id == t.id)) or 0) + 1
    # DELIBERATE, sandbox only: the provider is called while the training lock is held and BEFORE the row is inserted. The lock is what stops two requests
    # from both creating a provider order for one training and what keeps cancel / complete from racing the insert; and a failure here leaves no row, so
    # an order we never stored is an unreachable orphan (see the "provider fails while a payment is being started" tests). A real provider must NOT just have
    # this call moved out of the lock: it needs a reserve-then-call design (README, "Gates before anyone may call payments real").
    try:
        order = provider.create_order(reference=f"itb-training-{t.id}-attempt-{attempt}", amount_paise=amount_paise, currency=rules.CURRENCY)
    except providers.ProviderError:
        raise PaymentError(502, "PROVIDER_ERROR", "The payment provider could not start the payment. Nothing was charged. Try again")
    if not rules.valid_order_id(order.order_id):                  # checked before the insert: an unusable id must not become a database error
        log.error("payment provider %s returned an unusable order id (%d characters)", provider.name, len(str(order.order_id)))
        raise PaymentError(502, "PROVIDER_ERROR", "The payment provider could not start the payment. Nothing was charged. Try again")
    p = Payment(training_id=t.id, institution_id=prof.id, trainer_id=t.trainer_id, payer_user_id=user.id, attempt_no=attempt, amount_paise=amount_paise,
                currency=rules.CURRENCY, commission_bps=bps, platform_fee_paise=commission, net_paise=net, status=rules.PENDING, provider=provider.name,
                provider_order_id=order.order_id, provider_meta=order.meta, idempotency_key=key, request_fingerprint=rules.fingerprint(tid, amount_paise),
                needs_review=False, expires_at=utcnow() + timedelta(minutes=settings.payment_expiry_minutes))
    try:
        db.add(p)
        db.flush()
    except IntegrityError:
        # A concurrent request got there first (same key, or another attempt in flight). Roll back and answer from what is now committed.
        db.rollback()
        again = _by_key(db, user.id, key)
        if again:
            return _replay(db, again, tid, amount_paise)
        raise PaymentError(409, "IN_PROGRESS", rules.BLOCK_TEXT["IN_PROGRESS"])
    audit(db, user, "PAYMENT_CREATED", "payment", p.id, training_id=t.id, attempt=attempt, amount_paise=amount_paise, commission_bps=bps)
    db.commit()
    return {**payments_out(db, [p])[0], "checkout": _checkout(p)}, True


def cancel_payment(db: Session, user: User, pid: int) -> dict:
    """The payer abandons an attempt that has not started processing. A later success report for it is still recorded (late success)."""
    prof = _my_institution(user)
    p0 = db.get(Payment, pid)
    if p0 is None or p0.institution_id != prof.id:
        raise HTTPException(404, "Payment not found")
    lock_training(db, p0.training_id)
    p = lock_payment(db, pid)
    if p.status == rules.CANCELLED:
        return payments_out(db, [p])[0]
    if p.status != rules.PENDING:
        raise PaymentError(409, "NOT_CANCELLABLE", "Only a payment that has not started processing can be cancelled")
    p.status = rules.CANCELLED
    audit(db, user, "PAYMENT_CANCELLED", "payment", p.id, by="payer")
    db.commit()
    return payments_out(db, [p])[0]


# ---------- the trusted path: provider results ----------
def open_flags(db: Session, payment_id: int) -> list[PaymentReviewFlag]:
    return list(db.scalars(select(PaymentReviewFlag).where(PaymentReviewFlag.payment_id == payment_id, PaymentReviewFlag.resolved_at.is_(None))
                           .order_by(PaymentReviewFlag.id)))


def has_open_flag(db: Session, payment_id: int, reason: str) -> bool:
    return db.scalar(select(PaymentReviewFlag.id).where(PaymentReviewFlag.payment_id == payment_id, PaymentReviewFlag.reason == reason,
                                                         PaymentReviewFlag.resolved_at.is_(None))) is not None


def sync_review_state(db: Session, p: Payment) -> None:
    """`needs_review` and `review_reason` on the payment are a SUMMARY of its open flags (the oldest open reason); the flag rows are the truth.
    A payment leaves the review queue only when its last open flag is resolved. Call with the payment locked and any new flag flushed."""
    flags = open_flags(db, p.id)
    p.needs_review = bool(flags)
    p.review_reason = flags[0].reason if flags else None


def flag_for_review(db: Session, p: Payment, t: Training, reason: str, note: str | None = None) -> PaymentReviewFlag:
    """Puts a payment in front of an administrator for one REASON. A payment can carry several different open reasons at once (a late success
    on a cancelled training that was also charged twice): each is its own durable row, resolved on its own, and the payment stays in the review
    queue until all are resolved. The same reason is never opened twice (the database enforces it); repeating it is only audited."""
    flag = db.scalar(select(PaymentReviewFlag).where(PaymentReviewFlag.payment_id == p.id, PaymentReviewFlag.reason == reason, PaymentReviewFlag.resolved_at.is_(None)))
    created = flag is None
    if created:
        flag = PaymentReviewFlag(payment_id=p.id, reason=reason, note=note[:500] if note else None)
        db.add(flag)
        db.flush()
    sync_review_state(db, p)
    audit(db, None, "PAYMENT_FLAGGED", "payment", p.id, reason=reason, note=note, flag_id=flag.id, already_open=not created)
    if created:
        for admin in active_admins(db):
            notify_event_safe(db, admin.id, "PAYMENT_NEEDS_REVIEW", dedupe_key=f"payment-review:{flag.id}:{admin.id}",
                              title=t.title, reason=rules.REVIEW_TEXT[reason], training_id=t.id)
    return flag


def _amount(p: Payment) -> str:
    return rules.format_inr(p.amount_paise)


def _settle(db: Session, p: Payment, t: Training, full: bool = True) -> None:
    """A payment succeeded. Every successful payment gets its invoice. With `full` (the normal case) it also gets its trainer earning and
    its commission record; an over-cap payment does not: that money is not owed to the trainer and is waiting for an administrator's refund.
    The commission is FINALISED here, from what is already settled for the training, so late successes and refunds cannot make the
    total drift (the figure stored when the attempt was created was only an estimate). Each record is unique per payment in the database."""
    inst, trainer = db.get(InstitutionProfile, p.institution_id), db.get(TrainerProfile, p.trainer_id)
    if not full:
        p.platform_fee_paise, p.net_paise = 0, p.amount_paise      # no commission is recorded and no earning exists for money that is waiting for a refund
        db.flush()
    if full:
        other_rate = db.scalar(select(Payment.commission_bps).where(Payment.training_id == t.id, Payment.status == rules.SUCCEEDED, Payment.id != p.id)
                               .order_by(Payment.id).limit(1))
        bps = rules.choose_rate(other_rate, p.commission_bps)
        money, commission = settled_totals(db, t.id, exclude_payment_id=p.id)
        p.commission_bps = bps
        p.platform_fee_paise, p.net_paise = rules.settle_commission(money, commission, p.amount_paise, bps)
        db.flush()
    invoice_service.issue(db, p, t, inst, trainer)
    now = utcnow()
    if full:
        available = rules.initial_earning_status(t.status) == rules.E_AVAILABLE
        if available and settings.earning_hold_days > 0 and t.completed_at is not None:
            available = rules.hold_elapsed((now - aware(t.completed_at)).total_seconds(), settings.earning_hold_days)
        if not db.scalar(select(TrainerEarning.id).where(TrainerEarning.payment_id == p.id)):
            e = TrainerEarning(payment_id=p.id, trainer_id=p.trainer_id, training_id=t.id, gross_paise=p.amount_paise, commission_paise=p.platform_fee_paise,
                               net_paise=p.net_paise, status=rules.E_AVAILABLE if available else rules.E_PENDING, available_at=now if available else None)
            db.add(e)
            db.flush()
            if available:
                notify_event_safe(db, trainer.user_id, "EARNING_AVAILABLE", dedupe_key=f"earning-available:{e.id}", amount=rules.format_inr(e.net_paise), title=t.title, training_id=t.id)
        if not db.scalar(select(PlatformCommission.id).where(PlatformCommission.payment_id == p.id)):
            db.add(PlatformCommission(payment_id=p.id, rate_bps=p.commission_bps, amount_paise=p.platform_fee_paise, status=rules.C_RECORDED))
    payer = p.payer_user_id
    notify_event_safe(db, payer, "PAYMENT_SUCCEEDED", dedupe_key=f"payment-succeeded:{p.id}:{payer}", amount=_amount(p), title=t.title, training_id=t.id)
    if full:
        notify_event_safe(db, trainer.user_id, "PAYMENT_RECEIVED", dedupe_key=f"payment-received:{p.id}:{trainer.user_id}", amount=_amount(p), title=t.title, training_id=t.id)


def _record(db: Session, provider: str, ev: providers.ProviderEvent, payment_id: int | None, outcome: str, source: str,
            existing: PaymentWebhookEvent | None = None) -> None:
    """Stores the event (evidence, and the replay guard). `existing` is an earlier delivery that could not be matched to an order yet: it is
    updated in place, its original UNKNOWN_ORDER audit entry stays."""
    if existing is not None:
        existing.payment_id, existing.outcome, existing.source = payment_id, outcome, source
        return
    db.add(PaymentWebhookEvent(provider=provider, event_id=ev.event_id, event_type=ev.type[:40], payment_id=payment_id, outcome=outcome, source=source,
                               payload={"id": ev.event_id, "type": ev.type, "order_id": ev.order_id, "amount": ev.amount_paise, "currency": ev.currency,
                                        "transaction_id": ev.txn_id, "reason": ev.reason}))


def process_event(db: Session, provider: str, ev: providers.ProviderEvent, source: str) -> dict:
    """What a verified provider event does. Called ONLY by handle_webhook and reconcile. Idempotent per (provider, event id); safe against
    out-of-order, late, duplicate and mismatching events (see payment_rules.decide_event). Returns {'outcome': ..., 'payment_id': ...}."""
    seen = _seen(db, provider, ev.event_id)
    if seen is not None and seen[1] != "unknown_order":
        db.rollback()
        return {"outcome": "replay", "payment_id": None}
    row = db.execute(select(Payment.id, Payment.training_id).where(Payment.provider == provider, Payment.provider_order_id == ev.order_id)).first()
    if row is None:
        # The event may simply have overtaken the commit of the order it belongs to. It is stored once (evidence), and the answer is an ERROR so
        # the provider delivers it again; a later delivery is matched to the order (the stored row is then updated, see _record).
        if seen is None:
            _record(db, provider, ev, None, "unknown_order", source)
            audit(db, None, "PAYMENT_EVENT_UNKNOWN_ORDER", "payment_event", None, provider=provider, event_id=ev.event_id)
            _commit_event(db, provider, ev, None, "unknown_order")
        else:
            db.rollback()
        raise PaymentError(404, "UNKNOWN_ORDER", "No payment matches this event yet. Deliver it again later")
    pid, tid = row
    t = lock_training(db, tid)
    p = lock_payment(db, pid)
    seen = _seen(db, provider, ev.event_id)                       # re-check under the lock: another delivery may have committed while we waited
    if seen is not None and seen[1] != "unknown_order":
        db.rollback()
        return {"outcome": "replay", "payment_id": pid}
    existing = db.get(PaymentWebhookEvent, seen[0]) if seen is not None else None
    charge_txn = db.scalar(select(PaymentTransaction.provider_txn_id).where(PaymentTransaction.payment_id == p.id, PaymentTransaction.type == rules.TXN_CHARGE))
    d = rules.decide_event(status=p.status, amount_paise=p.amount_paise, currency=p.currency, charge_txn_on_file=charge_txn, event_type=ev.type,
                           event_amount=ev.amount_paise, event_currency=ev.currency, event_txn_id=ev.txn_id, event_reason=ev.reason,
                           collected_other=settled_totals(db, t.id, exclude_payment_id=p.id)[0], fee=rules.fee_paise(t.agreed_fee), training_status=t.status)
    txn_id = ev.txn_id or f"evt:{ev.event_id}"
    if d.record_charge:
        owner = db.scalar(select(PaymentTransaction.payment_id).where(PaymentTransaction.provider == provider, PaymentTransaction.provider_txn_id == txn_id))
        if owner is not None and owner != p.id:                   # the provider reused a transaction id: keep the evidence, change nothing else
            d = rules.EventDecision("txn_id_reused", flag=rules.DUPLICATE_CHARGE)
    if d.new_status:
        if not rules.can_transition(p.status, d.new_status):      # decide_event never asks for this; guard anyway
            raise RuntimeError(f"illegal payment transition {p.status} -> {d.new_status}")
        old, p.status = p.status, d.new_status
        if d.new_status == rules.SUCCEEDED:
            p.paid_at, p.failure_reason = utcnow(), None
        elif d.new_status == rules.FAILED:
            p.failure_reason = d.failure_reason
        audit(db, None, f"PAYMENT_{d.new_status}", "payment", p.id, was=old, outcome=d.outcome, source=source, event_id=ev.event_id)
    elif d.outcome not in ("stale_ignored", "duplicate", "ignored_unknown_type"):
        audit(db, None, "PAYMENT_EVENT_" + d.outcome.upper(), "payment", p.id, source=source, event_id=ev.event_id)
    if d.record_charge:
        db.add(PaymentTransaction(payment_id=p.id, type=rules.TXN_CHARGE, amount_paise=p.amount_paise, provider=provider, provider_txn_id=txn_id))
    _record(db, provider, ev, p.id, d.outcome, source, existing)
    db.flush()                                                    # a DML statement must precede the SAVEPOINT used by invoice numbering
    if d.flag:
        flag_for_review(db, p, t, d.flag, note=f"event {ev.event_id}")
    if d.new_status == rules.SUCCEEDED and t.status == "CANCELLED" and d.flag != rules.TRAINING_CANCELLED:
        flag_for_review(db, p, t, rules.TRAINING_CANCELLED, note=f"event {ev.event_id}")   # money arrived for a cancelled training: always say so
    if d.invoice:
        _settle(db, p, t, full=d.settle)
    if d.new_status == rules.FAILED:
        notify_event_safe(db, p.payer_user_id, "PAYMENT_FAILED", dedupe_key=f"payment-failed:{p.id}:{p.payer_user_id}", amount=_amount(p), title=t.title, training_id=t.id)
    return _commit_event(db, provider, ev, p.id, d.outcome)


def _seen(db: Session, provider: str, event_id: str) -> tuple[int, str] | None:
    """(row id, outcome) of an event already stored for this provider, or None."""
    row = db.execute(select(PaymentWebhookEvent.id, PaymentWebhookEvent.outcome).where(PaymentWebhookEvent.provider == provider,
                                                                                      PaymentWebhookEvent.event_id == event_id)).first()
    return (row[0], row[1]) if row else None


def _commit_event(db: Session, provider: str, ev: providers.ProviderEvent, pid: int | None, outcome: str) -> dict:
    try:
        db.commit()
    except IntegrityError:
        db.rollback()                                             # the unique (provider, event id) lost a race: it is a replay
        if _seen(db, provider, ev.event_id) is not None:
            return {"outcome": "replay", "payment_id": pid}
        raise
    return {"outcome": outcome, "payment_id": pid}


def handle_webhook(db: Session, body: bytes, signature: str | None, timestamp: str | None, source: str = "WEBHOOK") -> dict:
    """The only entry for provider-pushed results. Rejects anything unauthenticated BEFORE touching the database. It does NOT depend on
    PAYMENTS_ENABLED: a payment made earlier must still be recorded if the feature is switched off afterwards (evidence of a charge is
    never discarded). With no webhook secret configured nothing is accepted, and in production neither is a secret that is weak or a known
    example value (the start-up guard refuses to boot with one; this is the second line of defence)."""
    secret = settings.payment_webhook_secret if rules.webhook_secret_usable(settings.payment_webhook_secret, settings.environment) else ""
    why = rules.check_webhook(secret=secret, body=body, signature=signature, timestamp=timestamp, now_epoch=time.time(),
                              tolerance_seconds=settings.payment_webhook_tolerance_seconds)
    if why:
        log.warning("payment webhook rejected: %s", why)
        raise PaymentError(503 if why == "not_configured" else 401, "WEBHOOK_REJECTED", "Webhook rejected")
    try:
        provider = providers.get_provider()
        ev = provider.parse_event(body)
    except providers.ProviderError:
        raise PaymentError(503, "PROVIDER_UNAVAILABLE", "The payment provider is not available")
    except ValueError:
        raise PaymentError(400, "BAD_EVENT", "Malformed event")
    return process_event(db, provider.name, ev, source)


SANDBOX_OUTCOMES = {"success": rules.EVENT_SUCCEEDED, "fail": rules.EVENT_FAILED, "processing": rules.EVENT_PROCESSING}


def simulate(db: Session, user: User, pid: int, outcome: str) -> dict:
    """Development/test only. Builds a SIGNED event for the payer's own sandbox payment and feeds it to handle_webhook, the same code a real
    gateway's delivery goes through. Event ids are deterministic, so clicking twice is a replay, not a second charge."""
    if not sandbox_enabled():
        raise PaymentError(403, "SANDBOX_DISABLED", "The payment sandbox is only available in development and test environments")
    prof = _my_institution(user)
    p = db.get(Payment, pid)
    if p is None or p.institution_id != prof.id:
        raise HTTPException(404, "Payment not found")
    if p.provider not in rules.SANDBOX_PROVIDERS or outcome not in SANDBOX_OUTCOMES:
        raise PaymentError(422, "BAD_SANDBOX_REQUEST", "Not a sandbox payment or unknown outcome")
    if not settings.payment_webhook_secret:
        raise PaymentError(503, "WEBHOOK_NOT_CONFIGURED", "Set PAYMENT_WEBHOOK_SECRET to use the sandbox")
    ok = outcome == "success"
    audit(db, user, "PAYMENT_SANDBOX_SIMULATED", "payment", p.id, outcome=outcome)    # who pressed the button; the event itself is source SANDBOX
    db.commit()
    body, headers = providers.build_signed_event(
        settings.payment_webhook_secret, event_id=f"sbx_evt_{p.provider_order_id}_{outcome}", type_=SANDBOX_OUTCOMES[outcome], order_id=p.provider_order_id,
        amount_paise=p.amount_paise, currency=p.currency, txn_id=f"sbx_txn_{p.provider_order_id}" if ok else None,
        reason=None if ok else "Simulated failure (sandbox)", timestamp=int(time.time()))
    result = handle_webhook(db, body, headers[providers.SIGNATURE_HEADER], headers[providers.TIMESTAMP_HEADER], source="SANDBOX")
    db.expire_all()
    return {**result, "payment": get_payment(db, user, pid)}


# ---------- training lifecycle hooks (called by training_service inside its own transaction) ----------
def on_training_completed(db: Session, t: Training) -> int:
    """A completed training releases its trainer earnings (after the configured hold). Returns how many became available."""
    from app.services import earning_service  # lazy: earning_service imports this module
    lock_training_row(db, t.id)
    return earning_service.promote_available(db, training_id=t.id, training=t)


def on_training_cancelled(db: Session, t: Training, actor: User | None) -> None:
    """A cancelled training: attempts that have not started are cancelled; money already received is flagged for an administrator.
    NO automatic refund and no record is deleted. Earnings stay PENDING (a cancelled training can never complete)."""
    lock_training_row(db, t.id)
    for p in db.scalars(select(Payment).where(Payment.training_id == t.id).order_by(Payment.id).with_for_update()):
        if p.status == rules.PENDING:
            p.status = rules.CANCELLED
            audit(db, actor, "PAYMENT_CANCELLED", "payment", p.id, by="training_cancelled")
        elif p.status == rules.SUCCEEDED:                          # flags are per reason: another open flag neither hides this one nor is hidden by it
            refunded = db.scalar(select(PaymentRefund.id).where(PaymentRefund.payment_id == p.id, PaymentRefund.status == rules.R_SUCCEEDED))
            if not refunded:
                flag_for_review(db, p, t, rules.TRAINING_CANCELLED)


# ---------- reconciliation (worker) ----------
def _expire(db: Session, pid: int) -> bool:
    """Closes an abandoned attempt as EXPIRED. PENDING: after its expiry time. PROCESSING: only after PAYMENT_PROCESSING_TIMEOUT_MINUTES with no
    final result, and then it is flagged for review first. Either way a success the provider reports later is still recorded (late success)."""
    p0 = db.get(Payment, pid)
    lock_training(db, p0.training_id)
    p = lock_payment(db, pid)
    now = utcnow()
    if p.status == rules.PENDING and aware(p.expires_at) is not None and aware(p.expires_at) <= now:
        audit(db, None, "PAYMENT_EXPIRED", "payment", p.id)
    elif p.status == rules.PROCESSING and aware(p.created_at) <= now - timedelta(minutes=settings.payment_processing_timeout_minutes):
        flag_for_review(db, p, db.get(Training, p.training_id), rules.STUCK_PROCESSING)
        audit(db, None, "PAYMENT_EXPIRED", "payment", p.id, was=rules.PROCESSING, reason="no final result from the provider")
    else:
        db.rollback()
        return False
    p.status = rules.EXPIRED
    db.commit()
    return True


def _touch(db: Session, pid: int) -> None:
    """Records that reconciliation looked at this payment and found nothing to do. reconcile() takes the least recently looked-at payments
    first (updated_at), so a large backlog of old open attempts is worked through in turns instead of the same ones every run."""
    db.execute(update(Payment).where(Payment.id == pid).values(updated_at=utcnow()))
    db.commit()


def _reconcile_one(db: Session, provider, pid: int, now: datetime, counts: dict, poll: bool) -> None:
    p = db.get(Payment, pid)
    ev = None
    if poll:
        try:
            ev = provider.fetch_status(p.provider_order_id)
        except providers.ProviderError:
            log.warning("reconcile: provider lookup failed for payment %s", pid)
            _touch(db, pid)                                       # a failing lookup must not keep this payment at the front of the queue forever
            return
    if ev is not None:
        process_event(db, provider.name, ev, "RECONCILE")
        counts["settled"] += 1
        if db.scalar(select(Payment.status).where(Payment.id == pid)) in rules.IN_FLIGHT:
            _touch(db, pid)                                       # still open (a non-final or repeated provider result): rotate it to the back of the queue
        return
    if p.status == rules.PENDING or (p.status == rules.PROCESSING and aware(p.created_at) <= now - timedelta(minutes=settings.payment_processing_timeout_minutes)):
        if _expire(db, pid):
            counts["expired"] += 1
            return
    elif p.status == rules.PROCESSING and aware(p.created_at) <= now - timedelta(minutes=2 * settings.payment_expiry_minutes) and not has_open_flag(db, pid, rules.STUCK_PROCESSING):
        lock_training(db, p.training_id)
        p = lock_payment(db, pid)
        if p.status == rules.PROCESSING and not has_open_flag(db, pid, rules.STUCK_PROCESSING):
            flag_for_review(db, p, db.get(Training, p.training_id), rules.STUCK_PROCESSING)
            counts["stuck"] += 1
        db.commit()
        return
    _touch(db, pid)


def reconcile(db: Session) -> dict:
    """Closes the gap between what the provider knows and what we recorded. Safe to run as often as you like. Every step is isolated: one
    payment that cannot be processed is logged, rolled back and counted in "errors"; it never stops the others or the later steps.
      * an open attempt older than PAYMENT_RECONCILE_AFTER_MINUTES is looked up at the provider (only while payments are on); a result goes
        through process_event
      * a PENDING attempt past its expiry with no result becomes EXPIRED (a late success is still accepted afterwards)
      * a PROCESSING attempt open for twice the expiry is flagged STUCK_PROCESSING, and closed as EXPIRED after the processing timeout
      * refunds left PENDING are retried; earnings whose hold has elapsed become AVAILABLE
    Refund retries and earnings do not depend on PAYMENTS_ENABLED: money already taken must be finished even if the feature is switched off."""
    counts = {"settled": 0, "expired": 0, "stuck": 0, "refunds_retried": 0, "earnings_available": 0, "errors": 0}
    provider, poll = None, payments_on()
    try:
        provider = providers.get_provider()
    except providers.ProviderError:
        log.error("reconcile: payment provider unavailable")
        poll = False
    now = utcnow()
    if provider is not None:
        cutoff = now - timedelta(minutes=settings.payment_reconcile_after_minutes)
        ids = db.scalars(select(Payment.id).where(Payment.status.in_(rules.IN_FLIGHT), Payment.created_at <= cutoff).order_by(Payment.updated_at, Payment.id).limit(200)).all()
        db.rollback()                                             # end the read transaction before the per-payment units of work
        for pid in ids:
            try:
                _reconcile_one(db, provider, pid, now, counts, poll)
            except Exception:                                     # isolate: a bad payment must not stall the rest
                db.rollback()
                counts["errors"] += 1
                log.exception("reconcile: payment %s could not be processed", pid)
                try:
                    _touch(db, pid)                               # a payment that always fails still rotates to the back of the queue
                except Exception:
                    db.rollback()
                    log.exception("reconcile: payment %s could not be marked as visited", pid)
    from app.services import earning_service, payment_admin_service  # lazy: both import this module
    for key, step in (("refunds_retried", payment_admin_service.retry_pending_refunds), ("earnings_available", earning_service.promote_available)):
        try:
            counts[key] = step(db)
            db.commit()
        except Exception:
            db.rollback()
            counts["errors"] += 1
            log.exception("reconcile: step %s failed", key)
    return counts
