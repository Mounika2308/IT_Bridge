from datetime import date, datetime, timezone

from fastapi import HTTPException
from sqlalchemy import func, select
from sqlalchemy.orm import Session, joinedload, selectinload

from app.core.clock import now, today
from app.models.application import HiringRequest
from app.models.requirement import TrainingRequirement
from app.models.training import Attendance, Training, TrainingSession
from app.models.user import TrainerProfile, User
from app.schemas.training import AttendanceIn, SessionIn, SessionUpdateIn, TrainingDatesIn
from app.services.audit import audit
from app.services.notification_service import notify_event, notify_event_safe

SESSION_MOVES = {"SCHEDULED": {"ONGOING", "COMPLETED", "CANCELLED"}, "ONGOING": {"COMPLETED", "CANCELLED"}}


def create_for_hiring(db: Session, hr: HiringRequest) -> Training:
    """Called inside the trainer's accept transaction. Refuses anything but an accepted hiring request, and never
    creates a second training for the same one."""
    if hr.status != "ACCEPTED":
        raise HTTPException(409, "A training can only be created from an accepted hiring request")
    if db.scalar(select(Training.id).where(Training.hiring_request_id == hr.id)):
        raise HTTPException(409, "A training already exists for this hiring request")
    req = hr.requirement
    t = Training(hiring_request_id=hr.id, requirement_id=req.id, trainer_id=hr.trainer_id, institution_id=req.institution_id,
                 title=req.title, technology=req.technology, mode=req.mode, location=req.location,
                 description=req.description, terms=hr.terms, start_date=hr.start_date, end_date=hr.end_date, agreed_fee=hr.agreed_fee,
                 student_count=req.student_count, planned_sessions=hr.sessions)
    db.add(t)
    db.flush()
    return t


def phase(t: Training) -> str:
    """Lifecycle phase shown to users. COMPLETED and CANCELLED are stored; the other three are derived from the dates
    of an ACTIVE training. ENDED means the end date passed but nobody has completed or cancelled it yet."""
    if t.status != "ACTIVE":
        return t.status
    d = today()
    if t.start_date > d:
        return "UPCOMING"
    return "ENDED" if t.end_date < d else "IN_PROGRESS"


def _role(user: User, t: Training) -> str:
    if user.role == "TRAINER" and user.trainer_profile and user.trainer_profile.id == t.trainer_id:
        return "TRAINER"
    if user.role == "INSTITUTION" and user.institution_profile and user.institution_profile.id == t.institution_id:
        return "INSTITUTION"
    raise HTTPException(404, "Training not found")


def get_training(db: Session, user: User, tid: int) -> tuple[Training, str]:
    t = db.get(Training, tid)
    if not t:
        raise HTTPException(404, "Training not found")
    return t, _role(user, t)


def _get_session(db: Session, user: User, sid: int) -> tuple[TrainingSession, Training, str]:
    s = db.get(TrainingSession, sid)
    if not s:
        raise HTTPException(404, "Session not found")
    t, role = get_training(db, user, s.training_id)
    return s, t, role


def _t(x) -> str:
    return x.strftime("%H:%M")


def _tell_other(db: Session, actor: User, t: Training, type_: str, **ctx):
    """Notifies the other party of this training. The training title and id are always available to the message template."""
    target = t.institution.user_id if actor.id == t.trainer.user_id else t.trainer.user_id
    notify_event_safe(db, target, type_, training_id=t.id, title=t.title, **ctx)   # safe: a cancellation also flags payments in the same transaction


def session_start(s: TrainingSession) -> datetime:
    """Scheduled start as a naive platform-local datetime (the same clock as clock.now())."""
    return datetime.combine(s.session_date, s.start_time)


def _started(s: TrainingSession) -> bool:
    return session_start(s) <= now()


def session_out(s: TrainingSession) -> dict:
    a = s.attendance
    return {"id": s.id, "title": s.title, "session_date": str(s.session_date), "start_time": _t(s.start_time),
            "end_time": _t(s.end_time), "status": s.status, "notes": s.notes,
            "attendance": {"total_students": a.total_students, "present": a.present, "absent": a.absent,
                           "percent": round(a.present * 100 / a.total_students)} if a else None}


def training_out(t: Training, viewer_role: str, with_sessions: bool = True) -> dict:
    live = [s for s in t.sessions if s.status != "CANCELLED"]
    done = [s for s in live if s.status == "COMPLETED"]
    recorded = [s.attendance for s in t.sessions if s.attendance and s.status != "CANCELLED"]
    total = sum(a.total_students for a in recorded)
    out = {"id": t.id, "requirement_id": t.requirement_id, "title": t.title, "status": t.status, "phase": phase(t),
           "technology": t.technology, "mode": t.mode, "location": t.location, "description": t.description, "terms": t.terms, "meeting_link": t.meeting_link,
           "start_date": str(t.start_date), "end_date": str(t.end_date),
           "agreed_fee": t.agreed_fee, "student_count": t.student_count, "planned_sessions": t.planned_sessions,
           "institution_name": t.institution.institution_name, "trainer_name": t.trainer.user.full_name,
           "viewer_role": viewer_role, "cancel_reason": t.cancel_reason,
           "progress": {"scheduled": len(live), "completed": len(done),
                        "percent": min(100, round(len(done) * 100 / t.planned_sessions)) if t.planned_sessions else 0},
           "attendance_percent": round(sum(a.present for a in recorded) * 100 / total) if total else None}
    if with_sessions:  # the detail view only: list items carry no contact details and need no extra queries
        other = t.institution.user if viewer_role == "TRAINER" else t.trainer.user
        out["contact"] = {"name": other.full_name, "email": other.email, "phone": other.phone}
        out["sessions"] = [session_out(s) for s in t.sessions]
    return out


def _mine(user: User):
    if user.role == "TRAINER":
        return Training.trainer_id == user.trainer_profile.id
    return Training.institution_id == user.institution_profile.id


# Everything training_out reads for a list item, loaded in a fixed number of queries (no per-row lazy loading).
LIST_LOAD = (selectinload(Training.sessions).selectinload(TrainingSession.attendance),
             joinedload(Training.institution), joinedload(Training.trainer).joinedload(TrainerProfile.user))


def list_mine(db: Session, user: User, page: int, page_size: int, status: str | None) -> dict:
    stmt = select(Training).where(_mine(user))
    if status:
        stmt = stmt.where(Training.status == status)
    total = db.scalar(select(func.count()).select_from(stmt.subquery()))
    rows = db.scalars(stmt.options(*LIST_LOAD).order_by(Training.start_date.desc(), Training.id.desc())
                      .offset((page - 1) * page_size).limit(page_size))
    return {"items": [training_out(t, user.role, with_sessions=False) for t in rows], "total": total, "page": page, "page_size": page_size}


def summary(db: Session, user: User) -> dict:
    """Counts for the dashboard cards."""
    by_status = dict(db.execute(select(Training.status, func.count()).where(_mine(user)).group_by(Training.status)).all())
    upcoming = db.scalar(select(func.count()).select_from(Training).where(_mine(user), Training.status == "ACTIVE", Training.start_date > today())) or 0
    active = by_status.get("ACTIVE", 0)
    return {"active": active, "upcoming": upcoming, "in_progress": active - upcoming, "completed": by_status.get("COMPLETED", 0),
            "cancelled": by_status.get("CANCELLED", 0)}


def _require_active(t: Training):
    if t.status != "ACTIVE":
        raise HTTPException(409, f"This training is {t.status.lower()}")


def _check_session(db: Session, t: Training, d: date, start, end, exclude_id: int | None = None, check_past: bool = True):
    if not (t.start_date <= d <= t.end_date):
        raise HTTPException(422, f"Session date must be between {t.start_date} and {t.end_date}")
    if end <= start:
        raise HTTPException(422, "End time must be after the start time")
    if check_past and datetime.combine(d, start) < now():
        raise HTTPException(422, "A session cannot be scheduled in the past")
    # Date AND time overlap against every other live session of this trainer (touching times, e.g. 10-12 and 12-13, are fine).
    stmt = (select(TrainingSession.id).join(Training, Training.id == TrainingSession.training_id)
            .where(Training.trainer_id == t.trainer_id, Training.status == "ACTIVE", TrainingSession.status != "CANCELLED",
                   TrainingSession.session_date == d, TrainingSession.start_time < end, TrainingSession.end_time > start))
    if exclude_id:
        stmt = stmt.where(TrainingSession.id != exclude_id)
    if db.scalar(stmt.limit(1)):
        raise HTTPException(409, "The trainer already has a session at that time")


def create_session(db: Session, user: User, tid: int, data: SessionIn) -> dict:
    t, _ = get_training(db, user, tid)
    _require_active(t)
    if len([s for s in t.sessions if s.status != "CANCELLED"]) >= t.planned_sessions:
        raise HTTPException(409, "All planned sessions are already scheduled")
    _check_session(db, t, data.session_date, data.start_time, data.end_time)
    s = TrainingSession(training_id=t.id, **data.model_dump())
    db.add(s)
    db.flush()
    audit(db, user, "SESSION_SCHEDULED", "session", s.id, training_id=t.id)
    _tell_other(db, user, t, "SESSION_SCHEDULED", session=s.title, when=f"{s.session_date} {_t(s.start_time)}")
    db.commit()
    return session_out(s)


def update_session(db: Session, user: User, sid: int, data: SessionUpdateIn) -> dict:
    s, t, _ = _get_session(db, user, sid)
    _require_active(t)
    if s.status != "SCHEDULED":
        raise HTTPException(409, "Only a scheduled session can be changed")
    changes = data.model_dump(exclude_unset=True)
    new = {**{k: getattr(s, k) for k in ("title", "session_date", "start_time", "end_time")}, **changes}
    moved = any(k in changes and changes[k] != getattr(s, k) for k in ("session_date", "start_time", "end_time"))
    _check_session(db, t, new["session_date"], new["start_time"], new["end_time"], exclude_id=s.id, check_past=moved)
    old_date = s.session_date
    for k, v in new.items():
        setattr(s, k, v)
    audit(db, user, "SESSION_RESCHEDULED", "session", s.id, old_date=str(old_date), new_date=str(s.session_date))
    _tell_other(db, user, t, "SESSION_RESCHEDULED", session=s.title, when=f"{s.session_date} {_t(s.start_time)}")
    db.commit()
    return session_out(s)


def set_session_status(db: Session, user: User, sid: int, status: str) -> dict:
    s, t, role = _get_session(db, user, sid)
    _require_active(t)
    if status not in SESSION_MOVES.get(s.status, set()):
        raise HTTPException(409, f"Cannot move a {s.status.lower()} session to {status.lower()}")
    if status in ("ONGOING", "COMPLETED"):
        if role != "TRAINER":
            raise HTTPException(403, "Only the trainer can start or complete a session")
        if not _started(s):
            raise HTTPException(409, f"This session starts at {_t(s.start_time)} on {s.session_date}")
    if status == "CANCELLED" and s.attendance:
        raise HTTPException(409, "A session with recorded attendance has happened and cannot be cancelled")
    s.status = status
    audit(db, user, f"SESSION_{status}", "session", s.id)
    if status == "CANCELLED":
        _tell_other(db, user, t, "SESSION_CANCELLED", session=s.title, when=f"{s.session_date}")
    db.commit()
    return session_out(s)


def record_attendance(db: Session, user: User, sid: int, data: AttendanceIn) -> dict:
    s, t, role = _get_session(db, user, sid)
    if role != "TRAINER":
        raise HTTPException(403, "Only the trainer records attendance")
    _require_active(t)  # completed and cancelled trainings are read-only
    if s.status == "CANCELLED":
        raise HTTPException(409, "Attendance cannot be recorded for a cancelled session")
    if not _started(s):
        raise HTTPException(409, f"Attendance can be recorded once the session starts ({_t(s.start_time)} on {s.session_date})")
    if data.total_students > t.student_count or data.present + data.absent > t.student_count:
        raise HTTPException(422, f"Attendance cannot exceed the {t.student_count} students in this training")
    a = s.attendance or Attendance(session_id=s.id)
    a.total_students, a.present, a.absent = data.total_students, data.present, data.absent
    a.recorded_at = datetime.now(timezone.utc)
    s.attendance = a
    audit(db, user, "ATTENDANCE_RECORDED", "session", s.id, present=data.present, total=data.total_students)
    db.commit()
    return session_out(s)


def update_notes(db: Session, user: User, sid: int, notes: str | None) -> dict:
    """Session notes belong to the session and are written by the trainer, like attendance."""
    s, t, role = _get_session(db, user, sid)
    if role != "TRAINER":
        raise HTTPException(403, "Only the trainer writes session notes")
    _require_active(t)
    if s.status == "CANCELLED":
        raise HTTPException(409, "A cancelled session has no notes")
    s.notes = (notes or "").strip() or None
    audit(db, user, "SESSION_NOTES_UPDATED", "session", s.id)
    db.commit()
    return session_out(s)


def update_dates(db: Session, user: User, tid: int, data: TrainingDatesIn) -> dict:
    t, role = get_training(db, user, tid)
    if role != "INSTITUTION":
        raise HTTPException(403, "Only the institution can reschedule the training")
    _require_active(t)
    d = today()
    if t.start_date <= d and data.start_date != t.start_date:
        raise HTTPException(409, "The start date cannot be changed once the training has started")
    if t.start_date > d and data.start_date < d:
        raise HTTPException(422, "The start date cannot be in the past")
    outside = [s for s in t.sessions if s.status != "CANCELLED" and not (data.start_date <= s.session_date <= data.end_date)]
    if outside:
        raise HTTPException(409, "Some scheduled sessions fall outside the new dates. Move or cancel them first")
    old = (str(t.start_date), str(t.end_date))
    t.start_date, t.end_date = data.start_date, data.end_date
    t.hiring_request.start_date, t.hiring_request.end_date = data.start_date, data.end_date
    audit(db, user, "TRAINING_RESCHEDULED", "training", t.id, old=old, new=(str(data.start_date), str(data.end_date)))
    notify_event(db, t.trainer.user_id, "TRAINING_DATES_CHANGED", training_id=t.id, title=t.title, start=str(data.start_date), end=str(data.end_date))
    db.commit()
    return training_out(t, role)


def update_details(db: Session, user: User, tid: int, meeting_link: str | None) -> dict:
    """Online details. Either party may set the meeting link while the training is active."""
    t, role = get_training(db, user, tid)
    _require_active(t)
    if meeting_link and t.mode == "OFFLINE":
        raise HTTPException(422, "An offline training has no meeting link")
    previous, t.meeting_link = t.meeting_link, meeting_link or None
    audit(db, user, "TRAINING_DETAILS_UPDATED", "training", t.id, meeting_link_set=bool(meeting_link))
    if (meeting_link or None) != previous:  # only a real change is news; the message never contains the link itself
        _tell_other(db, user, t, "TRAINING_LINK_CHANGED", action="added" if not previous else ("removed" if not meeting_link else "updated"))
    db.commit()
    return training_out(t, role)


def update_planned_sessions(db: Session, user: User, tid: int, planned: int) -> dict:
    t, role = get_training(db, user, tid)
    if role != "INSTITUTION":
        raise HTTPException(403, "Only the institution can change the planned number of sessions")
    _require_active(t)
    live = len([s for s in t.sessions if s.status != "CANCELLED"])
    if planned < live:
        raise HTTPException(409, f"Cannot be lower than the {live} sessions already scheduled")
    old, t.planned_sessions = t.planned_sessions, planned
    audit(db, user, "PLANNED_SESSIONS_CHANGED", "training", t.id, old=old, new=planned)
    db.commit()
    return training_out(t, role)


def _close_out_sessions(t: Training, completing: bool) -> None:
    """Applies a training's end (completion or cancellation) to its sessions without destroying history.
    - a session that already started and has attendance happened: it becomes COMPLETED and stays in progress and averages
    - a session that has not started yet never happens: CANCELLED
    - an ONGOING session without attendance: COMPLETED when the training completes, CANCELLED when it is cancelled
    - a past SCHEDULED session without attendance is left exactly as it was (nothing proves it did or did not happen)"""
    for s in t.sessions:
        if s.status in ("COMPLETED", "CANCELLED"):
            continue
        started = _started(s)
        if s.attendance and started:
            s.status = "COMPLETED"
        elif not started:
            s.status = "CANCELLED"
        elif s.status == "ONGOING":
            s.status = "COMPLETED" if completing else "CANCELLED"


def complete(db: Session, user: User, tid: int) -> dict:
    t, role = get_training(db, user, tid)
    if role != "INSTITUTION":
        raise HTTPException(403, "Only the institution can complete the training")
    db.refresh(t, with_for_update=True)  # lock + re-read: a concurrent complete/cancel must not both pass the check below (money depends on the outcome, Phase 13)
    _require_active(t)
    if t.start_date > today():
        raise HTTPException(409, "This training has not started yet. Change its dates or cancel it instead")
    _close_out_sessions(t, completing=True)
    t.status, t.completed_at = "COMPLETED", datetime.now(timezone.utc)
    t.hiring_request.status = "COMPLETED"
    audit(db, user, "TRAINING_COMPLETED", "training", t.id, early=today() < t.end_date)
    from app.services.payment_service import on_training_completed  # lazy: payment_service imports this module
    on_training_completed(db, t)  # releases the trainer's earnings (Phase 13), in this same transaction
    # notify_event_safe: completion releases the trainer's earnings in this same transaction, so a notification failure must not undo it
    notify_event_safe(db, t.trainer.user_id, "TRAINING_COMPLETED", training_id=t.id, title=t.title)
    for uid in (t.trainer.user_id, t.institution.user_id):
        notify_event_safe(db, uid, "REVIEW_REQUEST", dedupe_key=f"review-request:{t.id}:{uid}", training_id=t.id, title=t.title)
    db.commit()
    return training_out(t, role)


def cancel(db: Session, user: User, tid: int, reason: str | None) -> dict:
    t, role = get_training(db, user, tid)
    db.refresh(t, with_for_update=True)  # lock + re-read: see complete()
    _require_active(t)
    not_started = t.start_date > today()
    _close_out_sessions(t, completing=False)
    t.status, t.cancel_reason = "CANCELLED", reason
    if not_started:  # cancelled before it began: the requirement goes back to hiring. A training that already started never reopens it.
        req = db.get(TrainingRequirement, t.requirement_id, with_for_update=True, populate_existing=True)
        if req is not None and req.status == "FILLED":  # a manually CLOSED requirement stays closed
            req.status = "OPEN"
            audit(db, user, "REQUIREMENT_REOPENED", "requirement", req.id, training_id=t.id)
            from app.services.application_service import notify_waiting_applicants  # lazy import: application_service imports this module lazily too
            key = f"requirement-reopened:{req.id}:{t.id}"
            notify_waiting_applicants(db, req, "REQUIREMENT_REOPENED", key)
            if role == "TRAINER":  # the institution cancelled it itself otherwise, so it already knows
                notify_event(db, req.institution.user_id, "REQUIREMENT_REOPENED", dedupe_key=key, link=f"/institution/requirements/{req.id}/applications",
                             requirement=req.title, requirement_id=req.id)
    t.hiring_request.status = "CANCELLED"
    audit(db, user, "TRAINING_CANCELLED", "training", t.id, by=role, reason=reason)
    from app.services.payment_service import on_training_cancelled  # lazy: payment_service imports this module
    on_training_cancelled(db, t, user)  # cancels unstarted payments and flags received money for review (Phase 13)
    _tell_other(db, user, t, "TRAINING_CANCELLED", reason=(f": {reason}" if reason else ""))
    db.commit()
    return training_out(t, role)
