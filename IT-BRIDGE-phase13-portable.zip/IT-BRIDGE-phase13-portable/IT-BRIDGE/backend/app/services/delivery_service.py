"""External delivery outbox. `enqueue` runs inside the business transaction; `process_pending` runs in a worker, never in a request."""
import logging
from datetime import datetime, timedelta, timezone

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.config import settings
from app.models.notification import NotificationDelivery
from app.models.user import User
from app.services import notification_preferences
from app.services.channels import get_email_provider, redact

log = logging.getLogger("itbridge.notifications")


def _now() -> datetime:
    return datetime.now(timezone.utc)


def enqueue(db: Session, user_id: int, channel: str, type_: str, title: str, body: str | None, link: str | None,
            dedupe_key: str | None = None) -> NotificationDelivery:
    d = NotificationDelivery(user_id=user_id, channel=channel, type=type_, title=title[:160], body=(body or None) and body[:500], link=link,
                             dedupe_key=dedupe_key, status="PENDING", attempts=0, next_attempt_at=_now())
    db.add(d)
    return d


# ---- pure decisions (no database), so they can be tested anywhere ----
def skip_reason(*, active: bool, has_email: bool, verified: bool, email_enabled: bool) -> str | None:
    """Why a queued email must not be attempted, or None if it may be. Checked at send time, so a preference change or a
    deactivation after queueing is honoured."""
    if not active:
        return "account is not active"
    if not email_enabled:
        return "email notifications are switched off"
    if not has_email:
        return "no email address"
    if not verified:
        return "email address is not verified"
    return None


def retry_state(attempts: int, now: datetime, max_attempts: int, base_seconds: int) -> tuple[str, datetime | None]:
    """State after a failed attempt (attempts already includes it): retry with exponential backoff, or give up."""
    if attempts >= max_attempts:
        return "FAILED", None
    return "PENDING", now + timedelta(seconds=base_seconds * 2 ** (attempts - 1))


def message_body(d: NotificationDelivery) -> str:
    parts = [d.body] if d.body else []
    if d.link:
        parts.append(f"Open: {settings.frontend_url.rstrip('/')}{d.link}")
    return "\n\n".join(parts) or d.title


def process_pending(db: Session, now: datetime | None = None, limit: int = 50) -> dict[str, int]:
    """Sends due PENDING rows once each. Safe to run repeatedly and concurrently: only PENDING rows are picked, rows are locked
    with SKIP LOCKED where the database supports it, and every status change is committed together."""
    now = now or _now()
    counts = {"sent": 0, "skipped": 0, "retry": 0, "failed": 0}
    provider = get_email_provider()  # a mis-configured provider is an operator error: fail loudly, do not burn attempts
    rows = list(db.scalars(select(NotificationDelivery).where(NotificationDelivery.status == "PENDING", NotificationDelivery.next_attempt_at <= now)
                           .order_by(NotificationDelivery.id).limit(limit).with_for_update(skip_locked=True)))
    for d in rows:
        user = db.get(User, d.user_id)
        reason = skip_reason(active=bool(user and user.is_active), has_email=bool(user and user.email), verified=bool(user and user.email_verified),
                             email_enabled=notification_preferences.get(db, d.user_id)["email"])
        if reason:
            d.status, d.last_error = "SKIPPED", reason
            counts["skipped"] += 1
            continue
        try:
            provider.send(user.email, d.title, message_body(d), idempotency_key=f"delivery-{d.id}")
        except Exception as e:  # any provider failure is retried; it must never escape and stop the other rows
            d.attempts += 1
            d.last_error = redact(f"{type(e).__name__}: {e}")[:200]
            d.status, d.next_attempt_at = retry_state(d.attempts, now, settings.notification_max_attempts, settings.notification_retry_base_seconds)
            d.next_attempt_at = d.next_attempt_at or now
            counts["failed" if d.status == "FAILED" else "retry"] += 1
            log.warning("delivery %s attempt %s failed: %s", d.id, d.attempts, d.last_error)
        else:
            d.attempts += 1
            d.status, d.sent_at, d.last_error = "SENT", now, None
            counts["sent"] += 1
    db.commit()
    return counts
