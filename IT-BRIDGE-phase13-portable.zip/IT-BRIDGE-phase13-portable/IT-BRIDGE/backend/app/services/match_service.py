
from fastapi import HTTPException
from app.core.clock import today
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models.matching import MatchScore, PlatformSetting, TrainerBusyPeriod
from app.models.requirement import TrainingRequirement
from app.models.user import Skill, TrainerProfile, User
from app.schemas.profile import SkillOut
from app.services import review_service
from app.services.matching import DEFAULT_WEIGHTS, compute_match

WEIGHTS_KEY = "matching_weights"
ELIGIBLE_STATUSES = ("PENDING", "VERIFIED")  # REJECTED and SUSPENDED trainers are never recommended


def get_weights(db: Session) -> dict:
    row = db.get(PlatformSetting, WEIGHTS_KEY)
    return {**DEFAULT_WEIGHTS, **(row.value if row else {})}


def set_weights(db: Session, weights: dict) -> dict:
    if set(weights) != set(DEFAULT_WEIGHTS):
        raise HTTPException(422, f"Provide exactly these weights: {', '.join(DEFAULT_WEIGHTS)}")
    if any(not isinstance(v, int) or v < 0 for v in weights.values()):
        raise HTTPException(422, "Weights must be whole numbers, 0 or more")
    if sum(weights.values()) != 100:
        raise HTTPException(422, f"Weights must add up to 100 (currently {sum(weights.values())})")
    row = db.get(PlatformSetting, WEIGHTS_KEY)
    if row:
        row.value = weights
    else:
        db.add(PlatformSetting(key=WEIGHTS_KEY, value=weights))
    db.commit()
    return weights


def busy_map(db: Session, trainer_ids: list[int]) -> dict[int, list]:
    """Manual unavailable dates plus the dates of the trainer's active trainings."""
    from app.models.training import Training
    out: dict[int, list] = {i: [] for i in trainer_ids}
    if trainer_ids:
        for b in db.scalars(select(TrainerBusyPeriod).where(TrainerBusyPeriod.trainer_id.in_(trainer_ids))):
            out[b.trainer_id].append(b)
        for t in db.scalars(select(Training).where(Training.trainer_id.in_(trainer_ids), Training.status == "ACTIVE")):
            out[t.trainer_id].append(t)  # exposes start_date / end_date like a busy period
    return out


def _store(db: Session, req_id: int, trainer_id: int, result: dict, weights: dict):
    row = db.scalar(select(MatchScore).where(MatchScore.requirement_id == req_id, MatchScore.trainer_id == trainer_id))
    if row:
        row.score, row.factors, row.weights = result["score"], result["factors"], weights
    else:
        db.add(MatchScore(requirement_id=req_id, trainer_id=trainer_id, score=result["score"],
                          factors=result["factors"], weights=weights))


def trainer_card(p: TrainerProfile, stats: dict | None = None) -> dict:
    stats = stats or {"rating": None, "review_count": 0, "completed_trainings": 0}
    return {**stats, "id": p.id, "full_name": p.user.full_name, "headline": p.headline, "location": p.location,
            "experience_years": p.experience_years, "training_mode": p.training_mode, "expected_fee": p.expected_fee,
            "skills": [SkillOut.model_validate(s).model_dump() for s in p.skills],
            "languages": p.languages or [], "verified": p.verification_status == "VERIFIED"}


def matches_for_requirement(db: Session, institution_user: User, req_id: int, limit: int = 20, min_score: int = 1) -> dict:
    req = db.get(TrainingRequirement, req_id)
    if not req or req.institution.user_id != institution_user.id:
        raise HTTPException(404, "Requirement not found")
    weights = get_weights(db)
    skill_ids = [s.id for s in req.skills]
    candidates = list(db.scalars(
        select(TrainerProfile).join(User, User.id == TrainerProfile.user_id)
        .where(User.is_active.is_(True), TrainerProfile.verification_status.in_(ELIGIBLE_STATUSES),
               TrainerProfile.headline.is_not(None), TrainerProfile.skills.any(Skill.id.in_(skill_ids)))))
    busy = busy_map(db, [c.id for c in candidates])
    stats = review_service.trainer_stats(db, [c.id for c in candidates])
    ranked = []
    for c in candidates:
        result = compute_match(req, c, busy[c.id], weights)
        _store(db, req.id, c.id, result, weights)
        if result["score"] >= min_score:
            ranked.append({**trainer_card(c, stats[c.id]), **result})
    db.commit()
    ranked.sort(key=lambda x: (-x["score"], -(x["experience_years"] or 0), x["id"]))
    return {"requirement_id": req.id, "weights": weights, "matches": ranked[:limit], "total": len(ranked)}


def recommendations_for_trainer(db: Session, trainer_user: User, limit: int = 10) -> list[dict]:
    p = trainer_user.trainer_profile
    skill_ids = [s.id for s in p.skills]
    if not skill_ids:
        return []
    weights = get_weights(db)
    reqs = list(db.scalars(
        select(TrainingRequirement).where(TrainingRequirement.status == "OPEN",
                                          TrainingRequirement.application_deadline >= today(),
                                          TrainingRequirement.skills.any(Skill.id.in_(skill_ids)))
        .order_by(TrainingRequirement.created_at.desc()).limit(200)))
    busy = busy_map(db, [p.id])[p.id]
    out = []
    for r in reqs:
        result = compute_match(r, p, busy, weights)
        out.append({"requirement_id": r.id, "title": r.title, "institution_name": r.institution.institution_name,
                    "location": r.location, "mode": r.mode, "start_date": str(r.start_date), **result})
    out.sort(key=lambda x: -x["score"])
    return out[:limit]
