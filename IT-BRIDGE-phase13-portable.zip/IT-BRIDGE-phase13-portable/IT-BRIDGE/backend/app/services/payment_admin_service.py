"""Administrator operations on money (Phase 13): a full refund, recording that a trainer payout was made, and resolving a review flag.
Deliberately small: there is no admin dashboard, no partial refund and no bank/UPI handling. Every operation is authorized on the backend
(the routes require the ADMIN role) and writes an audit row.

REFUND, IN TWO PHASES (the external provider is never called while a database lock is held, and a crash between the phases is recoverable):
  A. under the training -> payment -> earning locks: validate (payment_rules.refund_action), insert a PENDING `payment_refunds` row (unique per
     payment, with a fixed idempotency key `refund-<payment id>`) and COMMIT. A second or concurrent request finds that row and resumes it,
     so a refund can never be started twice.
  B. no locks: call the provider with that idempotency key. On success re-take the locks and, in ONE transaction, record the REFUND transaction,
     allocate the credit-note number, mark the refund SUCCEEDED, the earning REFUNDED, the commission REVERSED, and notify. On a provider error the
     refund stays PENDING (attempts and last_error recorded); the worker retries it, and after MAX_REFUND_ATTEMPTS the payment is flagged for review.
  Because the provider call is idempotent per key, repeating phase B after a crash cannot refund twice.
"""
import logging
from datetime import timedelta

from fastapi import HTTPException
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.models.payment import Payment, PaymentRefund, PaymentTransaction, PlatformCommission, TrainerEarning
from app.models.training import Training
from app.models.user import TrainerProfile, User
from app.services import invoice_service, payment_providers as providers, payment_rules as rules
from app.services.audit import audit
from app.services.notification_service import notify_event_safe
from app.services.payment_service import (PaymentError, flag_for_review, iso, lock_payment, lock_training, open_flags, payments_out, refuse, sync_review_state,
                                          trainer_user_id, utcnow)

log = logging.getLogger("itbridge.payments.admin")
MAX_REFUND_ATTEMPTS = 5
RETRY_AFTER = timedelta(minutes=1)


def refund_out(r: PaymentRefund) -> dict:
    return {"id": r.id, "payment_id": r.payment_id, "amount_paise": r.amount_paise, "currency": rules.CURRENCY, "status": r.status, "reason": r.reason,
            "credit_note_number": r.credit_note_number, "attempts": r.attempts, "last_error": r.last_error, "created_at": iso(r.created_at),
            "completed_at": iso(r.completed_at)}


# ---------- refund ----------
def request_refund(db: Session, admin: User, pid: int, reason: str | None) -> tuple[dict, bool]:
    """Starts (or resumes, or reports) the full refund of one payment. Returns (refund, completed)."""
    p0 = db.get(Payment, pid)
    if p0 is None:
        raise HTTPException(404, "Payment not found")
    lock_training(db, p0.training_id)
    p = lock_payment(db, pid)
    refund = db.scalar(select(PaymentRefund).where(PaymentRefund.payment_id == pid))
    earning = db.scalar(select(TrainerEarning).where(TrainerEarning.payment_id == pid).with_for_update())
    action, bad = rules.refund_action(p.status, refund.status if refund else None, earning.status if earning else None)
    if action == "refuse":
        refuse(bad)
    if action == "done":
        db.rollback()
        return refund_out(refund), True
    if action == "create":
        refund = PaymentRefund(payment_id=p.id, amount_paise=p.amount_paise, reason=(reason or "").strip()[:300] or None, status=rules.R_PENDING,
                               idempotency_key=f"refund-{p.id}", attempts=0, created_by=admin.id)
        db.add(refund)
        audit(db, admin, "REFUND_REQUESTED", "payment", p.id, amount_paise=p.amount_paise, reason=refund.reason)
        db.flush()
        refund_id = refund.id
        db.commit()
    else:
        rid = refund.id
        db.rollback()
        refund_id = rid
    refund = complete_refund(db, refund_id, actor=admin)
    return refund, refund["status"] == rules.R_SUCCEEDED


def _refund_failed(db: Session, refund_id: int, message: str) -> None:
    r0 = db.get(PaymentRefund, refund_id)
    if r0 is None:
        return
    p0 = db.get(Payment, r0.payment_id)
    lock_training(db, p0.training_id)                             # the same lock order as every other money path: training, payment, then the rest
    p = lock_payment(db, p0.id)
    r = db.get(PaymentRefund, refund_id, with_for_update=True, populate_existing=True)
    if r.status == rules.R_SUCCEEDED:
        db.rollback()
        return
    r.attempts += 1
    r.last_error = message[:200]
    audit(db, None, "REFUND_ATTEMPT_FAILED", "payment", r.payment_id, attempt=r.attempts)
    if r.attempts >= MAX_REFUND_ATTEMPTS:
        flag_for_review(db, p, db.get(Training, p.training_id), rules.REFUND_STUCK, note=f"refund {r.id} failed {r.attempts} times")
    db.commit()


def complete_refund(db: Session, refund_id: int, actor: User | None = None) -> dict:
    """Phase B. Safe to call any number of times, from the request or from the worker."""
    r = db.get(PaymentRefund, refund_id)
    if r is None:
        raise HTTPException(404, "Refund not found")
    if r.status == rules.R_SUCCEEDED:
        return refund_out(r)
    p = db.get(Payment, r.payment_id)
    charge = db.scalar(select(PaymentTransaction.provider_txn_id).where(PaymentTransaction.payment_id == p.id, PaymentTransaction.type == rules.TXN_CHARGE))
    amount, key, provider_name, payment_id, training_id = r.amount_paise, r.idempotency_key, p.provider, p.id, p.training_id
    db.rollback()                                                 # no transaction and no lock is open while the provider is called
    try:
        if charge is None:
            raise providers.ProviderError("no charge transaction is recorded for this payment")
        result = providers.get_provider(provider_name).refund(txn_id=charge, amount_paise=amount, idempotency_key=key)
    except providers.ProviderError as e:
        _refund_failed(db, refund_id, str(e))
        raise PaymentError(502, "REFUND_PENDING", "The provider did not confirm the refund yet. It stays pending and will be retried")
    lock_training(db, training_id)
    p = lock_payment(db, payment_id)
    r = db.get(PaymentRefund, refund_id, with_for_update=True, populate_existing=True)
    if r.status == rules.R_SUCCEEDED:                             # a concurrent completion won
        db.rollback()
        return refund_out(r)
    earning = db.scalar(select(TrainerEarning).where(TrainerEarning.payment_id == payment_id).with_for_update())
    now = utcnow()
    db.add(PaymentTransaction(payment_id=payment_id, type=rules.TXN_REFUND, amount_paise=amount, provider=provider_name, provider_txn_id=result.refund_id))
    db.flush()                                                    # a DML statement must precede the SAVEPOINT used by credit-note numbering
    r.credit_note_number = invoice_service.next_credit_note_number(db)
    r.status, r.completed_at, r.last_error, r.attempts = rules.R_SUCCEEDED, now, None, r.attempts + 1
    t = db.get(Training, training_id)
    if earning is not None:
        if rules.can_transition_earning(earning.status, rules.E_REFUNDED):
            earning.status = rules.E_REFUNDED
        else:                                                     # a payout was recorded before the refund (the locks make this unreachable): keep both facts
            log.error("refund %s completed but earning %s is %s", r.id, earning.id, earning.status)
            flag_for_review(db, p, t, rules.REFUND_STUCK, note=f"refund completed but the trainer payout ({earning.status}) was already recorded")
    commission = db.scalar(select(PlatformCommission).where(PlatformCommission.payment_id == payment_id))
    if commission is not None and commission.status == rules.C_RECORDED:
        commission.status, commission.reversed_at = rules.C_REVERSED, now
    audit(db, actor, "REFUND_COMPLETED", "payment", payment_id, refund_id=r.id, credit_note=r.credit_note_number, amount_paise=amount)
    amount_text = rules.format_inr(amount)
    notify_event_safe(db, p.payer_user_id, "PAYMENT_REFUNDED", dedupe_key=f"payment-refunded:{payment_id}:{p.payer_user_id}", amount=amount_text, title=t.title, training_id=t.id)
    if earning is not None:
        tuid = trainer_user_id(db, p.trainer_id)
        notify_event_safe(db, tuid, "PAYMENT_REFUNDED", dedupe_key=f"payment-refunded:{payment_id}:{tuid}", link="/trainer/earnings",
                          amount=rules.format_inr(earning.net_paise), title=t.title, training_id=t.id)
    db.commit()
    return refund_out(r)


def retry_pending_refunds(db: Session) -> int:
    """Worker: finishes refunds that were started but not completed (a crash between the phases, or a provider outage)."""
    cutoff = utcnow() - RETRY_AFTER
    ids = db.scalars(select(PaymentRefund.id).where(PaymentRefund.status == rules.R_PENDING, PaymentRefund.attempts < MAX_REFUND_ATTEMPTS,
                                                    PaymentRefund.created_at <= cutoff).order_by(PaymentRefund.id).limit(50)).all()
    done = 0
    for rid in ids:
        try:
            done += complete_refund(db, rid)["status"] == rules.R_SUCCEEDED
        except PaymentError:
            pass                                                  # recorded on the refund row by _refund_failed
        except Exception:
            db.rollback()
            log.exception("refund %s could not be completed", rid)
    return done


# ---------- payout ----------
def record_payout(db: Session, admin: User, earning_id: int, reference: str) -> dict:
    """Records that an AVAILABLE trainer earning was paid out outside IT BRIDGE. Nothing is sent anywhere and no bank or UPI detail is stored."""
    try:
        ref = rules.clean_payout_reference(reference)
    except ValueError as e:
        raise PaymentError(422, "INVALID_REFERENCE", str(e))
    e0 = db.get(TrainerEarning, earning_id)
    if e0 is None:
        raise HTTPException(404, "Earning not found")
    p = lock_payment(db, e0.payment_id)                           # payment first, then the earning: the same order as the refund path
    e = db.get(TrainerEarning, earning_id, with_for_update=True, populate_existing=True)
    refund_status = db.scalar(select(PaymentRefund.status).where(PaymentRefund.payment_id == p.id))
    bad = rules.payout_refusal(e.status, refund_status, bool(p.needs_review))
    if bad:
        refuse(bad)
    e.status, e.paid_at, e.paid_by, e.payout_reference = rules.E_PAID, utcnow(), admin.id, ref
    audit(db, admin, "PAYOUT_RECORDED", "earning", e.id, payment_id=p.id, net_paise=e.net_paise, reference=ref)
    t = db.get(Training, e.training_id)
    tuid = trainer_user_id(db, e.trainer_id)
    notify_event_safe(db, tuid, "PAYOUT_RECORDED", dedupe_key=f"payout-recorded:{e.id}", amount=rules.format_inr(e.net_paise), title=t.title, training_id=t.id)
    db.commit()
    return admin_earnings_out(db, [e])[0]


def resolve_review(db: Session, admin: User, pid: int, note: str, reason: str | None = None) -> dict:
    """Resolves ONE open review flag of a payment. A payment can carry several different open flags (rules.pick_flag): with more than one open
    the reason must be named, and resolving one never closes another. The payment leaves the review queue only when its last flag is resolved.
    An over-cap flag cannot be closed before the payment is refunded (rules.resolve_refusal)."""
    p0 = db.get(Payment, pid)
    if p0 is None:
        raise HTTPException(404, "Payment not found")
    lock_training(db, p0.training_id)
    p = lock_payment(db, pid)
    flags = open_flags(db, p.id)
    picked, bad = rules.pick_flag([f.reason for f in flags], reason)
    if bad:
        raise PaymentError(bad.status, bad.code, bad.message)
    refund_status = db.scalar(select(PaymentRefund.status).where(PaymentRefund.payment_id == p.id))
    refusal = rules.resolve_refusal(picked, p.status, refund_status)
    if refusal:
        raise PaymentError(refusal.status, refusal.code, refusal.message)
    flag = next(f for f in flags if f.reason == picked)
    now, text = utcnow(), note.strip()[:500]
    flag.resolved_at, flag.resolved_by, flag.resolution_note = now, admin.id, text
    still_open = [f.reason for f in flags if f.reason != picked]
    if not still_open:                                                       # the payment-level fields describe the LAST resolution and are set when the queue empties;
        p.review_note, p.reviewed_by, p.reviewed_at = text, admin.id, now    # per-flag detail (who, when, why) is always in review_flags / review_history
    db.flush()
    sync_review_state(db, p)
    audit(db, admin, "PAYMENT_REVIEW_RESOLVED", "payment", p.id, reason=picked, note=text, flag_id=flag.id, still_open=still_open)
    db.commit()
    return payments_out(db, [p], admin=True)[0]


# ---------- admin read models ----------
def admin_earnings_out(db: Session, rows: list[TrainerEarning]) -> list[dict]:
    rows = list(rows)
    if not rows:
        return []
    tids = list({e.training_id for e in rows})
    names = dict(db.execute(select(TrainerProfile.id, User.full_name).join(User, User.id == TrainerProfile.user_id).where(TrainerProfile.id.in_(list({e.trainer_id for e in rows})))).all())
    titles = dict(db.execute(select(Training.id, Training.title).where(Training.id.in_(tids))).all())
    pay = {p.id: p for p in db.scalars(select(Payment).where(Payment.id.in_([e.payment_id for e in rows])))}
    return [{"id": e.id, "payment_id": e.payment_id, "trainer_id": e.trainer_id, "trainer_name": names.get(e.trainer_id), "training_id": e.training_id,
             "training_title": titles.get(e.training_id), "gross_paise": e.gross_paise, "commission_paise": e.commission_paise, "net_paise": e.net_paise,
             "status": e.status, "available_at": iso(e.available_at), "paid_at": iso(e.paid_at), "paid_by": e.paid_by, "payout_reference": e.payout_reference,
             "payment_under_review": bool(pay[e.payment_id].needs_review)} for e in rows]


def list_payments(db: Session, page: int, page_size: int, status: str | None, needs_review: bool | None) -> dict:
    stmt = select(Payment)
    if status:
        stmt = stmt.where(Payment.status == status)
    if needs_review is not None:
        stmt = stmt.where(Payment.needs_review.is_(needs_review))
    total = db.scalar(select(func.count()).select_from(stmt.subquery()))
    rows = db.scalars(stmt.order_by(Payment.created_at.desc(), Payment.id.desc()).offset((page - 1) * page_size).limit(page_size)).all()
    return {"items": payments_out(db, rows, admin=True), "total": total, "page": page, "page_size": page_size}


def list_earnings(db: Session, page: int, page_size: int, status: str | None) -> dict:
    stmt = select(TrainerEarning)
    if status:
        stmt = stmt.where(TrainerEarning.status == status)
    total = db.scalar(select(func.count()).select_from(stmt.subquery()))
    rows = db.scalars(stmt.order_by(TrainerEarning.created_at.desc(), TrainerEarning.id.desc()).offset((page - 1) * page_size).limit(page_size)).all()
    return {"items": admin_earnings_out(db, rows), "total": total, "page": page, "page_size": page_size}
