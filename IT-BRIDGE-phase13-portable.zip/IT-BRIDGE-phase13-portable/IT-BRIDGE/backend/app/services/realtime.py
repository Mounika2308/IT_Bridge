"""In-process WebSocket fan-out. stdlib only.

Sync request handlers run in worker threads, so pushes go through loop.call_soon_threadsafe.
For several API processes, swap this for a Redis pub/sub broadcaster with the same two methods (Phase 18).
"""
import asyncio
import threading

MAX_CONNECTIONS_PER_USER = 5
CLOSE = {"__close__": True}  # sentinel: tells a connection to close itself (e.g. the account was deactivated)


class ConnectionManager:
    def __init__(self):
        self._conns: dict[int, list[tuple[asyncio.AbstractEventLoop, asyncio.Queue]]] = {}
        self._lock = threading.Lock()

    async def connect(self, user_id: int) -> asyncio.Queue | None:
        loop, q = asyncio.get_running_loop(), asyncio.Queue(maxsize=100)
        with self._lock:
            conns = self._conns.setdefault(user_id, [])
            if len(conns) >= MAX_CONNECTIONS_PER_USER:
                return None
            conns.append((loop, q))
        return q

    def disconnect(self, user_id: int, q: asyncio.Queue) -> None:
        with self._lock:
            self._conns[user_id] = [c for c in self._conns.get(user_id, []) if c[1] is not q]
            if not self._conns[user_id]:
                del self._conns[user_id]

    def push(self, user_id: int, payload: dict) -> None:
        with self._lock:
            targets = list(self._conns.get(user_id, []))
        for loop, q in targets:
            try:
                loop.call_soon_threadsafe(self._offer, q, payload)
            except RuntimeError:  # loop already closed
                pass

    def disconnect_user(self, user_id: int) -> None:
        """Asks every open connection of this user to close. Safe to call from any thread."""
        with self._lock:
            targets = list(self._conns.get(user_id, []))
        for loop, q in targets:
            try:
                loop.call_soon_threadsafe(self._offer_close, q)
            except RuntimeError:
                pass

    @staticmethod
    def _offer_close(q: asyncio.Queue) -> None:
        while q.full():  # the close signal must get through even if the client stalled
            q.get_nowait()
        q.put_nowait(CLOSE)

    @staticmethod
    def _offer(q: asyncio.Queue, payload: dict) -> None:
        if not q.full():  # a stalled client must never block the API
            q.put_nowait(payload)

    def connection_count(self, user_id: int) -> int:
        with self._lock:
            return len(self._conns.get(user_id, []))


manager = ConnectionManager()
