from datetime import datetime, timezone

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models.notification import NotificationPreference
from app.models.user import User

CHANNELS = ("in_app", "email")  # add "sms" / "whatsapp" here when those providers exist; no schema change needed


def get(db: Session, user_id: int) -> dict[str, bool]:
    """Every channel is enabled unless the user switched it off."""
    rows = dict(db.execute(select(NotificationPreference.channel, NotificationPreference.enabled).where(NotificationPreference.user_id == user_id)).all())
    return {c: rows.get(c, True) for c in CHANNELS}


def update(db: Session, user: User, changes: dict[str, bool]) -> dict[str, bool]:
    for channel, enabled in changes.items():
        if channel not in CHANNELS:
            raise ValueError(f"unknown channel {channel}")
        row = db.scalar(select(NotificationPreference).where(NotificationPreference.user_id == user.id, NotificationPreference.channel == channel))
        if row:
            row.enabled, row.updated_at = enabled, datetime.now(timezone.utc)
        else:
            db.add(NotificationPreference(user_id=user.id, channel=channel, enabled=enabled))
    db.commit()
    return get(db, user.id)


def out(db: Session, user: User) -> dict:
    return {**get(db, user.id), "email_verified": bool(user.email_verified)}
