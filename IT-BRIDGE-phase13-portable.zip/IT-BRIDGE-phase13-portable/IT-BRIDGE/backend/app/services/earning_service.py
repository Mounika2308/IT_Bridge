"""Trainer earnings (Phase 13): what a trainer is owed for a successful payment, and when it becomes available.

PENDING   the institution has paid, the training is not completed yet
AVAILABLE the training is COMPLETED (and the configured hold, EARNING_HOLD_DAYS, which is 0 initially, has elapsed)
PAID      an administrator recorded that the payout was made (outside IT BRIDGE: no bank or UPI detail is stored here)
REFUNDED  the payment was refunded

A trainer sees only their own earnings. The commission shown is the DEVELOPMENT PLACEHOLDER rate unless PAYMENT_COMMISSION_CONFIRMED is set.
"""
from datetime import timedelta

from fastapi import HTTPException
from sqlalchemy import func, select, update
from sqlalchemy.orm import Session

from app.core.config import settings
from app.models.payment import Payment, PaymentRefund, TrainerEarning
from app.models.training import Training
from app.models.user import TrainerProfile, User
from app.services import payment_rules as rules
from app.services.audit import audit
from app.services.notification_service import notify_event_safe


def _my_trainer(user: User):
    if user.role != "TRAINER" or user.trainer_profile is None:
        raise HTTPException(403, "You do not have permission to do this")
    return user.trainer_profile


def earnings_out(db: Session, rows: list[TrainerEarning]) -> list[dict]:
    """Serialises a trainer's own earnings with batched lookups. Never includes the payer's identity or provider details."""
    rows = list(rows)
    if not rows:
        return []
    pids, tids = [e.payment_id for e in rows], list({e.training_id for e in rows})
    pay = {p.id: p for p in db.scalars(select(Payment).where(Payment.id.in_(pids)))}
    titles = dict(db.execute(select(Training.id, Training.title).where(Training.id.in_(tids))).all())
    return [{"id": e.id, "training_id": e.training_id, "training_title": titles.get(e.training_id), "gross_paise": e.gross_paise,
             "commission_paise": e.commission_paise, "net_paise": e.net_paise, "commission_bps": pay[e.payment_id].commission_bps, "currency": rules.CURRENCY,
             "status": e.status, "available_at": e.available_at.isoformat() if e.available_at else None, "paid_at": e.paid_at.isoformat() if e.paid_at else None,
             "payout_reference": e.payout_reference, "on_hold": bool(pay[e.payment_id].needs_review and e.status != rules.E_REFUNDED),
             "sandbox": pay[e.payment_id].provider in rules.SANDBOX_PROVIDERS, "created_at": e.created_at.isoformat()} for e in rows]


def for_training(db: Session, training_id: int, trainer_id: int) -> list[dict]:
    rows = db.scalars(select(TrainerEarning).where(TrainerEarning.training_id == training_id, TrainerEarning.trainer_id == trainer_id).order_by(TrainerEarning.id)).all()
    return earnings_out(db, rows)


def list_mine(db: Session, user: User, page: int, page_size: int, status: str | None) -> dict:
    tp = _my_trainer(user)
    stmt = select(TrainerEarning).where(TrainerEarning.trainer_id == tp.id)
    if status:
        stmt = stmt.where(TrainerEarning.status == status)
    total = db.scalar(select(func.count()).select_from(stmt.subquery()))
    rows = db.scalars(stmt.order_by(TrainerEarning.created_at.desc(), TrainerEarning.id.desc()).offset((page - 1) * page_size).limit(page_size)).all()
    return {"items": earnings_out(db, rows), "total": total, "page": page, "page_size": page_size}


def summary(db: Session, user: User) -> dict:
    from app.services.payment_service import payments_on, sandbox_enabled  # lazy: payment_service imports this module lazily too
    tp = _my_trainer(user)
    sums = {s: int(v) for s, v in db.execute(select(TrainerEarning.status, func.coalesce(func.sum(TrainerEarning.net_paise), 0))
                                              .where(TrainerEarning.trainer_id == tp.id).group_by(TrainerEarning.status)).all()}
    commission = db.scalar(select(func.coalesce(func.sum(TrainerEarning.commission_paise), 0)).where(TrainerEarning.trainer_id == tp.id, TrainerEarning.status != rules.E_REFUNDED)) or 0
    count = db.scalar(select(func.count()).select_from(TrainerEarning).where(TrainerEarning.trainer_id == tp.id)) or 0
    return {"pending_paise": sums.get(rules.E_PENDING, 0), "available_paise": sums.get(rules.E_AVAILABLE, 0), "paid_paise": sums.get(rules.E_PAID, 0),
            "refunded_paise": sums.get(rules.E_REFUNDED, 0), "commission_paise": int(commission), "count": count,
            "commission_rate_bps": settings.platform_commission_bps, "commission_is_placeholder": not settings.payment_commission_confirmed,
            "enabled": payments_on(), "sandbox": sandbox_enabled()}


def promote_available(db: Session, training_id: int | None = None, training: Training | None = None) -> int:
    """PENDING -> AVAILABLE for earnings of COMPLETED trainings whose hold has elapsed. Each change is a conditional UPDATE
    (... WHERE status = 'PENDING'), so it can neither run twice nor overwrite a refund that got there first. Never touches earnings with a refund.
    `training` is the in-memory (not yet flushed) completed training when called from training_service.complete."""
    from app.services.payment_service import aware, utcnow  # lazy: payment_service imports this module lazily too
    now = utcnow()
    stmt = select(TrainerEarning).where(TrainerEarning.status == rules.E_PENDING)
    if training is not None:
        stmt = stmt.where(TrainerEarning.training_id == training.id)
    else:
        stmt = stmt.join(Training, Training.id == TrainerEarning.training_id).where(Training.status == "COMPLETED", Training.completed_at.is_not(None))
        if training_id is not None:
            stmt = stmt.where(TrainerEarning.training_id == training_id)
    # Rows that can never be promoted now (a refund exists; the hold has certainly not elapsed) are filtered IN SQL, so they cannot fill the 500-row
    # window and starve the earnings behind them. The Python checks below stay the authority (the date pre-filter is deliberately a day lenient (it keeps a
    # superset) so a timezone quirk in the database can only keep a row, never wrongly drop it).
    stmt = stmt.where(~select(PaymentRefund.id).where(PaymentRefund.payment_id == TrainerEarning.payment_id).correlate(TrainerEarning).exists())
    if training is None:
        stmt = stmt.where(Training.completed_at <= now - timedelta(days=max(settings.earning_hold_days - 1, 0)))   # a day EARLIER than the hold: keeps a superset
    promoted = 0
    for e in db.scalars(stmt.order_by(TrainerEarning.id).limit(500)).all():
        t = training or db.get(Training, e.training_id)
        if t.status != "COMPLETED" or t.completed_at is None:
            continue
        if not rules.hold_elapsed((now - aware(t.completed_at)).total_seconds(), settings.earning_hold_days):
            continue
        if db.scalar(select(PaymentRefund.id).where(PaymentRefund.payment_id == e.payment_id)):
            continue
        done = db.execute(update(TrainerEarning).where(TrainerEarning.id == e.id, TrainerEarning.status == rules.E_PENDING)
                          .values(status=rules.E_AVAILABLE, available_at=now, updated_at=now).execution_options(synchronize_session="fetch"))
        if done.rowcount:
            promoted += 1
            audit(db, None, "EARNING_AVAILABLE", "earning", e.id, training_id=e.training_id)
            notify_event_safe(db, _trainer_user(db, e.trainer_id), "EARNING_AVAILABLE",
                              dedupe_key=f"earning-available:{e.id}", amount=rules.format_inr(e.net_paise), title=t.title, training_id=t.id)
    return promoted


def _trainer_user(db: Session, trainer_id: int) -> int:
    return db.scalar(select(TrainerProfile.user_id).where(TrainerProfile.id == trainer_id))
