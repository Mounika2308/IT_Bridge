"""Pure payment rules (Phase 13). No imports from the app, no database, no network: everything here is plain Python, so the
financial decisions can be tested anywhere. The services only read and write rows around these functions.

MONEY
  * Every amount is an integer number of paise (Rs 100 = 10000 paise). Floating point is never used for money.
  * The training's agreed fee is stored in whole rupees (Phase 9); fee_paise() converts it.
  * Platform commission is taken out of the trainer's share. The institution pays the agreed fee, nothing on top.
  * Commission rate is in basis points (1000 = 10%). The 10% default is a DEVELOPMENT PLACEHOLDER, not a business decision.
  * Rounding: half up, on integers: (amount * bps + 5000) // 10000. For instalments the commission of an instalment is
    commission_total(collected + amount) - commission_total(collected), so the instalments of one training always add up to
    exactly commission_total(fee) no matter how the fee is split, and the trainer's net never goes negative.
    The commission stored when an attempt is CREATED is only an estimate. The final figure is computed when the payment SUCCEEDS, from the
    money and commission already settled for the training at that moment (settle_commission), so late successes and refunds cannot make
    the total drift from commission_total(collected).

THE FEE CAP counts SETTLED money only: a payment whose success was recorded in full (it has a commission record) and that is not refunded. A payment that
  went over the cap is held for an administrator's refund; it is invoice-only and must never push a later, legitimate payment over the cap.
  Creating a new attempt is stricter: money held for the training (collected) includes such a payment, so nothing more can be started while it waits.

PAYMENT STATES (one row per attempt; a retry is a new row, never a rewrite)
  PENDING -> PROCESSING -> SUCCEEDED | FAILED ;  PENDING -> CANCELLED | EXPIRED
  PROCESSING -> EXPIRED only by the system, when the provider never sent a final result for a very long time (the payment is flagged for review
  first, and a success that arrives later is still recorded as a late success)
  FAILED / CANCELLED / EXPIRED -> SUCCEEDED is allowed ONLY for a verified late success event: money really moved, so the record must say so.
  SUCCEEDED is final. A refund is a separate record, the payment stays SUCCEEDED.
"""
import hashlib
import hmac
import re
import unicodedata
from dataclasses import dataclass

CURRENCY = "INR"
PAISE_PER_RUPEE = 100
MIN_PAYMENT_PAISE = 100          # Rs 1, or whatever is left of the fee if that is less
MAX_BPS = 10_000
DEFAULT_COMMISSION_BPS = 1000    # 10%: DEVELOPMENT PLACEHOLDER
MAX_ORDER_ID = 80                # provider_order_id column width
SANDBOX_ENVIRONMENTS = ("development", "test")

# ---------- payment states ----------
PENDING, PROCESSING, SUCCEEDED, FAILED, CANCELLED, EXPIRED = "PENDING", "PROCESSING", "SUCCEEDED", "FAILED", "CANCELLED", "EXPIRED"
PAYMENT_STATUSES = (PENDING, PROCESSING, SUCCEEDED, FAILED, CANCELLED, EXPIRED)
IN_FLIGHT = (PENDING, PROCESSING)
LATE_SUCCESS_FROM = (FAILED, CANCELLED, EXPIRED)
TRANSITIONS: dict[str, frozenset[str]] = {
    PENDING: frozenset({PROCESSING, SUCCEEDED, FAILED, CANCELLED, EXPIRED}),
    PROCESSING: frozenset({SUCCEEDED, FAILED, EXPIRED}),   # EXPIRED: only the reconcile worker, after PAYMENT_PROCESSING_TIMEOUT_MINUTES
    FAILED: frozenset({SUCCEEDED}),       # late success only
    CANCELLED: frozenset({SUCCEEDED}),    # late success only
    EXPIRED: frozenset({SUCCEEDED}),      # late success only
    SUCCEEDED: frozenset(),
}

# ---------- earnings, refunds, commission ----------
E_PENDING, E_AVAILABLE, E_PAID, E_REFUNDED = "PENDING", "AVAILABLE", "PAID", "REFUNDED"
EARNING_STATUSES = (E_PENDING, E_AVAILABLE, E_PAID, E_REFUNDED)
EARNING_TRANSITIONS: dict[str, frozenset[str]] = {
    E_PENDING: frozenset({E_AVAILABLE, E_REFUNDED}),
    E_AVAILABLE: frozenset({E_PAID, E_REFUNDED}),
    E_PAID: frozenset(),          # a payout is final in Phase 13: a refund after payout is refused
    E_REFUNDED: frozenset(),
}
R_PENDING, R_SUCCEEDED = "PENDING", "SUCCEEDED"
REFUND_STATUSES = (R_PENDING, R_SUCCEEDED)
C_RECORDED, C_REVERSED = "RECORDED", "REVERSED"
COMMISSION_STATUSES = (C_RECORDED, C_REVERSED)
TXN_CHARGE, TXN_REFUND = "CHARGE", "REFUND"

# ---------- reasons a payment is flagged for an administrator ----------
LATE_SUCCESS, OVER_CAP, DUPLICATE_CHARGE = "LATE_SUCCESS", "OVER_CAP", "DUPLICATE_CHARGE"
AMOUNT_MISMATCH, CURRENCY_MISMATCH = "AMOUNT_MISMATCH", "CURRENCY_MISMATCH"
TRAINING_CANCELLED, STUCK_PROCESSING, REFUND_STUCK = "TRAINING_CANCELLED", "STUCK_PROCESSING", "REFUND_STUCK"
REVIEW_REASONS = (LATE_SUCCESS, OVER_CAP, DUPLICATE_CHARGE, AMOUNT_MISMATCH, CURRENCY_MISMATCH, TRAINING_CANCELLED, STUCK_PROCESSING, REFUND_STUCK)
REVIEW_TEXT = {
    LATE_SUCCESS: "A success report arrived after the payment had already been closed.",
    OVER_CAP: "The money received would take the total above the agreed fee. It needs a refund or a decision.",
    DUPLICATE_CHARGE: "The provider reported a second, different charge for this payment.",
    AMOUNT_MISMATCH: "The provider reported a different amount than the payment.",
    CURRENCY_MISMATCH: "The provider reported a different currency than the payment.",
    TRAINING_CANCELLED: "The training was cancelled after money was received.",
    STUCK_PROCESSING: "The payment has been processing for too long.",
    REFUND_STUCK: "A refund could not be completed after several attempts.",
}


def pick_flag(open_reasons: list[str], requested: str | None) -> tuple[str | None, "Refusal | None"]:
    """Which open review flag an administrator's resolve call refers to. A payment can carry several different open flags, and resolving one
    must never close another, so with more than one open the reason has to be named."""
    if not open_reasons:
        return None, Refusal(409, "NOT_FLAGGED", "This payment is not flagged for review")
    if requested is not None:
        if requested not in open_reasons:
            return None, Refusal(409, "FLAG_NOT_OPEN", f"{requested} is not an open review flag on this payment. Open: {', '.join(open_reasons)}")
        return requested, None
    if len(open_reasons) == 1:
        return open_reasons[0], None
    return None, Refusal(409, "REASON_REQUIRED", f"This payment has {len(open_reasons)} open review flags. Say which one you are resolving: {', '.join(open_reasons)}")


@dataclass(frozen=True)
class Refusal:
    """An operation that must not happen: the HTTP status, a stable code for the UI, and a sentence for the user."""
    status: int
    code: str
    message: str


# ---------- money ----------
def _paise(value, what="amount") -> int:
    if type(value) is not int or value < 0:
        raise ValueError(f"{what} must be a non-negative whole number of paise")
    return value


def _bps(value) -> int:
    if type(value) is not int or not 0 <= value <= MAX_BPS:
        raise ValueError(f"commission rate must be a whole number of basis points from 0 to {MAX_BPS}")
    return value


def fee_paise(agreed_fee_rupees: int) -> int:
    return _paise(agreed_fee_rupees, "fee") * PAISE_PER_RUPEE


def commission_total(total_paise: int, bps: int) -> int:
    """Commission on a whole amount: half up, integers only."""
    return (_paise(total_paise) * _bps(bps) + 5000) // 10_000


def instalment_commission(collected_before: int, amount: int, bps: int) -> int:
    """Commission on one instalment. Summed over any split of a fee it equals commission_total(fee)."""
    return commission_total(_paise(collected_before) + _paise(amount), bps) - commission_total(collected_before, bps)


def settle_commission(settled_collected: int, settled_commission: int, amount: int, bps: int) -> tuple[int, int]:
    """(commission, net) for a payment at the moment it succeeds. `settled_collected` / `settled_commission` are the money and the commission
    already recorded for the training's other live payments (not refunded). Aims at commission_total(settled_collected + amount) overall, never
    charges more commission than the payment itself, never negative. Without refunds this equals instalment_commission in any order."""
    target = commission_total(_paise(settled_collected) + _paise(amount), bps)
    fee = max(0, min(_paise(amount), target - _paise(settled_commission, "commission")))
    return fee, amount - fee


def split(collected_before: int, amount: int, bps: int) -> tuple[int, int]:
    """(estimated platform commission, trainer net) for one instalment when an attempt is created. See settle_commission for the final figure."""
    fee = instalment_commission(collected_before, amount, bps)
    return fee, amount - fee


def remaining(fee: int, collected: int) -> int:
    return max(0, _paise(fee, "fee") - _paise(collected, "collected"))


def choose_rate(rate_already_used: int | None, configured: int) -> int:
    """A training keeps the rate of the first money collected for it; a later change of the configured rate never changes it."""
    return _bps(rate_already_used if rate_already_used is not None else configured)


def format_inr(paise: int) -> str:
    """'₹1,23,456' or '₹1,23,456.50' (Indian digit grouping; decimals only when there are paise)."""
    sign, paise = ("-" if paise < 0 else ""), abs(_paise(abs(paise)))
    rupees, rest = divmod(paise, 100)
    digits = str(rupees)
    head, tail = digits[:-3], digits[-3:]
    groups = []
    while len(head) > 2:
        groups.insert(0, head[-2:])
        head = head[:-2]
    if head:
        groups.insert(0, head)
    text = ",".join(groups + [tail]) if groups else tail
    return f"{sign}₹{text}" + (f".{rest:02d}" if rest else "")


# ---------- creating a payment ----------
IDEMPOTENCY_KEY = re.compile(r"^[A-Za-z0-9_.:\-]{8,80}$")


def valid_idempotency_key(key) -> bool:
    return isinstance(key, str) and bool(IDEMPOTENCY_KEY.fullmatch(key))


def valid_order_id(order_id) -> bool:
    """A provider order id we can store: printable text of 1 to MAX_ORDER_ID characters with no surrounding blanks. Checked BEFORE the row is
    inserted, so a provider that returns something unusable becomes a clean 502 instead of a database error."""
    return isinstance(order_id, str) and 0 < len(order_id) <= MAX_ORDER_ID and order_id.isprintable() and order_id == order_id.strip()


def fingerprint(training_id: int, amount_paise: int) -> str:
    """What an idempotency key stands for. The same key with different parameters is a conflict, not a replay."""
    return hashlib.sha256(f"payment:{training_id}:{amount_paise}".encode()).hexdigest()


BLOCK_TEXT = {
    "DISABLED": "Payments are not enabled on this server.",
    "SUSPENDED": "This account cannot make payments.",
    "TRAINING_CANCELLED": "This training was cancelled, so it cannot be paid for.",
    "NO_FEE": "This training has no fee, so there is nothing to pay.",
    "IN_PROGRESS": "A payment for this training is already in progress. Wait for it to finish or cancel it.",
    "FULLY_PAID": "The agreed fee has been paid in full.",
    # Money is HELD for the full fee but part of it is an over-cap payment that is waiting for its refund, so the fee is NOT yet paid in full.
    # The text actually shown comes from block_text (it names the amount still due).
    "AWAITING_REFUND": "A payment for this training is on hold until an administrator refunds it, so the agreed fee is not yet fully paid.",
}


def block_text(why: str, *, fee: int = 0, settled: int | None = None) -> str:
    """The message for a block_reason. AWAITING_REFUND names the amount of the agreed fee still unpaid (fee - settled) and what happens next."""
    if why == "AWAITING_REFUND" and settled is not None:
        return (f"A payment for this training is on hold until an administrator refunds it, so a new payment cannot be started yet. "
                f"{format_inr(max(0, fee - settled))} of the agreed fee is still due and can be paid once that refund is complete.")
    return BLOCK_TEXT[why]


def block_reason(*, enabled: bool, account_blocked: bool, training_status: str, fee: int, collected: int, in_flight: bool,
                 settled: int | None = None) -> str | None:
    """Why this training cannot be paid right now (a key of BLOCK_TEXT), or None. The same answer feeds the API and the UI.
    `collected` is money HELD (an over-cap payment waiting for its refund included); `settled` is the part of it that counts towards the fee (None =
    not supplied: held money is taken to be paid money). When the held money reaches the fee but the settled money does not, the fee is NOT paid in
    full: the reason is AWAITING_REFUND, not FULLY_PAID. The cap rules themselves are unchanged."""
    if not enabled:
        return "DISABLED"
    if account_blocked:
        return "SUSPENDED"
    if training_status == "CANCELLED":
        return "TRAINING_CANCELLED"
    if fee == 0:
        return "NO_FEE"
    if in_flight:
        return "IN_PROGRESS"
    if remaining(fee, collected) == 0:
        return "FULLY_PAID" if settled is None or remaining(fee, settled) == 0 else "AWAITING_REFUND"
    return None


def check_create(*, enabled: bool, account_blocked: bool, training_status: str, fee: int, collected: int, in_flight: bool, amount,
                 settled: int | None = None) -> Refusal | None:
    if type(amount) is not int or amount <= 0:
        return Refusal(422, "INVALID_AMOUNT", "The amount must be a positive whole number of paise.")
    why = block_reason(enabled=enabled, account_blocked=account_blocked, training_status=training_status, fee=fee, collected=collected, in_flight=in_flight,
                       settled=settled)
    if why:
        return Refusal(503 if why == "DISABLED" else 403 if why == "SUSPENDED" else 409, why, block_text(why, fee=fee, settled=settled))
    left = remaining(fee, collected)
    if amount > left:
        return Refusal(409, "OVER_FEE", f"That is more than the {format_inr(left)} still due for this training.")
    if amount < min(MIN_PAYMENT_PAISE, left):
        return Refusal(422, "TOO_SMALL", f"The smallest payment is {format_inr(min(MIN_PAYMENT_PAISE, left))}.")
    return None


# ---------- provider events ----------
EVENT_SUCCEEDED, EVENT_FAILED, EVENT_PROCESSING = "payment.succeeded", "payment.failed", "payment.processing"
EVENT_TYPES = (EVENT_SUCCEEDED, EVENT_FAILED, EVENT_PROCESSING)


@dataclass(frozen=True)
class EventDecision:
    outcome: str                  # stored on the event row
    new_status: str | None = None
    record_charge: bool = False   # write the CHARGE transaction
    settle: bool = False          # create the trainer earning and the commission record
    invoice: bool = False         # create the invoice (every successful payment has exactly one, also an over-cap one that will be refunded)
    flag: str | None = None       # reason to put the payment in front of an administrator
    failure_reason: str | None = None


def decide_event(*, status: str, amount_paise: int, currency: str, charge_txn_on_file: str | None, event_type: str, event_amount: int,
                 event_currency: str, event_txn_id: str | None, event_reason: str | None, collected_other: int, fee: int,
                 training_status: str) -> EventDecision:
    """What a verified provider event does to a payment. Never discards evidence of a possible charge: anything unusual is
    recorded and flagged instead of ignored."""
    if event_type not in EVENT_TYPES:
        return EventDecision("ignored_unknown_type")
    if event_currency != currency:
        return EventDecision("currency_mismatch", flag=CURRENCY_MISMATCH)
    if event_amount != amount_paise:
        return EventDecision("amount_mismatch", flag=AMOUNT_MISMATCH)
    if event_type == EVENT_PROCESSING:
        return EventDecision("processing", new_status=PROCESSING) if status == PENDING else EventDecision("stale_ignored")
    if event_type == EVENT_FAILED:
        if status in IN_FLIGHT:
            return EventDecision("failed", new_status=FAILED, failure_reason=(event_reason or "Payment failed")[:200])
        return EventDecision("stale_ignored")
    # payment.succeeded
    if status == SUCCEEDED:
        if charge_txn_on_file is not None and charge_txn_on_file == event_txn_id:
            return EventDecision("duplicate")
        return EventDecision("duplicate_charge", flag=DUPLICATE_CHARGE)
    late = status in LATE_SUCCESS_FROM
    over = collected_other + amount_paise > fee
    flag = OVER_CAP if over else LATE_SUCCESS if late else TRAINING_CANCELLED if training_status == "CANCELLED" else None
    outcome = "succeeded_over_cap" if over else "succeeded_late" if late else "succeeded"
    return EventDecision(outcome, new_status=SUCCEEDED, record_charge=True, invoice=True, settle=not over, flag=flag)


def can_transition(old: str, new: str) -> bool:
    return new in TRANSITIONS.get(old, frozenset())


def can_transition_earning(old: str, new: str) -> bool:
    return new in EARNING_TRANSITIONS.get(old, frozenset())


# ---------- earnings, refunds, payouts ----------
def initial_earning_status(training_status: str) -> str:
    """AVAILABLE as soon as the training is COMPLETED (zero-day hold; a configured hold is applied by the caller via available_at)."""
    return E_AVAILABLE if training_status == "COMPLETED" else E_PENDING


def hold_elapsed(seconds_since_completion: float, hold_days: int) -> bool:
    return seconds_since_completion >= hold_days * 86_400


def refund_action(payment_status: str, refund_status: str | None, earning_status: str | None) -> tuple[str, Refusal | None]:
    """('create' | 'resume' | 'done' | 'refuse', refusal). Full refunds only; at most one refund per payment (also a database unique)."""
    if refund_status == R_SUCCEEDED:
        return "done", None
    if refund_status == R_PENDING:
        return "resume", None
    if payment_status != SUCCEEDED:
        return "refuse", Refusal(409, "NOT_REFUNDABLE", "Only a successful payment can be refunded.")
    if earning_status == E_PAID:
        return "refuse", Refusal(409, "ALREADY_PAID_OUT", "The trainer's payout for this payment was already recorded. A refund after payout is not supported yet.")
    return "create", None


def payout_refusal(earning_status: str, refund_status: str | None, payment_needs_review: bool = False) -> Refusal | None:
    if refund_status is not None:
        return Refusal(409, "REFUND_EXISTS", "This payment has a refund, so no payout can be recorded.")
    if payment_needs_review:
        return Refusal(409, "UNDER_REVIEW", "This payment is flagged for review. Resolve the review before recording a payout.")
    if earning_status == E_PAID:
        return Refusal(409, "ALREADY_PAID", "This payout was already recorded.")
    if earning_status == E_REFUNDED:
        return Refusal(409, "REFUNDED", "This earning was refunded.")
    if earning_status != E_AVAILABLE:
        return Refusal(409, "NOT_AVAILABLE", "The earning becomes available once the training is completed.")
    return None


def resolve_refusal(review_reason: str | None, payment_status: str, refund_status: str | None) -> Refusal | None:
    """A review may not be closed while it is still holding money that the books do not cover: an over-cap payment has an invoice but no
    earning and no commission, so the only honest ways out are a refund (then the flag can be closed) or never closing it."""
    if review_reason == OVER_CAP and payment_status == SUCCEEDED and refund_status != R_SUCCEEDED:
        return Refusal(409, "REFUND_REQUIRED", "This payment took the total above the agreed fee and has no earning. Refund it before closing the review.")
    return None


MAX_REFERENCE_DIGITS = 8


def clean_payout_reference(text) -> str:
    """A free-text reference for the operator's own records. It is a guard-rail against storing bank or UPI details by accident: anything
    that looks like a UPI id, or carries more than MAX_REFERENCE_DIGITS digits in total (separators of any kind, full-width and other-script
    digits and look-alike characters included), is refused. Use a batch name rather than a number."""
    if not isinstance(text, str):
        raise ValueError("Enter a payout reference")
    text = text.strip()
    if not 3 <= len(text) <= 80:
        raise ValueError("The payout reference must be 3 to 80 characters")
    folded = unicodedata.normalize("NFKC", text)
    digits = sum(ch.isdigit() for ch in folded)
    if "@" in folded or digits > MAX_REFERENCE_DIGITS or any(unicodedata.category(ch) in ("Cc", "Cf") for ch in text):
        raise ValueError("Do not enter bank account numbers or UPI ids. Use your own reference, for example a batch name, with at most "
                         f"{MAX_REFERENCE_DIGITS} digits")
    return text


# ---------- invoice numbers ----------
def invoice_number(year: int, n: int) -> str:
    if n < 1:
        raise ValueError("invoice sequence starts at 1")
    return f"ITB-{year}-{n:06d}"


def credit_note_number(year: int, n: int) -> str:
    if n < 1:
        raise ValueError("credit note sequence starts at 1")
    return f"ITB-CN-{year}-{n:06d}"


# ---------- webhook authentication ----------
def sign(secret: str, timestamp: str, body: bytes) -> str:
    """HMAC-SHA256 over '<timestamp>.<raw body>': binding the timestamp stops an old body being replayed with a fresh time."""
    return hmac.new(secret.encode(), timestamp.encode() + b"." + body, hashlib.sha256).hexdigest()


def check_webhook(*, secret: str, body: bytes, signature: str | None, timestamp: str | None, now_epoch: float, tolerance_seconds: int) -> str | None:
    """None when the request is authentic, otherwise a short reason. Fails closed: with no secret configured nothing is accepted."""
    if not secret:
        return "not_configured"
    if not signature:
        return "missing_signature"
    if not timestamp:
        return "missing_timestamp"
    try:
        ts = int(timestamp)
    except ValueError:
        return "bad_timestamp"
    try:
        stale = abs(now_epoch - ts) > tolerance_seconds
    except OverflowError:            # an integer too large for a float (a few hundred digits) is certainly outside any tolerance: refuse it, do not crash
        stale = True
    if stale:
        return "stale_timestamp"
    if not hmac.compare_digest(sign(secret, timestamp, body).encode(), signature.strip().lower().encode()):
        return "bad_signature"
    return None


# ---------- start-up safety ----------
_WEAK = {"change_me", "changeme", "secret", "password", "test", "testing", "dev", "development", "sandbox", "webhook", "webhook_secret"}
_WEAK_MARKERS = ("dev-only", "dev_only", "do-not-use", "do_not_use", "change_me", "changeme", "example", "placeholder", "sandbox", "test-only", "password")
IMPLEMENTED_PROVIDERS = ("sandbox",)
SANDBOX_PROVIDERS = ("sandbox",)


def is_weak_secret(secret: str) -> bool:
    s = (secret or "").strip()
    low = s.lower()
    return len(s) < 32 or low in _WEAK or len(set(s)) < 8 or any(m in low for m in _WEAK_MARKERS)


def is_production(environment: str) -> bool:
    return (environment or "").strip().lower() in ("production", "prod")


def environment_kind(environment) -> str:
    """'production', 'development', 'test' or 'unknown'. Missing, empty, misspelt or any other value is 'unknown': the application never guesses an
    environment. (There is no default: config.py leaves ENVIRONMENT empty until the operator sets it, so no library internals are needed to tell.)"""
    low = (environment or "").strip().lower() if isinstance(environment, str) else ""
    if low in ("production", "prod"):
        return "production"
    return low if low in SANDBOX_ENVIRONMENTS else "unknown"


def webhook_secret_usable(secret: str, environment: str) -> bool:
    """May the webhook endpoint use this secret to authenticate deliveries? (Defence in depth: the start-up guard already refuses to boot a production
    process with an unusable secret.) An empty secret never. Outside production any non-empty secret (development and tests use a documented example
    one). In production only a strong secret: an empty, weak or known example value leaves the endpoint rejecting everything (503), whether or not
    PAYMENTS_ENABLED is on. An unknown environment is treated like production here: only a strong secret."""
    if not secret:
        return False
    return not (environment_kind(environment) in ("production", "unknown") and is_weak_secret(secret))


def sandbox_usable(*, enabled: bool, provider: str, sandbox_opt_in: bool, environment: str) -> bool:
    """Payments are switched on AND usable. The sandbox moves no money and is completed only by its simulator, so it needs ALL of: the payments switch,
    an explicit sandbox opt-in, and a development or test environment. Any other combination is OFF, never half-on. A provider that is not
    implemented is OFF too."""
    if not enabled or provider not in IMPLEMENTED_PROVIDERS:
        return False
    if provider in SANDBOX_PROVIDERS:
        return bool(sandbox_opt_in) and (environment or "").strip().lower() in SANDBOX_ENVIRONMENTS
    return True


def config_problems(*, environment: str, enabled: bool, provider: str, secret: str, commission_bps: int, commission_confirmed: bool,
                    sandbox_opt_in: bool = False) -> list[str]:
    """Reasons the configuration is unsafe. The app (API, payment worker and loop) refuses to start if this list is not empty.
    Fails closed: ENVIRONMENT must be development, test or production. A missing, empty or unknown value is refused outright (there is no default
    and nothing is guessed), whether or not payments are enabled. The sandbox opt-in can never be true in production. In production the webhook
    secret must be present and strong, WHETHER OR NOT PAYMENTS ARE ENABLED: a missing, empty, weak or known example value (including the one in
    .env.example) is refused at start-up (13B.2). Development and test accept any secret, including none. Production real-money payments also need
    an implemented provider (none exists, so production with payments enabled never starts) and a confirmed commission."""
    problems = []
    kind = environment_kind(environment)
    if type(commission_bps) is not int or not 0 <= commission_bps <= MAX_BPS:
        problems.append(f"PLATFORM_COMMISSION_BPS must be a whole number from 0 to {MAX_BPS}")
    if kind == "unknown":
        problems.append(f"ENVIRONMENT is missing or not recognised ({environment!r}): set it to development, test or production. Nothing is assumed")
    if kind == "production":
        if sandbox_opt_in:
            problems.append("PAYMENT_SANDBOX_ENABLED must never be true in production")
        if not secret or not str(secret).strip():
            problems.append("PAYMENT_WEBHOOK_SECRET is missing or empty: production refuses to start without a strong webhook secret, whether or not payments are enabled "
                            "(use a random value of at least 32 characters)")
        elif is_weak_secret(secret):
            problems.append("PAYMENT_WEBHOOK_SECRET is weak or a known example value, which is refused in production whether or not payments are enabled "
                            "(use a random value of at least 32 characters)")
        if enabled:
            if provider in SANDBOX_PROVIDERS:
                problems.append("PAYMENT_PROVIDER is the sandbox, which moves no real money and must never run in production")
            elif provider not in IMPLEMENTED_PROVIDERS:
                problems.append(f"PAYMENT_PROVIDER={provider!r} is not implemented")
            if not commission_confirmed:
                problems.append("the platform commission is still a development placeholder: set PAYMENT_COMMISSION_CONFIRMED=true only after it is approved")
    elif kind in SANDBOX_ENVIRONMENTS and enabled and provider in SANDBOX_PROVIDERS and not sandbox_opt_in:
        problems.append("payments are enabled with the sandbox provider but PAYMENT_SANDBOX_ENABLED is not true: set it on purpose, or disable payments")
    return problems
