"""Platform invoices and credit notes (Phase 13).

An invoice is issued exactly once per SUCCESSFUL payment (database unique on payment_id) and never changes afterwards: no code path
updates an `invoices` row. A refund does not touch it; the refund's own record carries a credit-note number.

THESE ARE IT BRIDGE PLATFORM INVOICES, NOT GST OR TAX INVOICES. They carry no tax registration numbers and no tax breakdown. How tax
applies to a marketplace that collects money for trainers needs professional accounting advice before real money is handled.

Numbers: ITB-YYYY-NNNNNN for invoices and ITB-CN-YYYY-NNNNNN for credit notes, allocated from a locked `invoice_counters` row
(one per series and year). Allocation happens inside the transaction that issues the document, so a rolled-back payment settlement
releases its number and numbers have no gaps. SELECT ... FOR UPDATE serialises concurrent allocation on PostgreSQL; SQLite ignores
the lock, so this has NOT been exercised concurrently in this environment.
"""
from fastapi import HTTPException
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.core.clock import today
from app.models.payment import Invoice, InvoiceCounter, Payment, PaymentRefund
from app.models.training import Training
from app.models.user import InstitutionProfile, TrainerProfile, User
from app.services import payment_rules as rules

NOTICE = ("This is an IT BRIDGE platform invoice. It is not a GST or tax invoice. "
          "Tax treatment of marketplace payments should be confirmed with a qualified accountant.")
SANDBOX_NOTICE = "SANDBOX: no real money was processed for this document."


def next_number(db: Session, series: str, year: int) -> int:
    """The next sequence number of a series/year. The counter row is created on first use inside a SAVEPOINT, so two requests that
    race to create it cannot both insert: the loser re-reads the winner's row and locks it."""
    key = (series, year)
    row = db.get(InvoiceCounter, key, with_for_update=True, populate_existing=True)
    if row is None:
        try:
            with db.begin_nested():
                db.add(InvoiceCounter(series=series, year=year, last_number=0))
                db.flush()
        except IntegrityError:
            pass
        row = db.get(InvoiceCounter, key, with_for_update=True, populate_existing=True)
    row.last_number += 1
    db.flush()
    return row.last_number


def next_credit_note_number(db: Session) -> str:
    year = today().year
    return rules.credit_note_number(year, next_number(db, "CN", year))


def issue(db: Session, p: Payment, t: Training, institution: InstitutionProfile, trainer: TrainerProfile) -> Invoice:
    """The invoice of a succeeded payment. Idempotent: a second call returns the existing invoice and changes nothing."""
    existing = db.scalar(select(Invoice).where(Invoice.payment_id == p.id))
    if existing:
        return existing
    year = today().year
    inv = Invoice(
        payment_id=p.id, number=rules.invoice_number(year, next_number(db, "INV", year)), institution_id=p.institution_id,
        trainer_id=p.trainer_id, training_id=p.training_id, amount_paise=p.amount_paise, currency=p.currency,
        snapshot={"institution_name": institution.institution_name, "institution_location": institution.location,
                  "trainer_name": trainer.user.full_name, "training_title": t.title, "technology": t.technology,
                  "start_date": str(t.start_date), "end_date": str(t.end_date), "agreed_fee_paise": rules.fee_paise(t.agreed_fee),
                  "payment_attempt": p.attempt_no, "sandbox": p.provider in rules.SANDBOX_PROVIDERS,
                  "description": f"Training fee: {t.title}"})
    db.add(inv)
    db.flush()
    return inv


def view(db: Session, user: User, payment_id: int) -> dict:
    """The invoice as the paying institution sees it: no commission, no trainer net, no other user's data. Everyone else gets 404."""
    p = db.get(Payment, payment_id)
    prof = user.institution_profile
    if p is None or user.role != "INSTITUTION" or prof is None or p.institution_id != prof.id:
        raise HTTPException(404, "Invoice not found")
    inv = db.scalar(select(Invoice).where(Invoice.payment_id == p.id))
    if inv is None:
        raise HTTPException(404, "Invoice not found")
    refund = db.scalar(select(PaymentRefund).where(PaymentRefund.payment_id == p.id, PaymentRefund.status == rules.R_SUCCEEDED))
    snap = inv.snapshot
    return {"number": inv.number, "issued_at": inv.issued_at.isoformat(), "amount_paise": inv.amount_paise, "currency": inv.currency,
            "payment_id": p.id, "training_id": inv.training_id, "paid_at": p.paid_at.isoformat() if p.paid_at else None,
            "billed_to": {"name": snap["institution_name"], "location": snap.get("institution_location")},
            "issued_by": "IT BRIDGE (platform)", "trainer_name": snap["trainer_name"], "description": snap["description"],
            "training": {"title": snap["training_title"], "technology": snap.get("technology"), "start_date": snap["start_date"], "end_date": snap["end_date"]},
            "sandbox": bool(snap.get("sandbox")), "notice": NOTICE, "sandbox_notice": SANDBOX_NOTICE if snap.get("sandbox") else None,
            "credit_note": {"number": refund.credit_note_number, "amount_paise": refund.amount_paise,
                            "issued_at": refund.completed_at.isoformat() if refund.completed_at else None} if refund else None}
