from datetime import date, datetime, time

from fastapi import HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session, joinedload

from app.models.application import Application
from app.models.matching import TrainerBusyPeriod
from app.models.requirement import TrainingRequirement
from app.models.training import Training, TrainingSession
from app.models.user import TrainerProfile, User
from app.services.training_service import phase

MAX_DAYS = 100


def _ev(kind, d, title, subtitle=None, link=None, status=None, start=None, end=None, end_date=None, training=None):
    """One calendar entry. Training details (phase, mode, location, meeting link) are added only for the caller's own trainings."""
    ev = {"type": kind, "date": str(d), "end_date": str(end_date or d), "title": title, "subtitle": subtitle,
          "link": link, "status": status, "start_time": start.strftime("%H:%M") if start else None,
          "end_time": end.strftime("%H:%M") if end else None,
          "phase": None, "mode": None, "location": None, "meeting_link": None}
    if training is not None:
        ev.update(phase=phase(training), mode=training.mode, location=training.location,
                  meeting_link=training.meeting_link if training.mode != "OFFLINE" else None)
    return ev


def events(db: Session, user: User, start: date, end: date) -> list[dict]:
    if end < start or (end - start).days > MAX_DAYS:
        raise HTTPException(422, f"Choose a date range of at most {MAX_DAYS} days")
    trainer = user.role == "TRAINER"
    pid = user.trainer_profile.id if trainer else user.institution_profile.id
    owner = Training.trainer_id if trainer else Training.institution_id
    out = []

    # Eager loading keeps each section to a fixed number of queries regardless of how many rows come back.
    trainings = db.scalars(select(Training).options(joinedload(Training.institution), joinedload(Training.trainer).joinedload(TrainerProfile.user))
                           .where(owner == pid, Training.status != "CANCELLED", Training.start_date <= end, Training.end_date >= start))
    for t in trainings:
        out.append(_ev("TRAINING", t.start_date, t.title, t.institution.institution_name if trainer else t.trainer.user.full_name,
                       f"/trainings/{t.id}", t.status, end_date=t.end_date, training=t))

    sessions = db.scalars(select(TrainingSession).join(Training, Training.id == TrainingSession.training_id).options(joinedload(TrainingSession.training))
                          .where(owner == pid, Training.status != "CANCELLED", TrainingSession.status != "CANCELLED",
                                 TrainingSession.session_date.between(start, end)))
    for s in sessions:
        out.append(_ev("SESSION", s.session_date, s.title, s.training.title, f"/trainings/{s.training_id}", s.status,
                       s.start_time, s.end_time, training=s.training))

    interviews = (select(Application).join(TrainingRequirement, TrainingRequirement.id == Application.requirement_id)
                  .options(joinedload(Application.requirement).joinedload(TrainingRequirement.institution),
                           joinedload(Application.trainer).joinedload(TrainerProfile.user))
                  .where(Application.status == "INTERVIEW", Application.interview_at.is_not(None),
                         Application.interview_at >= datetime.combine(start, time.min),
                         Application.interview_at <= datetime.combine(end, time.max)))
    interviews = interviews.where(Application.trainer_id == pid) if trainer else interviews.where(TrainingRequirement.institution_id == pid)
    for a in db.scalars(interviews):
        other = a.requirement.institution.institution_name if trainer else a.trainer.user.full_name
        link = "/trainer/applications" if trainer else f"/institution/requirements/{a.requirement_id}/applications"
        out.append(_ev("INTERVIEW", a.interview_at.date(), f"Interview: {a.requirement.title}", other, link, a.status, a.interview_at.time()))

    if trainer:
        for b in db.scalars(select(TrainerBusyPeriod).where(TrainerBusyPeriod.trainer_id == pid,
                                                            TrainerBusyPeriod.start_date <= end, TrainerBusyPeriod.end_date >= start)):
            out.append(_ev("BUSY", b.start_date, "Unavailable", b.reason, None, None, end_date=b.end_date))
        rows = db.scalars(select(Application).join(TrainingRequirement, TrainingRequirement.id == Application.requirement_id)
                          .options(joinedload(Application.requirement))
                          .where(Application.trainer_id == pid, Application.status.in_(("APPLIED", "UNDER_REVIEW", "SHORTLISTED", "INTERVIEW")),
                                 TrainingRequirement.application_deadline.between(start, end)))
        for a in rows:
            out.append(_ev("DEADLINE", a.requirement.application_deadline, f"Deadline: {a.requirement.title}",
                           "Application deadline", f"/requirements/{a.requirement_id}", a.status))
    else:
        for r in db.scalars(select(TrainingRequirement).where(TrainingRequirement.institution_id == pid, TrainingRequirement.status == "OPEN",
                                                              TrainingRequirement.application_deadline.between(start, end))):
            out.append(_ev("DEADLINE", r.application_deadline, f"Deadline: {r.title}", "Application deadline",
                           f"/institution/requirements/{r.id}/applications", r.status))

    out.sort(key=lambda e: (e["date"], e["start_time"] or "00:00"))
    return out
