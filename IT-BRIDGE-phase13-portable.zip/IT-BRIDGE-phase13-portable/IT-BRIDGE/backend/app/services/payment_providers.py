"""Payment provider abstraction (Phase 13).

Only the SANDBOX provider exists. It moves no real money and talks to no network: it is for development and tests, and
`config_problems()` (payment_rules.py) stops production from starting with it. A real provider (Razorpay, Stripe, ...) is
OUT OF SCOPE for this phase: it would be one more class implementing `PaymentProvider`, plus an entry in IMPLEMENTED_PROVIDERS.

Trust model: the only way a payment becomes SUCCEEDED is an event that passed `payment_service.handle_webhook`
(signature + timestamp verified) or `payment_service.reconcile` (the provider was asked directly). The browser is never trusted.
No card number, CVV, bank account or UPI id is ever sent to, stored by or returned from this module.
"""
import hashlib
import json
import secrets
from dataclasses import dataclass, field
from typing import Protocol

from app.core.config import settings
from app.services import payment_rules as rules

SIGNATURE_HEADER = "X-ITB-Signature"
TIMESTAMP_HEADER = "X-ITB-Timestamp"


class ProviderError(Exception):
    """The provider could not be reached or refused the request. The message is safe to store (it never contains secrets)."""


@dataclass(frozen=True)
class ProviderOrder:
    order_id: str
    meta: dict = field(default_factory=dict)


@dataclass(frozen=True)
class ProviderEvent:
    event_id: str
    type: str
    order_id: str
    amount_paise: int
    currency: str
    txn_id: str | None = None
    reason: str | None = None


@dataclass(frozen=True)
class RefundResult:
    refund_id: str


class PaymentProvider(Protocol):
    name: str
    is_sandbox: bool

    def create_order(self, *, reference: str, amount_paise: int, currency: str) -> ProviderOrder: ...
    def parse_event(self, body: bytes) -> ProviderEvent: ...          # raises ValueError for anything malformed
    def fetch_status(self, order_id: str) -> ProviderEvent | None: ...  # None = the provider has no final result yet
    def refund(self, *, txn_id: str, amount_paise: int, idempotency_key: str) -> RefundResult: ...  # idempotent per key; raises ProviderError


MAX_EVENT_ID, MAX_ORDER_ID, MAX_TXN_ID = 80, rules.MAX_ORDER_ID, 120    # the transaction-id column holds 160, enough for the "evt:" + event id fallback too


class SandboxProvider:
    """Pretends to be a payment gateway. Orders are random ids, a refund id is derived from its idempotency key (so a retried refund
    returns the same id, like a real gateway), and `fetch_status` knows nothing (the sandbox keeps no state of its own)."""
    name = "sandbox"
    is_sandbox = True

    def create_order(self, *, reference: str, amount_paise: int, currency: str) -> ProviderOrder:
        return ProviderOrder(order_id="sbx_order_" + secrets.token_hex(10),
                             meta={"sandbox": True, "notice": "Sandbox payment: no real money is processed", "reference": reference})

    def parse_event(self, body: bytes) -> ProviderEvent:
        try:
            doc = json.loads(body)
            data = doc["data"]
            ev = ProviderEvent(event_id=str(doc["id"]), type=str(doc["type"]), order_id=str(data["order_id"]),
                               amount_paise=data["amount"], currency=str(data["currency"]),
                               txn_id=(str(data["transaction_id"]) if data.get("transaction_id") else None),
                               reason=(str(data["reason"])[:200] if data.get("reason") else None))
        except (ValueError, KeyError, TypeError, AttributeError) as e:
            raise ValueError("malformed event") from e
        if (type(ev.amount_paise) is not int or not ev.event_id or not ev.order_id or len(ev.event_id) > MAX_EVENT_ID or len(ev.order_id) > MAX_ORDER_ID
                or (ev.txn_id is not None and len(ev.txn_id) > MAX_TXN_ID)):
            raise ValueError("malformed event")      # every length is checked here so that a valid signature can never lead to a database error later
        return ev

    def fetch_status(self, order_id: str) -> ProviderEvent | None:
        return None

    def refund(self, *, txn_id: str, amount_paise: int, idempotency_key: str) -> RefundResult:
        return RefundResult("sbx_refund_" + hashlib.sha256(f"{txn_id}:{idempotency_key}".encode()).hexdigest()[:20])


_PROVIDERS = {"sandbox": SandboxProvider}


def get_provider(name: str | None = None) -> PaymentProvider:
    """The configured provider. Unknown names raise: a payment must never silently fall back to another provider."""
    name = name or settings.payment_provider
    if name not in _PROVIDERS or name not in rules.IMPLEMENTED_PROVIDERS:
        raise ProviderError(f"payment provider {name!r} is not available")
    return _PROVIDERS[name]()


def build_signed_event(secret: str, *, event_id: str, type_: str, order_id: str, amount_paise: int, currency: str,
                       txn_id: str | None = None, reason: str | None = None, timestamp: int) -> tuple[bytes, dict]:
    """A body and headers exactly as a gateway would deliver them. Used by the sandbox simulation and by the tests; the receiver
    (`payment_service.handle_webhook`) cannot tell it apart from a real delivery, which is the point."""
    body = json.dumps({"id": event_id, "type": type_, "created": timestamp,
                       "data": {"order_id": order_id, "amount": amount_paise, "currency": currency, "transaction_id": txn_id, "reason": reason}},
                      sort_keys=True, separators=(",", ":")).encode()
    ts = str(timestamp)
    return body, {SIGNATURE_HEADER: rules.sign(secret, ts, body), TIMESTAMP_HEADER: ts}
