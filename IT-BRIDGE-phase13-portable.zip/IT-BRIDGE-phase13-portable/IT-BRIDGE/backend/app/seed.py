"""Development seed data. Run: python -m app.seed  (never run against production data)."""
import os

from sqlalchemy import select

from app.core.database import SessionLocal
from app.models.requirement import Category
from app.models.user import Skill

SKILLS = {
    "Programming": ["Python", "Java", "JavaScript", "React", "Full Stack Development", "DSA"],
    "Data & AI": ["Data Science", "AI/ML"],
    "Infrastructure": ["Cloud", "DevOps", "Cyber Security"],
    "Career": ["Aptitude", "Soft Skills", "Communication Skills", "Interview Preparation"],
}


def seed_skills(db):
    existing = set(db.scalars(select(Skill.name)))
    for category, names in SKILLS.items():
        for n in names:
            if n not in existing:
                db.add(Skill(name=n, category=category))
    db.commit()


CATEGORIES = ["Programming", "Web Development", "Data & AI", "Cloud & DevOps", "Cyber Security", "Aptitude & Soft Skills"]


def seed_categories(db):
    existing = set(db.scalars(select(Category.name)))
    for n in CATEGORIES:
        if n not in existing:
            db.add(Category(name=n))
    db.commit()


def create_admin(db):
    """Create the first admin from ADMIN_EMAIL / ADMIN_PASSWORD env vars (never hard-coded)."""
    from app.core.security import hash_password
    from app.models.user import User
    email, password = os.getenv("ADMIN_EMAIL"), os.getenv("ADMIN_PASSWORD")
    if not (email and password) or db.scalar(select(User).where(User.email == email.lower())):
        return
    db.add(User(email=email.lower(), password_hash=hash_password(password), full_name="Platform Admin", role="ADMIN", email_verified=True))
    db.commit()


if __name__ == "__main__":
    with SessionLocal() as db:
        seed_skills(db)
        seed_categories(db)
        create_admin(db)
    print("Seeded skills")
