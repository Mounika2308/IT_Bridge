import asyncio

from fastapi import APIRouter, Depends, HTTPException, Query, WebSocket, WebSocketDisconnect
from sqlalchemy.orm import Session

from app.api.deps import current_user
from app.core.database import get_db
from app.core.security import decode_token
from app.models.user import User
from app.repositories import user_repo
from app.schemas.notification import PreferencesIn
from app.services import notification_preferences as prefs
from app.services import notification_service as svc
from app.services.realtime import CLOSE, manager

router = APIRouter(tags=["notifications"])
ws_router = APIRouter()


def ok(data, message="OK"):
    return {"success": True, "message": message, "data": data}


@router.get("/notifications")
def list_notifications(page: int = Query(1, ge=1), page_size: int = Query(20, ge=1, le=50), unread_only: bool = False,
                       user: User = Depends(current_user), db: Session = Depends(get_db)):
    return ok(svc.list_for(db, user, page, page_size, unread_only))


@router.get("/notifications/preferences")
def get_preferences(user: User = Depends(current_user), db: Session = Depends(get_db)):
    return ok(prefs.out(db, user))


@router.put("/notifications/preferences")
def put_preferences(body: PreferencesIn, user: User = Depends(current_user), db: Session = Depends(get_db)):
    prefs.update(db, user, {k: getattr(body, k) for k in body.model_fields_set})
    return ok(prefs.out(db, user), "Notification preferences saved")


@router.get("/notifications/unread-count")
def unread(user: User = Depends(current_user), db: Session = Depends(get_db)):
    return ok({"unread": svc.unread_count(db, user)})


@router.post("/notifications/read-all")
def read_all(user: User = Depends(current_user), db: Session = Depends(get_db)):
    svc.mark_all_read(db, user)
    return ok(None, "All notifications marked as read")


@router.post("/notifications/{nid}/read")
def read_one(nid: int, user: User = Depends(current_user), db: Session = Depends(get_db)):
    if not svc.mark_read(db, user, nid):
        raise HTTPException(404, "Notification not found")
    return ok(None, "Marked as read")


def _user_active(ws: WebSocket, uid: int) -> bool:
    dep = ws.app.dependency_overrides.get(get_db, get_db)
    gen = dep()
    db = next(gen)
    try:
        user = user_repo.get_by_id(db, uid)
        return bool(user and user.is_active)
    finally:
        gen.close()  # release the connection immediately; the socket can stay open for hours


def _authenticate(ws: WebSocket, token: str | None) -> int | None:
    uid = decode_token(token, "access") if token else None
    return uid if uid and _user_active(ws, uid) else None


@ws_router.websocket("/ws/notifications")
async def notifications_socket(ws: WebSocket):
    """Protocol: client connects, sends {"token": <access token>} within 5s, then receives
    {"type": "notification", "data": {...}} messages. The token is sent as a message, never in the URL."""
    await ws.accept()
    try:
        first = await asyncio.wait_for(ws.receive_json(), timeout=5)
    except Exception:
        await ws.close(code=4401)
        return
    uid = _authenticate(ws, first.get("token") if isinstance(first, dict) else None)
    queue = await manager.connect(uid) if uid else None
    if not uid or queue is None:
        await ws.close(code=4401 if not uid else 4429)
        return
    await ws.send_json({"type": "ready"})

    async def sender():
        while True:
            item = await queue.get()
            # An account deactivated after the socket opened must stop receiving: re-check before every message.
            if item is CLOSE or not _user_active(ws, uid):
                await ws.close(code=4403)
                return
            await ws.send_json({"type": "notification", "data": item})

    async def receiver():
        while True:
            if (await ws.receive_text()) == "ping":
                await ws.send_json({"type": "pong"})

    tasks = [asyncio.create_task(sender()), asyncio.create_task(receiver())]
    try:
        await asyncio.wait(tasks, return_when=asyncio.FIRST_COMPLETED)
    except WebSocketDisconnect:
        pass
    finally:
        for t in tasks:
            t.cancel()
        manager.disconnect(uid, queue)
