from fastapi import APIRouter, Depends
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.api.deps import current_user, require_roles
from app.core.database import get_db
from app.models.user import Skill, User
from app.schemas.profile import InstitutionProfileIn, InstitutionProfileOut, SkillIn, SkillOut, TrainerProfileIn
from app.services import profile_service as svc

router = APIRouter(tags=["profiles"])


def ok(data, message="OK"):
    return {"success": True, "message": message, "data": data.model_dump() if hasattr(data, "model_dump") else data}


@router.get("/skills")
def list_skills(db: Session = Depends(get_db)):
    rows = db.scalars(select(Skill).where(Skill.is_active.is_(True)).order_by(Skill.name))
    return ok([SkillOut.model_validate(s).model_dump() for s in rows])


@router.post("/skills", status_code=201)
def create_skill(body: SkillIn, db: Session = Depends(get_db), _: User = Depends(require_roles("ADMIN"))):
    skill = Skill(name=body.name.strip(), category=body.category)
    db.add(skill)
    db.commit()
    return ok(SkillOut.model_validate(skill), "Skill created")


@router.get("/trainers/me")
def my_trainer_profile(user: User = Depends(require_roles("TRAINER"))):
    return ok(svc.trainer_out(user.trainer_profile))


@router.put("/trainers/me")
def update_my_trainer_profile(body: TrainerProfileIn, user: User = Depends(require_roles("TRAINER")),
                              db: Session = Depends(get_db)):
    return ok(svc.update_trainer(db, user, body), "Profile saved")


@router.get("/trainers/{profile_id}")
def trainer_public(profile_id: int, _: User = Depends(current_user), db: Session = Depends(get_db)):
    return ok(svc.trainer_public(db, profile_id))


@router.get("/institutions/me")
def my_institution_profile(user: User = Depends(require_roles("INSTITUTION"))):
    return ok(InstitutionProfileOut.model_validate(user.institution_profile))


@router.put("/institutions/me")
def update_my_institution_profile(body: InstitutionProfileIn, user: User = Depends(require_roles("INSTITUTION")),
                                  db: Session = Depends(get_db)):
    return ok(svc.update_institution(db, user, body), "Profile saved")
