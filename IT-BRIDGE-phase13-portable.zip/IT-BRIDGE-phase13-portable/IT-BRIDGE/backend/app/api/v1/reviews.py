from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from app.api.deps import current_user, require_roles
from app.core.database import get_db
from app.models.user import User
from app.schemas.review import ReviewIn
from app.services import review_service as svc

router = APIRouter(tags=["reviews"])


def ok(data, message="OK"):
    return {"success": True, "message": message, "data": data}


@router.post("/trainings/{tid}/reviews", status_code=201)
def submit(tid: int, body: ReviewIn, user: User = Depends(require_roles("TRAINER", "INSTITUTION")), db: Session = Depends(get_db)):
    return ok(svc.submit(db, user, tid, body), "Review submitted")


@router.get("/trainings/{tid}/reviews")
def for_training(tid: int, user: User = Depends(require_roles("TRAINER", "INSTITUTION")), db: Session = Depends(get_db)):
    return ok(svc.for_training(db, user, tid))


@router.get("/trainers/{trainer_id}/reviews")
def for_trainer(trainer_id: int, page: int = Query(1, ge=1), page_size: int = Query(10, ge=1, le=50),
                _: User = Depends(current_user), db: Session = Depends(get_db)):
    return ok(svc.for_trainer(db, trainer_id, page, page_size))


@router.get("/institutions/{institution_id}/reviews")
def for_institution(institution_id: int, page: int = Query(1, ge=1), page_size: int = Query(10, ge=1, le=50),
                    _: User = Depends(current_user), db: Session = Depends(get_db)):
    return ok(svc.for_institution(db, institution_id, page, page_size))


@router.get("/reviews/me")
def my_summary(user: User = Depends(require_roles("TRAINER", "INSTITUTION")), db: Session = Depends(get_db)):
    """Own rating summary and the number of completed trainings still waiting for this user's review."""
    return ok(svc.my_summary(db, user))
