from datetime import date
from typing import Literal

from fastapi import APIRouter, Depends, Query
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.api.deps import current_user, require_roles
from app.core.database import get_db
from app.models.requirement import Category
from app.models.user import User
from app.schemas.requirement import CategoryIn, CategoryOut, RequirementIn
from app.services import requirement_service as svc

router = APIRouter(tags=["requirements"])


def ok(data, message="OK"):
    return {"success": True, "message": message, "data": data.model_dump(mode="json") if hasattr(data, "model_dump") else data}


@router.get("/categories")
def categories(db: Session = Depends(get_db)):
    rows = db.scalars(select(Category).where(Category.is_active.is_(True)).order_by(Category.name))
    return ok([CategoryOut.model_validate(c).model_dump() for c in rows])


@router.post("/categories", status_code=201)
def create_category(body: CategoryIn, db: Session = Depends(get_db), _: User = Depends(require_roles("ADMIN"))):
    c = Category(name=body.name.strip())
    db.add(c)
    db.commit()
    return ok(CategoryOut.model_validate(c), "Category created")


@router.post("/requirements", status_code=201)
def create(body: RequirementIn, user: User = Depends(require_roles("INSTITUTION")), db: Session = Depends(get_db)):
    return ok(svc.create(db, user, body), "Requirement posted")


@router.get("/requirements/mine")
def mine(page: int = Query(1, ge=1), page_size: int = Query(20, ge=1, le=50),
         user: User = Depends(require_roles("INSTITUTION")), db: Session = Depends(get_db)):
    return ok(svc.list_mine(db, user, page, page_size))


@router.get("/requirements")
def browse(q: str | None = Query(None, max_length=100), skill_id: int | None = None,
           location: str | None = Query(None, max_length=100), mode: Literal["ONLINE", "OFFLINE", "HYBRID"] | None = None,
           max_experience: int | None = Query(None, ge=0, le=60), min_budget: int | None = Query(None, ge=0),
           start_after: date | None = None, max_duration: int | None = Query(None, ge=1),
           page: int = Query(1, ge=1), page_size: int = Query(12, ge=1, le=50),
           user: User = Depends(current_user), db: Session = Depends(get_db)):
    f = dict(q=q, skill_id=skill_id, location=location, mode=mode, max_experience=max_experience,
             min_budget=min_budget, start_after=start_after, max_duration=max_duration)
    return ok(svc.browse(db, user, f, page, page_size))


@router.get("/requirements/{req_id}")
def detail(req_id: int, user: User = Depends(current_user), db: Session = Depends(get_db)):
    return ok(svc.detail(db, user, req_id))


@router.put("/requirements/{req_id}")
def update(req_id: int, body: RequirementIn, user: User = Depends(require_roles("INSTITUTION")), db: Session = Depends(get_db)):
    return ok(svc.update(db, user, req_id, body), "Requirement updated")


@router.post("/requirements/{req_id}/close")
def close(req_id: int, user: User = Depends(require_roles("INSTITUTION")), db: Session = Depends(get_db)):
    return ok(svc.close(db, user, req_id), "Requirement closed")
