from datetime import date
from typing import Literal

from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from app.api.deps import require_roles
from app.core.database import get_db
from app.models.user import User
from app.schemas.training import (AttendanceIn, CancelIn, SessionIn, SessionStatusIn, SessionUpdateIn, TrainingDatesIn, TrainingDetailsIn, PlannedSessionsIn, SessionNotesIn)
from app.services import calendar_service, training_service as svc

router = APIRouter(tags=["trainings"])
PARTIES = ("TRAINER", "INSTITUTION")


def ok(data, message="OK"):
    return {"success": True, "message": message, "data": data}


@router.get("/trainings/mine")
def mine(page: int = Query(1, ge=1), page_size: int = Query(12, ge=1, le=50),
         status: Literal["ACTIVE", "COMPLETED", "CANCELLED"] | None = None,
         user: User = Depends(require_roles(*PARTIES)), db: Session = Depends(get_db)):
    return ok(svc.list_mine(db, user, page, page_size, status))


@router.get("/trainings/summary")  # declared before /trainings/{tid} so "summary" is not parsed as an id
def summary(user: User = Depends(require_roles(*PARTIES)), db: Session = Depends(get_db)):
    return ok(svc.summary(db, user))


@router.get("/trainings/{tid}")
def detail(tid: int, user: User = Depends(require_roles(*PARTIES)), db: Session = Depends(get_db)):
    t, role = svc.get_training(db, user, tid)
    return ok(svc.training_out(t, role))


@router.patch("/trainings/{tid}/dates")
def dates(tid: int, body: TrainingDatesIn, user: User = Depends(require_roles("INSTITUTION")), db: Session = Depends(get_db)):
    return ok(svc.update_dates(db, user, tid, body), "Training dates updated")


@router.patch("/trainings/{tid}/details")
def details(tid: int, body: TrainingDetailsIn, user: User = Depends(require_roles(*PARTIES)), db: Session = Depends(get_db)):
    return ok(svc.update_details(db, user, tid, body.meeting_link), "Training details updated")


@router.patch("/trainings/{tid}/planned-sessions")
def planned_sessions(tid: int, body: PlannedSessionsIn, user: User = Depends(require_roles("INSTITUTION")), db: Session = Depends(get_db)):
    return ok(svc.update_planned_sessions(db, user, tid, body.planned_sessions), "Planned sessions updated")


@router.post("/trainings/{tid}/complete")
def complete(tid: int, user: User = Depends(require_roles("INSTITUTION")), db: Session = Depends(get_db)):
    return ok(svc.complete(db, user, tid), "Training completed")


@router.post("/trainings/{tid}/cancel")
def cancel(tid: int, body: CancelIn, user: User = Depends(require_roles(*PARTIES)), db: Session = Depends(get_db)):
    return ok(svc.cancel(db, user, tid, body.reason), "Training cancelled")


@router.post("/trainings/{tid}/sessions", status_code=201)
def create_session(tid: int, body: SessionIn, user: User = Depends(require_roles(*PARTIES)), db: Session = Depends(get_db)):
    return ok(svc.create_session(db, user, tid, body), "Session scheduled")


@router.patch("/sessions/{sid}")
def update_session(sid: int, body: SessionUpdateIn, user: User = Depends(require_roles(*PARTIES)), db: Session = Depends(get_db)):
    return ok(svc.update_session(db, user, sid, body), "Session updated")


@router.post("/sessions/{sid}/status")
def session_status(sid: int, body: SessionStatusIn, user: User = Depends(require_roles(*PARTIES)), db: Session = Depends(get_db)):
    return ok(svc.set_session_status(db, user, sid, body.status), "Session updated")


@router.put("/sessions/{sid}/notes")
def notes(sid: int, body: SessionNotesIn, user: User = Depends(require_roles("TRAINER")), db: Session = Depends(get_db)):
    return ok(svc.update_notes(db, user, sid, body.notes), "Notes saved")


@router.put("/sessions/{sid}/attendance")
def attendance(sid: int, body: AttendanceIn, user: User = Depends(require_roles("TRAINER")), db: Session = Depends(get_db)):
    return ok(svc.record_attendance(db, user, sid, body), "Attendance saved")


@router.get("/calendar")
def calendar(start: date, end: date, user: User = Depends(require_roles(*PARTIES)), db: Session = Depends(get_db)):
    return ok(calendar_service.events(db, user, start, end))
