from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.api.deps import current_user
from app.core.database import get_db
from app.models.user import User
from app.schemas.auth import LoginIn, RefreshIn, RegisterIn, UserOut
from app.services import auth_service as svc

router = APIRouter(prefix="/auth", tags=["auth"])


def _run(fn, *args):
    try:
        return {"success": True, "message": "OK", "data": fn(*args).model_dump()}
    except svc.AuthError as e:
        raise HTTPException(e.status, e.message)


@router.post("/register", status_code=201)
def register(body: RegisterIn, db: Session = Depends(get_db)):
    return _run(svc.register, db, body)


@router.post("/login")
def login(body: LoginIn, db: Session = Depends(get_db)):
    return _run(svc.login, db, body)


@router.post("/refresh")
def refresh(body: RefreshIn, db: Session = Depends(get_db)):
    return _run(svc.refresh, db, body.refresh_token)


@router.get("/me")
def me(user: User = Depends(current_user)):
    return {"success": True, "message": "OK", "data": UserOut.model_validate(user).model_dump()}
