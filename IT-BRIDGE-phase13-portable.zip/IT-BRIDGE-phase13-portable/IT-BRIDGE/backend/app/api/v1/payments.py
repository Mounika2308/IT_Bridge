"""Payments, invoices and trainer earnings (Phase 13). Static paths are declared before the `{pid}` ones so they are not parsed as ids.

Who may call what:
  INSTITUTION  create / list / read / cancel its own payments, read its own invoices, simulate a result in the SANDBOX (development/test only)
  TRAINER      read its own earnings
  ADMIN        refund a payment, record a payout, resolve a review flag, list payments and earnings
  (nobody)     there is no endpoint that sets a payment's status; results arrive only through POST /payments/webhook (signed by the provider)
"""
from fastapi import APIRouter, Depends, Header, Query, Request, Response
from sqlalchemy.orm import Session

from app.api.deps import require_roles
from app.core.database import get_db
from app.models.user import User
from app.schemas.payment import EarningStatus, PaymentCreateIn, PaymentStatus, PayoutIn, RefundIn, ReviewResolveIn, SandboxOutcome
from app.services import earning_service, invoice_service, payment_admin_service as admin_svc, payment_providers as providers, payment_service as svc
from app.services.payment_service import PaymentError

router = APIRouter(tags=["payments"])


def ok(data, message="OK"):
    return {"success": True, "message": message, "data": data}


MAX_WEBHOOK_BYTES = 64 * 1024


async def raw_body(request: Request) -> bytes:
    """The raw bytes (the signature covers them). This endpoint is open to the internet, so the body is never buffered beyond the limit: a declared
    Content-Length over the limit is refused before anything is read, and a body without one (chunked) is read piece by piece and refused as
    soon as it passes the limit, instead of being held in memory in full first."""
    declared = request.headers.get("content-length")
    if declared and declared.isascii() and declared.isdigit() and int(declared) > MAX_WEBHOOK_BYTES:
        raise PaymentError(413, "TOO_LARGE", "Webhook body too large")
    body = bytearray()
    async for chunk in request.stream():
        body += chunk
        if len(body) > MAX_WEBHOOK_BYTES:
            raise PaymentError(413, "TOO_LARGE", "Webhook body too large")
    return bytes(body)


# ----- provider -> us. Authenticated by the signature, not by a login. -----
@router.post("/payments/webhook")
def webhook(body: bytes = Depends(raw_body), signature: str | None = Header(default=None, alias=providers.SIGNATURE_HEADER),
            timestamp: str | None = Header(default=None, alias=providers.TIMESTAMP_HEADER), db: Session = Depends(get_db)):
    return ok(svc.handle_webhook(db, body, signature, timestamp), "Event processed")


# ----- institution -----
@router.get("/payments")
def list_payments(page: int = Query(1, ge=1), page_size: int = Query(10, ge=1, le=50), status: PaymentStatus | None = None,
                  user: User = Depends(require_roles("INSTITUTION")), db: Session = Depends(get_db)):
    return ok(svc.list_payments(db, user, page, page_size, status))


@router.get("/payments/summary")
def payments_summary(user: User = Depends(require_roles("INSTITUTION")), db: Session = Depends(get_db)):
    return ok(svc.payment_summary(db, user))


@router.get("/payments/{pid}")
def get_payment(pid: int, user: User = Depends(require_roles("INSTITUTION")), db: Session = Depends(get_db)):
    return ok(svc.get_payment(db, user, pid))


@router.post("/trainings/{tid}/payments")
def create_payment(tid: int, body: PaymentCreateIn, response: Response, idempotency_key: str | None = Header(default=None, alias="Idempotency-Key"),
                   user: User = Depends(require_roles("INSTITUTION")), db: Session = Depends(get_db)):
    data, created = svc.create_payment(db, user, tid, body.amount_paise, idempotency_key)
    response.status_code = 201 if created else 200
    return ok(data, "Payment started" if created else "This request was already received")


@router.post("/payments/{pid}/cancel")
def cancel_payment(pid: int, user: User = Depends(require_roles("INSTITUTION")), db: Session = Depends(get_db)):
    return ok(svc.cancel_payment(db, user, pid), "Payment cancelled")


@router.post("/payments/{pid}/sandbox/{outcome}")
def sandbox(pid: int, outcome: SandboxOutcome, user: User = Depends(require_roles("INSTITUTION")), db: Session = Depends(get_db)):
    """Development and test only (403 otherwise). Sends a signed event through the same path as a real provider's webhook."""
    return ok(svc.simulate(db, user, pid, outcome), "Sandbox result sent. No real money was processed")


@router.get("/payments/{pid}/invoice")
def invoice(pid: int, user: User = Depends(require_roles("INSTITUTION")), db: Session = Depends(get_db)):
    return ok(invoice_service.view(db, user, pid))


@router.get("/trainings/{tid}/payment-summary")
def training_payment_summary(tid: int, user: User = Depends(require_roles("INSTITUTION", "TRAINER")), db: Session = Depends(get_db)):
    return ok(svc.training_summary(db, user, tid))


# ----- trainer -----
@router.get("/earnings/summary")
def earnings_summary(user: User = Depends(require_roles("TRAINER")), db: Session = Depends(get_db)):
    return ok(earning_service.summary(db, user))


@router.get("/earnings")
def list_earnings(page: int = Query(1, ge=1), page_size: int = Query(10, ge=1, le=50), status: EarningStatus | None = None,
                  user: User = Depends(require_roles("TRAINER")), db: Session = Depends(get_db)):
    return ok(earning_service.list_mine(db, user, page, page_size, status))


# ----- administrator -----
@router.get("/admin/payments")
def admin_payments(page: int = Query(1, ge=1), page_size: int = Query(20, ge=1, le=100), status: PaymentStatus | None = None, needs_review: bool | None = None,
                   _: User = Depends(require_roles("ADMIN")), db: Session = Depends(get_db)):
    return ok(admin_svc.list_payments(db, page, page_size, status, needs_review))


@router.post("/admin/payments/{pid}/refund")
def admin_refund(pid: int, body: RefundIn, admin: User = Depends(require_roles("ADMIN")), db: Session = Depends(get_db)):
    """Full refund only. Repeating the request resumes or reports the same refund; it can never refund twice."""
    refund, done = admin_svc.request_refund(db, admin, pid, body.reason)
    return ok(refund, "Refund completed" if done else "Refund started")


@router.post("/admin/payments/{pid}/resolve-review")
def admin_resolve(pid: int, body: ReviewResolveIn, admin: User = Depends(require_roles("ADMIN")), db: Session = Depends(get_db)):
    return ok(admin_svc.resolve_review(db, admin, pid, body.note, body.reason), "Review resolved")


@router.get("/admin/earnings")
def admin_earnings(page: int = Query(1, ge=1), page_size: int = Query(20, ge=1, le=100), status: EarningStatus | None = None,
                   _: User = Depends(require_roles("ADMIN")), db: Session = Depends(get_db)):
    return ok(admin_svc.list_earnings(db, page, page_size, status))


@router.post("/admin/earnings/{eid}/payout")
def admin_payout(eid: int, body: PayoutIn, admin: User = Depends(require_roles("ADMIN")), db: Session = Depends(get_db)):
    """Records that the payout was made outside IT BRIDGE. Nothing is sent and no bank or UPI detail is accepted."""
    return ok(admin_svc.record_payout(db, admin, eid, body.reference), "Payout recorded")
