from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from app.api.deps import require_roles
from app.core.database import get_db
from app.models.user import User
from app.schemas.application import ApplyIn, HireIn, StatusIn
from app.services import application_service as svc

router = APIRouter(tags=["applications"])


def ok(data, message="OK"):
    return {"success": True, "message": message, "data": data}


@router.post("/requirements/{req_id}/apply", status_code=201)
def apply(req_id: int, body: ApplyIn, user: User = Depends(require_roles("TRAINER")), db: Session = Depends(get_db)):
    a = svc.apply(db, user, req_id, body)
    return ok(svc.application_out(db, a, "trainer"), "Application submitted")


@router.get("/applications/mine")
def mine(user: User = Depends(require_roles("TRAINER")), db: Session = Depends(get_db)):
    return ok(svc.list_for_trainer(db, user))


@router.post("/applications/{app_id}/withdraw")
def withdraw(app_id: int, user: User = Depends(require_roles("TRAINER")), db: Session = Depends(get_db)):
    return ok(svc.application_out(db, svc.withdraw(db, user, app_id), "trainer"), "Application withdrawn")


@router.get("/requirements/{req_id}/applications")
def for_requirement(req_id: int, status: str | None = Query(None, max_length=15),
                    user: User = Depends(require_roles("INSTITUTION")), db: Session = Depends(get_db)):
    return ok(svc.list_for_requirement(db, user, req_id, status))


@router.patch("/applications/{app_id}/status")
def change_status(app_id: int, body: StatusIn, user: User = Depends(require_roles("INSTITUTION")), db: Session = Depends(get_db)):
    a = svc.change_status(db, user, app_id, body.status, body.interview_at)
    return ok({"id": a.id, "status": a.status}, "Application updated")


@router.post("/applications/{app_id}/hire", status_code=201)
def hire(app_id: int, body: HireIn, user: User = Depends(require_roles("INSTITUTION")), db: Session = Depends(get_db)):
    return ok(svc.hiring_out(svc.hire(db, user, app_id, body), user), "Hiring request sent")


@router.get("/hiring-requests/mine")
def hiring_mine(user: User = Depends(require_roles("TRAINER", "INSTITUTION")), db: Session = Depends(get_db)):
    return ok(svc.list_hiring(db, user))


@router.post("/hiring-requests/{hid}/accept")
def accept(hid: int, user: User = Depends(require_roles("TRAINER")), db: Session = Depends(get_db)):
    return ok(svc.hiring_out(svc.respond(db, user, hid, True), user), "Hiring request accepted")


@router.post("/hiring-requests/{hid}/decline")
def decline(hid: int, user: User = Depends(require_roles("TRAINER")), db: Session = Depends(get_db)):
    return ok(svc.hiring_out(svc.respond(db, user, hid, False), user), "Hiring request declined")


@router.post("/hiring-requests/{hid}/cancel")
def cancel(hid: int, user: User = Depends(require_roles("INSTITUTION")), db: Session = Depends(get_db)):
    return ok(svc.hiring_out(svc.cancel(db, user, hid), user), "Hiring request cancelled")
