from datetime import date
from typing import Literal

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.api.deps import require_roles
from app.core.database import get_db
from app.models.matching import TrainerBusyPeriod
from app.models.user import User
from app.schemas.profile import BusyPeriodIn
from app.services import discovery_service, match_service

router = APIRouter(tags=["matching"])


def ok(data, message="OK"):
    return {"success": True, "message": message, "data": data}


@router.get("/trainers")
def search(q: str | None = Query(None, max_length=100), skill_id: int | None = None,
           location: str | None = Query(None, max_length=100), mode: Literal["ONLINE", "OFFLINE", "HYBRID"] | None = None,
           min_experience: int | None = Query(None, ge=0, le=60), max_fee: int | None = Query(None, ge=0),
           min_rating: float | None = Query(None, ge=1, le=5), verified_only: bool = False, has_certifications: bool = False, language: str | None = Query(None, max_length=40),
           available_from: date | None = None, available_to: date | None = None,
           page: int = Query(1, ge=1), page_size: int = Query(12, ge=1, le=50),
           _: User = Depends(require_roles("INSTITUTION", "ADMIN")), db: Session = Depends(get_db)):
    f = dict(min_rating=min_rating, q=q, skill_id=skill_id, location=location, mode=mode, min_experience=min_experience, max_fee=max_fee,
             verified_only=verified_only, has_certifications=has_certifications, language=language,
             available_from=available_from, available_to=available_to)
    return ok(discovery_service.search_trainers(db, f, page, page_size))


@router.get("/requirements/{req_id}/matches")
def matches(req_id: int, limit: int = Query(20, ge=1, le=50), user: User = Depends(require_roles("INSTITUTION")),
            db: Session = Depends(get_db)):
    return ok(match_service.matches_for_requirement(db, user, req_id, limit))


@router.get("/trainers/me/recommendations")
def recommendations(user: User = Depends(require_roles("TRAINER")), db: Session = Depends(get_db)):
    return ok(match_service.recommendations_for_trainer(db, user))


@router.get("/trainers/me/busy-periods")
def list_busy(user: User = Depends(require_roles("TRAINER")), db: Session = Depends(get_db)):
    rows = db.scalars(select(TrainerBusyPeriod).where(TrainerBusyPeriod.trainer_id == user.trainer_profile.id)
                      .order_by(TrainerBusyPeriod.start_date))
    return ok([{"id": b.id, "start_date": str(b.start_date), "end_date": str(b.end_date), "reason": b.reason} for b in rows])


@router.post("/trainers/me/busy-periods", status_code=201)
def add_busy(body: BusyPeriodIn, user: User = Depends(require_roles("TRAINER")), db: Session = Depends(get_db)):
    b = TrainerBusyPeriod(trainer_id=user.trainer_profile.id, **body.model_dump())
    db.add(b)
    db.commit()
    return ok({"id": b.id}, "Dates marked as unavailable")


@router.delete("/trainers/me/busy-periods/{bid}")
def delete_busy(bid: int, user: User = Depends(require_roles("TRAINER")), db: Session = Depends(get_db)):
    b = db.get(TrainerBusyPeriod, bid)
    if not b or b.trainer_id != user.trainer_profile.id:
        raise HTTPException(404, "Not found")
    db.delete(b)
    db.commit()
    return ok(None, "Removed")


@router.get("/admin/settings/matching-weights")
def get_weights(_: User = Depends(require_roles("ADMIN")), db: Session = Depends(get_db)):
    return ok(match_service.get_weights(db))


@router.put("/admin/settings/matching-weights")
def put_weights(body: dict[str, int], _: User = Depends(require_roles("ADMIN")), db: Session = Depends(get_db)):
    return ok(match_service.set_weights(db, body), "Matching weights updated")
