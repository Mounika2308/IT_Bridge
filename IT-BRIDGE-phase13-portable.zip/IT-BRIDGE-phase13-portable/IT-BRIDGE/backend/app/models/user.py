from datetime import datetime, timezone

from sqlalchemy import JSON, Boolean, Column, DateTime, ForeignKey, Integer, String, Table
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.database import Base


def _now():
    return datetime.now(timezone.utc)


trainer_skills = Table(
    "trainer_skills", Base.metadata,
    Column("trainer_id", ForeignKey("trainer_profiles.id", ondelete="CASCADE"), primary_key=True),
    Column("skill_id", ForeignKey("skills.id", ondelete="CASCADE"), primary_key=True),
)


class Skill(Base):
    __tablename__ = "skills"

    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(80), unique=True, index=True)
    category: Mapped[str | None] = mapped_column(String(80))
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)


class User(Base):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(primary_key=True)
    email: Mapped[str] = mapped_column(String(255), unique=True, index=True)
    password_hash: Mapped[str] = mapped_column(String(255))
    full_name: Mapped[str] = mapped_column(String(120))
    phone: Mapped[str | None] = mapped_column(String(20))
    role: Mapped[str] = mapped_column(String(20), index=True)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    email_verified: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)

    trainer_profile: Mapped["TrainerProfile | None"] = relationship(back_populates="user", uselist=False)
    institution_profile: Mapped["InstitutionProfile | None"] = relationship(back_populates="user", uselist=False)


class TrainerProfile(Base):
    __tablename__ = "trainer_profiles"

    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), unique=True)
    headline: Mapped[str | None] = mapped_column(String(160))
    about: Mapped[str | None] = mapped_column(String(2000))
    location: Mapped[str | None] = mapped_column(String(120), index=True)
    experience_years: Mapped[int | None] = mapped_column(Integer)
    training_mode: Mapped[str | None] = mapped_column(String(10))  # ONLINE | OFFLINE | HYBRID
    expected_fee: Mapped[int | None] = mapped_column(Integer)  # per day
    availability: Mapped[str | None] = mapped_column(String(300))
    languages: Mapped[list] = mapped_column(JSON, default=list)
    education: Mapped[list] = mapped_column(JSON, default=list)
    certifications: Mapped[list] = mapped_column(JSON, default=list)
    verification_status: Mapped[str] = mapped_column(String(20), default="PENDING")

    user: Mapped[User] = relationship(back_populates="trainer_profile")
    skills: Mapped[list[Skill]] = relationship(secondary=trainer_skills)


class InstitutionProfile(Base):
    __tablename__ = "institution_profiles"

    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), unique=True)
    institution_name: Mapped[str] = mapped_column(String(200))
    institution_type: Mapped[str | None] = mapped_column(String(40))
    location: Mapped[str | None] = mapped_column(String(120))
    about: Mapped[str | None] = mapped_column(String(2000))
    website: Mapped[str | None] = mapped_column(String(200))
    verification_status: Mapped[str] = mapped_column(String(20), default="PENDING")

    user: Mapped[User] = relationship(back_populates="institution_profile")
