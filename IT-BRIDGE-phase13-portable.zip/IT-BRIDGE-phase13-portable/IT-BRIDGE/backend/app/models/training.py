from datetime import date, datetime, time, timezone

from sqlalchemy import Date, DateTime, ForeignKey, Integer, String, Time
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.database import Base
from app.models.application import HiringRequest
from app.models.user import InstitutionProfile, TrainerProfile


def _now():
    return datetime.now(timezone.utc)


class Training(Base):
    __tablename__ = "trainings"

    id: Mapped[int] = mapped_column(primary_key=True)
    hiring_request_id: Mapped[int] = mapped_column(ForeignKey("hiring_requests.id", ondelete="CASCADE"), unique=True)
    requirement_id: Mapped[int] = mapped_column(ForeignKey("training_requirements.id", ondelete="CASCADE"), index=True)
    trainer_id: Mapped[int] = mapped_column(ForeignKey("trainer_profiles.id", ondelete="CASCADE"), index=True)
    institution_id: Mapped[int] = mapped_column(ForeignKey("institution_profiles.id", ondelete="CASCADE"), index=True)
    title: Mapped[str] = mapped_column(String(160))
    # Snapshot taken when the hiring request is accepted: later edits to the requirement never change an agreed training.
    technology: Mapped[str] = mapped_column(String(80))
    mode: Mapped[str] = mapped_column(String(10))            # ONLINE | OFFLINE | HYBRID
    location: Mapped[str] = mapped_column(String(120))
    description: Mapped[str] = mapped_column(String(4000))
    terms: Mapped[str | None] = mapped_column(String(2000))  # from the hiring request
    meeting_link: Mapped[str | None] = mapped_column(String(300))  # online/hybrid trainings only; set by either party
    status: Mapped[str] = mapped_column(String(10), default="ACTIVE", index=True)  # ACTIVE | COMPLETED | CANCELLED
    start_date: Mapped[date] = mapped_column(Date)
    end_date: Mapped[date] = mapped_column(Date)
    agreed_fee: Mapped[int] = mapped_column(Integer)
    student_count: Mapped[int] = mapped_column(Integer)
    planned_sessions: Mapped[int] = mapped_column(Integer)
    cancel_reason: Mapped[str | None] = mapped_column(String(500))
    completed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)

    hiring_request: Mapped[HiringRequest] = relationship()
    trainer: Mapped[TrainerProfile] = relationship()
    institution: Mapped[InstitutionProfile] = relationship()
    sessions: Mapped[list["TrainingSession"]] = relationship(
        back_populates="training",
        order_by=lambda: (TrainingSession.session_date, TrainingSession.start_time))


class TrainingSession(Base):
    __tablename__ = "training_sessions"

    id: Mapped[int] = mapped_column(primary_key=True)
    training_id: Mapped[int] = mapped_column(ForeignKey("trainings.id", ondelete="CASCADE"), index=True)
    title: Mapped[str] = mapped_column(String(120))
    session_date: Mapped[date] = mapped_column(Date, index=True)
    start_time: Mapped[time] = mapped_column(Time)
    end_time: Mapped[time] = mapped_column(Time)
    status: Mapped[str] = mapped_column(String(10), default="SCHEDULED")  # SCHEDULED | ONGOING | COMPLETED | CANCELLED
    notes: Mapped[str | None] = mapped_column(String(1000))  # session-level notes, written by the trainer

    training: Mapped[Training] = relationship(back_populates="sessions")
    attendance: Mapped["Attendance | None"] = relationship(back_populates="session", uselist=False, cascade="all, delete-orphan")


class Attendance(Base):
    """Headcount per session. Per-student and QR attendance can extend this later without changing sessions."""
    __tablename__ = "attendance"

    id: Mapped[int] = mapped_column(primary_key=True)
    session_id: Mapped[int] = mapped_column(ForeignKey("training_sessions.id", ondelete="CASCADE"), unique=True)
    total_students: Mapped[int] = mapped_column(Integer)
    present: Mapped[int] = mapped_column(Integer)
    absent: Mapped[int] = mapped_column(Integer)
    notes: Mapped[str | None] = mapped_column(String(1000))  # deprecated: notes now live on the session (kept so no data is lost)
    recorded_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)

    session: Mapped[TrainingSession] = relationship(back_populates="attendance")
