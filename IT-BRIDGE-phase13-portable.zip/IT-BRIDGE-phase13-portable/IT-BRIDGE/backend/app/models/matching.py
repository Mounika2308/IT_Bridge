from datetime import date, datetime, timezone

from sqlalchemy import JSON, Date, DateTime, ForeignKey, Integer, String, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column

from app.core.database import Base


class PlatformSetting(Base):
    __tablename__ = "platform_settings"

    key: Mapped[str] = mapped_column(String(80), primary_key=True)
    value: Mapped[dict] = mapped_column(JSON)


class TrainerBusyPeriod(Base):
    """Dates the trainer cannot take training. Active trainings will add to this in a later phase."""
    __tablename__ = "trainer_busy_periods"

    id: Mapped[int] = mapped_column(primary_key=True)
    trainer_id: Mapped[int] = mapped_column(ForeignKey("trainer_profiles.id", ondelete="CASCADE"), index=True)
    start_date: Mapped[date] = mapped_column(Date)
    end_date: Mapped[date] = mapped_column(Date)
    reason: Mapped[str | None] = mapped_column(String(120))


class MatchScore(Base):
    """Stored result of the matching engine so every score can be audited and explained later."""
    __tablename__ = "match_scores"
    __table_args__ = (UniqueConstraint("requirement_id", "trainer_id", name="uq_match_pair"),)

    id: Mapped[int] = mapped_column(primary_key=True)
    requirement_id: Mapped[int] = mapped_column(ForeignKey("training_requirements.id", ondelete="CASCADE"), index=True)
    trainer_id: Mapped[int] = mapped_column(ForeignKey("trainer_profiles.id", ondelete="CASCADE"), index=True)
    score: Mapped[int] = mapped_column(Integer)
    factors: Mapped[list] = mapped_column(JSON)
    weights: Mapped[dict] = mapped_column(JSON)
    computed_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
