"""Payments, invoices, refunds and trainer earnings (Phase 13).

All money is an integer number of paise (BigInteger). Financial rows are never deleted (ON DELETE RESTRICT everywhere) and the
invariants that must hold even if the service has a bug are database constraints, not just service checks:
  * one payment in flight per training (partial unique index), one attempt number per training, scoped idempotency keys
  * amount > 0, 0 <= commission <= amount, net = amount - commission, whitelisted statuses
  * one CHARGE and at most one REFUND transaction per payment, one invoice / earning / commission record / refund per payment
  * a processed provider event id can never be stored twice
PostgreSQL row locks (SELECT ... FOR UPDATE) serialise the read-then-write steps in the service; SQLite ignores them.
"""
from datetime import datetime, timezone

from sqlalchemy import JSON, BigInteger, CheckConstraint, DateTime, ForeignKey, Index, Integer, String, UniqueConstraint, text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.database import Base
from app.models.training import Training
from app.models.user import InstitutionProfile, TrainerProfile, User


def _now():
    return datetime.now(timezone.utc)


_IN_FLIGHT = text("status IN ('PENDING', 'PROCESSING')")
_OPEN = text("resolved_at IS NULL")


class Payment(Base):
    """One payment ATTEMPT by an institution for one training. A retry is a new row (attempt_no + 1)."""
    __tablename__ = "payments"
    __table_args__ = (
        UniqueConstraint("provider", "provider_order_id", name="uq_payment_provider_order"),
        UniqueConstraint("payer_user_id", "idempotency_key", name="uq_payment_idempotency"),
        UniqueConstraint("training_id", "attempt_no", name="uq_payment_attempt"),
        Index("ix_payments_training_status", "training_id", "status"),
        Index("uq_payment_one_in_flight", "training_id", unique=True, postgresql_where=_IN_FLIGHT, sqlite_where=_IN_FLIGHT),
        CheckConstraint("amount_paise > 0", name="ck_payment_amount_positive"),
        CheckConstraint("platform_fee_paise >= 0 AND platform_fee_paise <= amount_paise", name="ck_payment_fee_range"),
        CheckConstraint("net_paise = amount_paise - platform_fee_paise", name="ck_payment_net"),
        CheckConstraint("commission_bps >= 0 AND commission_bps <= 10000", name="ck_payment_bps"),
        CheckConstraint("attempt_no >= 1", name="ck_payment_attempt_no"),
        CheckConstraint("currency = 'INR'", name="ck_payment_currency"),
        CheckConstraint("status IN ('PENDING', 'PROCESSING', 'SUCCEEDED', 'FAILED', 'CANCELLED', 'EXPIRED')", name="ck_payment_status"),
        CheckConstraint("status <> 'SUCCEEDED' OR paid_at IS NOT NULL", name="ck_payment_paid_at"),
    )

    id: Mapped[int] = mapped_column(primary_key=True)
    training_id: Mapped[int] = mapped_column(ForeignKey("trainings.id", ondelete="RESTRICT"), index=True)
    institution_id: Mapped[int] = mapped_column(ForeignKey("institution_profiles.id", ondelete="RESTRICT"), index=True)
    trainer_id: Mapped[int] = mapped_column(ForeignKey("trainer_profiles.id", ondelete="RESTRICT"), index=True)
    payer_user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="RESTRICT"), index=True)
    attempt_no: Mapped[int] = mapped_column(Integer)
    amount_paise: Mapped[int] = mapped_column(BigInteger)
    currency: Mapped[str] = mapped_column(String(3))
    commission_bps: Mapped[int] = mapped_column(Integer)           # the rate snapshot used for this payment
    platform_fee_paise: Mapped[int] = mapped_column(BigInteger)    # commission, taken out of the trainer's share
    net_paise: Mapped[int] = mapped_column(BigInteger)             # the trainer's share
    status: Mapped[str] = mapped_column(String(12), index=True)
    provider: Mapped[str] = mapped_column(String(20))
    provider_order_id: Mapped[str] = mapped_column(String(80))
    provider_meta: Mapped[dict | None] = mapped_column(JSON)      # provider-side notes; never card or bank details
    idempotency_key: Mapped[str | None] = mapped_column(String(80))
    request_fingerprint: Mapped[str] = mapped_column(String(64))
    failure_reason: Mapped[str | None] = mapped_column(String(200))
    needs_review: Mapped[bool] = mapped_column(default=False)
    review_reason: Mapped[str | None] = mapped_column(String(30))
    review_note: Mapped[str | None] = mapped_column(String(500))
    reviewed_by: Mapped[int | None] = mapped_column(ForeignKey("users.id", ondelete="RESTRICT"))
    reviewed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    expires_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now, onupdate=_now)
    paid_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))

    training: Mapped[Training] = relationship()
    institution: Mapped[InstitutionProfile] = relationship()
    trainer: Mapped[TrainerProfile] = relationship()
    payer: Mapped[User] = relationship(foreign_keys=[payer_user_id])


class PaymentReviewFlag(Base):
    """One reason a payment is in front of an administrator. A payment can carry several different open reasons at once; each is its own row,
    resolved on its own with a note, and kept afterwards as history. `payments.needs_review` is only a summary of the open rows."""
    __tablename__ = "payment_review_flags"
    __table_args__ = (
        Index("uq_review_flag_open", "payment_id", "reason", unique=True, postgresql_where=_OPEN, sqlite_where=_OPEN),
        CheckConstraint("reason IN ('LATE_SUCCESS', 'OVER_CAP', 'DUPLICATE_CHARGE', 'AMOUNT_MISMATCH', 'CURRENCY_MISMATCH', 'TRAINING_CANCELLED', 'STUCK_PROCESSING', 'REFUND_STUCK')",
                        name="ck_review_flag_reason"),
        CheckConstraint("(resolved_at IS NULL) = (resolved_by IS NULL) AND (resolved_at IS NULL) = (resolution_note IS NULL)", name="ck_review_flag_resolution"),
    )

    id: Mapped[int] = mapped_column(primary_key=True)
    payment_id: Mapped[int] = mapped_column(ForeignKey("payments.id", ondelete="RESTRICT"), index=True)
    reason: Mapped[str] = mapped_column(String(30))
    note: Mapped[str | None] = mapped_column(String(500))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)
    resolved_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    resolved_by: Mapped[int | None] = mapped_column(ForeignKey("users.id", ondelete="RESTRICT"))
    resolution_note: Mapped[str | None] = mapped_column(String(500))


class PaymentTransaction(Base):
    """The money-movement ledger: one CHARGE per succeeded payment and at most one REFUND."""
    __tablename__ = "payment_transactions"
    __table_args__ = (
        UniqueConstraint("provider", "provider_txn_id", name="uq_payment_txn_provider"),
        UniqueConstraint("payment_id", "type", name="uq_payment_txn_type"),
        CheckConstraint("amount_paise > 0", name="ck_txn_amount_positive"),
        CheckConstraint("type IN ('CHARGE', 'REFUND')", name="ck_txn_type"),
    )

    id: Mapped[int] = mapped_column(primary_key=True)
    payment_id: Mapped[int] = mapped_column(ForeignKey("payments.id", ondelete="RESTRICT"), index=True)
    type: Mapped[str] = mapped_column(String(8))
    amount_paise: Mapped[int] = mapped_column(BigInteger)
    provider: Mapped[str] = mapped_column(String(20))
    provider_txn_id: Mapped[str] = mapped_column(String(160))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)


class PaymentWebhookEvent(Base):
    """Every provider event that reached the trusted processing path, with what it did. The unique key makes a replay a no-op,
    and the stored payload is the evidence if a charge ever has to be investigated."""
    __tablename__ = "payment_webhook_events"
    __table_args__ = (UniqueConstraint("provider", "event_id", name="uq_webhook_event"),)

    id: Mapped[int] = mapped_column(primary_key=True)
    provider: Mapped[str] = mapped_column(String(20))
    event_id: Mapped[str] = mapped_column(String(80))
    event_type: Mapped[str] = mapped_column(String(40))
    payment_id: Mapped[int | None] = mapped_column(ForeignKey("payments.id", ondelete="RESTRICT"), index=True)
    outcome: Mapped[str] = mapped_column(String(30))
    payload: Mapped[dict] = mapped_column(JSON)
    source: Mapped[str] = mapped_column(String(12))              # WEBHOOK | RECONCILE
    received_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)


class Invoice(Base):
    """An IT BRIDGE platform invoice for one successful payment. Immutable: no code path updates it. NOT a GST or tax invoice."""
    __tablename__ = "invoices"
    __table_args__ = (
        UniqueConstraint("payment_id", name="uq_invoice_payment"),
        UniqueConstraint("number", name="uq_invoice_number"),
        CheckConstraint("amount_paise > 0", name="ck_invoice_amount_positive"),
    )

    id: Mapped[int] = mapped_column(primary_key=True)
    payment_id: Mapped[int] = mapped_column(ForeignKey("payments.id", ondelete="RESTRICT"))
    number: Mapped[str] = mapped_column(String(24))
    institution_id: Mapped[int] = mapped_column(ForeignKey("institution_profiles.id", ondelete="RESTRICT"), index=True)
    trainer_id: Mapped[int] = mapped_column(ForeignKey("trainer_profiles.id", ondelete="RESTRICT"), index=True)
    training_id: Mapped[int] = mapped_column(ForeignKey("trainings.id", ondelete="RESTRICT"), index=True)
    amount_paise: Mapped[int] = mapped_column(BigInteger)
    currency: Mapped[str] = mapped_column(String(3))
    snapshot: Mapped[dict] = mapped_column(JSON)                 # names and the training as they were when it was issued
    issued_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)


class InvoiceCounter(Base):
    """Allocates invoice and credit-note numbers: one locked row per (series, year)."""
    __tablename__ = "invoice_counters"

    series: Mapped[str] = mapped_column(String(4), primary_key=True)   # INV | CN
    year: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=False)
    last_number: Mapped[int] = mapped_column(Integer)


class PaymentRefund(Base):
    """A full refund of one payment. Its own record (with its own credit-note number); the invoice is never rewritten.
    Created PENDING before the provider is called, so a crash between the two steps is recoverable by retrying with the same key."""
    __tablename__ = "payment_refunds"
    __table_args__ = (
        UniqueConstraint("payment_id", name="uq_refund_payment"),
        UniqueConstraint("idempotency_key", name="uq_refund_idempotency"),
        UniqueConstraint("credit_note_number", name="uq_refund_credit_note"),
        CheckConstraint("amount_paise > 0", name="ck_refund_amount_positive"),
        CheckConstraint("status IN ('PENDING', 'SUCCEEDED')", name="ck_refund_status"),
        CheckConstraint("status <> 'SUCCEEDED' OR (completed_at IS NOT NULL AND credit_note_number IS NOT NULL)", name="ck_refund_completed"),
    )

    id: Mapped[int] = mapped_column(primary_key=True)
    payment_id: Mapped[int] = mapped_column(ForeignKey("payments.id", ondelete="RESTRICT"))
    amount_paise: Mapped[int] = mapped_column(BigInteger)
    reason: Mapped[str | None] = mapped_column(String(300))
    status: Mapped[str] = mapped_column(String(10))
    idempotency_key: Mapped[str] = mapped_column(String(80))
    credit_note_number: Mapped[str | None] = mapped_column(String(24))
    attempts: Mapped[int] = mapped_column(Integer, default=0)
    last_error: Mapped[str | None] = mapped_column(String(200))
    created_by: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="RESTRICT"))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)
    completed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))


class TrainerEarning(Base):
    """The trainer's share of one successful payment: PENDING -> AVAILABLE (training completed) -> PAID (payout recorded),
    or REFUNDED. No bank or UPI details exist anywhere; payout_reference is the operator's own note."""
    __tablename__ = "trainer_earnings"
    __table_args__ = (
        UniqueConstraint("payment_id", name="uq_earning_payment"),
        CheckConstraint("gross_paise > 0", name="ck_earning_gross_positive"),
        CheckConstraint("commission_paise >= 0 AND commission_paise <= gross_paise", name="ck_earning_commission_range"),
        CheckConstraint("net_paise = gross_paise - commission_paise", name="ck_earning_net"),
        CheckConstraint("status IN ('PENDING', 'AVAILABLE', 'PAID', 'REFUNDED')", name="ck_earning_status"),
        CheckConstraint("status NOT IN ('AVAILABLE', 'PAID') OR available_at IS NOT NULL", name="ck_earning_available_at"),
        CheckConstraint("status <> 'PAID' OR (paid_at IS NOT NULL AND paid_by IS NOT NULL AND payout_reference IS NOT NULL)", name="ck_earning_paid_fields"),
        CheckConstraint("status = 'PAID' OR paid_at IS NULL", name="ck_earning_paid_only"),
    )

    id: Mapped[int] = mapped_column(primary_key=True)
    payment_id: Mapped[int] = mapped_column(ForeignKey("payments.id", ondelete="RESTRICT"))
    trainer_id: Mapped[int] = mapped_column(ForeignKey("trainer_profiles.id", ondelete="RESTRICT"), index=True)
    training_id: Mapped[int] = mapped_column(ForeignKey("trainings.id", ondelete="RESTRICT"), index=True)
    gross_paise: Mapped[int] = mapped_column(BigInteger)
    commission_paise: Mapped[int] = mapped_column(BigInteger)
    net_paise: Mapped[int] = mapped_column(BigInteger)
    status: Mapped[str] = mapped_column(String(10), index=True)
    available_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    paid_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    paid_by: Mapped[int | None] = mapped_column(ForeignKey("users.id", ondelete="RESTRICT"))
    payout_reference: Mapped[str | None] = mapped_column(String(80))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now, onupdate=_now)

    payment: Mapped[Payment] = relationship()
    training: Mapped[Training] = relationship()


class PlatformCommission(Base):
    """The platform's commission on one successful payment (REVERSED by a refund)."""
    __tablename__ = "platform_commissions"
    __table_args__ = (
        UniqueConstraint("payment_id", name="uq_commission_payment"),
        CheckConstraint("amount_paise >= 0", name="ck_commission_amount"),
        CheckConstraint("rate_bps >= 0 AND rate_bps <= 10000", name="ck_commission_rate"),
        CheckConstraint("status IN ('RECORDED', 'REVERSED')", name="ck_commission_status"),
        CheckConstraint("(status = 'REVERSED') = (reversed_at IS NOT NULL)", name="ck_commission_reversed_at"),
    )

    id: Mapped[int] = mapped_column(primary_key=True)
    payment_id: Mapped[int] = mapped_column(ForeignKey("payments.id", ondelete="RESTRICT"))
    rate_bps: Mapped[int] = mapped_column(Integer)
    amount_paise: Mapped[int] = mapped_column(BigInteger)
    status: Mapped[str] = mapped_column(String(10))
    reversed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)
