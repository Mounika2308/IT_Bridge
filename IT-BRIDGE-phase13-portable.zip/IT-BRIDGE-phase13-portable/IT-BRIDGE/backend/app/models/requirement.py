from datetime import date, datetime, timezone

from sqlalchemy import Boolean, Column, Date, DateTime, ForeignKey, Index, Integer, String, Table
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.database import Base
from app.models.user import InstitutionProfile, Skill

requirement_skills = Table(
    "requirement_skills", Base.metadata,
    Column("requirement_id", ForeignKey("training_requirements.id", ondelete="CASCADE"), primary_key=True),
    Column("skill_id", ForeignKey("skills.id", ondelete="CASCADE"), primary_key=True),
)


class Category(Base):
    __tablename__ = "categories"

    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(80), unique=True)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)


class TrainingRequirement(Base):
    __tablename__ = "training_requirements"
    __table_args__ = (Index("ix_req_status_deadline", "status", "application_deadline"),)

    id: Mapped[int] = mapped_column(primary_key=True)
    institution_id: Mapped[int] = mapped_column(ForeignKey("institution_profiles.id", ondelete="CASCADE"), index=True)
    category_id: Mapped[int | None] = mapped_column(ForeignKey("categories.id"))
    title: Mapped[str] = mapped_column(String(160))
    technology: Mapped[str] = mapped_column(String(80), index=True)
    description: Mapped[str] = mapped_column(String(4000))
    student_count: Mapped[int] = mapped_column(Integer)
    student_level: Mapped[str] = mapped_column(String(15))
    duration_days: Mapped[int] = mapped_column(Integer)
    sessions: Mapped[int] = mapped_column(Integer)
    location: Mapped[str] = mapped_column(String(120), index=True)
    mode: Mapped[str] = mapped_column(String(10))
    start_date: Mapped[date] = mapped_column(Date)
    end_date: Mapped[date] = mapped_column(Date)
    preferred_experience_years: Mapped[int] = mapped_column(Integer, default=0)
    budget_min: Mapped[int] = mapped_column(Integer)
    budget_max: Mapped[int] = mapped_column(Integer)
    application_deadline: Mapped[date] = mapped_column(Date)
    additional_requirements: Mapped[str | None] = mapped_column(String(2000))
    status: Mapped[str] = mapped_column(String(10), default="OPEN")  # OPEN | CLOSED
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))

    institution: Mapped[InstitutionProfile] = relationship()
    category: Mapped[Category | None] = relationship()
    skills: Mapped[list[Skill]] = relationship(secondary=requirement_skills)
