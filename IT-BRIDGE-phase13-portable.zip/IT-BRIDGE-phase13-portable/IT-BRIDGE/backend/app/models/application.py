from datetime import date, datetime, timezone

from sqlalchemy import Date, DateTime, ForeignKey, Integer, String, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.database import Base
from app.models.requirement import TrainingRequirement
from app.models.user import TrainerProfile


def _now():
    return datetime.now(timezone.utc)


class Application(Base):
    __tablename__ = "applications"
    __table_args__ = (UniqueConstraint("requirement_id", "trainer_id", name="uq_application_pair"),)

    id: Mapped[int] = mapped_column(primary_key=True)
    requirement_id: Mapped[int] = mapped_column(ForeignKey("training_requirements.id", ondelete="CASCADE"), index=True)
    trainer_id: Mapped[int] = mapped_column(ForeignKey("trainer_profiles.id", ondelete="CASCADE"), index=True)
    cover_note: Mapped[str | None] = mapped_column(String(2000))
    proposed_fee: Mapped[int | None] = mapped_column(Integer)  # total, in rupees
    status: Mapped[str] = mapped_column(String(15), default="APPLIED", index=True)
    interview_at: Mapped[datetime | None] = mapped_column(DateTime)  # naive, platform-local; set when moved to INTERVIEW
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now, onupdate=_now)

    requirement: Mapped[TrainingRequirement] = relationship()
    trainer: Mapped[TrainerProfile] = relationship()


class HiringRequest(Base):
    __tablename__ = "hiring_requests"

    id: Mapped[int] = mapped_column(primary_key=True)
    application_id: Mapped[int] = mapped_column(ForeignKey("applications.id", ondelete="CASCADE"), unique=True)
    requirement_id: Mapped[int] = mapped_column(ForeignKey("training_requirements.id", ondelete="CASCADE"), index=True)
    trainer_id: Mapped[int] = mapped_column(ForeignKey("trainer_profiles.id", ondelete="CASCADE"), index=True)
    agreed_fee: Mapped[int] = mapped_column(Integer)
    start_date: Mapped[date] = mapped_column(Date)
    end_date: Mapped[date] = mapped_column(Date)
    sessions: Mapped[int] = mapped_column(Integer)
    terms: Mapped[str | None] = mapped_column(String(2000))
    # PENDING | ACCEPTED | DECLINED | CANCELLED now; ACTIVE | COMPLETED arrive with training management.
    status: Mapped[str] = mapped_column(String(10), default="PENDING", index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)
    responded_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))

    application: Mapped[Application] = relationship()
    requirement: Mapped[TrainingRequirement] = relationship()
    trainer: Mapped[TrainerProfile] = relationship()
