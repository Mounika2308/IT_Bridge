from datetime import datetime, timezone

from sqlalchemy import JSON, Boolean, DateTime, Float, ForeignKey, String, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column

from app.core.database import Base


class Review(Base):
    __tablename__ = "reviews"
    # One review per direction per completed engagement: duplicates are impossible at the database level.
    __table_args__ = (UniqueConstraint("training_id", "direction", name="uq_review_per_engagement"),)

    id: Mapped[int] = mapped_column(primary_key=True)
    training_id: Mapped[int] = mapped_column(ForeignKey("trainings.id", ondelete="CASCADE"), index=True)
    direction: Mapped[str] = mapped_column(String(25))  # INSTITUTION_TO_TRAINER | TRAINER_TO_INSTITUTION
    reviewer_user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"))
    trainer_id: Mapped[int] = mapped_column(ForeignKey("trainer_profiles.id", ondelete="CASCADE"), index=True)
    institution_id: Mapped[int] = mapped_column(ForeignKey("institution_profiles.id", ondelete="CASCADE"), index=True)
    ratings: Mapped[dict] = mapped_column(JSON)
    overall: Mapped[float] = mapped_column(Float)
    comment: Mapped[str | None] = mapped_column(String(2000))
    is_hidden: Mapped[bool] = mapped_column(Boolean, default=False)  # admin moderation (admin phase)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
