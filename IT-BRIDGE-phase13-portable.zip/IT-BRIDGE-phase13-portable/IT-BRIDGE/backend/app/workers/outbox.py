"""Sends queued external notifications (email). Run it from cron every minute or two, or let app.workers.loop do it.
It is safe to run more than once at the same time and to re-run after a crash (see delivery_service)."""
from app.services.delivery_service import process_pending


def run_once() -> dict:
    from app.core.database import SessionLocal
    with SessionLocal() as db:
        return process_pending(db)


if __name__ == "__main__":
    print(run_once())
