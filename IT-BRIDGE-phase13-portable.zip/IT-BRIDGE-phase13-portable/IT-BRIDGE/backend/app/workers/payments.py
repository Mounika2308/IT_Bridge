"""Payment reconciliation worker (Phase 13): asks the provider about attempts that are still open, expires abandoned ones, retries refunds that
were started but not completed, and makes trainer earnings available once their training is complete and the hold has elapsed.
Idempotent: run it as often as you like (every minute is fine) or let app.workers.loop do it. Usage: python -m app.workers.payments"""
import logging

log = logging.getLogger("itbridge.payments.worker")


def run_once() -> dict:
    from app.core.database import SessionLocal
    from app.core.payment_guard import assert_safe_payment_config
    assert_safe_payment_config()   # a worker must not run with a configuration the API would refuse
    from app.services.payment_service import reconcile
    with SessionLocal() as db:
        return reconcile(db)


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    print(run_once())
