"""Scheduled reminders. Idempotent: every reminder carries a dedupe key, so running this as often as you like never duplicates one.

  day_before : sessions and trainings that start tomorrow (platform date), to both parties
  interview  : interviews starting within INTERVIEW_REMINDER_HOURS, to both parties
  review     : ONE reminder per participant, REVIEW_REMINDER_DAYS after a training was completed, only if that participant has not reviewed it
               and may still review (active, not suspended). Trainings completed more than REVIEW_REMINDER_WINDOW_DAYS ago are ignored.

Schedule it with cron (see README): the interview kind every 15 minutes, the day_before kind once a day at 17:00 platform time, the review kind hourly.
Usage: python -m app.workers.reminders [--kind day_before|interview|review|all]"""
import argparse
from datetime import date, datetime, timedelta, timezone

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.clock import now as local_now
from app.core.clock import today as local_today
from app.core.config import settings
from app.models.application import Application
from app.models.review import Review
from app.models.training import Training, TrainingSession
from app.services.notification_service import notify_event
from app.services.notification_types import fmt_when
from app.services.review_service import INSTITUTION_DIR, TRAINER_DIR, cannot_review


def _day_before(db: Session, today: date | None) -> int:
    tomorrow = (today or local_today()) + timedelta(days=1)
    created = 0
    sessions = db.scalars(select(TrainingSession).join(Training, Training.id == TrainingSession.training_id)
                          .where(TrainingSession.session_date == tomorrow, TrainingSession.status == "SCHEDULED", Training.status == "ACTIVE"))
    for s in sessions:
        t = s.training
        for uid in (t.trainer.user_id, t.institution.user_id):
            if notify_event(db, uid, "SESSION_REMINDER", dedupe_key=f"session-reminder:{s.id}:{s.session_date}", session=s.title, title=t.title,
                            time=f"{s.start_time:%H:%M} to {s.end_time:%H:%M}", training_id=t.id):
                created += 1
    starting = db.scalars(select(Training).where(Training.start_date == tomorrow, Training.status == "ACTIVE"))
    for t in starting:
        for uid in (t.trainer.user_id, t.institution.user_id):
            if notify_event(db, uid, "TRAINING_REMINDER", dedupe_key=f"training-reminder:{t.id}:{t.start_date}", title=t.title, training_id=t.id):
                created += 1
    return created


def _interviews(db: Session, now: datetime | None) -> int:
    now = now or local_now()
    horizon = now + timedelta(hours=settings.interview_reminder_hours)
    created = 0
    rows = db.scalars(select(Application).where(Application.status == "INTERVIEW", Application.interview_at.is_not(None),
                                                Application.interview_at >= now, Application.interview_at <= horizon))
    for a in rows:
        key = f"interview-reminder:{a.id}:{a.interview_at:%Y%m%dT%H%M}"   # a rescheduled interview gets a new key, so a new reminder
        common = dict(requirement=a.requirement.title, when=fmt_when(a.interview_at))
        if notify_event(db, a.trainer.user_id, "INTERVIEW_REMINDER", dedupe_key=key, link="/trainer/applications", **common):
            created += 1
        if notify_event(db, a.requirement.institution.user_id, "INTERVIEW_REMINDER", dedupe_key=key,
                        link=f"/institution/requirements/{a.requirement_id}/applications", **common):
            created += 1
    return created


def _reviews(db: Session, now: datetime | None) -> int:
    """`now` is timezone-aware (UTC): completed_at is stored in UTC. Idempotent through review-reminder:{training}:{user}."""
    now = now or datetime.now(timezone.utc)
    due, oldest = now - timedelta(days=settings.review_reminder_days), now - timedelta(days=settings.review_reminder_window_days)
    trainings = list(db.scalars(select(Training).where(Training.status == "COMPLETED", Training.completed_at <= due, Training.completed_at >= oldest)))
    if not trainings:
        return 0
    reviewed = {(tid, d) for tid, d in db.execute(select(Review.training_id, Review.direction).where(Review.training_id.in_([t.id for t in trainings])))}
    created = 0
    for t in trainings:
        # (who, the direction they would write): the trainer writes TRAINER_TO_INSTITUTION, the institution INSTITUTION_TO_TRAINER
        for profile, direction in ((t.trainer, INSTITUTION_DIR), (t.institution, TRAINER_DIR)):
            if (t.id, direction) in reviewed or cannot_review(profile.user):
                continue
            if notify_event(db, profile.user_id, "REVIEW_REMINDER", dedupe_key=f"review-reminder:{t.id}:{profile.user_id}", training_id=t.id, title=t.title):
                created += 1
    return created


def send_reminders(db: Session, today: date | None = None, kinds: tuple[str, ...] = ("day_before", "interview", "review"), now: datetime | None = None,
                   utc_now: datetime | None = None) -> int:
    created = ((_day_before(db, today) if "day_before" in kinds else 0) + (_interviews(db, now) if "interview" in kinds else 0)
               + (_reviews(db, utc_now) if "review" in kinds else 0))
    db.commit()
    return created


if __name__ == "__main__":
    from app.core.database import SessionLocal
    parser = argparse.ArgumentParser()
    parser.add_argument("--kind", choices=["day_before", "interview", "review", "all"], default="all")
    args = parser.parse_args()
    with SessionLocal() as session:
        kinds = ("day_before", "interview", "review") if args.kind == "all" else (args.kind,)
        print(f"Created {send_reminders(session, kinds=kinds)} reminders")
