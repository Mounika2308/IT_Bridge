"""A tiny scheduler for development and single-host deployments: one process that runs the outbox, interview reminders and the
daily reminders at the right times. It is a convenience, not a job-queue architecture. Production may use cron instead (README).
Usage: python -m app.workers.loop"""
import logging
import time
from datetime import datetime

from app.core.clock import now as local_now
from app.core.config import settings

log = logging.getLogger("itbridge.worker")
OUTBOX_EVERY, INTERVIEW_EVERY, REVIEW_EVERY, PAYMENTS_EVERY = 30, 15 * 60, 60 * 60, 60  # seconds


def due_tasks(now: datetime, last: dict) -> list[str]:
    """Which tasks should run now. `last` maps task name to the time it last ran (and 'day_before_date' to a date)."""
    tasks = []
    if (now - last.get("outbox", datetime.min)).total_seconds() >= OUTBOX_EVERY:
        tasks.append("outbox")
    if (now - last.get("payments", datetime.min)).total_seconds() >= PAYMENTS_EVERY:   # also when payments are switched off: refunds, late results and earnings must still be finished
        tasks.append("payments")
    if (now - last.get("interview", datetime.min)).total_seconds() >= INTERVIEW_EVERY:
        tasks.append("interview")
    if (now - last.get("review", datetime.min)).total_seconds() >= REVIEW_EVERY:
        tasks.append("review")
    if now.hour >= settings.day_before_reminder_hour and last.get("day_before_date") != now.date():
        tasks.append("day_before")
    return tasks


def run_task(name: str) -> None:
    from app.core.database import SessionLocal
    from app.services.delivery_service import process_pending
    from app.workers.reminders import send_reminders
    with SessionLocal() as db:
        if name == "outbox":
            log.info("outbox: %s", process_pending(db))
        elif name == "payments":
            from app.services.payment_service import reconcile
            log.info("payments: %s", reconcile(db))
        else:
            log.info("%s reminders created: %s", name, send_reminders(db, kinds=(name,)))


def main() -> None:
    logging.basicConfig(level=logging.INFO)
    from app.core.payment_guard import assert_safe_payment_config
    assert_safe_payment_config()   # the loop runs the payment worker too: refuse an unsafe payment configuration here as the API does
    last: dict = {}
    while True:
        now = local_now()
        for name in due_tasks(now, last):
            try:
                run_task(name)
            except Exception:  # one failing task must not stop the others; it is retried on the next tick
                log.exception("task %s failed", name)
                continue
            last[name] = now
            if name == "day_before":
                last["day_before_date"] = now.date()
        time.sleep(5)


if __name__ == "__main__":
    main()
