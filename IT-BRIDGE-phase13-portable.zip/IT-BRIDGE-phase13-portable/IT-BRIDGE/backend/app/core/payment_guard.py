"""The start-up safety check for payments (Phase 13). One function, called by the API (main.py) AND by every worker entry point, so a
worker cannot run with a configuration the API would refuse. Pure decisions live in services/payment_rules.config_problems."""
from app.core.config import settings
from app.services import payment_rules


def payment_config_problems() -> list[str]:
    return payment_rules.config_problems(
        environment=settings.environment, enabled=settings.payments_enabled, provider=settings.payment_provider, secret=settings.payment_webhook_secret,
        commission_bps=settings.platform_commission_bps, commission_confirmed=settings.payment_commission_confirmed,
        sandbox_opt_in=settings.payment_sandbox_enabled)


def assert_safe_payment_config() -> None:
    """Refuses to start (RuntimeError) on a bad commission rate and on a missing or unknown ENVIRONMENT, whatever PAYMENTS_ENABLED says. In
    production it also refuses a missing, empty, weak or known-example PAYMENT_WEBHOOK_SECRET WHETHER OR NOT payments are enabled (13B.2), the
    sandbox opt-in, and with payments enabled the sandbox / unimplemented provider and an unconfirmed commission. Outside production, with payments
    enabled, the sandbox needs its explicit opt-in. Development and test accept any secret, including none."""
    problems = payment_config_problems()
    if problems:
        raise RuntimeError("Refusing to start with an unsafe payment configuration: " + "; ".join(problems))
