from enum import Enum


class Role(str, Enum):
    TRAINER = "TRAINER"
    INSTITUTION = "INSTITUTION"
    ADMIN = "ADMIN"
    # Reserved for future: SUPER_ADMIN, INSTITUTION_ADMIN, INSTITUTION_STAFF
