from datetime import date, datetime
from zoneinfo import ZoneInfo

from app.core.config import settings


def now() -> datetime:
    """Current wall-clock time in the platform timezone, as a naive datetime (session and interview times are stored the same way)."""
    return datetime.now(ZoneInfo(settings.app_timezone)).replace(tzinfo=None)


def today() -> date:
    """Today's date in the platform timezone (APP_TIMEZONE), not the server's."""
    return datetime.now(ZoneInfo(settings.app_timezone)).date()
