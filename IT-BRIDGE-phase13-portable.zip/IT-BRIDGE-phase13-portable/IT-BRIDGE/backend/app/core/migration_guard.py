"""Downgrade safety for the Alembic migrations (Phase 13 follow-up).

THE PROBLEM. A downgrade runs the `downgrade()` of every revision between the database's current revision and the target, newest first. Before this
module each destructive step guarded only itself (0001, 0005 and 0006), 0002 / 0003 / 0004 had no guard, and a guard that refused part-way had
already let the steps above it run. On PostgreSQL the whole command is one transaction (alembic/env.py has a single `context.begin_transaction()` and
`PostgresqlImpl.transactional_ddl` is True), so a late refusal rolls the earlier steps back. On SQLite (`SQLiteImpl.transactional_ddl` is False, and
pysqlite does not roll DDL back) every revision is its own transaction: a refusal at 0001 would leave 0004 .. 0002 already applied.

WHAT THIS DOES. Every revision's `downgrade()` starts with `preflight_downgrade("<its revision>")`. The first call of a run works out EVERY revision this
run will downgrade, looks up what each one discards in POLICY below, and counts what the database holds. If anything is held and the operator has not
authorised it, the run is refused before any revision has executed. The existing per-revision guards in 0001 / 0005 / 0006 stay as a second line of defence.

HOW THE PATH IS ESTABLISHED, AND WHY UNCERTAINTY CANNOT NARROW IT. Two independent computations are combined (`resolve_path`): (1) this module's own, from
CHAIN, the starting revision and the target (`base`, a revision id, or `-N`); (2) Alembic's `script.iterate_revisions(..., select_for_downgrade=True)`.
A path is trusted only when the target is one this module recognises and, for a relative `-N`, Alembic's answer is there to confirm it; then the UNION is
checked, so a disagreement can only widen the check and the ordering of Alembic's answer does not matter. In every other case (unreadable or unrecognised
target, relative target with no answer from Alembic) everything from the starting revision down to base is checked, which contains anything the run can
remove. Alembic's answer is therefore only ever added to the check, never substituted for it where it matters. A failure to read the context, the
database or the policy raises: there is no path on which an error lets a downgrade continue. The assumptions about Alembic's API that remain are listed in
the Phase 13 report and are exercised by tests/test_migrations.py.

THE OVERRIDE. `ITB_ALLOW_FINANCIAL_DOWNGRADE` is kept under its old name for compatibility. Despite the name it authorises destroying EVERYTHING the
downgrade path removes: the core application tables (users, profiles, requirements, applications, trainings, reviews, audit logs ...), the snapshot
columns of trainings, session notes, interview times, notification preferences and the email outbox, and the financial records. It is an exact
comparison with one phrase: no other variable and no other value (`true`, `1`, a prefix, another case) enables it. Use it on a disposable database only.

This module imports only the standard library at import time (Alembic and SQLAlchemy are imported inside `preflight_downgrade`), so the policy and the
checking logic can be tested without them. It does not touch the upgrade path.
"""
import logging
import os
import re
from dataclasses import dataclass, field
from typing import Callable, Iterable, Mapping

log = logging.getLogger(__name__)

SWITCH = "ITB_ALLOW_FINANCIAL_DOWNGRADE"
PHRASE = "I_UNDERSTAND_DATA_WILL_BE_DESTROYED"


class DowngradeRefused(RuntimeError):
    """Raised before anything has been changed. The message always starts with 'Refusing to downgrade'."""


@dataclass(frozen=True)
class Discard:
    """What one revision's downgrade() removes. `tables` are dropped whole; `columns` are (table, (column, ...)) pairs, dropped from a table that stays."""
    tables: tuple[str, ...] = ()
    columns: tuple[tuple[str, tuple[str, ...]], ...] = field(default_factory=tuple)

    @property
    def destructive(self) -> bool:
        return bool(self.tables or self.columns)


# Oldest first, and CHAIN below is derived from this table's order, so the two cannot disagree: a revision is either in both or in neither (a revision
# missing here is refused as unknown). tests/test_migration_guards_static.py checks this against the migration files (the chain, every dropped table
# and every dropped column), so a migration that drops something this table does not know about fails a test instead of dropping data silently.
POLICY: dict[str, Discard] = {
    "0001": Discard(tables=("attendance", "training_sessions", "reviews", "trainings", "requirement_skills", "match_scores", "hiring_requests", "applications",
                            "training_requirements", "trainer_skills", "trainer_busy_periods", "trainer_profiles", "notifications", "institution_profiles",
                            "audit_logs", "users", "skills", "platform_settings", "categories")),
    # The snapshot of what was agreed (the requirement may change later, so the copy on the training is the record) and the meeting link, which exists
    # nowhere else: not derivable from the remaining tables, so any non-NULL value counts as data.
    "0002": Discard(columns=(("trainings", ("technology", "mode", "location", "description", "terms", "meeting_link")),)),
    # Session notes and the interview time are entered by users and exist nowhere else after the columns go.
    "0003": Discard(columns=(("training_sessions", ("notes",)), ("applications", ("interview_at",)))),
    "0004": Discard(tables=("notification_deliveries", "notification_preferences")),
    "0005": Discard(tables=("payments", "payment_transactions", "payment_webhook_events", "invoices", "invoice_counters", "payment_refunds", "trainer_earnings",
                            "platform_commissions")),
    "0006": Discard(tables=("payment_review_flags",)),
    "0007": Discard(),          # drops triggers and functions only: no data
}
CHAIN = tuple(POLICY)                    # ("0001", ..., "0007"): the revisions this module knows, oldest first


def override_enabled(environ: Mapping[str, str] | None = None) -> bool:
    """True only for the exact phrase in the one variable. Nothing else enables it."""
    return (os.environ if environ is None else environ).get(SWITCH) == PHRASE


def _what(rev: str) -> list[tuple[str, str]]:
    """(label, SQL that counts the rows that would be lost) for one revision."""
    d = POLICY[rev]
    out = [(t, f"SELECT COUNT(*) FROM {t}") for t in d.tables]
    for table, cols in d.columns:
        out.append((f"{table}.({', '.join(cols)})", f"SELECT COUNT(*) FROM {table} WHERE " + " OR ".join(f"{c} IS NOT NULL" for c in cols)))
    return out


def held_data(count: Callable[[str], int | None], revisions: Iterable[str]) -> dict[str, dict[str, int]]:
    """{revision: {label: rows}} for every revision whose downgrade would discard rows the database holds. `count(sql)` returns the single number the
    statement selects. A revision that discards nothing, or whose objects are all empty, is left out."""
    held: dict[str, dict[str, int]] = {}
    for rev in revisions:
        found = {label: n for label, sql in _what(rev) if (n := count(sql))}
        if found:
            held[rev] = found
    return held


def refusal(held: dict[str, dict[str, int]]) -> str:
    parts = "; ".join(f"{rev}: " + ", ".join(f"{label} {n} rows" for label, n in found.items()) for rev, found in held.items())
    return ("Refusing to downgrade: this run would permanently delete application data (" + parts + "). Nothing has been changed. Export or back it up "
            f"first. {SWITCH}={PHRASE} overrides this check for ALL data the downgrade path removes (core application data, notifications, trainings "
            "snapshot columns, session notes, interview times AND financial records), whatever the variable's name suggests: for a disposable database only.")


UNKNOWN = object()                      # "the target could not be read from Alembic"
_RELATIVE = re.compile(r"-[1-9][0-9]*")


def chain_path(first: str, target) -> list[str] | None:
    """The revisions a run that STARTS at `first` removes, newest first, from CHAIN alone: `target` None or 'base' removes all down to 0001, a revision id removes
    everything above it (the target stays), '-N' removes N revisions counting from `first`. None when it cannot say (unknown start, unreadable or over-long target)."""
    if first not in CHAIN:
        return None
    i = CHAIN.index(first)
    if target is None or target == "base":
        j = -1
    elif isinstance(target, str) and _RELATIVE.fullmatch(target):
        j = i - int(target[1:])
        if j < -1:
            return None
    elif isinstance(target, str) and target in CHAIN:
        j = CHAIN.index(target)
    else:
        return None
    return list(reversed(CHAIN[j + 1:i + 1]))


def _newest_first(revisions: Iterable[str]) -> list[str]:
    return sorted(set(revisions), key=lambda r: CHAIN.index(r) if r in CHAIN else len(CHAIN), reverse=True)


def _everything_below(first: str) -> list[str]:
    """The widest a run starting at `first` can be: `first` and every revision under it. Whatever a run removes is a subset of this."""
    return _newest_first(CHAIN[:CHAIN.index(first) + 1] if first in CHAIN else [first])


def resolve_path(first: str, target, alembic_path: Iterable[str] | None, alembic_error: str | None = None) -> tuple[list[str], str | None]:
    """(revisions to check newest first, a caveat to show if the run is refused). `first` is the revision whose downgrade() is running now, i.e. where the run
    starts; `target` is what get_revision_argument() returned (or UNKNOWN); `alembic_path` is Alembic's own answer (None if it failed, with the reason).

    The rule that keeps uncertainty from ever narrowing the check: a path is only TRUSTED when this module recognises the target (base, a revision of CHAIN, or
    '-N') AND, for '-N', Alembic's answer confirms it. In every other case the whole of `_everything_below(first)` is checked, which is a superset of anything
    the run can remove. Alembic's answer can only ever ADD revisions to the check."""
    own = chain_path(first, target) if target is not UNKNOWN else None
    theirs = None if alembic_path is None else list(alembic_path)
    relative = isinstance(target, str) and _RELATIVE.fullmatch(target) is not None
    caveat = None
    if own is None:
        path = _newest_first(_everything_below(first) + (theirs or []))
        caveat = ("The exact set of revisions could not be established" + (f" ({alembic_error})" if alembic_error else "") + f", so everything from {first} down to base "
                  "was checked; naming the target revision explicitly (for example `alembic downgrade 0006`) may narrow it.")
    elif relative and theirs is None:
        path = _newest_first(_everything_below(first))
        caveat = (f"A relative target ({target}) could not be cross-checked against Alembic ({alembic_error}), so everything from {first} down to base was checked; "
                  "naming the target revision explicitly (for example `alembic downgrade 0006`) may narrow it.")
    elif theirs is None:
        path = _newest_first(own)
        caveat = f"Alembic's own list of revisions was not available ({alembic_error}); this module's list ({', '.join(own)}) was used."
    else:
        path = _newest_first(own + theirs)
        if set(own) != set(theirs):
            caveat = f"Alembic's list of revisions ({', '.join(_newest_first(theirs))}) differs from this module's ({', '.join(own)}); the union was checked."
    if first not in path:                  # the revision running now is, by definition, part of the run: anything else means the inputs are not to be trusted
        path = _newest_first(_everything_below(first) + path)
        caveat = (caveat or "") + f" The computed path did not contain {first}; everything down to base was checked."
    return path, caveat.strip() if caveat else None


def check(revisions: Iterable[str], count: Callable[[str], int | None] | None, *, offline: bool = False, environ: Mapping[str, str] | None = None,
          caveat: str | None = None) -> None:
    """Raises DowngradeRefused unless the downgrade of these revisions is explicitly authorised or discards nothing. `revisions` is the whole path."""
    revisions = list(revisions)
    if override_enabled(environ):
        return
    unknown = [r for r in revisions if r not in POLICY]
    if unknown:
        raise DowngradeRefused(f"Refusing to downgrade: revision(s) {', '.join(unknown)} have no entry in app/core/migration_guard.py POLICY, so what they would "
                               "delete is unknown. Add the entry (and keep tests/test_migration_guards_static.py passing).")
    destructive = [r for r in revisions if POLICY[r].destructive]
    if offline:
        if destructive:
            raise DowngradeRefused("Refusing to generate an offline (--sql) downgrade that drops data (" + ", ".join(destructive) + "): it cannot check the "
                                   "database for records. Run the downgrade online." + (f" {caveat}" if caveat else ""))
        return
    held = held_data(count, revisions)
    if held:
        raise DowngradeRefused(refusal(held) + (f" {caveat}" if caveat else ""))


# The MigrationContext of the last run that passed (a strong reference, so an identity test cannot be fooled by a recycled id): the rest of that run is not
# checked again. Checking again would be wrong, not just slow: a relative target such as `-3` is counted from the revision the run STARTS at.
_checked = None


def preflight_downgrade(this_revision: str) -> None:
    """The first statement of every revision's downgrade(). Checks the WHOLE run on its first call, before any revision has executed."""
    global _checked
    if override_enabled():
        return
    from alembic import context, op
    ctx = context.get_context()
    if ctx is None:                        # `_checked` starts as None: a missing context must never read as "already checked"
        raise DowngradeRefused("Refusing to downgrade: Alembic gave the pre-flight no migration context, so the run cannot be identified or checked. Nothing has been changed.")
    if _checked is ctx:
        return
    offline = context.is_offline_mode()
    try:
        target = context.get_revision_argument()          # None = base; a revision id; the raw '-N' for a relative target
    except Exception as e:
        target, problem = UNKNOWN, repr(e)
    else:
        problem = None
    alembic_path = None
    if target is not UNKNOWN:
        try:
            alembic_path = [r.revision for r in context.script.iterate_revisions(this_revision, "base" if target is None else target, select_for_downgrade=True)]
        except Exception as e:
            problem = repr(e)
    path, caveat = resolve_path(this_revision, target, alembic_path, problem)
    if caveat:
        log.warning("downgrade pre-flight: %s", caveat)
    if offline:
        count = None
    else:
        import sqlalchemy as sa
        bind = op.get_bind()

        def count(sql: str) -> int | None:
            return bind.execute(sa.text(sql)).scalar()
    check(path, count, offline=offline, caveat=caveat)
    _checked = ctx
