from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    database_url: str = "postgresql+psycopg2://itbridge:change_me@localhost:5432/itbridge"
    jwt_secret: str = "change_me"
    jwt_algorithm: str = "HS256"
    access_token_minutes: int = 15
    refresh_token_days: int = 7
    environment: str = ""                      # REQUIRED: development, test or production. No default on purpose: missing or unknown is refused at start-up (payment_guard)
    app_timezone: str = "Asia/Kolkata"         # the timezone deadlines and session dates are judged in
    redis_url: str = "redis://localhost:6379/0"
    # Notifications (Phase 11). Only the console provider exists: no real email is sent.
    email_provider: str = "console"
    frontend_url: str = "http://localhost:5173"   # used to build absolute links in external messages
    notification_max_attempts: int = 5
    notification_retry_base_seconds: int = 60     # retry n waits base * 2^(n-1) seconds
    day_before_reminder_hour: int = 17            # platform-local hour from which "tomorrow" reminders are created
    interview_reminder_hours: int = 24            # interviews starting within this many hours get a reminder
    review_reminder_days: int = 3                 # one reminder this many days after completion, to a participant who has not reviewed
    review_reminder_window_days: int = 14         # ...but never for a training completed longer ago than this (e.g. after the worker was down)
    # Payments (Phase 13). Only the SANDBOX provider exists: it moves no real money. Disabled unless switched on.
    payments_enabled: bool = False                # PAYMENTS_ENABLED=true in development/test. Production keeps it false (see main.py)
    payment_sandbox_enabled: bool = False         # PAYMENT_SANDBOX_ENABLED=true: the explicit opt-in for the sandbox and its simulator (development/test only)
    payment_provider: str = "sandbox"
    payment_webhook_secret: str = ""              # empty = the webhook rejects everything (fails closed)
    payment_webhook_tolerance_seconds: int = 300
    platform_commission_bps: int = 1000           # 1000 = 10%. A DEVELOPMENT PLACEHOLDER, not a decided business rate
    payment_commission_confirmed: bool = False    # production real-money payments stay refused until this is set on purpose
    payment_expiry_minutes: int = 60              # an unpaid attempt is closed after this long
    payment_reconcile_after_minutes: int = 15     # ask the provider about attempts that are still open after this long
    payment_processing_timeout_minutes: int = 1440  # a PROCESSING attempt with no final result after this long is flagged and closed as EXPIRED (a later success is still recorded)
    earning_hold_days: int = 0                    # days after completion before an earning becomes AVAILABLE
    cors_origins: str = "http://localhost:5173"


settings = Settings()
