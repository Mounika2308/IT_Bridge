import logging

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from starlette.exceptions import HTTPException

from app.api.v1 import applications, auth, matching, notifications, payments, profiles, requirements, reviews, trainings
from app.core.config import settings
from app.core.payment_guard import assert_safe_payment_config

log = logging.getLogger("itbridge")

if settings.environment.strip().lower() in ("production", "prod") and (settings.jwt_secret in ("", "change_me") or len(settings.jwt_secret) < 32):
    raise RuntimeError("Refusing to start: set JWT_SECRET to a random value of at least 32 characters")

assert_safe_payment_config()  # refuses to start with an unsafe payment configuration (see core/payment_guard.py); workers call it too

app = FastAPI(title="IT BRIDGE API", version="0.3.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins.split(","),
    allow_methods=["*"],
    allow_headers=["*"],
    allow_credentials=True,
)


@app.exception_handler(HTTPException)
async def http_error(_: Request, exc: HTTPException):
    return JSONResponse({"success": False, "message": exc.detail, "data": getattr(exc, "data", None)}, status_code=exc.status_code)


@app.exception_handler(RequestValidationError)
async def validation_error(_: Request, exc: RequestValidationError):
    errors = {".".join(str(p) for p in e["loc"][1:]): e["msg"] for e in exc.errors()}
    return JSONResponse({"success": False, "message": "Validation failed", "data": errors}, status_code=422)


@app.exception_handler(Exception)
async def server_error(request: Request, exc: Exception):
    # Log the real error for operators; never leak it to clients.
    log.exception("Unhandled error on %s %s", request.method, request.url.path, exc_info=exc)
    return JSONResponse({"success": False, "message": "Something went wrong on our side", "data": None}, status_code=500)


app.include_router(auth.router, prefix="/api/v1")
app.include_router(profiles.router, prefix="/api/v1")
app.include_router(requirements.router, prefix="/api/v1")
app.include_router(matching.router, prefix="/api/v1")
app.include_router(applications.router, prefix="/api/v1")
app.include_router(trainings.router, prefix="/api/v1")
app.include_router(notifications.router, prefix="/api/v1")
app.include_router(reviews.router, prefix="/api/v1")
app.include_router(payments.router, prefix="/api/v1")
app.include_router(notifications.ws_router)


@app.get("/api/v1/health")
def health():
    return {"success": True, "message": "IT BRIDGE API is running", "data": {}}
