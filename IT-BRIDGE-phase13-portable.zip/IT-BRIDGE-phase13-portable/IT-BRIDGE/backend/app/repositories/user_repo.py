from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models.user import InstitutionProfile, TrainerProfile, User


def get_by_email(db: Session, email: str) -> User | None:
    return db.scalar(select(User).where(User.email == email.lower()))


def get_by_id(db: Session, user_id: int) -> User | None:
    return db.get(User, user_id)


def create_user(db: Session, user: User, institution_name: str | None) -> User:
    db.add(user)
    db.flush()
    if user.role == "TRAINER":
        db.add(TrainerProfile(user_id=user.id))
    else:
        db.add(InstitutionProfile(user_id=user.id, institution_name=institution_name or user.full_name))
    db.commit()
    return user
