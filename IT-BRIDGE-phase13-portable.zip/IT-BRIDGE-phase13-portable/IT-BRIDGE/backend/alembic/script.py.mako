"""${message}"""
revision = ${repr(up_revision)}
down_revision = ${repr(down_revision)}
from alembic import op
import sqlalchemy as sa
${imports if imports else ""}

def upgrade():
    ${upgrades if upgrades else "pass"}


def downgrade():
    # Every revision starts its downgrade with the whole-run data-loss check. A revision without an entry in app/core/migration_guard.py POLICY is REFUSED
    # (fail closed) until the entry is added; tests/test_migration_guards_static.py lists what else has to be updated.
    from app.core.migration_guard import preflight_downgrade
    preflight_downgrade(${repr(up_revision)})
    ${downgrades if downgrades else "pass"}
