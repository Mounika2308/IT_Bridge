"""payment review flags: several different unresolved review reasons per payment

Revision ID: 0006
Revises: 0005

Additive: one new table. Before this, a payment held a single review reason, so resolving the first could hide a later one. Each reason is now
its own row (open until an administrator resolves it with a note). Payments that were already flagged or resolved are copied across.
The downgrade REFUSES to run while the table holds a row (see ITB_ALLOW_FINANCIAL_DOWNGRADE in migration 0005).
"""
import os

import sqlalchemy as sa
from alembic import context, op

revision = "0006"
down_revision = "0005"
branch_labels = None
depends_on = None

OPEN = "resolved_at IS NULL"


def _refuse_to_discard(*tables: str) -> None:
    """Downgrading drops these tables. Financial records are never discarded silently: the downgrade stops while any of them holds a row, unless
    the operator sets ITB_ALLOW_FINANCIAL_DOWNGRADE=I_UNDERSTAND_DATA_WILL_BE_DESTROYED on purpose (development databases). Export first."""
    if os.environ.get("ITB_ALLOW_FINANCIAL_DOWNGRADE") == "I_UNDERSTAND_DATA_WILL_BE_DESTROYED":
        return
    if context.is_offline_mode():          # `alembic downgrade --sql` has no connection, so it cannot know whether the tables hold records
        raise RuntimeError("Refusing to generate an offline (--sql) downgrade that drops financial tables: it cannot check them for records. Run the downgrade online.")
    bind = op.get_bind()
    held = {t: bind.execute(sa.text(f"SELECT COUNT(*) FROM {t}")).scalar() for t in tables}
    held = {t: n for t, n in held.items() if n}
    if held and os.environ.get("ITB_ALLOW_FINANCIAL_DOWNGRADE") != "I_UNDERSTAND_DATA_WILL_BE_DESTROYED":
        raise RuntimeError("Refusing to downgrade: it would permanently delete financial records (" + ", ".join(f"{t}: {n} rows" for t, n in held.items())
                           + "). Export them first. For a development database only, set ITB_ALLOW_FINANCIAL_DOWNGRADE=I_UNDERSTAND_DATA_WILL_BE_DESTROYED.")


def _refuse_unrepresentable_reviews() -> None:
    """A payment flagged for review with no recorded reason cannot become a flag. The application never creates such a row; if one exists the upgrade stops
    instead of silently dropping the review. Repair it by hand (give it a reason, or resolve it), then upgrade."""
    if context.is_offline_mode():
        return                              # offline SQL generation cannot read the database; the online upgrade checks
    stuck = op.get_bind().execute(sa.text("SELECT COUNT(*) FROM payments WHERE needs_review = TRUE AND review_reason IS NULL")).scalar()
    if stuck:
        raise RuntimeError(f"Refusing to upgrade: {stuck} payment(s) are marked needs_review with no review_reason, which cannot be carried into payment_review_flags. "
                           "Set a review_reason on them (or clear needs_review after reviewing them), then run the upgrade again.")


def upgrade() -> None:
    _refuse_unrepresentable_reviews()
    op.create_table(
        "payment_review_flags",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("payment_id", sa.Integer(), sa.ForeignKey("payments.id", ondelete="RESTRICT"), nullable=False),
        sa.Column("reason", sa.String(30), nullable=False),
        sa.Column("note", sa.String(500), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("resolved_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("resolved_by", sa.Integer(), sa.ForeignKey("users.id", ondelete="RESTRICT"), nullable=True),
        sa.Column("resolution_note", sa.String(500), nullable=True),
        sa.PrimaryKeyConstraint("id"),
        sa.CheckConstraint("reason IN ('LATE_SUCCESS', 'OVER_CAP', 'DUPLICATE_CHARGE', 'AMOUNT_MISMATCH', 'CURRENCY_MISMATCH', 'TRAINING_CANCELLED', 'STUCK_PROCESSING', 'REFUND_STUCK')",
                           name="ck_review_flag_reason"),
        sa.CheckConstraint("(resolved_at IS NULL) = (resolved_by IS NULL) AND (resolved_at IS NULL) = (resolution_note IS NULL)", name="ck_review_flag_resolution"),
    )
    op.create_index(op.f("ix_payment_review_flags_payment_id"), "payment_review_flags", ["payment_id"], unique=False)
    # at most one OPEN flag per payment and reason: the database backs the service's rule
    op.create_index("uq_review_flag_open", "payment_review_flags", ["payment_id", "reason"], unique=True,
                    postgresql_where=sa.text(OPEN), sqlite_where=sa.text(OPEN))
    # Carry over what the single-reason columns held: payments still waiting for review stay open, resolved ones become history.
    op.execute("INSERT INTO payment_review_flags (payment_id, reason, note, created_at) "
               "SELECT id, review_reason, review_note, updated_at FROM payments WHERE needs_review = TRUE AND review_reason IS NOT NULL")
    op.execute("INSERT INTO payment_review_flags (payment_id, reason, created_at, resolved_at, resolved_by, resolution_note) "
               "SELECT id, review_reason, created_at, reviewed_at, reviewed_by, review_note FROM payments "
               "WHERE needs_review = FALSE AND review_reason IS NOT NULL AND reviewed_by IS NOT NULL AND reviewed_at IS NOT NULL AND review_note IS NOT NULL")


def downgrade() -> None:
    # imported here, not at module level: loading the migrations (alembic heads / history / revision) must not need `app`; env.py has already imported it by now
    from app.core.migration_guard import preflight_downgrade
    preflight_downgrade("0006")      # the WHOLE run is checked here, before any revision executes (app/core/migration_guard.py)
    _refuse_to_discard("payment_review_flags")
    op.drop_index("uq_review_flag_open", table_name="payment_review_flags")
    op.drop_index(op.f("ix_payment_review_flags_payment_id"), table_name="payment_review_flags")
    op.drop_table("payment_review_flags")
