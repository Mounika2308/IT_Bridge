"""payments, invoices, refunds and trainer earnings (all amounts in paise)

Revision ID: 0005
Revises: 0004

Additive: eight new tables, no existing table is touched. Every foreign key into financial data is ON DELETE RESTRICT.
The downgrade drops the eight tables. It REFUSES to run while any of them holds a row (financial records are never discarded silently), unless
the operator sets ITB_ALLOW_FINANCIAL_DOWNGRADE=I_UNDERSTAND_DATA_WILL_BE_DESTROYED on purpose (development databases only).
"""
import os

import sqlalchemy as sa
from alembic import context, op

revision = "0005"
down_revision = "0004"
branch_labels = None
depends_on = None

IN_FLIGHT = "status IN ('PENDING', 'PROCESSING')"


def _refuse_to_discard(*tables: str) -> None:
    """Downgrading drops these tables. Financial records are never discarded silently: the downgrade stops while any of them holds a row, unless
    the operator sets ITB_ALLOW_FINANCIAL_DOWNGRADE=I_UNDERSTAND_DATA_WILL_BE_DESTROYED on purpose (development databases). Export first."""
    if os.environ.get("ITB_ALLOW_FINANCIAL_DOWNGRADE") == "I_UNDERSTAND_DATA_WILL_BE_DESTROYED":
        return
    if context.is_offline_mode():          # `alembic downgrade --sql` has no connection, so it cannot know whether the tables hold records
        raise RuntimeError("Refusing to generate an offline (--sql) downgrade that drops financial tables: it cannot check them for records. Run the downgrade online.")
    bind = op.get_bind()
    held = {t: bind.execute(sa.text(f"SELECT COUNT(*) FROM {t}")).scalar() for t in tables}
    held = {t: n for t, n in held.items() if n}
    if held and os.environ.get("ITB_ALLOW_FINANCIAL_DOWNGRADE") != "I_UNDERSTAND_DATA_WILL_BE_DESTROYED":
        raise RuntimeError("Refusing to downgrade: it would permanently delete financial records (" + ", ".join(f"{t}: {n} rows" for t, n in held.items())
                           + "). Export them first. For a development database only, set ITB_ALLOW_FINANCIAL_DOWNGRADE=I_UNDERSTAND_DATA_WILL_BE_DESTROYED.")


def upgrade() -> None:
    op.create_table(
        "payments",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("training_id", sa.Integer(), sa.ForeignKey("trainings.id", ondelete="RESTRICT"), nullable=False),
        sa.Column("institution_id", sa.Integer(), sa.ForeignKey("institution_profiles.id", ondelete="RESTRICT"), nullable=False),
        sa.Column("trainer_id", sa.Integer(), sa.ForeignKey("trainer_profiles.id", ondelete="RESTRICT"), nullable=False),
        sa.Column("payer_user_id", sa.Integer(), sa.ForeignKey("users.id", ondelete="RESTRICT"), nullable=False),
        sa.Column("attempt_no", sa.Integer(), nullable=False),
        sa.Column("amount_paise", sa.BigInteger(), nullable=False),
        sa.Column("currency", sa.String(3), nullable=False),
        sa.Column("commission_bps", sa.Integer(), nullable=False),
        sa.Column("platform_fee_paise", sa.BigInteger(), nullable=False),
        sa.Column("net_paise", sa.BigInteger(), nullable=False),
        sa.Column("status", sa.String(12), nullable=False),
        sa.Column("provider", sa.String(20), nullable=False),
        sa.Column("provider_order_id", sa.String(80), nullable=False),
        sa.Column("provider_meta", sa.JSON(), nullable=True),
        sa.Column("idempotency_key", sa.String(80), nullable=True),
        sa.Column("request_fingerprint", sa.String(64), nullable=False),
        sa.Column("failure_reason", sa.String(200), nullable=True),
        sa.Column("needs_review", sa.Boolean(), nullable=False),
        sa.Column("review_reason", sa.String(30), nullable=True),
        sa.Column("review_note", sa.String(500), nullable=True),
        sa.Column("reviewed_by", sa.Integer(), sa.ForeignKey("users.id", ondelete="RESTRICT"), nullable=True),
        sa.Column("reviewed_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("expires_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("paid_at", sa.DateTime(timezone=True), nullable=True),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("provider", "provider_order_id", name="uq_payment_provider_order"),
        sa.UniqueConstraint("payer_user_id", "idempotency_key", name="uq_payment_idempotency"),
        sa.UniqueConstraint("training_id", "attempt_no", name="uq_payment_attempt"),
        sa.CheckConstraint("amount_paise > 0", name="ck_payment_amount_positive"),
        sa.CheckConstraint("platform_fee_paise >= 0 AND platform_fee_paise <= amount_paise", name="ck_payment_fee_range"),
        sa.CheckConstraint("net_paise = amount_paise - platform_fee_paise", name="ck_payment_net"),
        sa.CheckConstraint("commission_bps >= 0 AND commission_bps <= 10000", name="ck_payment_bps"),
        sa.CheckConstraint("attempt_no >= 1", name="ck_payment_attempt_no"),
        sa.CheckConstraint("currency = 'INR'", name="ck_payment_currency"),
        sa.CheckConstraint("status IN ('PENDING', 'PROCESSING', 'SUCCEEDED', 'FAILED', 'CANCELLED', 'EXPIRED')", name="ck_payment_status"),
        sa.CheckConstraint("status <> 'SUCCEEDED' OR paid_at IS NOT NULL", name="ck_payment_paid_at"),
    )
    op.create_index(op.f("ix_payments_training_id"), "payments", ["training_id"], unique=False)
    op.create_index(op.f("ix_payments_institution_id"), "payments", ["institution_id"], unique=False)
    op.create_index(op.f("ix_payments_trainer_id"), "payments", ["trainer_id"], unique=False)
    op.create_index(op.f("ix_payments_payer_user_id"), "payments", ["payer_user_id"], unique=False)
    op.create_index(op.f("ix_payments_status"), "payments", ["status"], unique=False)
    op.create_index("ix_payments_training_status", "payments", ["training_id", "status"], unique=False)
    # at most one open attempt per training: the database backs the service's one-in-flight rule
    op.create_index("uq_payment_one_in_flight", "payments", ["training_id"], unique=True,
                    postgresql_where=sa.text(IN_FLIGHT), sqlite_where=sa.text(IN_FLIGHT))

    op.create_table(
        "payment_transactions",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("payment_id", sa.Integer(), sa.ForeignKey("payments.id", ondelete="RESTRICT"), nullable=False),
        sa.Column("type", sa.String(8), nullable=False),
        sa.Column("amount_paise", sa.BigInteger(), nullable=False),
        sa.Column("provider", sa.String(20), nullable=False),
        sa.Column("provider_txn_id", sa.String(160), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("provider", "provider_txn_id", name="uq_payment_txn_provider"),
        sa.UniqueConstraint("payment_id", "type", name="uq_payment_txn_type"),
        sa.CheckConstraint("amount_paise > 0", name="ck_txn_amount_positive"),
        sa.CheckConstraint("type IN ('CHARGE', 'REFUND')", name="ck_txn_type"),
    )
    op.create_index(op.f("ix_payment_transactions_payment_id"), "payment_transactions", ["payment_id"], unique=False)

    op.create_table(
        "payment_webhook_events",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("provider", sa.String(20), nullable=False),
        sa.Column("event_id", sa.String(80), nullable=False),
        sa.Column("event_type", sa.String(40), nullable=False),
        sa.Column("payment_id", sa.Integer(), sa.ForeignKey("payments.id", ondelete="RESTRICT"), nullable=True),
        sa.Column("outcome", sa.String(30), nullable=False),
        sa.Column("payload", sa.JSON(), nullable=False),
        sa.Column("source", sa.String(12), nullable=False),
        sa.Column("received_at", sa.DateTime(timezone=True), nullable=False),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("provider", "event_id", name="uq_webhook_event"),
    )
    op.create_index(op.f("ix_payment_webhook_events_payment_id"), "payment_webhook_events", ["payment_id"], unique=False)

    op.create_table(
        "invoices",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("payment_id", sa.Integer(), sa.ForeignKey("payments.id", ondelete="RESTRICT"), nullable=False),
        sa.Column("number", sa.String(24), nullable=False),
        sa.Column("institution_id", sa.Integer(), sa.ForeignKey("institution_profiles.id", ondelete="RESTRICT"), nullable=False),
        sa.Column("trainer_id", sa.Integer(), sa.ForeignKey("trainer_profiles.id", ondelete="RESTRICT"), nullable=False),
        sa.Column("training_id", sa.Integer(), sa.ForeignKey("trainings.id", ondelete="RESTRICT"), nullable=False),
        sa.Column("amount_paise", sa.BigInteger(), nullable=False),
        sa.Column("currency", sa.String(3), nullable=False),
        sa.Column("snapshot", sa.JSON(), nullable=False),
        sa.Column("issued_at", sa.DateTime(timezone=True), nullable=False),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("payment_id", name="uq_invoice_payment"),
        sa.UniqueConstraint("number", name="uq_invoice_number"),
        sa.CheckConstraint("amount_paise > 0", name="ck_invoice_amount_positive"),
    )
    op.create_index(op.f("ix_invoices_institution_id"), "invoices", ["institution_id"], unique=False)
    op.create_index(op.f("ix_invoices_trainer_id"), "invoices", ["trainer_id"], unique=False)
    op.create_index(op.f("ix_invoices_training_id"), "invoices", ["training_id"], unique=False)

    op.create_table(
        "invoice_counters",
        sa.Column("series", sa.String(4), nullable=False),
        sa.Column("year", sa.Integer(), nullable=False),
        sa.Column("last_number", sa.Integer(), nullable=False),
        sa.PrimaryKeyConstraint("series", "year"),
    )

    op.create_table(
        "payment_refunds",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("payment_id", sa.Integer(), sa.ForeignKey("payments.id", ondelete="RESTRICT"), nullable=False),
        sa.Column("amount_paise", sa.BigInteger(), nullable=False),
        sa.Column("reason", sa.String(300), nullable=True),
        sa.Column("status", sa.String(10), nullable=False),
        sa.Column("idempotency_key", sa.String(80), nullable=False),
        sa.Column("credit_note_number", sa.String(24), nullable=True),
        sa.Column("attempts", sa.Integer(), nullable=False),
        sa.Column("last_error", sa.String(200), nullable=True),
        sa.Column("created_by", sa.Integer(), sa.ForeignKey("users.id", ondelete="RESTRICT"), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("completed_at", sa.DateTime(timezone=True), nullable=True),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("payment_id", name="uq_refund_payment"),
        sa.UniqueConstraint("idempotency_key", name="uq_refund_idempotency"),
        sa.UniqueConstraint("credit_note_number", name="uq_refund_credit_note"),
        sa.CheckConstraint("amount_paise > 0", name="ck_refund_amount_positive"),
        sa.CheckConstraint("status IN ('PENDING', 'SUCCEEDED')", name="ck_refund_status"),
        sa.CheckConstraint("status <> 'SUCCEEDED' OR (completed_at IS NOT NULL AND credit_note_number IS NOT NULL)", name="ck_refund_completed"),
    )

    op.create_table(
        "trainer_earnings",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("payment_id", sa.Integer(), sa.ForeignKey("payments.id", ondelete="RESTRICT"), nullable=False),
        sa.Column("trainer_id", sa.Integer(), sa.ForeignKey("trainer_profiles.id", ondelete="RESTRICT"), nullable=False),
        sa.Column("training_id", sa.Integer(), sa.ForeignKey("trainings.id", ondelete="RESTRICT"), nullable=False),
        sa.Column("gross_paise", sa.BigInteger(), nullable=False),
        sa.Column("commission_paise", sa.BigInteger(), nullable=False),
        sa.Column("net_paise", sa.BigInteger(), nullable=False),
        sa.Column("status", sa.String(10), nullable=False),
        sa.Column("available_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("paid_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("paid_by", sa.Integer(), sa.ForeignKey("users.id", ondelete="RESTRICT"), nullable=True),
        sa.Column("payout_reference", sa.String(80), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("payment_id", name="uq_earning_payment"),
        sa.CheckConstraint("gross_paise > 0", name="ck_earning_gross_positive"),
        sa.CheckConstraint("commission_paise >= 0 AND commission_paise <= gross_paise", name="ck_earning_commission_range"),
        sa.CheckConstraint("net_paise = gross_paise - commission_paise", name="ck_earning_net"),
        sa.CheckConstraint("status IN ('PENDING', 'AVAILABLE', 'PAID', 'REFUNDED')", name="ck_earning_status"),
        sa.CheckConstraint("status NOT IN ('AVAILABLE', 'PAID') OR available_at IS NOT NULL", name="ck_earning_available_at"),
        sa.CheckConstraint("status <> 'PAID' OR (paid_at IS NOT NULL AND paid_by IS NOT NULL AND payout_reference IS NOT NULL)", name="ck_earning_paid_fields"),
        sa.CheckConstraint("status = 'PAID' OR paid_at IS NULL", name="ck_earning_paid_only"),
    )
    op.create_index(op.f("ix_trainer_earnings_trainer_id"), "trainer_earnings", ["trainer_id"], unique=False)
    op.create_index(op.f("ix_trainer_earnings_training_id"), "trainer_earnings", ["training_id"], unique=False)
    op.create_index(op.f("ix_trainer_earnings_status"), "trainer_earnings", ["status"], unique=False)

    op.create_table(
        "platform_commissions",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("payment_id", sa.Integer(), sa.ForeignKey("payments.id", ondelete="RESTRICT"), nullable=False),
        sa.Column("rate_bps", sa.Integer(), nullable=False),
        sa.Column("amount_paise", sa.BigInteger(), nullable=False),
        sa.Column("status", sa.String(10), nullable=False),
        sa.Column("reversed_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("payment_id", name="uq_commission_payment"),
        sa.CheckConstraint("amount_paise >= 0", name="ck_commission_amount"),
        sa.CheckConstraint("rate_bps >= 0 AND rate_bps <= 10000", name="ck_commission_rate"),
        sa.CheckConstraint("status IN ('RECORDED', 'REVERSED')", name="ck_commission_status"),
        sa.CheckConstraint("(status = 'REVERSED') = (reversed_at IS NOT NULL)", name="ck_commission_reversed_at"),
    )


def downgrade() -> None:
    # imported here, not at module level: loading the migrations (alembic heads / history / revision) must not need `app`; env.py has already imported it by now
    from app.core.migration_guard import preflight_downgrade
    preflight_downgrade("0005")      # the WHOLE run is checked here, before any revision executes (app/core/migration_guard.py)
    _refuse_to_discard("payments", "payment_transactions", "payment_webhook_events", "invoices", "invoice_counters", "payment_refunds", "trainer_earnings",
                       "platform_commissions")
    op.drop_table("platform_commissions")
    op.drop_index(op.f("ix_trainer_earnings_status"), table_name="trainer_earnings")
    op.drop_index(op.f("ix_trainer_earnings_training_id"), table_name="trainer_earnings")
    op.drop_index(op.f("ix_trainer_earnings_trainer_id"), table_name="trainer_earnings")
    op.drop_table("trainer_earnings")
    op.drop_table("payment_refunds")
    op.drop_table("invoice_counters")
    op.drop_index(op.f("ix_invoices_training_id"), table_name="invoices")
    op.drop_index(op.f("ix_invoices_trainer_id"), table_name="invoices")
    op.drop_index(op.f("ix_invoices_institution_id"), table_name="invoices")
    op.drop_table("invoices")
    op.drop_index(op.f("ix_payment_webhook_events_payment_id"), table_name="payment_webhook_events")
    op.drop_table("payment_webhook_events")
    op.drop_index(op.f("ix_payment_transactions_payment_id"), table_name="payment_transactions")
    op.drop_table("payment_transactions")
    op.drop_index("uq_payment_one_in_flight", table_name="payments")
    op.drop_index("ix_payments_training_status", table_name="payments")
    op.drop_index(op.f("ix_payments_status"), table_name="payments")
    op.drop_index(op.f("ix_payments_payer_user_id"), table_name="payments")
    op.drop_index(op.f("ix_payments_trainer_id"), table_name="payments")
    op.drop_index(op.f("ix_payments_institution_id"), table_name="payments")
    op.drop_index(op.f("ix_payments_training_id"), table_name="payments")
    op.drop_table("payments")
