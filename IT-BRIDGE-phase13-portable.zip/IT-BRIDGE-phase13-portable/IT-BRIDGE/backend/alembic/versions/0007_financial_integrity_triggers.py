"""PostgreSQL integrity triggers for financial records (defence in depth behind the service code)

Revision ID: 0007
Revises: 0006

No table or column changes, so no data is touched and the downgrade is safe. PostgreSQL only: on any other database both directions do nothing
(SQLite has the CHECK/UNIQUE constraints of 0005 and 0006 but no triggers; it is used for the test suite only).

What the triggers do and do NOT do (verified against PostgreSQL 16 with hand-written SQL: scripts/verify_postgres_sql.py, groups C and F).

  1. Tables that REJECT every UPDATE and DELETE (trigger itb_forbid_change):
       invoices, payment_transactions (the ledger)
  2. A table whose UPDATE is restricted to NON-identity columns (trigger itb_payment_identity):
       payments - amount, currency, training, institution, trainer, payer, provider, provider order id, attempt number, idempotency key and request
       fingerprint can never change. EVERY OTHER COLUMN CAN, status included: a SUCCEEDED payment can still be set to FAILED by hand.
  3. Checks that run at INSERT only (BEFORE INSERT; a later UPDATE or DELETE of the same row is not checked):
       invoices            the payment is SUCCEEDED; amount, currency, institution, trainer and training equal the payment's
       trainer_earnings    the payment is SUCCEEDED; gross, commission and net equal the payment's amount, platform fee and net; trainer and training equal
       platform_commissions  the payment is SUCCEEDED; amount equals the payment's platform fee; rate equals its commission_bps
       payment_refunds     the payment is SUCCEEDED; the amount equals the payment's amount (a full refund is the whole payment)
       payment_transactions  the amount equals the payment's amount
  4. Cross-table relationships that are validated: exactly the ones listed in 3 (child row against its own payment). Nothing validates the
     payer user against any child, nothing re-checks a child after the payment changes, and a child is not checked against its sibling children.
  5. Financial records that REMAIN EDITABLE and DELETABLE by hand-written SQL (only CHECK/FOREIGN KEY/UNIQUE constraints apply):
       platform_commissions, trainer_earnings (a self-consistent edit of gross/commission/net passes; ck_earning_net only catches an inconsistent one),
       payment_refunds, payment_webhook_events, payment_review_flags (rows can be deleted), invoice_counters, and payments outside its identity columns
       (a payment is not protected from DELETE by a trigger; ON DELETE RESTRICT only stops deleting one that has dependent rows).
     The application changes some of these on purpose (a commission is REVERSED, an earning is PAID, a flag is resolved), which is why they are not frozen.

So: invoices and the ledger are immutable; payment identity is frozen; the five child tables are checked at INSERT. Commissions, refunds, earnings, review
flags, webhook events and payment statuses are NOT immutable. Partial refunds do not exist in Phase 13; introducing one means changing the refund and
ledger checks below in the same migration.

Operational notes. upgrade() is not idempotent: functions use CREATE OR REPLACE but CREATE TRIGGER does not, so running it twice against a database that
already has the triggers fails; the downgrade uses DROP ... IF EXISTS and can be repeated. Both directions are plain DDL, so on PostgreSQL they take
effect together with the rest of the Alembic command's transaction.
"""
from alembic import op

revision = "0007"
down_revision = "0006"
branch_labels = None
depends_on = None

FUNCTIONS = [
    """
CREATE OR REPLACE FUNCTION itb_forbid_change() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    RAISE EXCEPTION '% rows are immutable (% of row %)', TG_TABLE_NAME, TG_OP, OLD.id USING ERRCODE = '23000';
END
$fn$""",
    """
CREATE OR REPLACE FUNCTION itb_payment_identity() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF NEW.amount_paise IS DISTINCT FROM OLD.amount_paise OR NEW.currency IS DISTINCT FROM OLD.currency OR NEW.training_id IS DISTINCT FROM OLD.training_id
       OR NEW.institution_id IS DISTINCT FROM OLD.institution_id OR NEW.trainer_id IS DISTINCT FROM OLD.trainer_id
       OR NEW.payer_user_id IS DISTINCT FROM OLD.payer_user_id OR NEW.provider IS DISTINCT FROM OLD.provider
       OR NEW.provider_order_id IS DISTINCT FROM OLD.provider_order_id OR NEW.attempt_no IS DISTINCT FROM OLD.attempt_no
       OR NEW.idempotency_key IS DISTINCT FROM OLD.idempotency_key OR NEW.request_fingerprint IS DISTINCT FROM OLD.request_fingerprint THEN
        RAISE EXCEPTION 'payment % identity columns are immutable', OLD.id USING ERRCODE = '23000';
    END IF;
    RETURN NEW;
END
$fn$""",
    """
CREATE OR REPLACE FUNCTION itb_check_invoice() RETURNS trigger LANGUAGE plpgsql AS $fn$
DECLARE p payments%ROWTYPE;
BEGIN
    SELECT * INTO p FROM payments WHERE id = NEW.payment_id;
    IF NOT FOUND OR p.status <> 'SUCCEEDED' OR NEW.amount_paise <> p.amount_paise OR NEW.currency <> p.currency
       OR NEW.institution_id <> p.institution_id OR NEW.trainer_id <> p.trainer_id OR NEW.training_id <> p.training_id THEN
        RAISE EXCEPTION 'invoice does not match its payment %', NEW.payment_id USING ERRCODE = '23000';
    END IF;
    RETURN NEW;
END
$fn$""",
    """
CREATE OR REPLACE FUNCTION itb_check_earning() RETURNS trigger LANGUAGE plpgsql AS $fn$
DECLARE p payments%ROWTYPE;
BEGIN
    SELECT * INTO p FROM payments WHERE id = NEW.payment_id;
    IF NOT FOUND OR p.status <> 'SUCCEEDED' OR NEW.gross_paise <> p.amount_paise OR NEW.commission_paise <> p.platform_fee_paise
       OR NEW.net_paise <> p.net_paise OR NEW.trainer_id <> p.trainer_id OR NEW.training_id <> p.training_id THEN
        RAISE EXCEPTION 'trainer earning does not match its payment %', NEW.payment_id USING ERRCODE = '23000';
    END IF;
    RETURN NEW;
END
$fn$""",
    """
CREATE OR REPLACE FUNCTION itb_check_commission() RETURNS trigger LANGUAGE plpgsql AS $fn$
DECLARE p payments%ROWTYPE;
BEGIN
    SELECT * INTO p FROM payments WHERE id = NEW.payment_id;
    IF NOT FOUND OR p.status <> 'SUCCEEDED' OR NEW.amount_paise <> p.platform_fee_paise OR NEW.rate_bps <> p.commission_bps THEN
        RAISE EXCEPTION 'platform commission does not match its payment %', NEW.payment_id USING ERRCODE = '23000';
    END IF;
    RETURN NEW;
END
$fn$""",
    """
CREATE OR REPLACE FUNCTION itb_check_amount_of_payment() RETURNS trigger LANGUAGE plpgsql AS $fn$
DECLARE p payments%ROWTYPE;
BEGIN
    SELECT * INTO p FROM payments WHERE id = NEW.payment_id;
    IF NOT FOUND OR NEW.amount_paise <> p.amount_paise THEN
        RAISE EXCEPTION '% of % does not match the amount of payment % (full refunds only)', TG_TABLE_NAME, NEW.amount_paise, NEW.payment_id USING ERRCODE = '23000';
    END IF;
    IF TG_TABLE_NAME = 'payment_refunds' AND p.status <> 'SUCCEEDED' THEN
        RAISE EXCEPTION 'only a SUCCEEDED payment can be refunded (payment %)', NEW.payment_id USING ERRCODE = '23000';
    END IF;
    RETURN NEW;
END
$fn$""",
]

TRIGGERS = [
    ("trg_invoices_immutable", "invoices", "BEFORE UPDATE OR DELETE", "itb_forbid_change"),
    ("trg_payment_transactions_immutable", "payment_transactions", "BEFORE UPDATE OR DELETE", "itb_forbid_change"),
    ("trg_payments_identity", "payments", "BEFORE UPDATE", "itb_payment_identity"),
    ("trg_invoices_check", "invoices", "BEFORE INSERT", "itb_check_invoice"),
    ("trg_trainer_earnings_check", "trainer_earnings", "BEFORE INSERT", "itb_check_earning"),
    ("trg_platform_commissions_check", "platform_commissions", "BEFORE INSERT", "itb_check_commission"),
    ("trg_payment_refunds_check", "payment_refunds", "BEFORE INSERT", "itb_check_amount_of_payment"),
    ("trg_payment_transactions_check", "payment_transactions", "BEFORE INSERT", "itb_check_amount_of_payment"),
]
FUNCTION_NAMES = ["itb_forbid_change", "itb_payment_identity", "itb_check_invoice", "itb_check_earning", "itb_check_commission", "itb_check_amount_of_payment"]


def _postgres() -> bool:
    return op.get_bind().dialect.name == "postgresql"


def upgrade() -> None:
    if not _postgres():
        return
    for fn in FUNCTIONS:
        op.execute(fn)
    for name, table, when, fn in TRIGGERS:
        op.execute(f"CREATE TRIGGER {name} {when} ON {table} FOR EACH ROW EXECUTE FUNCTION {fn}()")


def downgrade() -> None:
    # imported here, not at module level: loading the migrations (alembic heads / history / revision) must not need `app`; env.py has already imported it by now
    from app.core.migration_guard import preflight_downgrade
    preflight_downgrade("0007")      # the WHOLE run is checked here, before any revision executes (app/core/migration_guard.py)
    if not _postgres():
        return
    for name, table, _when, _fn in reversed(TRIGGERS):
        op.execute(f"DROP TRIGGER IF EXISTS {name} ON {table}")
    for fn in FUNCTION_NAMES:
        op.execute(f"DROP FUNCTION IF EXISTS {fn}()")
