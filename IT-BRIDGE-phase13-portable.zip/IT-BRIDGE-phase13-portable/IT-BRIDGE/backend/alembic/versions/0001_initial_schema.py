"""initial schema (generated from the SQLAlchemy models)

Revision ID: 0001
Revises: None

Downgrade (Phase 13 follow-up): this revision's downgrade drops EVERY application table (users, profiles, requirements, trainings, reviews, audit logs ...),
so it is the one step that turns `alembic downgrade base` into total data loss. It now refuses while any of those tables holds a row, with the same explicit
switch as 0005/0006 (ITB_ALLOW_FINANCIAL_DOWNGRADE=I_UNDERSTAND_DATA_WILL_BE_DESTROYED; despite its name it authorises ALL data loss on the downgrade path). An empty
database (a fresh test database) is not affected. Since the whole-path pre-flight (app/core/migration_guard.py) every run is checked BEFORE its first revision
executes; this guard is the second line of defence. The upgrade is unchanged.
"""
import os

import sqlalchemy as sa
from alembic import context, op

revision = "0001"
down_revision = None
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "categories",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("name", sa.String(80), nullable=False),
        sa.Column("is_active", sa.Boolean, nullable=False),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint("name"),
    )
    op.create_table(
        "platform_settings",
        sa.Column("key", sa.String(80), nullable=False),
        sa.Column("value", sa.JSON, nullable=False),
        sa.PrimaryKeyConstraint('key'),
    )
    op.create_table(
        "skills",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("name", sa.String(80), nullable=False),
        sa.Column("category", sa.String(80), nullable=True),
        sa.Column("is_active", sa.Boolean, nullable=False),
        sa.PrimaryKeyConstraint('id'),
    )
    op.create_index(op.f("ix_skills_name"), "skills", ['name'], unique=True)
    op.create_table(
        "users",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("email", sa.String(255), nullable=False),
        sa.Column("password_hash", sa.String(255), nullable=False),
        sa.Column("full_name", sa.String(120), nullable=False),
        sa.Column("phone", sa.String(20), nullable=True),
        sa.Column("role", sa.String(20), nullable=False),
        sa.Column("is_active", sa.Boolean, nullable=False),
        sa.Column("email_verified", sa.Boolean, nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.PrimaryKeyConstraint('id'),
    )
    op.create_index(op.f("ix_users_email"), "users", ['email'], unique=True)
    op.create_index(op.f("ix_users_role"), "users", ['role'], unique=False)
    op.create_table(
        "audit_logs",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("user_id", sa.Integer(), sa.ForeignKey('users.id', ondelete='SET NULL'), nullable=True),
        sa.Column("action", sa.String(60), nullable=False),
        sa.Column("entity", sa.String(60), nullable=False),
        sa.Column("entity_id", sa.Integer, nullable=True),
        sa.Column("details", sa.JSON, nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.PrimaryKeyConstraint('id'),
    )
    op.create_index(op.f("ix_audit_logs_user_id"), "audit_logs", ['user_id'], unique=False)
    op.create_index(op.f("ix_audit_logs_action"), "audit_logs", ['action'], unique=False)
    op.create_table(
        "institution_profiles",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("user_id", sa.Integer(), sa.ForeignKey('users.id', ondelete='CASCADE'), nullable=False),
        sa.Column("institution_name", sa.String(200), nullable=False),
        sa.Column("institution_type", sa.String(40), nullable=True),
        sa.Column("location", sa.String(120), nullable=True),
        sa.Column("about", sa.String(2000), nullable=True),
        sa.Column("website", sa.String(200), nullable=True),
        sa.Column("verification_status", sa.String(20), nullable=False),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint("user_id"),
    )
    op.create_table(
        "notifications",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("user_id", sa.Integer(), sa.ForeignKey('users.id', ondelete='CASCADE'), nullable=False),
        sa.Column("type", sa.String(30), nullable=False),
        sa.Column("title", sa.String(160), nullable=False),
        sa.Column("body", sa.String(500), nullable=True),
        sa.Column("link", sa.String(200), nullable=True),
        sa.Column("is_read", sa.Boolean, nullable=False),
        sa.Column("dedupe_key", sa.String(120), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('user_id', 'dedupe_key', name='uq_notification_dedupe'),
    )
    op.create_index(op.f("ix_notifications_user_id"), "notifications", ['user_id'], unique=False)
    op.create_index(op.f("ix_notifications_is_read"), "notifications", ['is_read'], unique=False)
    op.create_table(
        "trainer_profiles",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("user_id", sa.Integer(), sa.ForeignKey('users.id', ondelete='CASCADE'), nullable=False),
        sa.Column("headline", sa.String(160), nullable=True),
        sa.Column("about", sa.String(2000), nullable=True),
        sa.Column("location", sa.String(120), nullable=True),
        sa.Column("experience_years", sa.Integer, nullable=True),
        sa.Column("training_mode", sa.String(10), nullable=True),
        sa.Column("expected_fee", sa.Integer, nullable=True),
        sa.Column("availability", sa.String(300), nullable=True),
        sa.Column("languages", sa.JSON, nullable=False),
        sa.Column("education", sa.JSON, nullable=False),
        sa.Column("certifications", sa.JSON, nullable=False),
        sa.Column("verification_status", sa.String(20), nullable=False),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint("user_id"),
    )
    op.create_index(op.f("ix_trainer_profiles_location"), "trainer_profiles", ['location'], unique=False)
    op.create_table(
        "trainer_busy_periods",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("trainer_id", sa.Integer(), sa.ForeignKey('trainer_profiles.id', ondelete='CASCADE'), nullable=False),
        sa.Column("start_date", sa.Date, nullable=False),
        sa.Column("end_date", sa.Date, nullable=False),
        sa.Column("reason", sa.String(120), nullable=True),
        sa.PrimaryKeyConstraint('id'),
    )
    op.create_index(op.f("ix_trainer_busy_periods_trainer_id"), "trainer_busy_periods", ['trainer_id'], unique=False)
    op.create_table(
        "trainer_skills",
        sa.Column("trainer_id", sa.Integer(), sa.ForeignKey('trainer_profiles.id', ondelete='CASCADE'), nullable=False),
        sa.Column("skill_id", sa.Integer(), sa.ForeignKey('skills.id', ondelete='CASCADE'), nullable=False),
        sa.PrimaryKeyConstraint('trainer_id', 'skill_id'),
    )
    op.create_table(
        "training_requirements",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("institution_id", sa.Integer(), sa.ForeignKey('institution_profiles.id', ondelete='CASCADE'), nullable=False),
        sa.Column("category_id", sa.Integer(), sa.ForeignKey('categories.id'), nullable=True),
        sa.Column("title", sa.String(160), nullable=False),
        sa.Column("technology", sa.String(80), nullable=False),
        sa.Column("description", sa.String(4000), nullable=False),
        sa.Column("student_count", sa.Integer, nullable=False),
        sa.Column("student_level", sa.String(15), nullable=False),
        sa.Column("duration_days", sa.Integer, nullable=False),
        sa.Column("sessions", sa.Integer, nullable=False),
        sa.Column("location", sa.String(120), nullable=False),
        sa.Column("mode", sa.String(10), nullable=False),
        sa.Column("start_date", sa.Date, nullable=False),
        sa.Column("end_date", sa.Date, nullable=False),
        sa.Column("preferred_experience_years", sa.Integer, nullable=False),
        sa.Column("budget_min", sa.Integer, nullable=False),
        sa.Column("budget_max", sa.Integer, nullable=False),
        sa.Column("application_deadline", sa.Date, nullable=False),
        sa.Column("additional_requirements", sa.String(2000), nullable=True),
        sa.Column("status", sa.String(10), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.PrimaryKeyConstraint('id'),
    )
    op.create_index(op.f("ix_req_status_deadline"), "training_requirements", ['status', 'application_deadline'], unique=False)
    op.create_index(op.f("ix_training_requirements_institution_id"), "training_requirements", ['institution_id'], unique=False)
    op.create_index(op.f("ix_training_requirements_technology"), "training_requirements", ['technology'], unique=False)
    op.create_index(op.f("ix_training_requirements_location"), "training_requirements", ['location'], unique=False)
    op.create_table(
        "applications",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("requirement_id", sa.Integer(), sa.ForeignKey('training_requirements.id', ondelete='CASCADE'), nullable=False),
        sa.Column("trainer_id", sa.Integer(), sa.ForeignKey('trainer_profiles.id', ondelete='CASCADE'), nullable=False),
        sa.Column("cover_note", sa.String(2000), nullable=True),
        sa.Column("proposed_fee", sa.Integer, nullable=True),
        sa.Column("status", sa.String(15), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('requirement_id', 'trainer_id', name='uq_application_pair'),
    )
    op.create_index(op.f("ix_applications_requirement_id"), "applications", ['requirement_id'], unique=False)
    op.create_index(op.f("ix_applications_trainer_id"), "applications", ['trainer_id'], unique=False)
    op.create_index(op.f("ix_applications_status"), "applications", ['status'], unique=False)
    op.create_table(
        "hiring_requests",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("application_id", sa.Integer(), sa.ForeignKey('applications.id', ondelete='CASCADE'), nullable=False),
        sa.Column("requirement_id", sa.Integer(), sa.ForeignKey('training_requirements.id', ondelete='CASCADE'), nullable=False),
        sa.Column("trainer_id", sa.Integer(), sa.ForeignKey('trainer_profiles.id', ondelete='CASCADE'), nullable=False),
        sa.Column("agreed_fee", sa.Integer, nullable=False),
        sa.Column("start_date", sa.Date, nullable=False),
        sa.Column("end_date", sa.Date, nullable=False),
        sa.Column("sessions", sa.Integer, nullable=False),
        sa.Column("terms", sa.String(2000), nullable=True),
        sa.Column("status", sa.String(10), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("responded_at", sa.DateTime(timezone=True), nullable=True),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint("application_id"),
    )
    op.create_index(op.f("ix_hiring_requests_requirement_id"), "hiring_requests", ['requirement_id'], unique=False)
    op.create_index(op.f("ix_hiring_requests_trainer_id"), "hiring_requests", ['trainer_id'], unique=False)
    op.create_index(op.f("ix_hiring_requests_status"), "hiring_requests", ['status'], unique=False)
    op.create_table(
        "match_scores",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("requirement_id", sa.Integer(), sa.ForeignKey('training_requirements.id', ondelete='CASCADE'), nullable=False),
        sa.Column("trainer_id", sa.Integer(), sa.ForeignKey('trainer_profiles.id', ondelete='CASCADE'), nullable=False),
        sa.Column("score", sa.Integer, nullable=False),
        sa.Column("factors", sa.JSON, nullable=False),
        sa.Column("weights", sa.JSON, nullable=False),
        sa.Column("computed_at", sa.DateTime(timezone=True), nullable=False),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('requirement_id', 'trainer_id', name='uq_match_pair'),
    )
    op.create_index(op.f("ix_match_scores_requirement_id"), "match_scores", ['requirement_id'], unique=False)
    op.create_index(op.f("ix_match_scores_trainer_id"), "match_scores", ['trainer_id'], unique=False)
    op.create_table(
        "requirement_skills",
        sa.Column("requirement_id", sa.Integer(), sa.ForeignKey('training_requirements.id', ondelete='CASCADE'), nullable=False),
        sa.Column("skill_id", sa.Integer(), sa.ForeignKey('skills.id', ondelete='CASCADE'), nullable=False),
        sa.PrimaryKeyConstraint('requirement_id', 'skill_id'),
    )
    op.create_table(
        "trainings",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("hiring_request_id", sa.Integer(), sa.ForeignKey('hiring_requests.id', ondelete='CASCADE'), nullable=False),
        sa.Column("requirement_id", sa.Integer(), sa.ForeignKey('training_requirements.id', ondelete='CASCADE'), nullable=False),
        sa.Column("trainer_id", sa.Integer(), sa.ForeignKey('trainer_profiles.id', ondelete='CASCADE'), nullable=False),
        sa.Column("institution_id", sa.Integer(), sa.ForeignKey('institution_profiles.id', ondelete='CASCADE'), nullable=False),
        sa.Column("title", sa.String(160), nullable=False),
        sa.Column("status", sa.String(10), nullable=False),
        sa.Column("start_date", sa.Date, nullable=False),
        sa.Column("end_date", sa.Date, nullable=False),
        sa.Column("agreed_fee", sa.Integer, nullable=False),
        sa.Column("student_count", sa.Integer, nullable=False),
        sa.Column("planned_sessions", sa.Integer, nullable=False),
        sa.Column("cancel_reason", sa.String(500), nullable=True),
        sa.Column("completed_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint("hiring_request_id"),
    )
    op.create_index(op.f("ix_trainings_requirement_id"), "trainings", ['requirement_id'], unique=False)
    op.create_index(op.f("ix_trainings_trainer_id"), "trainings", ['trainer_id'], unique=False)
    op.create_index(op.f("ix_trainings_institution_id"), "trainings", ['institution_id'], unique=False)
    op.create_index(op.f("ix_trainings_status"), "trainings", ['status'], unique=False)
    op.create_table(
        "reviews",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("training_id", sa.Integer(), sa.ForeignKey('trainings.id', ondelete='CASCADE'), nullable=False),
        sa.Column("direction", sa.String(25), nullable=False),
        sa.Column("reviewer_user_id", sa.Integer(), sa.ForeignKey('users.id', ondelete='CASCADE'), nullable=False),
        sa.Column("trainer_id", sa.Integer(), sa.ForeignKey('trainer_profiles.id', ondelete='CASCADE'), nullable=False),
        sa.Column("institution_id", sa.Integer(), sa.ForeignKey('institution_profiles.id', ondelete='CASCADE'), nullable=False),
        sa.Column("ratings", sa.JSON, nullable=False),
        sa.Column("overall", sa.Float, nullable=False),
        sa.Column("comment", sa.String(2000), nullable=True),
        sa.Column("is_hidden", sa.Boolean, nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('training_id', 'direction', name='uq_review_per_engagement'),
    )
    op.create_index(op.f("ix_reviews_training_id"), "reviews", ['training_id'], unique=False)
    op.create_index(op.f("ix_reviews_trainer_id"), "reviews", ['trainer_id'], unique=False)
    op.create_index(op.f("ix_reviews_institution_id"), "reviews", ['institution_id'], unique=False)
    op.create_table(
        "training_sessions",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("training_id", sa.Integer(), sa.ForeignKey('trainings.id', ondelete='CASCADE'), nullable=False),
        sa.Column("title", sa.String(120), nullable=False),
        sa.Column("session_date", sa.Date, nullable=False),
        sa.Column("start_time", sa.Time, nullable=False),
        sa.Column("end_time", sa.Time, nullable=False),
        sa.Column("status", sa.String(10), nullable=False),
        sa.PrimaryKeyConstraint('id'),
    )
    op.create_index(op.f("ix_training_sessions_training_id"), "training_sessions", ['training_id'], unique=False)
    op.create_index(op.f("ix_training_sessions_session_date"), "training_sessions", ['session_date'], unique=False)
    op.create_table(
        "attendance",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("session_id", sa.Integer(), sa.ForeignKey('training_sessions.id', ondelete='CASCADE'), nullable=False),
        sa.Column("total_students", sa.Integer, nullable=False),
        sa.Column("present", sa.Integer, nullable=False),
        sa.Column("absent", sa.Integer, nullable=False),
        sa.Column("notes", sa.String(1000), nullable=True),
        sa.Column("recorded_at", sa.DateTime(timezone=True), nullable=False),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint("session_id"),
    )


def _refuse_to_discard(*tables: str) -> None:
    """Downgrading 0001 drops all of these tables. Application data is never discarded silently: the downgrade stops while any of them holds a row, unless the
    operator sets ITB_ALLOW_FINANCIAL_DOWNGRADE=I_UNDERSTAND_DATA_WILL_BE_DESTROYED on purpose (disposable test databases). Export first. On PostgreSQL a refusal
    rolls back the whole `alembic downgrade` command (one transaction); SQLite does not give that guarantee, so never downgrade a database you want to keep."""
    if os.environ.get("ITB_ALLOW_FINANCIAL_DOWNGRADE") == "I_UNDERSTAND_DATA_WILL_BE_DESTROYED":
        return
    if context.is_offline_mode():          # `alembic downgrade --sql` has no connection, so it cannot know whether the tables hold records
        raise RuntimeError("Refusing to generate an offline (--sql) downgrade that drops every application table: it cannot check them for records. Run the downgrade online.")
    bind = op.get_bind()
    held = {t: bind.execute(sa.text(f"SELECT COUNT(*) FROM {t}")).scalar() for t in tables}
    held = {t: n for t, n in held.items() if n}
    if held:
        raise RuntimeError("Refusing to downgrade: it would permanently delete application data (" + ", ".join(f"{t}: {n} rows" for t, n in held.items())
                           + "). Export or back it up first. For a disposable test database only, set ITB_ALLOW_FINANCIAL_DOWNGRADE=I_UNDERSTAND_DATA_WILL_BE_DESTROYED.")


def downgrade() -> None:
    # imported here, not at module level: loading the migrations (alembic heads / history / revision) must not need `app`; env.py has already imported it by now
    from app.core.migration_guard import preflight_downgrade
    preflight_downgrade("0001")      # the WHOLE run is checked here, before any revision executes (app/core/migration_guard.py)
    _refuse_to_discard("attendance", "training_sessions", "reviews", "trainings", "requirement_skills", "match_scores", "hiring_requests", "applications", "training_requirements", "trainer_skills", "trainer_busy_periods", "trainer_profiles", "notifications", "institution_profiles", "audit_logs", "users", "skills", "platform_settings", "categories")
    op.drop_table("attendance")
    op.drop_index(op.f("ix_training_sessions_training_id"), table_name="training_sessions")
    op.drop_index(op.f("ix_training_sessions_session_date"), table_name="training_sessions")
    op.drop_table("training_sessions")
    op.drop_index(op.f("ix_reviews_training_id"), table_name="reviews")
    op.drop_index(op.f("ix_reviews_trainer_id"), table_name="reviews")
    op.drop_index(op.f("ix_reviews_institution_id"), table_name="reviews")
    op.drop_table("reviews")
    op.drop_index(op.f("ix_trainings_requirement_id"), table_name="trainings")
    op.drop_index(op.f("ix_trainings_trainer_id"), table_name="trainings")
    op.drop_index(op.f("ix_trainings_institution_id"), table_name="trainings")
    op.drop_index(op.f("ix_trainings_status"), table_name="trainings")
    op.drop_table("trainings")
    op.drop_table("requirement_skills")
    op.drop_index(op.f("ix_match_scores_requirement_id"), table_name="match_scores")
    op.drop_index(op.f("ix_match_scores_trainer_id"), table_name="match_scores")
    op.drop_table("match_scores")
    op.drop_index(op.f("ix_hiring_requests_requirement_id"), table_name="hiring_requests")
    op.drop_index(op.f("ix_hiring_requests_trainer_id"), table_name="hiring_requests")
    op.drop_index(op.f("ix_hiring_requests_status"), table_name="hiring_requests")
    op.drop_table("hiring_requests")
    op.drop_index(op.f("ix_applications_requirement_id"), table_name="applications")
    op.drop_index(op.f("ix_applications_trainer_id"), table_name="applications")
    op.drop_index(op.f("ix_applications_status"), table_name="applications")
    op.drop_table("applications")
    op.drop_index(op.f("ix_req_status_deadline"), table_name="training_requirements")
    op.drop_index(op.f("ix_training_requirements_institution_id"), table_name="training_requirements")
    op.drop_index(op.f("ix_training_requirements_technology"), table_name="training_requirements")
    op.drop_index(op.f("ix_training_requirements_location"), table_name="training_requirements")
    op.drop_table("training_requirements")
    op.drop_table("trainer_skills")
    op.drop_index(op.f("ix_trainer_busy_periods_trainer_id"), table_name="trainer_busy_periods")
    op.drop_table("trainer_busy_periods")
    op.drop_index(op.f("ix_trainer_profiles_location"), table_name="trainer_profiles")
    op.drop_table("trainer_profiles")
    op.drop_index(op.f("ix_notifications_user_id"), table_name="notifications")
    op.drop_index(op.f("ix_notifications_is_read"), table_name="notifications")
    op.drop_table("notifications")
    op.drop_table("institution_profiles")
    op.drop_index(op.f("ix_audit_logs_user_id"), table_name="audit_logs")
    op.drop_index(op.f("ix_audit_logs_action"), table_name="audit_logs")
    op.drop_table("audit_logs")
    op.drop_index(op.f("ix_users_email"), table_name="users")
    op.drop_index(op.f("ix_users_role"), table_name="users")
    op.drop_table("users")
    op.drop_index(op.f("ix_skills_name"), table_name="skills")
    op.drop_table("skills")
    op.drop_table("platform_settings")
    op.drop_table("categories")
