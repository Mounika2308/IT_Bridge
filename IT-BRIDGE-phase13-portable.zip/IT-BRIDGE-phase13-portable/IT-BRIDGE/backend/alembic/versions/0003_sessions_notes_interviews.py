"""session notes (moved off attendance) and interview date/time on applications

Revision ID: 0003
Revises: 0002
"""
import sqlalchemy as sa
from alembic import op

revision = "0003"
down_revision = "0002"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column("training_sessions", sa.Column("notes", sa.String(1000), nullable=True))
    # Notes used to live on attendance rows: carry them over. attendance.notes stays (deprecated), so nothing is lost.
    op.execute("UPDATE training_sessions SET notes = (SELECT a.notes FROM attendance a WHERE a.session_id = training_sessions.id)")
    op.add_column("applications", sa.Column("interview_at", sa.DateTime(), nullable=True))


def downgrade() -> None:
    # imported here, not at module level: loading the migrations (alembic heads / history / revision) must not need `app`; env.py has already imported it by now
    from app.core.migration_guard import preflight_downgrade
    preflight_downgrade("0003")      # the WHOLE run is checked here, before any revision executes (app/core/migration_guard.py)
    with op.batch_alter_table("applications") as batch:
        batch.drop_column("interview_at")
    with op.batch_alter_table("training_sessions") as batch:
        batch.drop_column("notes")
