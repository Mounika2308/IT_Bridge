"""trainings: snapshot of what was agreed (technology, mode, location, description, terms) and the online meeting link

Revision ID: 0002
Revises: 0001
"""
import sqlalchemy as sa
from alembic import op

revision = "0002"
down_revision = "0001"
branch_labels = None
depends_on = None

REQUIRED = [("technology", sa.String(80)), ("mode", sa.String(10)), ("location", sa.String(120)), ("description", sa.String(4000))]


def upgrade() -> None:
    for name, typ in REQUIRED:
        op.add_column("trainings", sa.Column(name, typ, nullable=True))
    op.add_column("trainings", sa.Column("terms", sa.String(2000), nullable=True))
    op.add_column("trainings", sa.Column("meeting_link", sa.String(300), nullable=True))
    # Existing trainings take their values from the requirement and hiring request they were created from.
    op.execute(
        "UPDATE trainings SET "
        "technology = (SELECT r.technology FROM training_requirements r WHERE r.id = trainings.requirement_id), "
        "mode = (SELECT r.mode FROM training_requirements r WHERE r.id = trainings.requirement_id), "
        "location = (SELECT r.location FROM training_requirements r WHERE r.id = trainings.requirement_id), "
        "description = (SELECT r.description FROM training_requirements r WHERE r.id = trainings.requirement_id), "
        "terms = (SELECT h.terms FROM hiring_requests h WHERE h.id = trainings.hiring_request_id)"
    )
    with op.batch_alter_table("trainings") as batch:
        for name, typ in REQUIRED:
            batch.alter_column(name, existing_type=typ, nullable=False)


def downgrade() -> None:
    # imported here, not at module level: loading the migrations (alembic heads / history / revision) must not need `app`; env.py has already imported it by now
    from app.core.migration_guard import preflight_downgrade
    preflight_downgrade("0002")      # the WHOLE run is checked here, before any revision executes (app/core/migration_guard.py)
    with op.batch_alter_table("trainings") as batch:
        for name in ("meeting_link", "terms", "description", "location", "mode", "technology"):
            batch.drop_column(name)
