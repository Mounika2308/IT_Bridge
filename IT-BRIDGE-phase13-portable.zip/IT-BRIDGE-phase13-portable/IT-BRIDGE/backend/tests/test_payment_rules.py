"""Phase 13: the pure payment rules. No database, no network, no app imports beyond the rules module itself."""
import itertools
import random

import pytest

from app.services import payment_rules as r

SECRET = "x" * 12 + "Kq7vR2mZp9sT4wB8nC3dF6hJ1LaE5gY0"


# ---------- money ----------
def test_fee_is_converted_from_rupees_to_paise():
    assert r.fee_paise(0) == 0 and r.fee_paise(1) == 100 and r.fee_paise(100_000_000) == 10_000_000_000


@pytest.mark.parametrize("bad", [-1, 1.5, "10", None, True])
def test_money_rejects_anything_that_is_not_a_non_negative_int(bad):
    with pytest.raises(ValueError):
        r.fee_paise(bad)
    with pytest.raises(ValueError):
        r.commission_total(bad, 1000)


@pytest.mark.parametrize("bad", [-1, 10_001, 10.0, "1000", None, True])
def test_commission_rate_must_be_whole_basis_points_in_range(bad):
    with pytest.raises(ValueError):
        r.commission_total(10_000, bad)


@pytest.mark.parametrize("amount,bps,expected", [
    (10_000, 1000, 1000),      # 10% of Rs 100
    (5, 1000, 1),              # 0.5 paise rounds half UP
    (4, 1000, 0),              # 0.4 rounds down
    (15, 1000, 2),             # 1.5 rounds up
    (14, 1000, 1),             # 1.4 rounds down
    (1, 5000, 1),              # 0.5
    (3, 5000, 2),              # 1.5
    (99_999, 1000, 10_000),    # 9999.9 -> 10000
    (12_345, 0, 0),            # no commission
    (12_345, 10_000, 12_345),  # everything
])
def test_commission_is_integer_half_up(amount, bps, expected):
    assert r.commission_total(amount, bps) == expected


def test_commission_never_negative_or_above_amount_and_is_monotonic():
    for bps in (0, 1, 333, 1000, 2500, 5000, 9999, 10_000):
        last = 0
        for amount in range(0, 400):
            c = r.commission_total(amount, bps)
            assert 0 <= c <= amount and c >= last
            last = c


def test_every_split_of_a_fee_collects_exactly_the_same_commission():
    """Instalments: whatever way a fee is paid, commission adds up to commission_total(fee) and net adds up to fee - commission."""
    for bps in (0, 333, 1000, 2500, 9999, 10_000):
        for fee in range(1, 45):
            want = r.commission_total(fee, bps)
            for a in range(1, fee):                              # two instalments
                c1, n1 = r.split(0, a, bps)
                c2, n2 = r.split(a, fee - a, bps)
                assert c1 + c2 == want and n1 + n2 == fee - want and min(n1, n2) >= 0
            for a, b in itertools.combinations(range(1, fee), 2):  # three instalments
                parts, before, total_c = [a, b - a, fee - b], 0, 0
                for amt in parts:
                    c, n = r.split(before, amt, bps)
                    assert 0 <= c <= amt and n == amt - c
                    total_c, before = total_c + c, before + amt
                assert total_c == want


def test_random_large_splits_keep_the_invariant():
    rnd = random.Random(13)
    for _ in range(300):
        fee, bps = rnd.randint(1, 10 ** 10), rnd.choice([1, 250, 1000, 1234, 9999])
        cuts = sorted(rnd.sample(range(1, fee), min(4, fee - 1))) if fee > 5 else []
        parts, prev = [], 0
        for c in cuts + [fee]:
            parts.append(c - prev)
            prev = c
        before = total = 0
        for amt in parts:
            total += r.instalment_commission(before, amt, bps)
            before += amt
        assert total == r.commission_total(fee, bps)


def test_remaining_never_goes_below_zero():
    assert r.remaining(1000, 0) == 1000 and r.remaining(1000, 400) == 600 and r.remaining(1000, 1000) == 0 and r.remaining(1000, 1500) == 0


def test_a_training_keeps_the_rate_of_its_first_collected_money():
    assert r.choose_rate(None, 1000) == 1000
    assert r.choose_rate(750, 1000) == 750          # the configured rate changed later: the training keeps its own
    with pytest.raises(ValueError):
        r.choose_rate(None, 10_001)


@pytest.mark.parametrize("paise,text", [
    (0, "₹0"), (100, "₹1"), (150, "₹1.50"), (5, "₹0.05"), (99_999, "₹999.99"), (100_000, "₹1,000"), (10_000_000, "₹1,00,000"),
    (12_345_678, "₹1,23,456.78"), (10_000_000_000, "₹10,00,00,000"), (100_000_000_000, "₹1,00,00,00,000"), (-250, "-₹2.50")])
def test_money_is_formatted_with_indian_grouping(paise, text):
    assert r.format_inr(paise) == text


# ---------- creating a payment ----------
OK = dict(enabled=True, account_blocked=False, training_status="ACTIVE", fee=100_000, collected=0, in_flight=False, amount=100_000)


def create(**kw):
    return r.check_create(**{**OK, **kw})


def test_a_valid_full_payment_is_allowed():
    assert create() is None and create(amount=40_000) is None and create(collected=60_000, amount=40_000) is None
    assert create(training_status="COMPLETED") is None    # paying after completion is fine


@pytest.mark.parametrize("amount", [0, -5, 1.5, "100", None, True, False])
def test_amount_must_be_a_positive_integer(amount):
    refusal = create(amount=amount)
    assert refusal and refusal.status == 422 and refusal.code == "INVALID_AMOUNT"


@pytest.mark.parametrize("kw,status,code", [
    (dict(enabled=False), 503, "DISABLED"), (dict(account_blocked=True), 403, "SUSPENDED"),
    (dict(training_status="CANCELLED"), 409, "TRAINING_CANCELLED"), (dict(fee=0), 409, "NO_FEE"),
    (dict(in_flight=True), 409, "IN_PROGRESS"), (dict(collected=100_000), 409, "FULLY_PAID"),
    (dict(collected=150_000), 409, "FULLY_PAID"), (dict(amount=100_001), 409, "OVER_FEE"),
    (dict(collected=99_950, amount=60), 409, "OVER_FEE"), (dict(amount=99), 422, "TOO_SMALL"),
])
def test_refusals(kw, status, code):
    refusal = create(**kw)
    assert refusal and (refusal.status, refusal.code) == (status, code) and refusal.message


def test_a_free_training_can_never_be_charged():
    for amount in (1, 100, 100_000):
        assert create(fee=0, amount=amount).code == "NO_FEE"


def test_the_last_instalment_may_be_below_the_minimum_but_only_if_it_is_exactly_what_is_left():
    assert create(collected=99_950, amount=50) is None
    assert create(collected=99_950, amount=49).code == "TOO_SMALL"


def test_block_reason_matches_check_create_and_has_text():
    for kw in (dict(enabled=False), dict(account_blocked=True), dict(training_status="CANCELLED"), dict(fee=0), dict(in_flight=True), dict(collected=100_000)):
        why = r.block_reason(**{k: v for k, v in {**OK, **kw}.items() if k != "amount"})
        assert why in r.BLOCK_TEXT and why == create(**kw).code
    assert r.block_reason(**{k: v for k, v in OK.items() if k != "amount"}) is None


# ---------- 13B.1: held money that has not settled is not "paid in full" ----------
def _why(**kw):
    return r.block_reason(**{k: v for k, v in {**OK, **kw}.items() if k != "amount"})


def test_held_money_that_has_not_settled_is_awaiting_refund_not_fully_paid():
    assert _why(collected=120_000, settled=60_000) == "AWAITING_REFUND"           # fee 100_000: Rs 60 settled, Rs 60 on hold
    assert _why(collected=100_000, settled=0) == "AWAITING_REFUND"                  # nothing settled, a whole fee on hold
    assert _why(collected=100_000, settled=99_999) == "AWAITING_REFUND"             # one paisa short


def test_settled_money_that_reaches_the_fee_is_fully_paid_even_if_more_is_on_hold():
    assert _why(collected=200_000, settled=100_000) == "FULLY_PAID"
    assert _why(collected=100_000, settled=100_000) == "FULLY_PAID"
    assert _why(collected=150_000, settled=150_000) == "FULLY_PAID"


def test_without_a_settled_figure_the_old_behaviour_is_unchanged():
    assert _why(collected=100_000) == "FULLY_PAID" and _why(collected=150_000, settled=None) == "FULLY_PAID"


def test_the_other_reasons_keep_their_precedence_over_the_fee_reasons():
    for kw, want in ((dict(enabled=False), "DISABLED"), (dict(account_blocked=True), "SUSPENDED"), (dict(training_status="CANCELLED"), "TRAINING_CANCELLED"),
                     (dict(fee=0), "NO_FEE"), (dict(in_flight=True), "IN_PROGRESS")):
        assert _why(collected=120_000, settled=60_000, **kw) == want


def test_the_awaiting_refund_refusal_names_the_amount_still_due_and_never_says_paid_in_full():
    refusal = create(collected=120_000, settled=60_000)
    assert (refusal.status, refusal.code) == (409, "AWAITING_REFUND")
    assert "paid in full" not in refusal.message and r.format_inr(40_000) in refusal.message and "refund" in refusal.message
    assert r.block_text("AWAITING_REFUND", fee=100_000, settled=60_000) == refusal.message
    assert "paid in full" not in r.BLOCK_TEXT["AWAITING_REFUND"]                    # the static fallback is accurate too
    assert r.block_text("FULLY_PAID") == "The agreed fee has been paid in full."


def test_the_cap_rules_are_unchanged_by_the_settled_figure():
    assert create(collected=60_000, settled=60_000, amount=40_000) is None
    assert create(collected=60_000, settled=60_000, amount=40_001).code == "OVER_FEE"
    assert create(collected=60_000, amount=40_000) is None


def test_idempotency_keys_and_fingerprints():
    assert r.valid_idempotency_key("abcd1234") and r.valid_idempotency_key("a-b_c.d:e" + "1" * 10)
    for bad in (None, "", "short", "has space 123", "x" * 81, "émoji-12345678", 12345678, "new\nline12345"):
        assert not r.valid_idempotency_key(bad)
    assert r.fingerprint(1, 100) == r.fingerprint(1, 100)
    assert r.fingerprint(1, 100) != r.fingerprint(2, 100) != r.fingerprint(2, 101)


# ---------- commission at settlement ----------
def _settle_all(fee, bps, order, refund=()):
    """Settles instalments (a list of amounts) in `order` of success; `refund` lists instalment indexes refunded at the start. Returns the live commissions."""
    live = []                                              # (amount, commission) of live settled payments
    for i in order:
        money, commission = sum(a for a, _ in live), sum(c for _, c in live)
        c, net = r.settle_commission(money, commission, AMOUNTS[i], bps)
        assert 0 <= c <= AMOUNTS[i] and net == AMOUNTS[i] - c
        live.append((AMOUNTS[i], c))
    return live


AMOUNTS = [105, 105]


def test_settlement_in_creation_order_equals_the_instalment_rule():
    rng = random.Random(7)
    for _ in range(2000):
        fee = rng.randint(1, 5_000_000)
        cuts = sorted(rng.sample(range(1, fee), min(rng.randint(0, 5), fee - 1))) if fee > 1 else []
        parts = [b - a for a, b in zip([0] + cuts, cuts + [fee])]
        bps = rng.choice([0, 1, 333, 1000, 1250, 2500, 9999, 10_000])
        money = commission = 0
        for a in parts:
            c, _ = r.settle_commission(money, commission, a, bps)
            assert c == r.instalment_commission(money, a, bps)
            money, commission = money + a, commission + c
        assert commission == r.commission_total(fee, bps)


def test_settlement_in_ANY_order_still_adds_up_to_the_commission_on_the_whole_fee():
    """The reviewer's scenario: instalments of 105 on a fee of 210 at 10%. Estimates made at creation time (11 and 11) would total 22."""
    global AMOUNTS
    for amounts in ([105, 105], [101, 104], [1, 209], [70, 70, 70], [33, 77, 100]):
        AMOUNTS = amounts
        for order in itertools.permutations(range(len(amounts))):
            live = _settle_all(sum(amounts), 1000, order)
            assert sum(c for _, c in live) == r.commission_total(sum(amounts), 1000), (amounts, order)


def test_settlement_after_a_refund_and_a_new_payment_still_totals_the_commission_on_the_money_held():
    """Reviewer scenario 2: #1 and #2 succeed, #1 is refunded, #3 pays the same amount again. The live commissions must total commission_total(live money)."""
    c1, _ = r.settle_commission(0, 0, 105, 1000)
    c2, _ = r.settle_commission(105, c1, 105, 1000)
    assert (c1, c2) == (11, 10)
    c3, _ = r.settle_commission(105, c2, 105, 1000)                  # #1 refunded: only #2 is live
    assert c2 + c3 == r.commission_total(210, 1000) == 21
    # the other reviewer example: A=101, B=104, refund A, then C=100, fee 204 at 10%
    a, _ = r.settle_commission(0, 0, 101, 1000)
    b, _ = r.settle_commission(101, a, 104, 1000)
    c, _ = r.settle_commission(104, b, 100, 1000)
    assert b + c == r.commission_total(204, 1000) == 20


def test_settled_commission_is_never_negative_never_above_the_payment_and_net_is_never_negative():
    rng = random.Random(11)
    for _ in range(5000):
        amount = rng.randint(1, 1_000_000)
        money = rng.randint(0, 1_000_000)
        bps = rng.choice([0, 1, 1000, 5000, 10_000])
        commission = rng.randint(0, r.commission_total(money, bps) + 3)          # stale drift of a few paise either way
        c, net = r.settle_commission(money, commission, amount, bps)
        assert 0 <= c <= amount and net == amount - c and net >= 0


def test_a_hundred_percent_commission_leaves_the_trainer_nothing_but_never_less():
    assert r.settle_commission(0, 0, 500, 10_000) == (500, 0)
    assert r.settle_commission(0, 0, 500, 0) == (0, 500)


@pytest.mark.parametrize("args", [(-1, 0, 100, 1000), (0, -1, 100, 1000), (0, 0, -1, 1000), (0, 0, 100, 10_001), (0.5, 0, 100, 1000), (0, 0, True, 1000)])
def test_settle_commission_rejects_bad_input(args):
    with pytest.raises(ValueError):
        r.settle_commission(*args)


# ---------- state machine ----------
def test_transition_table_is_closed_and_succeeded_is_final():
    assert set(r.TRANSITIONS) == set(r.PAYMENT_STATUSES)
    for old, new in r.TRANSITIONS.items():
        assert new <= set(r.PAYMENT_STATUSES) and old not in new
    assert r.TRANSITIONS[r.SUCCEEDED] == frozenset()
    assert not any(r.can_transition(r.SUCCEEDED, s) for s in r.PAYMENT_STATUSES)
    for s in r.LATE_SUCCESS_FROM:
        assert r.TRANSITIONS[s] == frozenset({r.SUCCEEDED})
    assert r.can_transition(r.PENDING, r.PROCESSING) and not r.can_transition(r.PROCESSING, r.PENDING) and not r.can_transition(r.PENDING, "BOGUS")
    assert r.TRANSITIONS[r.PROCESSING] == frozenset({r.SUCCEEDED, r.FAILED, r.EXPIRED})     # EXPIRED: the worker's way out of a payment stuck in PROCESSING
    assert not r.can_transition(r.PROCESSING, r.CANCELLED)                                # the payer can never cancel something already being processed
    assert set(r.IN_FLIGHT) == {r.PENDING, r.PROCESSING}


def test_earning_transitions():
    assert r.can_transition_earning("PENDING", "AVAILABLE") and r.can_transition_earning("AVAILABLE", "PAID")
    assert r.can_transition_earning("PENDING", "REFUNDED") and r.can_transition_earning("AVAILABLE", "REFUNDED")
    assert not r.can_transition_earning("PENDING", "PAID")           # a payout needs the training to be complete
    assert not r.can_transition_earning("PAID", "REFUNDED") and not r.can_transition_earning("REFUNDED", "AVAILABLE")


BASE = dict(status="PENDING", amount_paise=50_000, currency="INR", charge_txn_on_file=None, event_type="payment.succeeded", event_amount=50_000,
            event_currency="INR", event_txn_id="txn_1", event_reason=None, collected_other=0, fee=100_000, training_status="ACTIVE")


def decide(**kw):
    return r.decide_event(**{**BASE, **kw})


def test_success_settles_a_pending_or_processing_payment():
    for st in ("PENDING", "PROCESSING"):
        d = decide(status=st)
        assert (d.outcome, d.new_status, d.record_charge, d.settle, d.flag) == ("succeeded", "SUCCEEDED", True, True, None)
        assert d.invoice


def test_late_success_is_accepted_and_flagged_never_discarded():
    for st in ("FAILED", "CANCELLED", "EXPIRED"):
        d = decide(status=st)
        assert (d.outcome, d.new_status, d.record_charge, d.settle, d.flag) == ("succeeded_late", "SUCCEEDED", True, True, "LATE_SUCCESS")


def test_success_that_would_exceed_the_fee_is_recorded_and_flagged_but_not_settled():
    d = decide(collected_other=60_000)                               # 60,000 + 50,000 > 100,000
    assert (d.outcome, d.new_status, d.record_charge, d.settle, d.flag) == ("succeeded_over_cap", "SUCCEEDED", True, False, "OVER_CAP")
    assert d.invoice                                                   # every successful payment has its invoice, also one that will be refunded
    assert decide(collected_other=50_000).settle is True              # exactly the fee is fine
    assert decide(collected_other=50_001).flag == "OVER_CAP"          # one paise over is over
    assert decide(status="FAILED", collected_other=60_000).flag == "OVER_CAP"


def test_success_on_a_cancelled_training_is_flagged_for_review():
    d = decide(training_status="CANCELLED")
    assert d.new_status == "SUCCEEDED" and d.flag == "TRAINING_CANCELLED" and d.settle


def test_replayed_and_second_success_events():
    assert decide(status="SUCCEEDED", charge_txn_on_file="txn_1").outcome == "duplicate"
    d = decide(status="SUCCEEDED", charge_txn_on_file="txn_OTHER")   # a different charge for the same payment: evidence of a double charge
    assert d.outcome == "duplicate_charge" and d.flag == "DUPLICATE_CHARGE" and d.new_status is None and not d.settle


@pytest.mark.parametrize("status", r.PAYMENT_STATUSES)
def test_amount_or_currency_mismatch_changes_nothing_and_is_flagged(status):
    d = decide(status=status, event_amount=49_999)
    assert (d.outcome, d.new_status, d.flag, d.record_charge, d.settle) == ("amount_mismatch", None, "AMOUNT_MISMATCH", False, False)
    d = decide(status=status, event_currency="USD")
    assert (d.outcome, d.new_status, d.flag, d.record_charge, d.settle) == ("currency_mismatch", None, "CURRENCY_MISMATCH", False, False)


def test_failure_only_closes_an_open_payment():
    d = decide(event_type="payment.failed", event_reason="Card declined", event_txn_id=None)
    assert (d.outcome, d.new_status, d.failure_reason) == ("failed", "FAILED", "Card declined")
    assert decide(status="PROCESSING", event_type="payment.failed").new_status == "FAILED"
    for st in ("SUCCEEDED", "FAILED", "CANCELLED", "EXPIRED"):      # a failure report can never undo a success or reopen a closed attempt
        assert decide(status=st, event_type="payment.failed").new_status is None
    assert len(decide(event_type="payment.failed", event_reason="x" * 999).failure_reason) == 200


def test_processing_event_only_moves_a_pending_payment():
    assert decide(event_type="payment.processing").new_status == "PROCESSING"
    for st in ("PROCESSING", "SUCCEEDED", "FAILED", "CANCELLED", "EXPIRED"):
        d = decide(status=st, event_type="payment.processing")
        assert d.new_status is None and d.outcome == "stale_ignored"


def test_unknown_event_types_are_ignored_not_trusted():
    d = decide(event_type="payment.refunded")
    assert d.outcome == "ignored_unknown_type" and d.new_status is None and not d.settle


def test_no_decision_ever_asks_for_an_illegal_transition():
    for st, et, other, ts in itertools.product(r.PAYMENT_STATUSES, r.EVENT_TYPES, (0, 60_000), ("ACTIVE", "CANCELLED")):
        d = decide(status=st, event_type=et, collected_other=other, training_status=ts)
        assert d.new_status is None or r.can_transition(st, d.new_status)
        assert not d.settle or (d.new_status == "SUCCEEDED" and d.record_charge)


# ---------- earnings, refunds, payouts ----------
def test_earning_starts_available_only_for_a_completed_training():
    assert r.initial_earning_status("COMPLETED") == "AVAILABLE"
    assert r.initial_earning_status("ACTIVE") == "PENDING" and r.initial_earning_status("CANCELLED") == "PENDING"


def test_hold_period():
    assert r.hold_elapsed(0, 0) and r.hold_elapsed(86_400, 1) and not r.hold_elapsed(86_399, 1)


@pytest.mark.parametrize("pay,refund,earning,action", [
    ("SUCCEEDED", None, "PENDING", "create"), ("SUCCEEDED", None, "AVAILABLE", "create"), ("SUCCEEDED", None, None, "create"),
    ("SUCCEEDED", "PENDING", "PENDING", "resume"), ("SUCCEEDED", "SUCCEEDED", "REFUNDED", "done"),
    ("SUCCEEDED", None, "PAID", "refuse"), ("FAILED", None, None, "refuse"), ("PENDING", None, None, "refuse"), ("CANCELLED", None, None, "refuse"),
])
def test_refund_action(pay, refund, earning, action):
    got, refusal = r.refund_action(pay, refund, earning)
    assert got == action and (refusal is not None) == (action == "refuse")
    if refusal:
        assert refusal.status == 409 and refusal.message


def test_refunding_twice_is_never_a_second_create():
    assert r.refund_action("SUCCEEDED", "PENDING", "PENDING")[0] != "create" and r.refund_action("SUCCEEDED", "SUCCEEDED", "REFUNDED")[0] != "create"


def test_payout_reference_allows_at_most_eight_digits():
    assert r.clean_payout_reference("BATCH-2030-07-15") == "BATCH-2030-07-15"          # 8 digits
    with pytest.raises(ValueError):
        r.clean_payout_reference("BATCH-2030-07-15-1")                                 # 9 digits


def test_an_over_cap_review_cannot_be_closed_until_the_payment_is_refunded():
    assert r.resolve_refusal("OVER_CAP", "SUCCEEDED", None).code == "REFUND_REQUIRED"
    assert r.resolve_refusal("OVER_CAP", "SUCCEEDED", "PENDING").code == "REFUND_REQUIRED"      # a refund still in progress is not a refund yet
    assert r.resolve_refusal("OVER_CAP", "SUCCEEDED", "SUCCEEDED") is None
    for reason in ("LATE_SUCCESS", "DUPLICATE_CHARGE", "AMOUNT_MISMATCH", "CURRENCY_MISMATCH", "TRAINING_CANCELLED", "STUCK_PROCESSING", "REFUND_STUCK", None):
        assert r.resolve_refusal(reason, "SUCCEEDED", None) is None


def test_payout_rules():
    assert r.payout_refusal("AVAILABLE", None) is None
    assert r.payout_refusal("PENDING", None).code == "NOT_AVAILABLE"
    assert r.payout_refusal("PAID", None).code == "ALREADY_PAID"
    assert r.payout_refusal("REFUNDED", None).code == "REFUNDED"
    assert r.payout_refusal("AVAILABLE", "PENDING").code == "REFUND_EXISTS" and r.payout_refusal("AVAILABLE", "SUCCEEDED").code == "REFUND_EXISTS"
    assert r.payout_refusal("AVAILABLE", None, True).code == "UNDER_REVIEW"


@pytest.mark.parametrize("text", ["BATCH-2026-10-A", "  October payout run  ", "ref 42", "abc"])
def test_payout_reference_accepts_an_operators_own_reference(text):
    assert r.clean_payout_reference(text) == text.strip()


@pytest.mark.parametrize("text", ["12", "x" * 81, "", "   ", None, 123456789012, "123456789012", "1234 5678 9012", "1234-5678-9012-3456", "someone@upi", "name@okbank", "bad\x00ref", "line\nbreak",
                                  # separators of every kind, other digit forms and look-alike characters must not get an account number or UPI id through
                                  "1234.5678.9012", "1234/5678/9012", "1234_5678_9012", "1234,5678,9012", "1234:5678:9012", "1234|5678|9012", "1234(5678)9012",
                                  "1234 \u00b7 5678 \u00b7 9012", "1234\u200b5678\u200b9012", "name\uff20upi", "\uff11\uff12\uff13\uff14\uff15\uff16\uff17\uff18\uff19",
                                  "\u0661\u0662\u0663\u0664\u0665\u0666\u0667\u0668\u0669", "A1B2C3D4E5F6G7H8I9", "PAYOUT-2030-07-15-001"])
def test_payout_reference_refuses_bank_and_upi_details(text):
    with pytest.raises(ValueError):
        r.clean_payout_reference(text)


# ---------- numbering ----------
def test_document_numbers():
    assert r.invoice_number(2026, 1) == "ITB-2026-000001" and r.invoice_number(2026, 123456) == "ITB-2026-123456"
    assert r.credit_note_number(2026, 7) == "ITB-CN-2026-000007"
    assert len(r.credit_note_number(2026, 999_999)) <= 24
    for bad in (0, -1):
        with pytest.raises(ValueError):
            r.invoice_number(2026, bad)
        with pytest.raises(ValueError):
            r.credit_note_number(2026, bad)


# ---------- webhook authentication ----------
NOW, BODY = 1_800_000_000, b'{"id":"evt_1"}'


def check(**kw):
    args = dict(secret=SECRET, body=BODY, signature=r.sign(SECRET, str(NOW), BODY), timestamp=str(NOW), now_epoch=NOW, tolerance_seconds=300)
    return r.check_webhook(**{**args, **kw})


def test_a_correctly_signed_fresh_request_is_accepted():
    assert check() is None
    assert check(signature=r.sign(SECRET, str(NOW), BODY).upper()) is None          # hex case does not matter
    assert check(now_epoch=NOW + 299) is None and check(now_epoch=NOW - 299) is None


@pytest.mark.parametrize("kw,reason", [
    (dict(secret=""), "not_configured"), (dict(signature=None), "missing_signature"), (dict(signature=""), "missing_signature"),
    (dict(timestamp=None), "missing_timestamp"), (dict(timestamp="soon"), "bad_timestamp"), (dict(timestamp="1.5"), "bad_timestamp"),
    (dict(now_epoch=NOW + 301), "stale_timestamp"), (dict(now_epoch=NOW - 301), "stale_timestamp"),
    (dict(body=b'{"id":"evt_2"}'), "bad_signature"), (dict(secret="y" * 40), "bad_signature"), (dict(signature="0" * 64), "bad_signature"),
])
def test_everything_else_is_rejected_with_a_reason(kw, reason):
    assert check(**kw) == reason


@pytest.mark.parametrize("timestamp", ["9" * 400, "-" + "9" * 400, "9" * 309, "1" + "0" * 4000])
def test_a_timestamp_too_large_for_a_float_is_refused_not_a_crash(timestamp):
    """int() accepts hundreds of digits but float arithmetic does not. This used to raise OverflowError, a server error on an endpoint that is open
    to the internet. It is a refusal like any other stale timestamp."""
    assert check(timestamp=timestamp, now_epoch=float(NOW)) == "stale_timestamp"     # production passes time.time(), a float: an int here would never overflow


def test_the_largest_timestamp_a_float_can_hold_is_still_just_stale_and_an_absurd_one_is_malformed():
    assert check(timestamp="9" * 308, now_epoch=float(NOW)) == "stale_timestamp"               # fits a float: ordinary arithmetic
    assert check(timestamp="9" * 5000, now_epoch=float(NOW)) in ("bad_timestamp", "stale_timestamp")                 # int() itself refuses it on current Python (bad), older Python (stale)


def test_the_timestamp_is_part_of_the_signature_so_an_old_body_cannot_be_replayed_with_a_fresh_time():
    old_sig = r.sign(SECRET, str(NOW - 10_000), BODY)
    assert check(signature=old_sig) == "bad_signature"
    assert check(signature=old_sig, timestamp=str(NOW - 10_000)) == "stale_timestamp"


def test_with_no_secret_nothing_is_accepted_even_with_a_matching_empty_signature():
    assert r.check_webhook(secret="", body=BODY, signature=r.sign("", str(NOW), BODY), timestamp=str(NOW), now_epoch=NOW, tolerance_seconds=300) == "not_configured"


# ---------- start-up safety ----------
SAFE = dict(environment="production", enabled=True, provider="realgateway", secret=SECRET, commission_bps=1000, commission_confirmed=True)


DEV = dict(environment="development", enabled=True, provider="sandbox", secret="", commission_bps=1000, commission_confirmed=False)


def test_development_with_the_sandbox_is_allowed_only_with_the_explicit_opt_in():
    assert r.config_problems(**DEV, sandbox_opt_in=True) == []
    assert any("PAYMENT_SANDBOX_ENABLED" in p for p in r.config_problems(**DEV))                # enabled, no opt-in: refuse to start
    assert any("PAYMENT_SANDBOX_ENABLED" in p for p in r.config_problems(**DEV, sandbox_opt_in=False))


def test_production_with_payments_off_needs_a_strong_webhook_secret_but_nothing_else():
    """13B.2: payments off no longer excuses a missing or weak webhook secret in production. With a strong one the other defaults are fine."""
    off = dict(environment="production", enabled=False, provider="sandbox", commission_bps=1000, commission_confirmed=False)
    assert r.config_problems(**off, secret=SECRET) == []
    assert any("PAYMENT_WEBHOOK_SECRET is missing" in p for p in r.config_problems(**off, secret=""))


def test_production_refuses_the_sandbox_a_weak_secret_and_an_unconfirmed_commission():
    problems = r.config_problems(**{**SAFE, "provider": "sandbox", "secret": "", "commission_confirmed": False})
    text = " ".join(problems)
    assert len(problems) == 3 and "sandbox" in text and "WEBHOOK_SECRET" in text and "COMMISSION" in text


def test_production_refuses_a_provider_that_is_not_implemented():
    assert any("not implemented" in p for p in r.config_problems(**SAFE))      # no real provider exists in Phase 13, so this can never pass


@pytest.mark.parametrize("secret", ["", "   ", "change_me", "short", "a" * 40, "secret", "x" * 31])
def test_weak_secrets(secret):
    assert r.is_weak_secret(secret)


@pytest.mark.parametrize("secret", ["dev-only-sandbox-webhook-secret-do-not-use-in-production", "please-change_me-" + "Kq7vR2mZp9sT4wB8nC3dF6hJ1LaE5gY0",
                                    "this-is-an-example-secret-Kq7vR2mZp9sT4wB8nC3dF6hJ1LaE5gY0", "my-placeholder-Kq7vR2mZp9sT4wB8nC3dF6hJ1LaE5gY0"])
def test_the_documented_example_secrets_are_weak(secret):
    assert r.is_weak_secret(secret)                       # a copied .env.example must not pass the production guard once a real provider exists


@pytest.mark.parametrize("env", ["production", "Production", " PRODUCTION ", "prod", "PROD"])
def test_the_production_guard_does_not_depend_on_how_the_environment_is_spelled(env):
    assert r.is_production(env)
    assert r.config_problems(**{**SAFE, "environment": env, "provider": "sandbox", "secret": "", "commission_confirmed": False})


@pytest.mark.parametrize("env", ["development", "test", "staging", "", None])
def test_other_environments_are_not_production(env):
    assert not r.is_production(env)


def test_a_long_random_secret_is_not_weak():
    assert not r.is_weak_secret(SECRET)


@pytest.mark.parametrize("bps", [-1, 10_001, 10.5, None])
def test_an_invalid_commission_rate_is_a_problem_everywhere(bps):
    assert r.config_problems(environment="development", enabled=False, provider="sandbox", secret="", commission_bps=bps, commission_confirmed=False)


# ---------- Phase 13 remediation: sandbox opt-in and environment ----------
def test_payments_disabled_is_safe_for_every_recognised_environment_and_the_sandbox_is_never_usable():
    for env in ("production", "development", "test"):
        for opt_in in (False, True):
            got = r.config_problems(environment=env, enabled=False, provider="sandbox", secret=SECRET, commission_bps=1000, commission_confirmed=False,
                                    sandbox_opt_in=opt_in)
            assert got == ([] if not (env == "production" and opt_in) else got), (env, opt_in, got)
    for env in ("production", "development", "test", "staging", "", "nonsense", None):
        for opt_in in (False, True):
            assert not r.sandbox_usable(enabled=False, provider="sandbox", sandbox_opt_in=opt_in, environment=env)       # switched off: nothing is usable


def test_the_sandbox_opt_in_is_refused_in_production_even_with_payments_disabled():
    problems = r.config_problems(environment="production", enabled=False, provider="sandbox", secret=SECRET, commission_bps=1000, commission_confirmed=False, sandbox_opt_in=True)
    assert len(problems) == 1 and "PAYMENT_SANDBOX_ENABLED" in problems[0]


@pytest.mark.parametrize("enabled", [True, False])
@pytest.mark.parametrize("env", ["", "  ", None, 5, "staging", "prodution", "live", "nonsense"])
def test_a_missing_or_unrecognised_environment_is_refused_whether_or_not_payments_are_enabled(env, enabled):
    """ENVIRONMENT has no default. Nothing is assumed, so a missing production value can never be taken for development."""
    problems = r.config_problems(**{**DEV, "environment": env, "enabled": enabled}, sandbox_opt_in=True)
    assert len(problems) == 1 and "ENVIRONMENT is missing or not recognised" in problems[0], problems
    assert r.environment_kind(env) == "unknown"


@pytest.mark.parametrize("env,kind", [("production", "production"), ("PROD", "production"), (" Production ", "production"), ("development", "development"),
                                      ("Development", "development"), (" test ", "test"), ("TEST", "test"), ("", "unknown"), ("staging", "unknown"),
                                      (None, "unknown"), (7, "unknown")])
def test_environment_kind(env, kind):
    assert r.environment_kind(env) == kind


@pytest.mark.parametrize("env", ["development", "Development", " TEST ", "test"])
def test_the_sandbox_is_usable_only_in_development_or_test_with_every_switch_on(env):
    assert r.sandbox_usable(enabled=True, provider="sandbox", sandbox_opt_in=True, environment=env)
    assert not r.sandbox_usable(enabled=True, provider="sandbox", sandbox_opt_in=False, environment=env)      # no opt-in
    assert not r.sandbox_usable(enabled=False, provider="sandbox", sandbox_opt_in=True, environment=env)      # switched off


@pytest.mark.parametrize("env", ["production", "prod", "staging", "", None, "live"])
def test_the_sandbox_is_never_usable_outside_development_and_test(env):
    assert not r.sandbox_usable(enabled=True, provider="sandbox", sandbox_opt_in=True, environment=env)


def test_an_unimplemented_provider_is_never_usable():
    for env in ("development", "production"):
        assert not r.sandbox_usable(enabled=True, provider="somegateway", sandbox_opt_in=True, environment=env)


def test_production_with_every_unsafe_setting_reports_each_one():
    problems = " | ".join(r.config_problems(environment="production", enabled=True, provider="sandbox", secret="", commission_bps=1000,
                                              commission_confirmed=False, sandbox_opt_in=True))
    for needle in ("PAYMENT_SANDBOX_ENABLED", "sandbox", "WEBHOOK_SECRET", "COMMISSION"):
        assert needle in problems, needle


def test_production_can_never_pass_while_no_real_provider_exists():
    """Even a perfect-looking production configuration is refused: the only implemented provider is the sandbox."""
    for provider in ("sandbox", "somegateway", "razorpay", ""):
        assert r.config_problems(**{**SAFE, "provider": provider})


# ---------- Phase 13B.2: the production webhook secret is validated at start-up, whatever PAYMENTS_ENABLED says ----------
from tests import webhook_secret_matrix as M          # noqa: E402  (the one shared definition of the matrix)

EXAMPLE_SECRET = M.EXAMPLE_SECRET                      # read from .env.example itself
PROD_OFF = dict(environment="production", enabled=False, provider="sandbox", commission_bps=1000, commission_confirmed=False)


def problems_for(env, enabled, kind):
    """config_problems for one matrix cell, with the other settings at the safest value that is possible for that environment."""
    secret = M.SECRETS[kind] or ""                      # a missing variable reaches the code as the empty default
    if env == "production":
        return r.config_problems(environment=env, enabled=enabled, provider="somegateway" if enabled else "sandbox", secret=secret,
                                 commission_bps=1000, commission_confirmed=True)
    return r.config_problems(environment=env, enabled=enabled, provider="sandbox", secret=secret, commission_bps=1000, commission_confirmed=False,
                             sandbox_opt_in=enabled)


@pytest.mark.parametrize("case", M.CASES, ids=M.case_id)
def test_the_start_up_matrix_environment_x_payments_x_secret(case):
    env, enabled, kind = case
    starts, must, must_not = M.startup(env, enabled, kind)
    problems = " | ".join(problems_for(env, enabled, kind))
    if starts:
        assert problems == "", problems
    else:
        assert problems and must in problems, problems
        if must_not:
            assert must_not not in problems, problems


@pytest.mark.parametrize("case", M.CASES, ids=M.case_id)
def test_the_request_handler_applies_the_same_secret_test_as_defence_in_depth(case):
    env, enabled, kind = case
    assert r.webhook_secret_usable(M.SECRETS[kind] or "", env) is M.webhook_accepts(env, kind)


def test_the_matrix_covers_every_combination_and_every_refusal_has_a_reason():
    assert len(M.CASES) == 3 * 2 * 5 == 30
    refused = [c for c in M.CASES if not M.startup(*c)[0]]
    assert refused and all(M.startup(*c)[1] for c in refused)
    assert {c[0] for c in M.CASES if c[2] in ("missing", "empty", "weak", "example") and not M.startup(*c)[0]} == {"production"}


def test_production_payments_disabled_with_the_example_secret_is_refused():
    problems = r.config_problems(**PROD_OFF, secret=EXAMPLE_SECRET)
    assert len(problems) == 1 and "PAYMENT_WEBHOOK_SECRET is weak or a known example value" in problems[0] and "whether or not payments are enabled" in problems[0]


def test_the_secret_in_env_example_and_the_one_used_by_the_test_suite_are_both_weak():
    """So neither can ever start a production process. (An .env.example edited to a strong value would fail this on purpose: the example must stay public-safe.)"""
    assert r.is_weak_secret(M.EXAMPLE_SECRET) and r.is_weak_secret(M.SUITE_SECRET)
    assert not r.is_weak_secret(M.STRONG_SECRET)


@pytest.mark.parametrize("secret", [EXAMPLE_SECRET, M.SUITE_SECRET, "change_me", "short", "x" * 40, "my-placeholder-Kq7vR2mZp9sT4wB8nC3dF6hJ1LaE5gY0", "   "])
@pytest.mark.parametrize("enabled", [True, False])
def test_production_refuses_any_weak_secret_whether_or_not_payments_are_enabled(secret, enabled):
    assert any("PAYMENT_WEBHOOK_SECRET" in p for p in r.config_problems(**{**PROD_OFF, "enabled": enabled}, secret=secret))


@pytest.mark.parametrize("enabled", [True, False])
@pytest.mark.parametrize("secret", ["", None, "  "])
def test_production_refuses_a_missing_secret_whether_or_not_payments_are_enabled(secret, enabled):
    got = r.config_problems(**{**PROD_OFF, "enabled": enabled}, secret=secret)
    assert any("PAYMENT_WEBHOOK_SECRET is missing or empty" in p for p in got), got
    assert not r.webhook_secret_usable(secret or "", "production")


def test_production_with_payments_disabled_and_a_strong_secret_starts():
    assert r.config_problems(**PROD_OFF, secret=SECRET) == []
    assert r.webhook_secret_usable(SECRET, "production")


@pytest.mark.parametrize("env", ["development", "test"])
@pytest.mark.parametrize("secret", ["", EXAMPLE_SECRET, M.SUITE_SECRET, "change_me"])
def test_development_and_test_accept_any_secret_for_start_up(env, secret):
    base = dict(environment=env, provider="sandbox", commission_bps=1000, commission_confirmed=False, secret=secret)
    assert r.config_problems(**base, enabled=True, sandbox_opt_in=True) == []
    assert r.config_problems(**base, enabled=False) == []
    assert r.webhook_secret_usable(secret, env) is bool(secret)       # any non-empty secret authenticates the sandbox; an empty one never does


@pytest.mark.parametrize("env", ["production", "prod", " PRODUCTION ", "staging", "", None])
@pytest.mark.parametrize("secret", [EXAMPLE_SECRET, "", "change_me", "x" * 40])
def test_an_unsafe_secret_is_never_usable_by_the_webhook_in_production_or_an_unknown_environment(env, secret):
    assert not r.webhook_secret_usable(secret, env)


@pytest.mark.parametrize("env", ["staging", "", None])
def test_an_unknown_environment_gets_no_production_exemption_but_is_refused_at_start(env):
    assert r.config_problems(environment=env, enabled=False, provider="sandbox", secret=EXAMPLE_SECRET, commission_bps=1000, commission_confirmed=False)


# ---------- Phase 13 remediation: provider order id ----------
@pytest.mark.parametrize("ok", ["ord_1", "x", "o" * 80, "sandbox_ord_abc123"])
def test_valid_order_ids(ok):
    assert r.valid_order_id(ok)


@pytest.mark.parametrize("bad", ["", " ", " lead", "trail ", "o" * 81, "new\nline", "tab\there", "nul\x00", None, 5, b"abc", "o" * 5000])
def test_invalid_order_ids_are_refused_before_a_row_is_written(bad):
    assert not r.valid_order_id(bad)


def test_the_order_id_limit_matches_the_column():
    assert r.MAX_ORDER_ID == 80


# ---------- Phase 13 remediation (B2): which review flag a resolve call refers to ----------
def test_pick_flag_with_nothing_open_is_not_flagged():
    for requested in (None, "OVER_CAP"):
        reason, refusal = r.pick_flag([], requested)
        assert reason is None and refusal.status == 409 and refusal.code == "NOT_FLAGGED"


def test_pick_flag_with_one_open_flag_needs_no_reason_but_accepts_the_right_one():
    assert r.pick_flag(["LATE_SUCCESS"], None) == ("LATE_SUCCESS", None)
    assert r.pick_flag(["LATE_SUCCESS"], "LATE_SUCCESS") == ("LATE_SUCCESS", None)


def test_pick_flag_never_lets_the_wrong_reason_through():
    reason, refusal = r.pick_flag(["LATE_SUCCESS"], "OVER_CAP")
    assert reason is None and refusal.code == "FLAG_NOT_OPEN" and "LATE_SUCCESS" in refusal.message


def test_pick_flag_with_several_open_flags_requires_a_named_reason():
    open_ = ["DUPLICATE_CHARGE", "AMOUNT_MISMATCH", "TRAINING_CANCELLED"]
    reason, refusal = r.pick_flag(open_, None)
    assert reason is None and refusal.status == 409 and refusal.code == "REASON_REQUIRED"
    assert all(x in refusal.message for x in open_)                           # the administrator is told what is open
    for want in open_:
        assert r.pick_flag(open_, want) == (want, None)
    assert r.pick_flag(open_, "OVER_CAP")[1].code == "FLAG_NOT_OPEN"


def test_resolving_flags_one_by_one_leaves_the_rest_open_until_none_remain():
    open_ = ["DUPLICATE_CHARGE", "AMOUNT_MISMATCH", "TRAINING_CANCELLED"]
    resolved = []
    while open_:
        assert r.pick_flag(open_, None)[1] is not None or len(open_) == 1       # several open: always a refusal without a name
        pick = open_[len(open_) // 2]
        assert r.pick_flag(open_, pick) == (pick, None)
        open_.remove(pick)
        resolved.append(pick)
    assert sorted(resolved) == ["AMOUNT_MISMATCH", "DUPLICATE_CHARGE", "TRAINING_CANCELLED"]
    assert r.pick_flag(open_, None)[1].code == "NOT_FLAGGED"


def test_an_over_cap_flag_is_resolvable_only_after_the_refund_whatever_else_is_open():
    assert r.resolve_refusal("OVER_CAP", "SUCCEEDED", None).code == "REFUND_REQUIRED"
    assert r.resolve_refusal("OVER_CAP", "SUCCEEDED", "PENDING").code == "REFUND_REQUIRED"
    assert r.resolve_refusal("OVER_CAP", "SUCCEEDED", "SUCCEEDED") is None
    assert r.resolve_refusal("LATE_SUCCESS", "SUCCEEDED", None) is None


# ---------- Phase 13 remediation (B1): the fee cap counts settled money only ----------
class Ledger:
    """A model of the service's cap bookkeeping, driven by the real rules (decide_event, settle_commission, remaining). It mirrors
    payment_service.collected_paise (money HELD: every SUCCEEDED, unrefunded payment, over-cap ones included) and settled_totals (money and commission
    of SUCCEEDED, unrefunded payments that HAVE a recorded commission). The real functions run against a database in test_payments_phase13.py."""
    def __init__(self, fee, bps=1000):
        self.fee, self.bps, self.pay, self.n = fee, bps, {}, 0

    def create(self, amount):
        assert amount <= r.remaining(self.fee, self.held()), "the amount may not exceed what is still unheld"
        self.n += 1
        self.pay[self.n] = dict(amount=amount, status="PENDING", settled=False, refunded=False, commission=None, flags=[])
        return self.n

    def held(self):
        return sum(p["amount"] for p in self.pay.values() if p["status"] == "SUCCEEDED" and not p["refunded"])

    def settled(self, exclude=None):
        live = [p for i, p in self.pay.items() if i != exclude and p["status"] == "SUCCEEDED" and p["settled"] and not p["refunded"]]
        return sum(p["amount"] for p in live), sum(p["commission"] for p in live)

    def set(self, pid, status):
        self.pay[pid]["status"] = status

    def succeed(self, pid, txn="t"):
        p = self.pay[pid]
        d = r.decide_event(status=p["status"], amount_paise=p["amount"], currency="INR", charge_txn_on_file=None, event_type="payment.succeeded",
                           event_amount=p["amount"], event_currency="INR", event_txn_id=txn, event_reason=None,
                           collected_other=self.settled(exclude=pid)[0], fee=self.fee, training_status="ACTIVE")
        p["status"] = "SUCCEEDED"
        if d.flag:
            p["flags"].append(d.flag)
        if d.settle:
            money, commission = self.settled(exclude=pid)
            p["commission"], _ = r.settle_commission(money, commission, p["amount"], self.bps)
            p["settled"] = True
        return d

    def refund(self, pid):
        self.pay[pid]["refunded"] = True


def _b1_until_c_is_open():
    """The user's scenario. Fee Rs 100; payments of Rs 60 (A), Rs 60 (B) and Rs 40 (C). Only one attempt may be in flight and the cap applies at
    creation, so B (the one that expires) necessarily existed before A succeeded: B is created and expires, A is created and succeeds, C is created."""
    L = Ledger(100_00)
    b = L.create(60_00)
    L.set(b, "EXPIRED")
    a = L.create(60_00)
    assert L.succeed(a).outcome == "succeeded" and L.held() == 60_00
    c = L.create(40_00)                                                       # 60 held, 40 left: allowed
    return L, a, b, c


def test_B1_an_over_cap_payment_does_not_make_a_later_legitimate_payment_over_cap():
    L, a, b, c = _b1_until_c_is_open()
    d = L.succeed(b)                                                          # B reports a late success
    assert d.outcome == "succeeded_over_cap" and d.flag == "OVER_CAP" and d.settle is False and d.invoice is True
    assert L.held() == 120_00 and L.settled() == (60_00, 6_00)                # B is held (awaiting refund) but is not settled
    d = L.succeed(c)                                                          # C succeeds
    assert d.outcome == "succeeded" and d.flag is None and d.settle is True, "C must not be flagged because of B"
    assert L.pay[c]["flags"] == [] and L.pay[b]["flags"] == ["OVER_CAP"] and L.pay[a]["flags"] == []
    # totals: the settled payments add up to the fee and to exactly the commission on it; the over-cap payment carries none
    assert L.settled() == (100_00, 10_00) and (L.pay[a]["commission"], L.pay[c]["commission"]) == (6_00, 4_00) and L.pay[b]["commission"] is None


def test_B1_after_B_is_refunded_nothing_changes_for_the_settled_payments():
    L, a, b, c = _b1_until_c_is_open()
    L.succeed(b)
    L.succeed(c)
    L.refund(b)
    assert L.held() == 100_00 == L.fee, "the money held is back at the fee"
    assert L.settled() == (100_00, 10_00)
    assert r.remaining(L.fee, L.held()) == 0                                  # nothing further can be requested


def test_B1_refunding_B_before_C_succeeds_gives_the_same_result():
    L, a, b, c = _b1_until_c_is_open()
    L.succeed(b)
    L.refund(b)
    assert L.held() == 60_00
    d = L.succeed(c)
    assert d.outcome == "succeeded" and d.flag is None
    assert L.settled() == (100_00, 10_00)


def test_B1_C_succeeding_first_makes_a_later_B_the_over_cap_one():
    L, a, b, c = _b1_until_c_is_open()
    assert L.succeed(c).flag is None
    d = L.succeed(b)
    assert d.outcome == "succeeded_over_cap" and d.settle is False
    assert L.settled() == (100_00, 10_00) and L.held() == 160_00


def test_B1_the_old_basis_would_have_flagged_C_wrongly():
    """Negative control: measuring the cap against money HELD (what the code did before the fix) flags C, which is the defect."""
    L, a, b, c = _b1_until_c_is_open()
    L.succeed(b)
    held_other = L.held() - L.pay[c]["amount"] * 0                           # C is not yet succeeded: everything held counts
    old = r.decide_event(status="PENDING", amount_paise=40_00, currency="INR", charge_txn_on_file=None, event_type="payment.succeeded", event_amount=40_00,
                         event_currency="INR", event_txn_id="t", event_reason=None, collected_other=held_other, fee=L.fee, training_status="ACTIVE")
    assert old.outcome == "succeeded_over_cap", "documents the defect that settled_totals() fixes"
    new = r.decide_event(status="PENDING", amount_paise=40_00, currency="INR", charge_txn_on_file=None, event_type="payment.succeeded", event_amount=40_00,
                         event_currency="INR", event_txn_id="t", event_reason=None, collected_other=L.settled(exclude=c)[0], fee=L.fee, training_status="ACTIVE")
    assert new.outcome == "succeeded" and new.flag is None


def test_B1_two_over_cap_late_successes_are_each_flagged_and_neither_settles():
    L = Ledger(100_00)
    b1, b2 = L.create(60_00), None
    L.set(b1, "EXPIRED")
    b2 = L.create(60_00)
    L.set(b2, "FAILED")
    a = L.create(100_00)
    L.succeed(a)
    assert L.succeed(b1).flag == "OVER_CAP" and L.succeed(b2).flag == "OVER_CAP"
    assert L.settled() == (100_00, 10_00) and L.held() == 220_00


def test_B1_the_cap_never_lets_settled_money_pass_the_fee():
    rng = random.Random(7)
    for _ in range(300):
        fee = rng.randint(1, 500)
        L = Ledger(fee)
        ids = []
        for _ in range(rng.randint(1, 6)):
            room = r.remaining(fee, L.held())
            if room == 0:
                break
            ids.append(L.create(rng.randint(1, room)))
            if rng.random() < 0.5:
                L.set(ids[-1], rng.choice(["FAILED", "EXPIRED", "CANCELLED"]))
            else:
                L.succeed(ids[-1])
        for i in ids:                                                         # late successes arrive in random order
            if L.pay[i]["status"] in ("FAILED", "EXPIRED", "CANCELLED") and rng.random() < 0.7:
                L.succeed(i)
        money, commission = L.settled()
        assert money <= fee, (fee, money)
        assert commission == r.commission_total(money, 1000) or money == 0, (fee, money, commission)
