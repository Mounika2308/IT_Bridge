from app.core.database import get_db
from app.main import app
from app.models.review import Review
from tests.test_trainings import begin, hire_flow, reg, session, world  # noqa: F401

TRAINER_RATINGS = {"technical_knowledge": 5, "teaching_quality": 4, "communication": 5, "punctuality": 4, "professionalism": 5}
INST_RATINGS = {"communication": 4, "professionalism": 5, "coordination": 3}


def finish(client, ih, tid):
    begin(client, tid)
    assert client.post(f"/api/v1/trainings/{tid}/complete", headers=ih).status_code == 200


def review(client, h, tid, ratings, comment=None):
    return client.post(f"/api/v1/trainings/{tid}/reviews", headers=h, json={"ratings": ratings, "comment": comment})


def test_cannot_review_before_completion(client):
    th, ih, rid, tid = world(client)
    assert review(client, ih, tid, TRAINER_RATINGS).status_code == 409


def test_institution_reviews_trainer_once(client):
    th, ih, rid, tid = world(client)
    finish(client, ih, tid)
    r = review(client, ih, tid, TRAINER_RATINGS, "Great trainer")
    assert r.status_code == 201 and r.json()["data"]["overall"] == 4.6
    assert review(client, ih, tid, TRAINER_RATINGS).status_code == 409   # duplicate blocked
    db = next(app.dependency_overrides[get_db]())
    assert db.query(Review).count() == 1


def test_trainer_can_optionally_rate_institution_with_own_categories(client):
    th, ih, rid, tid = world(client)
    finish(client, ih, tid)
    assert review(client, th, tid, TRAINER_RATINGS).status_code == 422     # wrong categories for this direction
    assert review(client, th, tid, INST_RATINGS).status_code == 201


def test_rating_validation(client):
    th, ih, rid, tid = world(client)
    finish(client, ih, tid)
    assert review(client, ih, tid, {**TRAINER_RATINGS, "punctuality": 6}).status_code == 422
    assert review(client, ih, tid, {**TRAINER_RATINGS, "punctuality": 0}).status_code == 422
    missing = {k: v for k, v in TRAINER_RATINGS.items() if k != "punctuality"}
    assert review(client, ih, tid, missing).status_code == 422


def test_outsiders_cannot_review_or_read(client):
    th, ih, rid, tid = world(client)
    finish(client, ih, tid)
    other = reg(client, "o@example.com", "INSTITUTION", institution_name="Other")
    assert review(client, other, tid, TRAINER_RATINGS).status_code == 404
    assert client.get(f"/api/v1/trainings/{tid}/reviews", headers=other).status_code == 404


def test_can_review_flag_and_notification(client):
    th, ih, rid, tid = world(client)
    finish(client, ih, tid)
    assert client.get(f"/api/v1/trainings/{tid}/reviews", headers=ih).json()["data"]["can_review"] is True
    review(client, ih, tid, TRAINER_RATINGS)
    d = client.get(f"/api/v1/trainings/{tid}/reviews", headers=ih).json()["data"]
    assert d["can_review"] is False and len(d["reviews"]) == 1
    titles = [n["title"] for n in client.get("/api/v1/notifications", headers=th).json()["data"]["items"]]
    assert "You received a new review" in titles


def test_public_profile_and_search_show_rating(client):
    th, ih, rid, tid = world(client)
    finish(client, ih, tid)
    review(client, ih, tid, TRAINER_RATINGS, "Great trainer")
    pid = client.get("/api/v1/trainers/me", headers=th)  # profile exists
    prof = client.get("/api/v1/trainers/1", headers=ih).json()["data"]
    assert prof["rating"] == 4.6 and prof["review_count"] == 1 and prof["completed_trainings"] == 1
    items = client.get("/api/v1/trainers/1/reviews", headers=ih).json()["data"]
    assert items["total"] == 1 and items["items"][0]["reviewer"] == "Sunrise College"
    # Phase 12: the rating filter needs at least two reviews, so one review is displayed but not yet filterable (see test_reviews_phase12.py)
    assert client.get("/api/v1/trainers?min_rating=4", headers=ih).json()["data"]["total"] == 0
    assert client.get("/api/v1/trainers?min_rating=5", headers=ih).json()["data"]["total"] == 0
    card = client.get("/api/v1/trainers", headers=ih).json()["data"]["items"][0]
    assert card["rating"] == 4.6


def test_institution_rating_shows_on_requirement(client):
    th, ih, rid, tid = world(client)
    finish(client, ih, tid)
    review(client, th, tid, INST_RATINGS)
    d = client.get(f"/api/v1/requirements/{rid}", headers=ih).json()["data"]
    assert d["institution_rating"] == 4.0 and d["institution_review_count"] == 1
