"""Phase 10: session rules, attendance rules, notes, planned sessions, history-preserving completion, calendar, interviews."""
from datetime import datetime, time, timedelta

from sqlalchemy import event

from app.core.clock import today
from app.models.training import Attendance, TrainingSession
from app.models.user import Skill
from app.services import application_service, training_service
from tests.test_trainings import END, START, begin, db_of, hire_flow, reg, req_body, session, world

YESTERDAY = today() - timedelta(days=1)


# ---------- helpers ----------
def at(day, hh, mm=0):
    return datetime.combine(day, time(hh, mm))


def freeze(monkeypatch, dt):
    """Pins the platform clock used by the session and interview rules."""
    monkeypatch.setattr(training_service, "now", lambda: dt)
    monkeypatch.setattr(training_service, "today", lambda: dt.date())
    monkeypatch.setattr(application_service, "now", lambda: dt)


def new_session(client, h, tid, **kw):
    r = session(client, h, tid, **kw)
    assert r.status_code == 201, r.text
    return r.json()["data"]["id"]


def move_session(client, sid, day):
    db = db_of(client)
    db.get(TrainingSession, sid).session_date = day
    db.commit()


def set_status(client, h, sid, st):
    return client.post(f"/api/v1/sessions/{sid}/status", headers=h, json={"status": st})


def attend(client, h, sid, total=60, present=45, absent=15):
    return client.put(f"/api/v1/sessions/{sid}/attendance", headers=h, json={"total_students": total, "present": present, "absent": absent})


def patch(client, h, sid, **body):
    return client.patch(f"/api/v1/sessions/{sid}", headers=h, json=body)


def det(client, h, tid):
    return client.get(f"/api/v1/trainings/{tid}", headers=h).json()["data"]


def held_session(client, th, tid, title="Held"):
    """A session that has already started (moved to yesterday), inside a training that has started."""
    begin(client, tid)
    sid = new_session(client, th, tid, title=title)
    move_session(client, sid, YESTERDAY)
    return sid


# ---------- session start / complete / transitions ----------
def test_start_and_complete_wait_for_the_scheduled_start_time(client, monkeypatch):
    th, ih, rid, tid = world(client)
    sid = new_session(client, th, tid, start="10:00", end="12:00")
    freeze(monkeypatch, at(START, 9, 59))
    assert set_status(client, th, sid, "ONGOING").status_code == 409
    assert set_status(client, th, sid, "COMPLETED").status_code == 409
    freeze(monkeypatch, at(START, 10, 0))
    assert set_status(client, ih, sid, "ONGOING").status_code == 403           # only the trainer starts a session
    assert set_status(client, th, sid, "ONGOING").json()["data"]["status"] == "ONGOING"
    assert set_status(client, th, sid, "COMPLETED").json()["data"]["status"] == "COMPLETED"


def test_invalid_session_transitions(client, monkeypatch):
    th, ih, rid, tid = world(client)
    done, cancelled, ongoing = (new_session(client, th, tid, start=f"{h:02d}:00", end=f"{h:02d}:30", title=t) for h, t in ((9, "A"), (10, "B"), (11, "C")))
    freeze(monkeypatch, at(START, 12, 0))
    assert set_status(client, th, done, "COMPLETED").status_code == 200
    assert set_status(client, th, done, "ONGOING").status_code == 409           # completed is final
    assert set_status(client, th, done, "CANCELLED").status_code == 409
    assert set_status(client, th, cancelled, "CANCELLED").status_code == 200
    assert set_status(client, th, cancelled, "ONGOING").status_code == 409      # cancelled is final
    assert set_status(client, th, cancelled, "COMPLETED").status_code == 409
    assert set_status(client, th, ongoing, "ONGOING").status_code == 200
    assert set_status(client, th, ongoing, "COMPLETED").status_code == 200
    assert set_status(client, th, ongoing, "SCHEDULED").status_code == 422      # not a status you can move to


def test_cancelling_sessions(client):
    th, ih, rid, tid = world(client)
    ids = [new_session(client, th, tid, day=START + timedelta(days=i), title=f"Day {i}") for i in range(3)]
    assert session(client, th, tid, day=START + timedelta(days=3), title="Extra").status_code == 409     # 3 planned, 3 live
    assert set_status(client, ih, ids[0], "CANCELLED").json()["data"]["status"] == "CANCELLED"           # either party may cancel
    assert patch(client, th, ids[0], title="Renamed").status_code == 409                                  # cancelled sessions are frozen
    assert session(client, th, tid, day=START + timedelta(days=3), title="Replacement").status_code == 201  # the slot was freed


def test_a_session_with_attendance_cannot_be_cancelled(client):
    th, ih, rid, tid = world(client)
    sid = held_session(client, th, tid)
    assert attend(client, th, sid).status_code == 200
    assert set_status(client, th, sid, "CANCELLED").status_code == 409
    assert set_status(client, ih, sid, "CANCELLED").status_code == 409


# ---------- creating / editing sessions: past, nulls, time validation, overlap ----------
def test_new_sessions_cannot_be_scheduled_in_the_past(client, monkeypatch):
    th, ih, rid, tid = world(client)
    freeze(monkeypatch, at(START, 10, 0))
    assert session(client, th, tid, start="09:00", end="10:00").status_code == 422        # earlier today
    assert session(client, th, tid, start="10:30", end="11:30").status_code == 201        # later today is fine
    begin(client, tid)
    assert session(client, th, tid, day=YESTERDAY, title="Yesterday").status_code == 422  # a past day


def test_rescheduling_into_the_past_is_refused(client, monkeypatch):
    th, ih, rid, tid = world(client)
    sid = new_session(client, th, tid, start="10:00", end="12:00")
    freeze(monkeypatch, at(START, 11, 0))
    assert patch(client, th, sid, start_time="09:00").status_code == 422
    assert patch(client, th, sid, title="Only the title changes").status_code == 200       # a rename is not a reschedule


def test_explicit_nulls_are_422_not_500(client):
    th, ih, rid, tid = world(client)
    sid = new_session(client, th, tid)
    for field in ("title", "session_date", "start_time", "end_time"):
        assert patch(client, th, sid, **{field: None}).status_code == 422, field
    assert patch(client, th, sid).status_code == 200                                       # an empty update is harmless
    assert det(client, th, tid)["sessions"][0]["title"] == "Day 1"


def test_time_and_date_validation(client):
    th, ih, rid, tid = world(client)
    assert session(client, th, tid, start="12:00", end="10:00").status_code == 422
    assert session(client, th, tid, start="10:00", end="10:00").status_code == 422
    assert client.post(f"/api/v1/trainings/{tid}/sessions", headers=th, json={"title": "Bad", "session_date": str(START), "start_time": "25:99", "end_time": "11:00"}).status_code == 422
    assert client.post(f"/api/v1/trainings/{tid}/sessions", headers=th, json={"title": "Bad", "session_date": "not-a-date", "start_time": "10:00", "end_time": "11:00"}).status_code == 422
    assert session(client, th, tid, day=END + timedelta(days=1)).status_code == 422        # outside the training dates
    sid = new_session(client, th, tid, start="10:00", end="12:00")
    assert patch(client, th, sid, start_time="13:00").status_code == 422                   # would end before it starts


def test_trainer_cannot_be_double_booked_across_trainings(client):
    th, ih, rid, tid = world(client)
    rid2 = client.post("/api/v1/requirements", headers=ih, json=req_body(title="Second Python workshop")).json()["data"]["id"]
    tid2 = hire_flow(client, th, ih, rid2)
    first = new_session(client, th, tid, start="10:00", end="12:00", title="First")
    assert session(client, th, tid2, start="11:00", end="13:00", title="Overlaps the end").status_code == 409
    assert session(client, ih, tid2, start="09:00", end="10:30", title="Overlaps the start").status_code == 409   # either party is checked
    assert session(client, th, tid2, start="10:30", end="11:30", title="Inside").status_code == 409
    assert session(client, th, tid2, start="12:00", end="13:00", title="Touching is fine").status_code == 201
    assert session(client, th, tid2, day=START + timedelta(days=1), start="10:00", end="12:00", title="Another day").status_code == 201
    assert set_status(client, th, first, "CANCELLED").status_code == 200
    assert session(client, th, tid2, start="10:00", end="11:30", title="Freed slot").status_code == 201   # cancelled sessions do not block


# ---------- attendance ----------
def test_attendance_can_be_saved_again(client):
    th, ih, rid, tid = world(client)
    sid = held_session(client, th, tid)
    assert attend(client, th, sid, present=45, absent=15).json()["data"]["attendance"]["percent"] == 75
    r = attend(client, th, sid, present=50, absent=10)
    assert r.status_code == 200 and r.json()["data"]["attendance"]["percent"] == 83
    assert db_of(client).query(Attendance).count() == 1                                    # updated in place, not duplicated
    assert det(client, ih, tid)["attendance_percent"] == 83
    assert "notes" not in r.json()["data"]["attendance"]


def test_attendance_authorization(client):
    th, ih, rid, tid = world(client)
    sid = held_session(client, th, tid)
    other_trainer = reg(client, "other@example.com")
    other_inst = reg(client, "oi@example.com", "INSTITUTION", institution_name="Other College")
    assert attend(client, ih, sid).status_code == 403                                      # the institution's own training: read only
    assert attend(client, other_trainer, sid).status_code == 404
    assert attend(client, other_inst, sid).status_code == 404
    assert client.put(f"/api/v1/sessions/{sid}/attendance", json={"total_students": 60, "present": 1, "absent": 1}).status_code == 401
    assert attend(client, th, 999999).status_code == 404


def test_attendance_is_capped_by_the_student_count_and_validated(client):
    th, ih, rid, tid = world(client)                                                       # 60 students
    sid = held_session(client, th, tid)
    assert attend(client, th, sid, total=61, present=40, absent=10).status_code == 422
    assert attend(client, th, sid, total=61, present=61, absent=0).status_code == 422
    assert attend(client, th, sid, total=60, present=40, absent=21).status_code == 422     # present + absent > total
    assert attend(client, th, sid, total=60, present=-1, absent=0).status_code == 422
    assert attend(client, th, sid, total=60, present=0, absent=-5).status_code == 422
    assert attend(client, th, sid, total=0, present=0, absent=0).status_code == 422
    for bad in ("many", None, 1.5):
        assert client.put(f"/api/v1/sessions/{sid}/attendance", headers=th, json={"total_students": 60, "present": bad, "absent": 0}).status_code == 422
    assert attend(client, th, sid, total=50, present=30, absent=20).status_code == 200      # fewer than enrolled is fine
    assert attend(client, th, sid, total=60, present=60, absent=0).json()["data"]["attendance"]["percent"] == 100


def test_attendance_waits_for_the_session_to_start(client, monkeypatch):
    th, ih, rid, tid = world(client)
    sid = new_session(client, th, tid, start="10:00", end="12:00")
    freeze(monkeypatch, at(START, 9, 0))
    assert attend(client, th, sid).status_code == 409
    freeze(monkeypatch, at(START, 10, 5))
    assert attend(client, th, sid).status_code == 200


def test_attendance_is_read_only_once_the_training_is_completed_or_cancelled(client):
    th, ih, rid, tid = world(client)
    sid = held_session(client, th, tid)
    assert attend(client, th, sid).status_code == 200
    assert client.post(f"/api/v1/trainings/{tid}/complete", headers=ih).status_code == 200
    assert attend(client, th, sid, present=10, absent=5).status_code == 409                # completed: no edits
    assert det(client, th, tid)["sessions"][0]["attendance"]["present"] == 45
    rid2 = client.post("/api/v1/requirements", headers=ih, json=req_body(title="Another Python workshop")).json()["data"]["id"]
    tid2 = hire_flow(client, th, ih, rid2)
    sid2 = held_session(client, th, tid2, title="Other")
    assert attend(client, th, sid2).status_code == 200
    client.post(f"/api/v1/trainings/{tid2}/cancel", headers=ih, json={})
    assert attend(client, th, sid2, present=1, absent=1).status_code == 409                # cancelled: no edits


# ---------- completion / cancellation preserve history ----------
def test_completing_a_training_keeps_what_happened(client):
    th, ih, rid, tid = world(client)
    begin(client, tid)
    held = new_session(client, th, tid, day=START, title="Held with attendance")
    unrecorded = new_session(client, th, tid, day=START + timedelta(days=1), title="Past, nothing recorded")
    future = new_session(client, th, tid, day=START + timedelta(days=2), title="Still to come")
    move_session(client, held, YESTERDAY)
    move_session(client, unrecorded, YESTERDAY)
    assert attend(client, th, held).status_code == 200
    d = client.post(f"/api/v1/trainings/{tid}/complete", headers=ih).json()["data"]
    by_title = {s["title"]: s for s in d["sessions"]}
    assert by_title["Held with attendance"]["status"] == "COMPLETED"            # attendance proves it happened
    assert by_title["Held with attendance"]["attendance"]["percent"] == 75       # and its attendance survives
    assert by_title["Past, nothing recorded"]["status"] == "SCHEDULED"           # left alone: nothing proves what happened
    assert by_title["Still to come"]["status"] == "CANCELLED"                    # never happened
    assert d["progress"]["completed"] == 1 and d["attendance_percent"] == 75
    assert len(d["sessions"]) == 3                                               # nothing was deleted


def test_cancelling_a_training_also_keeps_held_sessions(client):
    th, ih, rid, tid = world(client)
    held = held_session(client, th, tid)
    future = new_session(client, th, tid, day=START + timedelta(days=3), title="Future")
    attend(client, th, held)
    d = client.post(f"/api/v1/trainings/{tid}/cancel", headers=ih, json={"reason": "Budget"}).json()["data"]
    by_title = {s["title"]: s["status"] for s in d["sessions"]}
    assert by_title["Held"] == "COMPLETED" and by_title["Future"] == "CANCELLED"


# ---------- session notes ----------
def test_session_notes_belong_to_the_session(client):
    th, ih, rid, tid = world(client)
    sid = new_session(client, th, tid)
    put = lambda h, notes: client.put(f"/api/v1/sessions/{sid}/notes", headers=h, json={"notes": notes})
    assert put(th, "Covered loops and functions").json()["data"]["notes"] == "Covered loops and functions"
    assert det(client, ih, tid)["sessions"][0]["notes"] == "Covered loops and functions"      # the institution can read them
    assert put(ih, "Not allowed").status_code == 403
    assert put(reg(client, "o@example.com"), "x").status_code == 404
    assert put(th, "x" * 1001).status_code == 422
    assert put(th, "   ").json()["data"]["notes"] is None                                       # blank clears
    assert put(th, "Again").status_code == 200
    set_status(client, th, sid, "CANCELLED")
    assert put(th, "Too late").status_code == 409


def test_notes_are_read_only_after_the_training_ends(client):
    th, ih, rid, tid = world(client)
    sid = held_session(client, th, tid)
    client.put(f"/api/v1/sessions/{sid}/notes", headers=th, json={"notes": "Before the end"})
    client.post(f"/api/v1/trainings/{tid}/complete", headers=ih)
    assert client.put(f"/api/v1/sessions/{sid}/notes", headers=th, json={"notes": "After the end"}).status_code == 409
    assert det(client, th, tid)["sessions"][0]["notes"] == "Before the end"


# ---------- planned session count ----------
def test_planned_sessions_can_be_adjusted_by_the_institution(client):
    th, ih, rid, tid = world(client)                                                          # planned: 3
    plan = lambda h, n: client.patch(f"/api/v1/trainings/{tid}/planned-sessions", headers=h, json={"planned_sessions": n})
    for i in range(2):
        new_session(client, th, tid, day=START + timedelta(days=i), title=f"Day {i}")
    assert plan(ih, 1).status_code == 409                                                     # lower than the 2 already scheduled
    assert plan(ih, 2).json()["data"]["planned_sessions"] == 2                                # equal is allowed
    assert session(client, th, tid, day=START + timedelta(days=2), title="Third").status_code == 409
    assert plan(ih, 4).status_code == 200
    assert session(client, th, tid, day=START + timedelta(days=2), title="Third").status_code == 201
    assert plan(th, 9).status_code == 403                                                     # the trainer cannot change the plan
    assert plan(reg(client, "o@example.com", "INSTITUTION", institution_name="Other"), 9).status_code == 404
    assert plan(ih, 0).status_code == 422 and plan(ih, 1001).status_code == 422
    assert client.patch(f"/api/v1/trainings/{tid}/planned-sessions", headers=ih, json={"planned_sessions": "many"}).status_code == 422


def test_cancelled_sessions_do_not_count_toward_the_minimum_plan(client):
    th, ih, rid, tid = world(client)
    ids = [new_session(client, th, tid, day=START + timedelta(days=i), title=f"Day {i}") for i in range(3)]
    set_status(client, th, ids[0], "CANCELLED")
    assert client.patch(f"/api/v1/trainings/{tid}/planned-sessions", headers=ih, json={"planned_sessions": 2}).status_code == 200


def test_planned_sessions_locked_after_completion(client):
    th, ih, rid, tid = world(client)
    begin(client, tid)
    client.post(f"/api/v1/trainings/{tid}/complete", headers=ih)
    assert client.patch(f"/api/v1/trainings/{tid}/planned-sessions", headers=ih, json={"planned_sessions": 5}).status_code == 409


# ---------- calendar ----------
def online_world(client):
    th, ih, rid, tid = world(client)
    rid2 = client.post("/api/v1/requirements", headers=ih, json=req_body(title="Online Python workshop", mode="ONLINE", location="Remote")).json()["data"]["id"]
    tid2 = hire_flow(client, th, ih, rid2)
    client.patch(f"/api/v1/trainings/{tid2}/details", headers=th, json={"meeting_link": "https://meet.example.com/abc"})
    return th, ih, tid, tid2


def cal(client, h, start=START, end=END):
    r = client.get(f"/api/v1/calendar?start={start}&end={end}", headers=h)
    assert r.status_code == 200, r.text
    return r.json()["data"]


def test_calendar_shows_phase_session_times_mode_location_and_link(client):
    th, ih, tid, tid2 = online_world(client)
    new_session(client, th, tid2, start="14:00", end="15:30", title="Online day 1")
    for h in (th, ih):
        events = cal(client, h)
        training = next(e for e in events if e["type"] == "TRAINING" and e["link"] == f"/trainings/{tid2}")
        assert (training["phase"], training["mode"], training["location"]) == ("UPCOMING", "ONLINE", "Remote")
        assert training["meeting_link"] == "https://meet.example.com/abc"
        sess = next(e for e in events if e["type"] == "SESSION")
        assert (sess["start_time"], sess["end_time"], sess["status"], sess["phase"]) == ("14:00", "15:30", "SCHEDULED", "UPCOMING")
        assert sess["mode"] == "ONLINE" and sess["meeting_link"] == "https://meet.example.com/abc"
        offline = next(e for e in events if e["type"] == "TRAINING" and e["link"] == f"/trainings/{tid}")
        assert offline["mode"] == "OFFLINE" and offline["meeting_link"] is None                  # no link for an offline training
    begin(client, tid2)
    assert next(e for e in cal(client, th) if e["type"] == "TRAINING" and e["link"] == f"/trainings/{tid2}")["phase"] == "IN_PROGRESS"


def test_calendar_never_leaks_other_peoples_trainings(client):
    th, ih, tid, tid2 = online_world(client)
    new_session(client, th, tid2, title="Private session")
    strangers = [reg(client, "x@example.com"), reg(client, "y@example.com", "INSTITUTION", institution_name="Other College")]
    for h in strangers:
        events = cal(client, h)
        assert not [e for e in events if e["type"] in ("TRAINING", "SESSION")]
        assert "meet.example.com" not in str(events) and "Private session" not in str(events)
    assert client.get(f"/api/v1/calendar?start={START}&end={END}").status_code == 401


def test_calendar_is_closed_to_admins_and_has_a_range_limit(client):
    from app.core.security import hash_password
    from app.models.user import User
    th, ih, tid, tid2 = online_world(client)
    db = db_of(client)
    db.add(User(email="admin@example.com", password_hash=hash_password("Passw0rd123"), full_name="Admin", role="ADMIN"))
    db.commit()
    token = client.post("/api/v1/auth/login", json={"email": "admin@example.com", "password": "Passw0rd123"}).json()["data"]["access_token"]
    assert client.get(f"/api/v1/calendar?start={START}&end={END}", headers={"Authorization": f"Bearer {token}"}).status_code == 403
    assert client.get(f"/api/v1/calendar?start={START}&end={START + timedelta(days=200)}", headers=th).status_code == 422
    assert client.get(f"/api/v1/calendar?start={END}&end={START}", headers=th).status_code == 422


# ---------- interviews ----------
def interview_world(client):
    db = db_of(client)
    db.add(Skill(name="Python"))
    db.commit()
    th, ih = reg(client, "t@example.com"), reg(client, "i@example.com", "INSTITUTION", institution_name="Sunrise College")
    rid = client.post("/api/v1/requirements", headers=ih, json=req_body()).json()["data"]["id"]
    client.put("/api/v1/trainers/me", headers=th, json={"headline": "Python trainer", "location": "Pune", "experience_years": 5,
                                                      "training_mode": "OFFLINE", "expected_fee": 4000, "skill_ids": [1]})
    aid = client.post(f"/api/v1/requirements/{rid}/apply", headers=th, json={}).json()["data"]["id"]
    client.patch(f"/api/v1/applications/{aid}/status", headers=ih, json={"status": "SHORTLISTED"})
    return th, ih, rid, aid


def interview(client, h, aid, when):
    return client.patch(f"/api/v1/applications/{aid}/status", headers=h, json={"status": "INTERVIEW", "interview_at": when.isoformat()})


def window(client, h):
    return cal(client, h, today(), today() + timedelta(days=10))


def test_interview_needs_a_future_date_and_time(client):
    th, ih, rid, aid = interview_world(client)
    patch_status = lambda **b: client.patch(f"/api/v1/applications/{aid}/status", headers=ih, json=b)
    assert patch_status(status="INTERVIEW").status_code == 422                                  # no date
    assert patch_status(status="REJECTED", interview_at="2030-01-01T10:00:00").status_code == 422  # date with another status
    assert interview(client, ih, aid, at(YESTERDAY, 10)).status_code == 422                     # in the past
    assert patch_status(status="INTERVIEW", interview_at="not a date").status_code == 422
    assert interview(client, th, aid, at(today() + timedelta(days=3), 14, 30)).status_code == 403   # the trainer cannot schedule it


def test_interview_appears_on_both_calendars_and_nowhere_else(client):
    th, ih, rid, aid = interview_world(client)
    when = at(today() + timedelta(days=3), 14, 30)
    assert interview(client, ih, aid, when).status_code == 200
    seen_by_trainer = next(e for e in window(client, th) if e["type"] == "INTERVIEW")
    assert (seen_by_trainer["date"], seen_by_trainer["start_time"], seen_by_trainer["subtitle"]) == (str(when.date()), "14:30", "Sunrise College")
    seen_by_institution = next(e for e in window(client, ih) if e["type"] == "INTERVIEW")
    assert seen_by_institution["subtitle"] == "T" and seen_by_institution["link"].endswith(f"/institution/requirements/{rid}/applications")
    assert client.get("/api/v1/applications/mine", headers=th).json()["data"][0]["interview_at"] == when.isoformat()
    for h in (reg(client, "x@example.com"), reg(client, "y@example.com", "INSTITUTION", institution_name="Other College")):
        assert not [e for e in window(client, h) if e["type"] == "INTERVIEW"]


def test_interview_can_be_rescheduled_and_disappears_when_rejected(client):
    th, ih, rid, aid = interview_world(client)
    interview(client, ih, aid, at(today() + timedelta(days=3), 14, 30))
    assert interview(client, ih, aid, at(today() + timedelta(days=4), 11, 0)).status_code == 200    # INTERVIEW -> INTERVIEW
    ev = next(e for e in window(client, th) if e["type"] == "INTERVIEW")
    assert (ev["date"], ev["start_time"]) == (str(today() + timedelta(days=4)), "11:00")
    client.patch(f"/api/v1/applications/{aid}/status", headers=ih, json={"status": "REJECTED"})
    assert not [e for e in window(client, th) if e["type"] == "INTERVIEW"]
    assert client.get("/api/v1/applications/mine", headers=th).json()["data"][0]["interview_at"] is None


def test_cannot_jump_to_interview_without_shortlisting(client):
    db = db_of(client)
    db.add(Skill(name="Python"))
    db.commit()
    th, ih = reg(client, "t@example.com"), reg(client, "i@example.com", "INSTITUTION", institution_name="Sunrise College")
    rid = client.post("/api/v1/requirements", headers=ih, json=req_body()).json()["data"]["id"]
    client.put("/api/v1/trainers/me", headers=th, json={"headline": "Python trainer", "location": "Pune", "experience_years": 5,
                                                      "training_mode": "OFFLINE", "expected_fee": 4000, "skill_ids": [1]})
    aid = client.post(f"/api/v1/requirements/{rid}/apply", headers=th, json={}).json()["data"]["id"]
    assert interview(client, ih, aid, at(today() + timedelta(days=3), 10)).status_code == 409


# ---------- progress regression and query counts ----------
def test_training_list_carries_progress_and_no_contact_details(client, monkeypatch):
    th, ih, rid, tid = world(client)
    sid = held_session(client, th, tid)
    set_status(client, th, sid, "COMPLETED")
    item = client.get("/api/v1/trainings/mine", headers=ih).json()["data"]["items"][0]
    assert item["progress"] == {"scheduled": 1, "completed": 1, "percent": 33}
    assert "contact" not in item and "sessions" not in item and "t@example.com" not in str(item)
    assert "contact" in det(client, ih, tid)                                                 # the detail view still has them


def _count_queries(client, request):
    engine = db_of(client).get_bind()
    seen = []
    listener = lambda conn, cur, stmt, *a: seen.append(stmt)
    event.listen(engine, "before_cursor_execute", listener)
    try:
        request()
    finally:
        event.remove(engine, "before_cursor_execute", listener)
    return len(seen)


def test_list_and_calendar_query_counts_do_not_grow_with_the_data(client):
    th, ih, rid, tid = world(client)
    new_session(client, th, tid)
    list_req = lambda: client.get("/api/v1/trainings/mine", headers=th)
    cal_req = lambda: client.get(f"/api/v1/calendar?start={START}&end={END}", headers=th)
    list_before, cal_before = _count_queries(client, list_req), _count_queries(client, cal_req)
    for i in range(3):                                                                       # three more trainings, each with sessions
        r = client.post("/api/v1/requirements", headers=ih, json=req_body(title=f"Extra workshop number {i}")).json()["data"]["id"]
        t = hire_flow(client, th, ih, r)
        new_session(client, th, t, day=START + timedelta(days=i + 1), title=f"Extra {i}")
    assert _count_queries(client, list_req) == list_before
    assert _count_queries(client, cal_req) == cal_before
