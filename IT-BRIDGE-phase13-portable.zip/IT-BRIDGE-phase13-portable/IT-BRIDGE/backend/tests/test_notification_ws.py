"""WebSocket delivery: reconnect, per-user limit, deactivated users, payload privacy, token handling (Phase 11)."""
import asyncio
from contextlib import ExitStack

from app.models.user import User
from app.services.realtime import CLOSE, ConnectionManager
from tests.test_trainings import db_of, session, world

KEYS = {"id", "type", "title", "body", "link", "is_read", "created_at"}


def token_of(h):
    return h["Authorization"].split()[1]


def open_ready(stack, client, h):
    ws = stack.enter_context(client.websocket_connect("/ws/notifications"))
    ws.send_json({"token": token_of(h)})
    assert ws.receive_json() == {"type": "ready"}
    return ws


def closed(ws) -> bool:
    try:
        ws.receive_json()
    except Exception:
        return True
    return False


def test_a_reconnected_socket_receives_new_notifications(client):
    th, ih, rid, tid = world(client)
    with ExitStack() as first:
        open_ready(first, client, ih)
    with ExitStack() as second:                                                  # the first connection is gone; connect again
        ws = open_ready(second, client, ih)
        session(client, th, tid)
        msg = ws.receive_json()
        assert msg["type"] == "notification" and msg["data"]["type"] == "SESSION_SCHEDULED"


def test_the_per_user_socket_limit_still_applies(client):
    th, ih, rid, tid = world(client)
    with ExitStack() as stack:
        for _ in range(5):
            open_ready(stack, client, ih)
        sixth = stack.enter_context(client.websocket_connect("/ws/notifications"))
        sixth.send_json({"token": token_of(ih)})
        assert closed(sixth)                                                     # refused: five is the maximum


def test_a_deactivated_user_stops_receiving_on_an_open_socket(client):
    th, ih, rid, tid = world(client)
    with ExitStack() as stack:
        ws = open_ready(stack, client, ih)
        db = db_of(client)
        db.query(User).filter(User.email == "i@example.com").update({"is_active": False})
        db.commit()
        session(client, th, tid)                                                 # an event for the now deactivated institution
        assert closed(ws)                                                        # the socket is closed instead of delivering it


def test_payload_contains_no_contact_details(client):
    th, ih, rid, tid = world(client)
    with ExitStack() as stack:
        ws = open_ready(stack, client, ih)
        session(client, th, tid)
        data = ws.receive_json()["data"]
        assert set(data) == KEYS and "example.com" not in str(data) and "phone" not in str(data).lower()


def test_a_token_in_the_url_is_ignored_and_a_bad_first_message_closes_the_socket(client):
    th, ih, rid, tid = world(client)
    with ExitStack() as stack:
        ws = stack.enter_context(client.websocket_connect(f"/ws/notifications?token={token_of(ih)}"))
        ws.send_json({"token": "not-a-token"})
        assert closed(ws)


def test_manager_can_close_all_of_a_users_connections_even_if_a_client_stalled():
    async def run():
        m = ConnectionManager()
        q = await m.connect(7)
        for i in range(100):
            m.push(7, {"n": i})
        await asyncio.sleep(0.05)                                                # the queue is now full
        await asyncio.get_running_loop().run_in_executor(None, m.disconnect_user, 7)
        await asyncio.sleep(0.05)
        items = [q.get_nowait() for _ in range(q.qsize())]
        assert items[-1] is CLOSE                                                # the close signal got through
        m.disconnect_user(99)                                                    # unknown user: no error
    asyncio.run(run())
