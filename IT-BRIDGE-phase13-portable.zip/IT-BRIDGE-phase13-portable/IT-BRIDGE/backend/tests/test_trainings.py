from datetime import timedelta

from app.core.clock import today
from app.core.database import get_db
from app.main import app
from app.models.user import Skill

D = today()
START, END = D + timedelta(days=30), D + timedelta(days=40)


def reg(client, email, role="TRAINER", **extra):
    body = {"full_name": email.split("@")[0].title(), "email": email, "password": "Passw0rd123", "role": role, **extra}
    d = client.post("/api/v1/auth/register", json=body).json()["data"]
    return {"Authorization": f"Bearer {d['access_token']}"}


def db_of(client):
    return next(app.dependency_overrides[get_db]())


def req_body(**kw):
    b = dict(title="Python workshop for 3rd years", technology="Python", description="x" * 40, skill_ids=[1], student_count=60,
             student_level="BEGINNER", duration_days=10, sessions=3, location="Pune", mode="OFFLINE", start_date=str(START),
             end_date=str(END), budget_min=20000, budget_max=50000, application_deadline=str(D + timedelta(days=20)))
    b.update(kw)
    return b


def hire_flow(client, th, ih, rid):
    client.put("/api/v1/trainers/me", headers=th, json={"headline": "Python trainer", "location": "Pune", "experience_years": 5,
                                                      "training_mode": "OFFLINE", "expected_fee": 4000, "skill_ids": [1]})
    aid = client.post(f"/api/v1/requirements/{rid}/apply", headers=th, json={}).json()["data"]["id"]
    client.patch(f"/api/v1/applications/{aid}/status", headers=ih, json={"status": "SHORTLISTED"})
    hid = client.post(f"/api/v1/applications/{aid}/hire", headers=ih, json={"agreed_fee": 40000}).json()["data"]["id"]
    client.post(f"/api/v1/hiring-requests/{hid}/accept", headers=th)
    return client.get("/api/v1/trainings/mine", headers=th).json()["data"]["items"][0]["id"]


def begin(client, tid):
    """Moves the training's start into the past so it counts as started (completion is not allowed before the start date)."""
    from app.models.training import Training
    db = db_of(client)
    db.get(Training, tid).start_date = D - timedelta(days=1)
    db.commit()


def world(client):
    db = db_of(client)
    db.add(Skill(name="Python"))
    db.commit()
    th, ih = reg(client, "t@example.com"), reg(client, "i@example.com", "INSTITUTION", institution_name="Sunrise College")
    rid = client.post("/api/v1/requirements", headers=ih, json=req_body()).json()["data"]["id"]
    return th, ih, rid, hire_flow(client, th, ih, rid)


def session(client, h, tid, day=START, start="10:00", end="12:00", title="Day 1"):
    return client.post(f"/api/v1/trainings/{tid}/sessions", headers=h,
                       json={"title": title, "session_date": str(day), "start_time": start, "end_time": end})


def test_accepting_creates_training_for_both_parties(client):
    th, ih, rid, tid = world(client)
    assert client.get("/api/v1/trainings/mine", headers=ih).json()["data"]["items"][0]["status"] == "ACTIVE"
    d = client.get(f"/api/v1/trainings/{tid}", headers=ih).json()["data"]
    assert d["contact"]["email"] == "t@example.com" and d["planned_sessions"] == 3
    outsider = reg(client, "x@example.com")
    assert client.get(f"/api/v1/trainings/{tid}", headers=outsider).status_code == 404


def test_session_rules(client):
    th, ih, rid, tid = world(client)
    assert session(client, ih, tid).status_code == 201
    assert session(client, th, tid, day=D + timedelta(days=5)).status_code == 422          # outside training dates
    assert session(client, th, tid, start="11:00", end="13:00", title="Clash").status_code == 409  # overlaps Day 1
    assert session(client, th, tid, start="12:00", end="13:00", title="Day 1b").status_code == 201
    assert session(client, th, tid, day=START + timedelta(days=1), title="Day 2").status_code == 201
    assert session(client, th, tid, day=START + timedelta(days=2), title="Day 3").status_code == 409  # all 3 planned used


def test_reschedule_session_and_audit(client):
    th, ih, rid, tid = world(client)
    sid = session(client, th, tid).json()["data"]["id"]
    r = client.patch(f"/api/v1/sessions/{sid}", headers=ih, json={"session_date": str(START + timedelta(days=2))})
    assert r.status_code == 200 and r.json()["data"]["session_date"] == str(START + timedelta(days=2))


def test_attendance_only_trainer_and_not_future(client):
    th, ih, rid, tid = world(client)
    sid = session(client, th, tid).json()["data"]["id"]
    body = {"total_students": 60, "present": 50, "absent": 10}
    assert client.put(f"/api/v1/sessions/{sid}/attendance", headers=th, json=body).status_code == 409   # future session
    assert client.put(f"/api/v1/sessions/{sid}/attendance", headers=ih, json=body).status_code == 403
    assert client.put(f"/api/v1/sessions/{sid}/attendance", headers=th, json={**body, "present": 55}).status_code == 422
    assert client.post(f"/api/v1/sessions/{sid}/status", headers=th, json={"status": "COMPLETED"}).status_code == 409


def test_past_session_attendance_and_progress(client):
    th, ih, rid, tid = world(client)
    sid = session(client, th, tid).json()["data"]["id"]
    from app.models.training import TrainingSession
    db = db_of(client)
    db.query(TrainingSession).update({"session_date": D - timedelta(days=1)})
    db.commit()
    r = client.put(f"/api/v1/sessions/{sid}/attendance", headers=th, json={"total_students": 60, "present": 45, "absent": 15, "notes": "Good"})
    assert r.json()["data"]["attendance"]["percent"] == 75
    assert client.post(f"/api/v1/sessions/{sid}/status", headers=ih, json={"status": "COMPLETED"}).status_code == 403
    assert client.post(f"/api/v1/sessions/{sid}/status", headers=th, json={"status": "COMPLETED"}).status_code == 200
    d = client.get(f"/api/v1/trainings/{tid}", headers=ih).json()["data"]
    assert d["progress"]["completed"] == 1 and d["progress"]["percent"] == 33 and d["attendance_percent"] == 75


def test_complete_early_cancels_unrun_sessions(client):
    th, ih, rid, tid = world(client)
    session(client, th, tid)
    assert client.post(f"/api/v1/trainings/{tid}/complete", headers=th).status_code == 403
    assert client.post(f"/api/v1/trainings/{tid}/complete", headers=ih).status_code == 409  # not started yet
    begin(client, tid)
    d = client.post(f"/api/v1/trainings/{tid}/complete", headers=ih).json()["data"]
    assert d["status"] == "COMPLETED" and d["sessions"][0]["status"] == "CANCELLED"
    assert client.post(f"/api/v1/trainings/{tid}/complete", headers=ih).status_code == 409
    assert session(client, th, tid, title="Late").status_code == 409
    assert client.get("/api/v1/hiring-requests/mine", headers=th).json()["data"][0]["status"] == "COMPLETED"


def test_cancel_training_frees_requirement_for_new_hire(client):
    th, ih, rid, tid = world(client)
    session(client, th, tid)
    d = client.post(f"/api/v1/trainings/{tid}/cancel", headers=th, json={"reason": "Family emergency"}).json()["data"]
    assert d["status"] == "CANCELLED" and d["sessions"][0]["status"] == "CANCELLED"
    assert client.get("/api/v1/hiring-requests/mine", headers=ih).json()["data"][0]["status"] == "CANCELLED"


def test_reschedule_training_dates_guarded_by_sessions(client):
    th, ih, rid, tid = world(client)
    session(client, th, tid, day=START + timedelta(days=9))
    bad = client.patch(f"/api/v1/trainings/{tid}/dates", headers=ih, json={"start_date": str(START), "end_date": str(START + timedelta(days=3))})
    assert bad.status_code == 409
    good = client.patch(f"/api/v1/trainings/{tid}/dates", headers=ih, json={"start_date": str(START), "end_date": str(END + timedelta(days=5))})
    assert good.status_code == 200 and client.patch(f"/api/v1/trainings/{tid}/dates", headers=th, json={"start_date": str(START), "end_date": str(END)}).status_code == 403


def test_active_training_blocks_trainer_availability_in_matching(client):
    th, ih, rid, tid = world(client)
    ih2 = reg(client, "i2@example.com", "INSTITUTION", institution_name="Other College")
    rid2 = client.post("/api/v1/requirements", headers=ih2, json=req_body(title="Another Python workshop")).json()["data"]["id"]
    m = client.get(f"/api/v1/requirements/{rid2}/matches", headers=ih2).json()["data"]["matches"][0]
    avail = next(f for f in m["factors"] if f["key"] == "availability")
    assert avail["points"] == 0


def test_calendar_events_per_role(client):
    th, ih, rid, tid = world(client)
    session(client, th, tid)
    q = f"?start={START}&end={END}"
    for h in (th, ih):
        types = {e["type"] for e in client.get(f"/api/v1/calendar{q}", headers=h).json()["data"]}
        assert {"TRAINING", "SESSION"} <= types
    assert client.get(f"/api/v1/calendar?start={D}&end={D + timedelta(days=400)}", headers=th).status_code == 422
