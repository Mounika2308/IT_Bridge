from datetime import date
from types import SimpleNamespace as NS

from app.services.matching import compute_match

PY, RE = NS(id=1, name="Python"), NS(id=2, name="React")


def req(**kw):
    base = dict(skills=[PY, RE], mode="OFFLINE", location="Pune", preferred_experience_years=4, duration_days=10,
                budget_max=50000, start_date=date(2030, 1, 10), end_date=date(2030, 1, 20))
    base.update(kw)
    return NS(**base)


def trainer(**kw):
    base = dict(skills=[PY, RE], experience_years=5, location="Pune", training_mode="OFFLINE", expected_fee=4000)
    base.update(kw)
    return NS(**base)


def test_perfect_match_is_100():
    r = compute_match(req(), trainer(), [])
    assert r["score"] == 100 and all(f["status"] == "full" for f in r["factors"])


def test_partial_skill_match_scales_points():
    r = compute_match(req(), trainer(skills=[PY]), [])
    skill = next(f for f in r["factors"] if f["key"] == "skill")
    assert skill["points"] == 20.0 and "missing React" in skill["detail"]
    assert r["score"] == 80


def test_busy_dates_remove_availability_points():
    busy = [NS(start_date=date(2030, 1, 15), end_date=date(2030, 1, 16))]
    r = compute_match(req(), trainer(), busy)
    assert next(f for f in r["factors"] if f["key"] == "availability")["points"] == 0
    assert r["score"] == 85


def test_online_requirement_ignores_location():
    r = compute_match(req(mode="ONLINE"), trainer(location="Delhi", training_mode="ONLINE"), [])
    assert next(f for f in r["factors"] if f["key"] == "location")["status"] == "full"


def test_budget_tiers():
    f = lambda fee: next(x for x in compute_match(req(), trainer(expected_fee=fee), [])["factors"] if x["key"] == "budget")["status"]
    assert f(5000) == "full" and f(5500) == "partial" and f(9000) == "none"


def test_custom_weights_change_score_and_are_reported():
    heavy = {"skill": 0, "experience": 0, "location": 0, "availability": 0, "mode": 0, "budget": 100}
    r = compute_match(req(), trainer(skills=[]), [], heavy)
    assert r["score"] == 100 and next(f for f in r["factors"] if f["key"] == "budget")["weight"] == 100
