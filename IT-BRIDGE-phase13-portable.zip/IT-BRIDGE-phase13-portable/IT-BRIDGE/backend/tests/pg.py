"""Shared helpers for the PostgreSQL-only tests (test_migrations_postgres.py, test_postgres_concurrency.py, test_postgres_notifications.py).

These tests need a REAL PostgreSQL 16 database that will be WIPED (DROP SCHEMA public CASCADE). They therefore refuse everything that is not a
database somebody prepared on purpose for being wiped. Without ITB_TEST_DATABASE_URL every test that uses these helpers is SKIPPED (never passed).

ITB_TEST_DATABASE_URL must match ONE fixed shape, character for character (no URL library, no decoding):
    postgresql[+psycopg2]://USER[:PASSWORD]@127.0.0.1|[::1]:PORT/DBNAME
    USER [A-Za-z_][A-Za-z0-9_]*, PASSWORD [A-Za-z0-9_.~-]*, PORT 1024-65535 but not 5432, DBNAME [a-z][a-z0-9_]* and containing "test".
    No query string or fragment (SQLAlchemy/psycopg2 would let "?host=", "?port=", "?dbname=", "?hostaddr=", "?service=" override the URL), no
    percent-encoding, and not "localhost" (a name is resolved by /etc/hosts and DNS; the project's own dev default is localhost:5432/itbridge).
The environment must not redirect libpq: any PG* variable except PGPASSWORD (PGHOST, PGHOSTADDR, PGPORT, PGDATABASE, PGSERVICE, PGOPTIONS ...) refuses.
The SERVER must then prove, in the very connection that wipes, that it is disposable (`assert_disposable`, run in the same transaction immediately
before every destructive statement):
    current_database() is the database named in the URL; PostgreSQL 16; not a replica;
    the database carries the comment ITB_PHASE13_DISPOSABLE:  COMMENT ON DATABASE itbridge_test IS 'ITB_PHASE13_DISPOSABLE';
    every other non-template database of the cluster except `postgres` carries it too (a cluster that also holds a dev/prod database is refused).
A database called itbridge_test is NOT enough. kit tool: itb_db_gate.py (same rules, outside the repository) is used by the validation driver first.
"""
import os
import re

import pytest

MARKER = "ITB_PHASE13_DISPOSABLE"
GRAMMAR = re.compile(
    r"postgresql(?:\+psycopg2)?://"
    r"(?P<user>[A-Za-z_][A-Za-z0-9_]{0,62})(?::(?P<password>[A-Za-z0-9_.~-]{0,128}))?@"
    r"(?P<host>127\.0\.0\.1|\[::1\]):(?P<port>[1-9][0-9]{3,4})/"
    r"(?P<db>[a-z][a-z0-9_]{0,62})",
    re.ASCII,
)
URL = os.environ.get("ITB_TEST_DATABASE_URL", "").strip()


class Refused(RuntimeError):
    """Raised (never swallowed) when a destructive helper is asked to act on something that is not a prepared, disposable database."""


def parse_url(url: str) -> dict:
    """Pure: returns host/port/user/db of an acceptable URL, raises ValueError for anything else."""
    m = GRAMMAR.fullmatch(url) if isinstance(url, str) else None
    if not m:
        shown = url if isinstance(url, str) and len(url) < 200 else "<not a short string>"
        raise ValueError(f"{shown!r} does not match postgresql://USER[:PASSWORD]@127.0.0.1|[::1]:PORT/DBNAME (no query, fragment, encoding, other host form)")
    port = int(m["port"])
    if not 1024 <= port <= 65535 or port == 5432:
        raise ValueError(f"port {port}: use a port in 1024-65535 other than 5432 (the default of the dev database) for the throwaway cluster")
    if "test" not in m["db"]:
        raise ValueError(f"database name {m['db']!r} must contain 'test'")
    return {"host": m["host"].strip("[]"), "port": port, "user": m["user"], "db": m["db"]}


def environment_problems(environ=None) -> list[str]:
    environ = os.environ if environ is None else environ
    return [f"{k} is set" for k in sorted(environ) if k.startswith("PG") and k != "PGPASSWORD"]


def guard_sql(db: str) -> str:
    """Server-side guard: RAISES unless this session is on the named, marked, PostgreSQL 16 primary whose cluster holds no unmarked database (db is regex-checked)."""
    marker_of = "coalesce(shobj_description(d.oid, 'pg_database'), '')"
    return (
        "DO $itbguard$ BEGIN "
        f"IF current_database() <> '{db}' THEN RAISE EXCEPTION 'itb gate: connected to another database than {db}'; END IF; "
        "IF current_setting('server_version_num')::int NOT BETWEEN 160000 AND 169999 THEN RAISE EXCEPTION 'itb gate: PostgreSQL 16 is required'; END IF; "
        "IF pg_is_in_recovery() THEN RAISE EXCEPTION 'itb gate: the server is a replica'; END IF; "
        f"IF NOT EXISTS (SELECT 1 FROM pg_database d WHERE d.datname = '{db}' AND {marker_of} = '{MARKER}') THEN "
        f"RAISE EXCEPTION 'itb gate: database {db} does not carry the {MARKER} comment'; END IF; "
        f"IF EXISTS (SELECT 1 FROM pg_database d WHERE NOT d.datistemplate AND d.datname NOT IN ('postgres', '{db}') AND {marker_of} <> '{MARKER}') THEN "
        f"RAISE EXCEPTION 'itb gate: the cluster holds a database without the {MARKER} comment'; END IF; "
        "END $itbguard$"
    )


def require_postgres() -> str:
    if not URL:
        pytest.skip("ITB_TEST_DATABASE_URL is not set: PostgreSQL tests are skipped (NOT passed)")
    try:
        parse_url(URL)
    except ValueError as e:
        pytest.fail(f"refusing ITB_TEST_DATABASE_URL: {e}")
    problems = environment_problems()
    if problems:
        pytest.fail("refusing to run PostgreSQL tests, the environment could redirect a connection: " + "; ".join(problems))
    return URL


def assert_disposable(conn, db: str) -> None:
    """Run on the connection that is about to execute a destructive statement, in the same transaction. Raises (and so aborts the transaction) if not disposable."""
    from sqlalchemy import text
    conn.execute(text(guard_sql(db)))


def _check_engine(engine) -> str:
    """The engine must be exactly the validated URL: same host, port, database, no query items that could override them."""
    want = parse_url(URL)
    u = engine.url
    got = (str(u.host), u.port, u.database, dict(u.query))
    if got != (want["host"], want["port"], want["db"], {}) or not u.drivername.startswith("postgresql"):
        raise Refused(f"refusing to wipe: the engine ({u.drivername}://{u.host}:{u.port}/{u.database}, query {dict(u.query)}) is not the validated ITB_TEST_DATABASE_URL")
    return want["db"]


def wipe(engine) -> None:
    """Drops everything in the public schema (tables, triggers, functions, types) so each test starts from nothing.
    Every transaction that does anything destructive starts with assert_disposable on its own connection."""
    from sqlalchemy import text
    db = _check_engine(engine)
    problems = environment_problems()
    if problems:
        raise Refused("refusing to wipe, the environment could redirect a connection: " + "; ".join(problems))
    with engine.begin() as conn:
        assert_disposable(conn, db)
        conn.execute(text("SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE datname = current_database() AND pid <> pg_backend_pid()"))
    with engine.begin() as conn:
        assert_disposable(conn, db)
        conn.execute(text("DROP SCHEMA public CASCADE"))
        conn.execute(text("CREATE SCHEMA public"))
