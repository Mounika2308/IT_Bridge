"""The downgrade policy and its checking logic (app/core/migration_guard.py). Standard library only: sqlite3 holds the "database", and
`preflight_downgrade` is driven through fake `alembic` and `sqlalchemy` modules (unittest.mock.patch.dict on sys.modules).

What this proves: which rows count as data a downgrade would lose, which revisions are looked at for a given run, that the first call of a run refuses the
WHOLE run (so a refusal cannot come after earlier revisions have executed), that a run is checked once, that an unknown path fails closed, and that the
override is the exact phrase in the one variable and nothing else.

What it does NOT prove: that real Alembic hands the guard the revisions assumed here (`script.iterate_revisions(..., select_for_downgrade=True)`,
`get_revision_argument()`), or anything about PostgreSQL. Those are tests/test_migrations.py (real Alembic, SQLite) and tests/test_migrations_postgres.py
(real Alembic, PostgreSQL), both needing the full dependency set.
"""
import os
import sqlite3
import sys
import types
from contextlib import contextmanager
from unittest import mock

import pytest

from app.core import migration_guard as mg

SWITCH, PHRASE = mg.SWITCH, mg.PHRASE
NEWEST_FIRST = tuple(reversed(mg.CHAIN))


def database(*inserts: str) -> sqlite3.Connection:
    """Every table and column the policy mentions, empty, plus the given INSERTs."""
    cols: dict[str, set[str]] = {}
    for d in mg.POLICY.values():
        for t in d.tables:
            cols.setdefault(t, set())
        for t, cs in d.columns:
            cols.setdefault(t, set()).update(cs)
    conn = sqlite3.connect(":memory:")
    for t, cs in cols.items():
        conn.execute(f"CREATE TABLE {t} (id INTEGER" + "".join(f", {c} TEXT" for c in sorted(cs)) + ")")
    for sql in inserts:
        conn.execute(sql)
    return conn


def counter(conn):
    return lambda sql: conn.execute(sql).fetchone()[0]


# one row in each kind of thing a downgrade removes -> the revision that must be named and how the data is labelled
HELD = [
    ("INSERT INTO users (id) VALUES (1)", "0001", "users 1 rows"),
    ("INSERT INTO reviews (id) VALUES (1)", "0001", "reviews 1 rows"),
    ("INSERT INTO trainings (id, meeting_link) VALUES (1, 'https://meet.example/x')", "0002", "trainings.(technology, mode, location, description, terms, meeting_link) 1 rows"),
    ("INSERT INTO trainings (id, terms) VALUES (1, 'travel covered')", "0002", "1 rows"),
    ("INSERT INTO training_sessions (id, notes) VALUES (1, 'covered loops')", "0003", "training_sessions.(notes) 1 rows"),
    ("INSERT INTO applications (id, interview_at) VALUES (1, '2030-01-01 10:00')", "0003", "applications.(interview_at) 1 rows"),
    ("INSERT INTO notification_preferences (id) VALUES (1)", "0004", "notification_preferences 1 rows"),
    ("INSERT INTO notification_deliveries (id) VALUES (1)", "0004", "notification_deliveries 1 rows"),
    ("INSERT INTO invoice_counters (id) VALUES (1)", "0005", "invoice_counters 1 rows"),
    ("INSERT INTO payments (id) VALUES (1)", "0005", "payments 1 rows"),
    ("INSERT INTO payment_review_flags (id) VALUES (1)", "0006", "payment_review_flags 1 rows"),
]


@pytest.mark.parametrize("insert,rev,label", HELD)
def test_a_downgrade_that_would_drop_held_data_is_refused_naming_the_revision_and_the_data(insert, rev, label):
    with pytest.raises(mg.DowngradeRefused) as e:
        mg.check(NEWEST_FIRST, counter(database(insert)), environ={})
    msg = str(e.value)
    assert msg.startswith("Refusing to downgrade") and f"{rev}: " in msg and label in msg and "Nothing has been changed" in msg


@pytest.mark.parametrize("insert,rev,label", HELD)
def test_only_the_revisions_a_run_removes_are_looked_at(insert, rev, label):
    # the same data, but this run does not reach the revision that would lose it (nor 0001, whose tables include trainings, training_sessions and applications)
    path = [r for r in NEWEST_FIRST if r not in (rev, "0001")]
    mg.check(path, counter(database(insert)), environ={})


def test_a_dropped_column_counts_only_when_some_row_holds_a_value_in_it():
    conn = database("INSERT INTO trainings (id) VALUES (1)", "INSERT INTO training_sessions (id) VALUES (1)", "INSERT INTO applications (id) VALUES (1)")
    to_0001 = NEWEST_FIRST[:-1]                                          # 0007 .. 0002: the run stops above 0001, whose tables do hold these rows
    mg.check(to_0001, counter(conn), environ={})                         # rows exist, but every dropped column is NULL: nothing is lost
    conn.execute("UPDATE training_sessions SET notes = 'x'")
    with pytest.raises(mg.DowngradeRefused, match="0003: training_sessions"):
        mg.check(to_0001, counter(conn), environ={})


def test_every_revision_that_would_lose_data_is_named_not_just_the_first():
    conn = database("INSERT INTO users (id) VALUES (1)", "INSERT INTO notification_preferences (id) VALUES (1)", "INSERT INTO invoice_counters (id) VALUES (1)")
    held = mg.held_data(counter(conn), NEWEST_FIRST)
    assert list(held) == ["0005", "0004", "0001"]                     # newest first, the order the run would reach them
    with pytest.raises(mg.DowngradeRefused) as e:
        mg.check(NEWEST_FIRST, counter(conn), environ={})
    assert all(x in str(e.value) for x in ("0005: invoice_counters", "0004: notification_preferences", "0001: users"))


def test_the_refusal_states_the_whole_scope_of_the_override_and_that_it_keeps_its_old_name():
    with pytest.raises(mg.DowngradeRefused) as e:
        mg.check(NEWEST_FIRST, counter(database("INSERT INTO users (id) VALUES (1)")), environ={})
    msg = str(e.value)
    assert f"{SWITCH}={PHRASE}" in msg
    for scope in ("core application data", "notifications", "snapshot columns", "session notes", "interview times", "financial records", "disposable"):
        assert scope in msg, scope


@pytest.mark.parametrize("environ", [
    {}, {SWITCH: ""}, {SWITCH: "true"}, {SWITCH: "1"}, {SWITCH: "yes"}, {SWITCH: "I_UNDERSTAND"}, {SWITCH: PHRASE.lower()}, {SWITCH: PHRASE + " "}, {SWITCH: " " + PHRASE},
    {SWITCH: PHRASE + "\n"}, {SWITCH: PHRASE + "X"}, {SWITCH + "S": PHRASE}, {"ALLOW_DOWNGRADE": PHRASE}, {"ITB_ALLOW_DOWNGRADE": PHRASE}, {"I_UNDERSTAND": PHRASE},
    {PHRASE: PHRASE}, {"ITB_ALLOW_DESTRUCTIVE_DOWNGRADE": PHRASE}, {"CI": "true", "DEBUG": "1", "ENVIRONMENT": "test"},
])
def test_nothing_but_the_exact_phrase_in_the_one_variable_unlocks_a_downgrade(environ):
    assert not mg.override_enabled(environ)
    with pytest.raises(mg.DowngradeRefused):
        mg.check(NEWEST_FIRST, counter(database("INSERT INTO users (id) VALUES (1)")), environ=environ)


def test_the_exact_phrase_authorises_every_kind_of_data_and_the_checks_are_then_not_even_run():
    conn = database("INSERT INTO users (id) VALUES (1)", "INSERT INTO notification_deliveries (id) VALUES (1)", "INSERT INTO payments (id) VALUES (1)")
    asked = []
    mg.check(NEWEST_FIRST, lambda sql: asked.append(sql) or counter(conn)(sql), environ={SWITCH: PHRASE})
    assert mg.override_enabled({SWITCH: PHRASE}) and asked == []


def test_override_enabled_reads_the_real_environment_by_default():
    with mock.patch.dict(os.environ, {SWITCH: PHRASE}):
        assert mg.override_enabled()
    with mock.patch.dict(os.environ, {SWITCH: "true"}):
        assert not mg.override_enabled()
    with mock.patch.dict(os.environ):
        os.environ.pop(SWITCH, None)
        assert not mg.override_enabled()


def test_a_revision_without_a_policy_entry_fails_closed_even_on_an_empty_database():
    with pytest.raises(mg.DowngradeRefused, match="0099"):
        mg.check(["0099", *NEWEST_FIRST], counter(database()), environ={})
    mg.check(["0099"], counter(database()), environ={SWITCH: PHRASE})              # only the explicit phrase lets an unknown revision through


def test_an_empty_database_is_never_refused():
    mg.check(NEWEST_FIRST, counter(database()), environ={})


def test_offline_sql_is_refused_when_the_path_drops_data_and_allowed_when_it_does_not():
    with pytest.raises(mg.DowngradeRefused, match="offline"):
        mg.check(NEWEST_FIRST, None, offline=True, environ={})
    with pytest.raises(mg.DowngradeRefused, match="0004"):
        mg.check(["0007", "0006", "0005", "0004"], None, offline=True, environ={})
    mg.check(["0007"], None, offline=True, environ={})                                # triggers and functions only
    mg.check(NEWEST_FIRST, None, offline=True, environ={SWITCH: PHRASE})


# ---------- preflight_downgrade, driven through a fake Alembic ----------
class FakeAlembic:
    """Just enough of alembic.context / alembic.op / sqlalchemy for preflight_downgrade. It records how the guard asked for the path and what it counted."""

    def __init__(self, conn, path, target=None, offline=False, fail_path=None, fail_target=None):
        self.conn, self.path, self.target, self.offline, self.fail_path = conn, path, target, offline, fail_path
        self.fail_target = fail_target
        self.ctx = types.SimpleNamespace()
        self.iterated, self.queries = [], []
        owner = self

        class Script:
            def iterate_revisions(self, upper, lower, **kw):
                owner.iterated.append((upper, lower, kw))
                if owner.fail_path:
                    raise owner.fail_path
                return [types.SimpleNamespace(revision=r) for r in owner.path]

        class Bind:
            def execute(self, sql):
                owner.queries.append(sql)
                return types.SimpleNamespace(scalar=lambda: conn.execute(sql).fetchone()[0])

        def get_revision_argument():
            if owner.fail_target:
                raise owner.fail_target
            return owner.target

        self.context = types.SimpleNamespace(get_context=lambda: self.ctx, get_revision_argument=get_revision_argument, script=Script(),
                                             is_offline_mode=lambda: self.offline)
        self.op = types.SimpleNamespace(get_bind=lambda: Bind())

    @contextmanager
    def installed(self, override=None):
        alembic = types.ModuleType("alembic")
        alembic.context, alembic.op = self.context, self.op
        sa = types.ModuleType("sqlalchemy")
        sa.text = lambda sql: sql
        with mock.patch.dict(sys.modules, {"alembic": alembic, "sqlalchemy": sa}), mock.patch.dict(os.environ):
            os.environ.pop(SWITCH, None)
            if override is not None:
                os.environ[SWITCH] = override
            mg._checked = None
            try:
                yield self
            finally:
                mg._checked = None


def test_the_first_revision_of_a_run_refuses_the_whole_run_before_any_revision_executes():
    fake = FakeAlembic(database("INSERT INTO users (id) VALUES (1)"), NEWEST_FIRST)
    with fake.installed(), pytest.raises(mg.DowngradeRefused, match="0001: users 1 rows"):
        mg.preflight_downgrade("0007")                # 0007 is where the run starts; the data that stops it lives in 0001
    assert fake.iterated == [("0007", "base", {"select_for_downgrade": True})]


def test_the_target_is_passed_on_as_given_and_base_is_spelled_out():
    for target, expected in ((None, "base"), ("0004", "0004"), ("-1", "-1"), ("-3", "-3")):
        fake = FakeAlembic(database(), ["0007"], target=target)
        with fake.installed():
            mg.preflight_downgrade("0007")
        assert fake.iterated[0][1] == expected, target


def test_a_run_is_checked_once_so_a_relative_target_cannot_be_misread_half_way():
    fake = FakeAlembic(database(), ["0007", "0006"])
    with fake.installed():
        mg.preflight_downgrade("0007")
        asked = len(fake.queries)
        assert asked > 0
        mg.preflight_downgrade("0006")               # the second revision of the SAME run: nothing is asked or counted again
        assert len(fake.queries) == asked and len(fake.iterated) == 1


def test_a_new_run_is_checked_again():
    fake = FakeAlembic(database(), ["0007"])
    with fake.installed():
        mg.preflight_downgrade("0007")
        fake.ctx = types.SimpleNamespace()           # a new command, a new MigrationContext
        fake.context.get_context = lambda: fake.ctx
        mg.preflight_downgrade("0007")
        assert len(fake.iterated) == 2


def test_a_refused_run_is_not_remembered_as_checked():
    fake = FakeAlembic(database("INSERT INTO users (id) VALUES (1)"), NEWEST_FIRST)
    with fake.installed():
        for _ in range(2):
            with pytest.raises(mg.DowngradeRefused):
                mg.preflight_downgrade("0007")


def test_the_override_skips_everything_including_the_questions_to_alembic():
    fake = FakeAlembic(database("INSERT INTO users (id) VALUES (1)"), NEWEST_FIRST)
    with fake.installed(override=PHRASE):
        mg.preflight_downgrade("0007")
    assert fake.iterated == [] and fake.queries == []


@pytest.mark.parametrize("override", ["true", "1", PHRASE.lower(), PHRASE + " ", ""])
def test_a_wrong_value_of_the_variable_does_not_skip_the_check(override):
    fake = FakeAlembic(database("INSERT INTO users (id) VALUES (1)"), NEWEST_FIRST)
    with fake.installed(override=override), pytest.raises(mg.DowngradeRefused):
        mg.preflight_downgrade("0007")


PROBLEMS = [KeyError("-1"), ValueError("Relative revision -9 didn't produce 9 migrations"), RuntimeError("anything")]


@contextmanager
def warnings_logged():
    with mock.patch.object(mg.log, "warning") as w:
        yield w


# ---------- chain_path: the revisions a run removes, from CHAIN alone ----------
@pytest.mark.parametrize("first,target,expected", [
    ("0007", None, list(NEWEST_FIRST)),
    ("0007", "base", list(NEWEST_FIRST)),
    ("0007", "0004", ["0007", "0006", "0005"]),                  # the target stays
    ("0007", "0006", ["0007"]),
    ("0007", "0001", list(NEWEST_FIRST[:-1])),
    ("0007", "-1", ["0007"]),
    ("0007", "-3", ["0007", "0006", "0005"]),
    ("0007", "-7", list(NEWEST_FIRST)),                          # -7 from 0007 is base
    ("0006", "-1", ["0006"]),                                    # counted from where THIS run starts, not from head
    ("0006", "-3", ["0006", "0005", "0004"]),
    ("0004", "0002", ["0004", "0003"]),
    ("0002", "-2", ["0002", "0001"]),
    ("0001", None, ["0001"]),
    ("0001", "-1", ["0001"]),
    ("0007", "0007", []),                                        # nothing to remove
])
def test_chain_path_is_the_revisions_above_the_target_counted_from_where_the_run_starts(first, target, expected):
    assert mg.chain_path(first, target) == expected


@pytest.mark.parametrize("first,target", [
    ("0099", None), ("0099", "-1"), ("", "base"),                # a start revision the policy does not know
    ("0002", "-3"), ("0007", "-8"), ("0001", "-2"),              # relative step longer than the chain
    ("0007", "-0"), ("0007", "-"), ("0007", "+1"), ("0007", "- 1"), ("0007", "-01"), ("0007", "-1.5"), ("0007", "1"),
    ("0007", "0099"), ("0007", "head"), ("0007", "heads"), ("0007", "BASE"), ("0007", "0004+1"), ("0007", ""), ("0007", 4),
    ("0007", mg.UNKNOWN),
])
def test_chain_path_says_it_does_not_know_rather_than_guessing(first, target):
    assert mg.chain_path(first, target) is None


# ---------- resolve_path: combining this module's answer with Alembic's ----------
def theirs(*revs):
    return list(revs)


def test_when_both_agree_the_path_is_that_path_with_no_caveat():
    path, caveat = mg.resolve_path("0007", "0004", theirs("0007", "0006", "0005"))
    assert path == ["0007", "0006", "0005"] and caveat is None


@pytest.mark.parametrize("order", ["newest_first", "oldest_first", "shuffled"])
def test_the_order_of_alembics_answer_does_not_matter(order):
    answer = {"newest_first": ["0007", "0006", "0005"], "oldest_first": ["0005", "0006", "0007"], "shuffled": ["0006", "0007", "0005"]}[order]
    path, caveat = mg.resolve_path("0007", "0004", answer)
    assert path == ["0007", "0006", "0005"] and caveat is None


def test_a_wider_answer_from_alembic_widens_the_check_and_says_so():
    path, caveat = mg.resolve_path("0007", "-1", theirs("0007", "0006"))
    assert path == ["0007", "0006"] and "differs" in caveat and "union" in caveat


def test_a_narrower_answer_from_alembic_cannot_narrow_the_check():
    path, caveat = mg.resolve_path("0007", None, theirs("0007"))
    assert path == list(NEWEST_FIRST) and "differs" in caveat


@pytest.mark.parametrize("target,expected", [(None, list(NEWEST_FIRST)), ("0004", ["0007", "0006", "0005"])])
def test_when_alembics_answer_is_unavailable_a_target_whose_meaning_does_not_depend_on_alembic_uses_this_modules_own_list(target, expected):
    path, caveat = mg.resolve_path("0007", target, None, "KeyError('x')")
    assert path == expected and "KeyError('x')" in caveat and "not available" in caveat


def test_a_relative_target_that_alembic_cannot_confirm_checks_everything_down_to_base():
    path, caveat = mg.resolve_path("0007", "-1", None, "KeyError('-1')")
    assert path == list(NEWEST_FIRST) and "KeyError('-1')" in caveat and "cross-checked" in caveat and "alembic downgrade 0006" in caveat
    path, caveat = mg.resolve_path("0004", "-1", None, "x")                       # from where the run starts, not from head
    assert path == ["0004", "0003", "0002", "0001"]


@pytest.mark.parametrize("target", [mg.UNKNOWN, "head", "0004+1", "-0", "-9", "0099", ""])
def test_when_this_module_does_not_recognise_the_target_alembics_answer_is_added_to_the_widest_check_not_substituted_for_it(target):
    path, caveat = mg.resolve_path("0007", target, theirs("0007", "0006"))
    assert path == list(NEWEST_FIRST) and "could not be established" in caveat


def test_when_neither_can_say_everything_from_the_start_down_to_base_is_checked():
    path, caveat = mg.resolve_path("0004", mg.UNKNOWN, None, "RuntimeError('x')")
    assert path == ["0004", "0003", "0002", "0001"] and "could not be established" in caveat and "RuntimeError('x')" in caveat
    path, caveat = mg.resolve_path("0007", "head", None)
    assert path == list(NEWEST_FIRST) and "could not be established" in caveat
    path, caveat = mg.resolve_path("0099", "head", theirs("0098"))                 # nothing is known: the revision itself and Alembic's names stay in the path
    assert set(path) == {"0099", "0098"}


def test_a_path_that_does_not_contain_the_revision_being_run_is_not_trusted():
    path, caveat = mg.resolve_path("0007", "0007", [])                          # "nothing to remove", yet 0007's downgrade() is running
    assert path == list(NEWEST_FIRST) and "did not contain 0007" in caveat
    path, caveat = mg.resolve_path("0005", None, theirs("0004", "0003"))        # Alembic's list would have skipped the revision running now
    assert "0005" in path and path == ["0005", "0004", "0003", "0002", "0001"]


def test_a_start_revision_outside_the_chain_is_still_part_of_its_own_path():
    path, caveat = mg.resolve_path("0099", None, theirs("0099", "0001"))
    assert "0099" in path and "0001" in path
    with pytest.raises(mg.DowngradeRefused, match="0099"):
        mg.check(path, counter(database()), environ={})


def test_the_caveat_is_part_of_a_refusal_so_the_operator_can_see_what_was_assumed():
    with pytest.raises(mg.DowngradeRefused) as e:
        mg.check(NEWEST_FIRST, counter(database("INSERT INTO users (id) VALUES (1)")), environ={}, caveat="CAVEAT-TEXT")
    assert str(e.value).endswith("CAVEAT-TEXT") and "0001: users 1 rows" in str(e.value)
    with pytest.raises(mg.DowngradeRefused, match="CAVEAT-TEXT"):
        mg.check(NEWEST_FIRST, None, offline=True, environ={}, caveat="CAVEAT-TEXT")


# ---------- preflight_downgrade when the (fake) Alembic misbehaves ----------
@pytest.mark.parametrize("problem", PROBLEMS)
def test_if_alembics_path_fails_a_relative_target_checks_everything_below_so_users_block_a_minus_one_and_the_message_names_the_way_out(problem):
    fake = FakeAlembic(database("INSERT INTO users (id) VALUES (1)"), ["0007"], target="-1", fail_path=problem)
    with fake.installed(), warnings_logged() as w, pytest.raises(mg.DowngradeRefused, match="0001: users 1 rows") as e:
        mg.preflight_downgrade("0007")
    assert "alembic downgrade 0006" in str(e.value) and repr(problem) in str(e.value) and w.call_count == 1


def test_if_alembics_path_fails_a_relative_target_every_revision_below_is_checked_and_an_empty_database_still_runs():
    fake = FakeAlembic(database("INSERT INTO invoice_counters (id) VALUES (1)"), ["0007"], target="-1", fail_path=RuntimeError("x"))
    with fake.installed(), warnings_logged(), pytest.raises(mg.DowngradeRefused, match="0005: invoice_counters"):
        mg.preflight_downgrade("0007")                 # data in 0005 is below 0007, so it is in "everything below"
    fake = FakeAlembic(database(), ["0007"], target="-1", fail_path=RuntimeError("x"))
    with fake.installed(), warnings_logged():
        mg.preflight_downgrade("0007")


@pytest.mark.parametrize("problem", PROBLEMS)
def test_if_alembics_path_fails_naming_the_target_revision_explicitly_uses_this_modules_own_list(problem):
    fake = FakeAlembic(database("INSERT INTO users (id) VALUES (1)", "INSERT INTO notification_preferences (id) VALUES (1)"), ["0007"], target="0006", fail_path=problem)
    with fake.installed(), warnings_logged() as w:
        mg.preflight_downgrade("0007")                 # 0006 stays, so only 0007 goes, and it drops no data
    assert w.call_count == 1 and repr(problem) in w.call_args.args[1]
    fake = FakeAlembic(database("INSERT INTO notification_preferences (id) VALUES (1)"), ["0007"], target="0003", fail_path=problem)
    with fake.installed(), warnings_logged(), pytest.raises(mg.DowngradeRefused, match="0004: notification_preferences 1 rows"):
        mg.preflight_downgrade("0007")


def test_if_alembics_path_fails_the_run_is_still_checked_for_the_data_a_relative_target_does_reach():
    fake = FakeAlembic(database("INSERT INTO payment_review_flags (id) VALUES (1)"), ["0007"], target="-2", fail_path=RuntimeError("x"))
    with fake.installed(), warnings_logged(), pytest.raises(mg.DowngradeRefused, match="0006: payment_review_flags 1 rows"):
        mg.preflight_downgrade("0007")


@pytest.mark.parametrize("problem", PROBLEMS)
def test_if_the_target_cannot_be_read_everything_from_the_start_down_is_checked_and_alembic_is_not_asked_about_it(problem):
    fake = FakeAlembic(database("INSERT INTO users (id) VALUES (1)"), ["0007"], fail_target=problem)
    with fake.installed(), warnings_logged() as w, pytest.raises(mg.DowngradeRefused, match="0001: users 1 rows") as e:
        mg.preflight_downgrade("0007")
    assert fake.iterated == [] and "could not be established" in str(e.value) and repr(problem) in str(e.value) and w.call_count == 1


def test_if_the_target_cannot_be_read_an_empty_database_still_passes():
    fake = FakeAlembic(database(), ["0007"], fail_target=RuntimeError("x"))
    with fake.installed(), warnings_logged():
        mg.preflight_downgrade("0007")


@pytest.mark.parametrize("answer", [["0001", "0002", "0003", "0004", "0005", "0006", "0007"], list(NEWEST_FIRST), ["0004", "0007", "0001", "0005", "0003", "0006", "0002"]])
def test_the_order_of_the_answer_from_alembic_does_not_change_the_outcome(answer):
    fake = FakeAlembic(database("INSERT INTO notification_preferences (id) VALUES (1)"), answer)
    with fake.installed(), pytest.raises(mg.DowngradeRefused, match="0004: notification_preferences 1 rows"):
        mg.preflight_downgrade("0007")


def test_a_narrower_answer_from_alembic_than_the_target_implies_still_checks_the_whole_run():
    fake = FakeAlembic(database("INSERT INTO users (id) VALUES (1)"), ["0006", "0005"], target=None)      # Alembic "forgot" 0007 and everything below 0005
    with fake.installed(), warnings_logged() as w, pytest.raises(mg.DowngradeRefused, match="0001: users 1 rows") as e:
        mg.preflight_downgrade("0007")
    assert "differs" in str(e.value) and w.call_count == 1


def test_a_wider_answer_from_alembic_is_honoured():
    fake = FakeAlembic(database("INSERT INTO payment_review_flags (id) VALUES (1)"), ["0007", "0006"], target="-1")
    with fake.installed(), warnings_logged(), pytest.raises(mg.DowngradeRefused, match="0006: payment_review_flags 1 rows"):
        mg.preflight_downgrade("0007")


def test_a_run_that_starts_part_way_is_judged_from_that_revision_not_from_head():
    # database at 0004: `downgrade -1` starts at 0004 and removes 0004 (notification tables) only
    fake = FakeAlembic(database("INSERT INTO notification_preferences (id) VALUES (1)", "INSERT INTO users (id) VALUES (1)"), ["0004"], target="-1")
    with fake.installed(), pytest.raises(mg.DowngradeRefused) as e:
        mg.preflight_downgrade("0004")
    assert "0004: notification_preferences 1 rows" in str(e.value) and "0001" not in str(e.value)
    fake = FakeAlembic(database("INSERT INTO invoice_counters (id) VALUES (1)", "INSERT INTO users (id) VALUES (1)"), ["0004"], target="-1")
    with fake.installed():
        mg.preflight_downgrade("0004")                     # 0005's tables are above where this run starts: not this run's business


def test_offline_mode_refuses_a_destructive_path_without_counting_anything():
    fake = FakeAlembic(database(), NEWEST_FIRST, offline=True)
    with fake.installed(), pytest.raises(mg.DowngradeRefused, match="offline"):
        mg.preflight_downgrade("0007")
    assert fake.queries == []
    fake = FakeAlembic(database(), ["0007"], target="0006", offline=True)
    with fake.installed():
        mg.preflight_downgrade("0007")


def test_a_database_error_while_counting_aborts_the_run_instead_of_passing_it():
    fake = FakeAlembic(sqlite3.connect(":memory:"), NEWEST_FIRST)        # none of the tables exist: the count fails
    with fake.installed(), pytest.raises(sqlite3.OperationalError):
        mg.preflight_downgrade("0007")


def test_a_missing_migration_context_is_a_refusal_not_a_run_that_looks_already_checked():
    fake = FakeAlembic(database(), NEWEST_FIRST)
    with fake.installed():
        fake.context.get_context = lambda: None            # `_checked` is None between runs: None must not read as "checked"
        with pytest.raises(mg.DowngradeRefused, match="no migration context"):
            mg.preflight_downgrade("0007")
    assert fake.iterated == []


def test_an_exception_from_alembic_that_is_not_about_the_path_is_not_swallowed():
    fake = FakeAlembic(database(), NEWEST_FIRST)
    with fake.installed():
        def broken():
            raise RuntimeError("no context configured")
        fake.context.get_context = broken
        with pytest.raises(RuntimeError, match="no context configured"):
            mg.preflight_downgrade("0007")
    assert mg._checked is None


def test_nothing_is_remembered_as_checked_until_the_check_has_passed():
    fake = FakeAlembic(database("INSERT INTO users (id) VALUES (1)"), NEWEST_FIRST)
    with fake.installed():
        with pytest.raises(mg.DowngradeRefused):
            mg.preflight_downgrade("0007")
        assert mg._checked is None
        fake.conn.execute("DELETE FROM users")
        mg.preflight_downgrade("0007")                      # the same run, now passing: remembered
        assert mg._checked is fake.ctx


def test_the_known_chain_is_the_policy_so_a_revision_cannot_be_ordered_but_unchecked_or_checked_but_unordered():
    assert mg.CHAIN == tuple(mg.POLICY) and list(mg.CHAIN) == sorted(mg.CHAIN)          # oldest first; the ids are zero-padded, so text order is revision order
    # a revision the policy has never heard of, starting a run whose reach nobody can establish, is refused (it is not "checked as only itself")
    path, caveat = mg.resolve_path("0008", "-1", None, "x")
    with pytest.raises(mg.DowngradeRefused, match="0008"):
        mg.check(path, counter(database()), environ={})
