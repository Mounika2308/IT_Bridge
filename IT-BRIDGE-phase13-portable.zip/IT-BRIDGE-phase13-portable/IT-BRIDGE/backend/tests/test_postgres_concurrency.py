"""Concurrency against a REAL PostgreSQL 16 database, through the real FastAPI app and services (Phase 13 remediation).

SKIPPED unless ITB_TEST_DATABASE_URL points at a dedicated, wipeable test database (see tests/pg.py); a skip is never a pass. These tests were
WRITTEN but NOT EXECUTED in the environment where Phase 13 was remediated: no SQLAlchemy, FastAPI or PostgreSQL driver could be installed there.

The schema is built from the models and then the migration-0007 triggers are installed, so the service code also runs against the integrity
triggers. Each scenario starts N requests at once (a Barrier), each on its own database session and connection, and then checks the invariants
that must hold whatever the interleaving: no server error, no duplicate money records, consistent totals, and no deadlock (every request
finishes within the timeout).
"""
import importlib.util
import threading
from concurrent.futures import ThreadPoolExecutor

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine, func, text
from sqlalchemy.orm import sessionmaker

import app.models  # noqa: F401
from app.core.database import Base, get_db
from app.main import app
from app.models.payment import (Invoice, InvoiceCounter, Payment, PaymentRefund, PaymentTransaction, PaymentWebhookEvent, PlatformCommission,
                                TrainerEarning)
from app.models.training import Training
from tests import pg
from tests.test_payments_phase13 import API, FEE, admin, deliver, new_key, paid, pay, refund, row, setup, signed, start
from tests.test_trainings import begin, db_of

TIMEOUT = 90


def _install_triggers(engine):
    path = pg.__file__.replace("tests/pg.py", "alembic/versions/0007_financial_integrity_triggers.py")
    spec = importlib.util.spec_from_file_location("migration_0007", path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    with engine.begin() as c:
        for fn in mod.FUNCTIONS:
            c.execute(text(fn))
        for name, table, when, fn in mod.TRIGGERS:
            c.execute(text(f"CREATE TRIGGER {name} {when} ON {table} FOR EACH ROW EXECUTE FUNCTION {fn}()"))


@pytest.fixture()
def client():
    url = pg.require_postgres()
    engine = create_engine(url, pool_size=30, max_overflow=30, pool_pre_ping=True)
    pg.wipe(engine)
    Base.metadata.create_all(engine)
    _install_triggers(engine)
    Session = sessionmaker(bind=engine, expire_on_commit=False, autoflush=False)   # as in app/core/database.py (the SQLite conftest uses the default)

    def override():
        db = Session()
        try:
            yield db
        finally:
            db.close()

    app.dependency_overrides[get_db] = override
    yield TestClient(app)
    app.dependency_overrides.clear()
    engine.dispose()


def race(calls):
    """Runs the callables at the same moment, each in its own thread (and with its own TestClient). Returns their results.
    LIMIT: `f.result(timeout=TIMEOUT)` makes a call that is still running after TIMEOUT seconds raise, but the `with ThreadPoolExecutor` block then
    waits for every worker thread on exit. A request that never returns (a genuine deadlock the database does not break) would therefore still hang
    the run; PostgreSQL's own deadlock detector (about 1 second) normally turns a deadlock into an error first. Use an external timeout (for
    example `pytest --timeout` or `timeout 600 pytest ...`) if a hang must be impossible."""
    barrier = threading.Barrier(len(calls))

    def run(fn):
        barrier.wait(timeout=TIMEOUT)
        return fn()

    with ThreadPoolExecutor(max_workers=len(calls)) as pool:
        futures = [pool.submit(run, fn) for fn in calls]
        return [f.result(timeout=TIMEOUT) for f in futures]


def fresh():
    return TestClient(app)


# ---------- 1. the same Idempotency-Key, sent many times at once ----------
def test_same_key_concurrent_payment_requests_create_exactly_one_payment(client):
    th, ih, tid = setup(client)
    key = new_key()
    results = race([lambda: pay(fresh(), ih, tid, FEE // 2, key=key) for _ in range(8)])
    assert {r.status_code for r in results} <= {200, 201}, [r.text for r in results if r.status_code not in (200, 201)]
    assert sum(r.status_code == 201 for r in results) == 1, "exactly one request created the payment; the rest are replays"
    assert len({r.json()["data"]["id"] for r in results}) == 1
    assert row(client, Payment, idempotency_key=key).amount_paise == FEE // 2
    assert db_count(client, Payment) == 1


def test_different_keys_at_once_still_allow_only_one_payment_in_flight(client):
    th, ih, tid = setup(client)
    results = race([lambda: pay(fresh(), ih, tid, FEE // 2) for _ in range(6)])
    assert sum(r.status_code == 201 for r in results) == 1
    assert {r.status_code for r in results} <= {201, 409}, [r.text for r in results]
    assert db_count(client, Payment) == 1


# ---------- 2. creating a payment while the training is being completed ----------
def test_payment_creation_racing_with_training_completion(client):
    th, ih, tid = setup(client)
    begin(client, tid)
    r_pay, r_done = race([lambda: pay(fresh(), ih, tid, FEE), lambda: fresh().post(f"{API}/trainings/{tid}/complete", headers=ih)])
    assert r_done.status_code == 200 and r_pay.status_code in (201, 409), (r_pay.text, r_done.text)
    assert row(client, Training, id=tid).status == "COMPLETED"
    if r_pay.status_code == 201:
        assert db_count(client, Payment) == 1
        ok = fresh().post(f"{API}/payments/{r_pay.json()['data']['id']}/sandbox/success", headers=ih)
        assert ok.status_code == 200 and ok.json()["data"]["outcome"] in ("succeeded", "succeeded_late")
        # the payment settled after completion, so its earning must be available at once, never stuck in PENDING
        assert row(client, TrainerEarning, payment_id=r_pay.json()["data"]["id"]).status == "AVAILABLE"
    else:
        assert db_count(client, Payment) == 0


# ---------- 3. the same webhook delivered many times at once ----------
def test_concurrent_duplicate_webhooks_settle_once(client):
    th, ih, tid = setup(client)
    p = start(client, ih, tid)
    body, headers = signed(p["checkout"]["order_id"], event_id="evt_race_1", txn_id="txn_race_1")
    results = race([lambda: fresh().post(f"{API}/payments/webhook", content=body, headers=headers) for _ in range(8)])
    assert {r.status_code for r in results} == {200}, [r.text for r in results]
    outcomes = [r.json()["data"]["outcome"] for r in results]
    assert outcomes.count("succeeded") == 1 and set(outcomes) <= {"succeeded", "replay", "duplicate"}, outcomes
    pid = p["id"]
    assert (db_count(client, Invoice), db_count(client, TrainerEarning), db_count(client, PlatformCommission), db_count(client, PaymentTransaction)) == (1, 1, 1, 1)
    assert db_count(client, PaymentWebhookEvent, payment_id=pid) == 1
    assert row(client, Payment, id=pid).status == "SUCCEEDED" and not row(client, Payment, id=pid).needs_review


def test_concurrent_different_events_for_one_payment_settle_once_and_flag_the_second_charge(client):
    th, ih, tid = setup(client)
    p = start(client, ih, tid)
    results = race([lambda: deliver(fresh(), p["checkout"]["order_id"], txn_id=f"txn_{i}") for i in range(4)])
    assert {r.status_code for r in results} == {200}
    outcomes = sorted(r.json()["data"]["outcome"] for r in results)
    assert outcomes.count("succeeded") == 1 and outcomes.count("duplicate_charge") == 3, outcomes
    assert (db_count(client, Invoice), db_count(client, TrainerEarning), db_count(client, PlatformCommission), db_count(client, PaymentTransaction)) == (1, 1, 1, 1)


# ---------- 4. a refund racing with a payout ----------
def test_refund_racing_with_payout_never_both_pay_the_trainer_and_return_the_money(client):
    th, ih, tid = setup(client)
    ah = admin(client)
    pid = paid(client, ih, tid)
    begin(client, tid)
    assert client.post(f"{API}/trainings/{tid}/complete", headers=ih).status_code == 200
    eid = row(client, TrainerEarning, payment_id=pid).id
    assert row(client, TrainerEarning, id=eid).status == "AVAILABLE"
    r_refund, r_payout = race([lambda: refund(fresh(), ah, pid),
                               lambda: fresh().post(f"{API}/admin/earnings/{eid}/payout", headers=ah, json={"reference": "BATCH-RACE-1"})])
    assert r_refund.status_code in (200, 409) and r_payout.status_code in (200, 409), (r_refund.text, r_payout.text)
    assert (r_refund.status_code == 200) != (r_payout.status_code == 200), "exactly one of the two wins"
    earning = row(client, TrainerEarning, id=eid)
    if r_payout.status_code == 200:
        assert earning.status == "PAID" and db_count(client, PaymentRefund) == 0
        assert r_refund.json()["data"]["code"] == "ALREADY_PAID_OUT"
        assert row(client, PlatformCommission, payment_id=pid).status == "RECORDED"
    else:
        assert earning.status == "REFUNDED" and row(client, PaymentRefund, payment_id=pid).status == "SUCCEEDED"
        assert row(client, PlatformCommission, payment_id=pid).status == "REVERSED" and earning.paid_at is None
        assert r_payout.json()["data"]["code"] in ("REFUND_EXISTS", "REFUNDED")
    assert db_count(client, PaymentTransaction, type="REFUND") == (1 if r_refund.status_code == 200 else 0)


def test_two_refund_requests_at_once_refund_once(client):
    th, ih, tid = setup(client)
    ah = admin(client)
    pid = paid(client, ih, tid)
    results = race([lambda: refund(fresh(), ah, pid) for _ in range(4)])
    assert {r.status_code for r in results} <= {200, 409, 502}, [r.text for r in results]
    assert db_count(client, PaymentRefund) == 1 and db_count(client, PaymentTransaction, type="REFUND") == 1
    assert row(client, PaymentRefund, payment_id=pid).status == "SUCCEEDED"


# ---------- 5. the first invoice numbers of a year, allocated concurrently ----------
def test_concurrent_first_time_invoice_numbering_gives_distinct_sequential_numbers(client):
    pairs = [setup(client, f"n{i}") for i in range(6)]
    started = [start(client, ih, tid) for _, ih, tid in pairs]
    assert db_count(client, InvoiceCounter) == 0, "the counter row does not exist yet: the race is for creating it"
    results = race([lambda ih=ih, p=p: fresh().post(f"{API}/payments/{p['id']}/sandbox/success", headers=ih) for (_, ih, _), p in zip(pairs, started)])
    assert {r.status_code for r in results} == {200}, [r.text for r in results]
    numbers = sorted(i.number for i in db_of(client).query(Invoice))
    assert len(numbers) == 6 and len(set(numbers)) == 6, numbers
    assert [int(n.rsplit("-", 1)[1]) for n in numbers] == [1, 2, 3, 4, 5, 6]
    assert row(client, InvoiceCounter, series="INV").last_number == 6


def test_concurrent_first_time_credit_note_numbering(client):
    pairs = [setup(client, f"c{i}") for i in range(4)]
    ah = admin(client)
    ids = [paid(client, ih, tid) for _, ih, tid in pairs]
    assert db_count(client, InvoiceCounter, series="CN") == 0
    results = race([lambda pid=pid: refund(fresh(), ah, pid) for pid in ids])
    assert {r.status_code for r in results} == {200}, [r.text for r in results]
    notes = sorted(r.credit_note_number for r in db_of(client).query(PaymentRefund))
    assert len(set(notes)) == 4 and [int(n.rsplit("-", 1)[1]) for n in notes] == [1, 2, 3, 4], notes


# ---------- the integrity triggers against the real service code ----------
def test_the_triggers_do_not_get_in_the_way_of_the_normal_lifecycle(client):
    """A late success, an over-cap payment, a cancellation and refunds, with the 0007 triggers installed: the service's own insert order must satisfy them."""
    th, ih, tid = setup(client)
    ah = admin(client)
    first = start(client, ih, tid)
    assert fresh().post(f"{API}/payments/{first['id']}/sandbox/fail", headers=ih).status_code == 200
    settled = paid(client, ih, tid)                                                   # the whole fee is held
    late = deliver(fresh(), first["checkout"]["order_id"])                            # over cap: an invoice, no earning, no commission
    assert late.status_code == 200 and late.json()["data"]["outcome"] == "succeeded_over_cap"
    assert refund(client, ah, first["id"]).status_code == 200                         # a credit note for the over-cap payment
    assert fresh().post(f"{API}/trainings/{tid}/cancel", headers=ih, json={"reason": "no longer needed"}).status_code == 200
    assert refund(client, ah, settled).status_code == 200


def test_the_database_refuses_to_edit_an_invoice_or_the_ledger_even_with_hand_written_sql(client):
    from sqlalchemy.exc import IntegrityError
    th, ih, tid = setup(client)
    pid = paid(client, ih, tid)
    inv = row(client, Invoice, payment_id=pid)
    db = db_of(client)
    with pytest.raises(IntegrityError):
        db.execute(text("UPDATE invoices SET amount_paise = amount_paise + 1 WHERE id = :i"), {"i": inv.id})
        db.commit()
    db.rollback()
    with pytest.raises(IntegrityError):
        db.execute(text("DELETE FROM payment_transactions WHERE payment_id = :p"), {"p": pid})
        db.commit()
    db.rollback()
    with pytest.raises(IntegrityError):
        db.execute(text("UPDATE payments SET amount_paise = amount_paise + 1 WHERE id = :p"), {"p": pid})
        db.commit()
    db.rollback()


def db_count(client, model, **where):
    q = db_of(client).query(func.count()).select_from(model)
    for k, v in where.items():
        q = q.filter(getattr(model, k) == v)
    return q.scalar()
