"""Start-up / configuration tests that do NOT depend on backend/.env, on the shell's variables or on the directory pytest was started from (13B.1).

Every test runs the application in a child process through tests/boot_env.py: empty temporary cwd, scrubbed environment, optional explicit `.env`.

Two groups:
  * helper mechanics   - need only the standard library, so they run anywhere.
  * application start-up - import the real app, so they need fastapi, pydantic-settings and SQLAlchemy. Without them they are SKIPPED, never passed:
    a child that dies on `import fastapi` would otherwise look like "the guard refused", which is exactly the false pass this file must not allow.
    Every "refused" case also asserts the guard's own message, and every "starts" case asserts exit code 0.
"""
import os
from pathlib import Path

import pytest

from tests import boot_env
from tests import webhook_secret_matrix as M
from tests.boot_env import BACKEND, boot, clean_environ, settings_variable_names

EXAMPLE_SECRET = M.EXAMPLE_SECRET                    # read from .env.example
STRONG = M.STRONG_SECRET
needs_app = pytest.mark.skipif(bool(boot_env.missing_modules()), reason=f"needs {boot_env.missing_modules()}: NOT RUN here (skipped, not passed)")


# ---------------------------------------------------------------- helper mechanics (standard library only)
def test_the_child_runs_in_an_empty_temporary_directory_not_in_backend():
    b = boot("import os, sys; print(os.getcwd()); print(sorted(os.listdir('.')))")
    out = b.stdout.splitlines()
    assert b.returncode == 0, b.stderr
    assert Path(out[0]).resolve() != BACKEND.resolve() and BACKEND.resolve() not in Path(out[0]).resolve().parents
    assert out[1] == "[]"                                                        # nothing at all in the cwd, so no stray .env
    assert not Path(b.cwd).exists()                                              # and it is removed afterwards


def test_a_dotenv_exists_in_the_child_only_when_the_test_supplies_one():
    probe = "import os; print(os.path.exists('.env')); print(open('.env').read() if os.path.exists('.env') else '')"
    assert boot(probe).stdout.splitlines()[0] == "False"
    b = boot(probe, dotenv={"ENVIRONMENT": "test", "X": "1"})
    assert b.stdout.splitlines()[0] == "True" and "ENVIRONMENT=test" in b.stdout
    assert boot(probe, dotenv="RAW=text\n").stdout.count("RAW=text") == 1


def test_the_real_backend_dotenv_is_never_what_the_child_reads():
    """Whether or not backend/.env exists on this machine, the child's cwd is a different, empty directory."""
    has_real_dotenv = (BACKEND / ".env").exists()                                 # recorded, not touched
    b = boot("import os; print(os.path.exists('.env'))")
    assert b.stdout.strip() == "False", f"backend/.env present={has_real_dotenv} must be irrelevant"


def test_every_settings_variable_is_scrubbed_from_the_childs_environment(monkeypatch):
    names = settings_variable_names()
    assert {"ENVIRONMENT", "DATABASE_URL", "JWT_SECRET", "PAYMENTS_ENABLED", "PAYMENT_WEBHOOK_SECRET", "PAYMENT_SANDBOX_ENABLED", "PLATFORM_COMMISSION_BPS",
            "PAYMENT_COMMISSION_CONFIRMED", "CORS_ORIGINS", "EARNING_HOLD_DAYS"} <= names
    for n in names:
        monkeypatch.setenv(n, "leaked-from-the-parent")
    b = boot("import os; print(sorted(k for k in os.environ if k.upper() in %r))" % sorted(names))
    assert b.returncode == 0, b.stderr
    assert b.stdout.strip() == str(sorted(boot_env.DEFAULT_ENV)), b.stdout          # only the two neutral defaults remain


def test_a_variable_passed_to_boot_is_set_and_none_unsets_it(monkeypatch):
    monkeypatch.setenv("ENVIRONMENT", "production")                              # a hostile parent
    seen = boot("import os; print(os.environ.get('ENVIRONMENT'))", env={"ENVIRONMENT": "test"}).stdout.strip()
    assert seen == "test"
    assert boot("import os; print(os.environ.get('ENVIRONMENT'))").stdout.strip() == "None"
    assert boot("import os; print(os.environ.get('JWT_SECRET'))", env={"JWT_SECRET": None}).stdout.strip() == "None"


def test_clean_environ_does_not_modify_the_parent_environment(monkeypatch):
    monkeypatch.setenv("ENVIRONMENT", "production")
    clean_environ({"ENVIRONMENT": "test"})
    assert os.environ["ENVIRONMENT"] == "production"


# ---------------------------------------------------------------- application start-up (needs the real dependencies)
def _opposite(env: dict) -> dict:
    """A `.env` that DISAGREES with every variable the case sets (and sets nothing else). Environment variables outrank `.env`, so the outcome must not move."""
    flip = {"ENVIRONMENT": "development", "PAYMENTS_ENABLED": "false", "PAYMENT_SANDBOX_ENABLED": "true", "PAYMENT_PROVIDER": "sandbox",
            "PAYMENT_WEBHOOK_SECRET": STRONG, "PAYMENT_COMMISSION_CONFIRMED": "true", "PLATFORM_COMMISSION_BPS": "1000", "JWT_SECRET": "change_me"}
    return {k: flip.get(k, "ignored") for k, v in env.items() if v is not None}


PROD = {"ENVIRONMENT": "production", "PAYMENT_WEBHOOK_SECRET": STRONG}         # 13B.2: a production process needs a strong webhook secret even with payments off
# name -> (environment variables, None = must start | text that the refusal must contain)
CASES = {
    "production, payments off, strong secret (the default deployment)": (PROD, None),
    "production, payments OFF, missing secret": ({"ENVIRONMENT": "production"}, "PAYMENT_WEBHOOK_SECRET is missing or empty"),
    "production, payments OFF, empty secret": ({"ENVIRONMENT": "production", "PAYMENT_WEBHOOK_SECRET": ""}, "PAYMENT_WEBHOOK_SECRET is missing or empty"),
    "production, payments OFF, example secret": ({**PROD, "PAYMENT_WEBHOOK_SECRET": EXAMPLE_SECRET}, "PAYMENT_WEBHOOK_SECRET is weak or a known example value"),
    "production, payments OFF, weak secret": ({**PROD, "PAYMENT_WEBHOOK_SECRET": "change_me"}, "PAYMENT_WEBHOOK_SECRET is weak"),
    "production, payments ON, example secret": ({**PROD, "PAYMENTS_ENABLED": "true", "PAYMENT_PROVIDER": "somegateway", "PAYMENT_COMMISSION_CONFIRMED": "true",
                                                 "PAYMENT_WEBHOOK_SECRET": EXAMPLE_SECRET}, "PAYMENT_WEBHOOK_SECRET is weak or a known example value"),
    "production, payments ON, missing secret": ({"ENVIRONMENT": "production", "PAYMENTS_ENABLED": "true", "PAYMENT_PROVIDER": "somegateway", "PAYMENT_COMMISSION_CONFIRMED": "true"},
                                                "PAYMENT_WEBHOOK_SECRET is missing or empty"),
    "production, sandbox opt-in, payments off": ({**PROD, "PAYMENT_SANDBOX_ENABLED": "true"}, "PAYMENT_SANDBOX_ENABLED must never be true in production"),
    "ENVIRONMENT missing, payments off": ({}, "ENVIRONMENT is missing or not recognised"),
    "ENVIRONMENT missing, payments on": ({"PAYMENTS_ENABLED": "true", "PAYMENT_PROVIDER": "sandbox", "PAYMENT_SANDBOX_ENABLED": "true"},
                                         "ENVIRONMENT is missing or not recognised"),
    "ENVIRONMENT empty": ({"ENVIRONMENT": ""}, "ENVIRONMENT is missing or not recognised"),
    "ENVIRONMENT misspelt": ({"ENVIRONMENT": "prodution"}, "ENVIRONMENT is missing or not recognised"),
    "ENVIRONMENT staging, payments off": ({"ENVIRONMENT": "staging"}, "ENVIRONMENT is missing or not recognised"),
    "development, payments off": ({"ENVIRONMENT": "development"}, None),
    "development, sandbox with opt-in and the example secret": ({"ENVIRONMENT": "development", "PAYMENTS_ENABLED": "true", "PAYMENT_PROVIDER": "sandbox",
                                                                "PAYMENT_SANDBOX_ENABLED": "true", "PAYMENT_WEBHOOK_SECRET": EXAMPLE_SECRET}, None),
    "test, sandbox with opt-in": ({"ENVIRONMENT": "test", "PAYMENTS_ENABLED": "true", "PAYMENT_PROVIDER": "sandbox", "PAYMENT_SANDBOX_ENABLED": "true"}, None),
    "development, sandbox without opt-in": ({"ENVIRONMENT": "development", "PAYMENTS_ENABLED": "true", "PAYMENT_PROVIDER": "sandbox"},
                                            "PAYMENT_SANDBOX_ENABLED is not true"),
    "commission rate out of range": ({"ENVIRONMENT": "development", "PLATFORM_COMMISSION_BPS": "10001"}, "PLATFORM_COMMISSION_BPS must be a whole number"),
}


def _assert_outcome(b, must_contain):
    if must_contain is None:
        assert b.returncode == 0, b.stderr[-800:]
    else:
        assert b.returncode != 0 and "Refusing to start with an unsafe payment configuration" in b.stderr and must_contain in b.stderr, (b.returncode, b.stderr[-800:])


@needs_app
@pytest.mark.parametrize("name", list(CASES))
def test_start_up_outcome_without_any_dotenv(name):
    env, must_contain = CASES[name]
    _assert_outcome(boot("import app.main", env=env), must_contain)


@needs_app
@pytest.mark.parametrize("name", list(CASES))
def test_start_up_outcome_is_identical_with_a_dotenv_that_disagrees(name):
    """Same case, but a `.env` in the child's cwd disagrees with every variable the case sets: the environment variables must win, so nothing changes."""
    env, must_contain = CASES[name]
    _assert_outcome(boot("import app.main", env=env, dotenv=_opposite(env)), must_contain)


@needs_app
def test_a_dotenv_alone_may_supply_the_environment_and_is_then_judged_like_any_other_source():
    _assert_outcome(boot("import app.main", dotenv={"ENVIRONMENT": "development"}), None)
    _assert_outcome(boot("import app.main", dotenv={"ENVIRONMENT": "staging"}), "ENVIRONMENT is missing or not recognised")
    _assert_outcome(boot("import app.main", dotenv={"ENVIRONMENT": "production", "PAYMENT_WEBHOOK_SECRET": EXAMPLE_SECRET}), "known example value")


@needs_app
def test_a_missing_environment_is_never_treated_as_development():
    """No ENVIRONMENT anywhere. If the app guessed 'development' this would start (and a production deployment with a forgotten variable would run
    with development behaviour)."""
    b = boot("import app.main")
    assert b.returncode != 0 and "ENVIRONMENT is missing or not recognised" in b.stderr


@needs_app
@pytest.mark.parametrize("entry", ["from app.workers.payments import run_once; run_once()", "from app.workers.loop import main; main()"])
@pytest.mark.parametrize("env,needle", [({}, "ENVIRONMENT is missing"), ({"ENVIRONMENT": "production", "PAYMENT_WEBHOOK_SECRET": EXAMPLE_SECRET}, "known example value")])
def test_the_payment_workers_refuse_the_same_unsafe_configurations_as_the_api(entry, env, needle):
    b = boot(entry, env=env)
    assert b.returncode != 0 and "unsafe payment configuration" in b.stderr and needle in b.stderr, b.stderr[-800:]


@needs_app
def test_the_example_env_file_is_a_safe_development_configuration_and_never_valid_for_production():
    """Copying .env.example verbatim must start in development and must be refused the moment ENVIRONMENT is production."""
    example = (BACKEND.parent / ".env.example").read_text()
    values = {}
    for line in example.splitlines():
        if "=" in line and not line.lstrip().startswith("#"):
            k, v = line.split("=", 1)
            values[k.strip()] = v.strip()
    assert values["ENVIRONMENT"] == "development" and values["PAYMENT_WEBHOOK_SECRET"] == EXAMPLE_SECRET
    values["JWT_SECRET"] = "j" * 40
    _assert_outcome(boot("import app.main", dotenv=values), None)
    _assert_outcome(boot("import app.main", dotenv={**values, "ENVIRONMENT": "production"}), "known example value")


# ---------------------------------------------------------------- 13B.2: the production webhook-secret matrix (30 cells), in a real child process
@needs_app
@pytest.mark.parametrize("case", M.CASES, ids=M.case_id)
def test_webhook_secret_matrix_without_a_dotenv(case):
    starts, must, must_not = M.startup(*case)
    b = boot("import app.main", env=M.env_vars(*case))
    if starts:
        assert b.returncode == 0, b.stderr[-800:]
    else:
        assert b.returncode != 0 and "Refusing to start with an unsafe payment configuration" in b.stderr and must in b.stderr, b.stderr[-800:]
        if must_not:
            assert must_not not in b.stderr, b.stderr[-800:]


@needs_app
@pytest.mark.parametrize("case", M.CASES, ids=M.case_id)
def test_webhook_secret_matrix_with_a_dotenv_that_disagrees(case):
    """The same cell with a `.env` that sets every variable the cell sets to a permissive value: the environment variables still win."""
    starts, must, must_not = M.startup(*case)
    env = M.env_vars(*case)
    b = boot("import app.main", env=env, dotenv=_opposite(env))
    if starts:
        assert b.returncode == 0, b.stderr[-800:]
    else:
        assert b.returncode != 0 and must in b.stderr, b.stderr[-800:]


@needs_app
@pytest.mark.parametrize("entry", ["from app.workers.payments import run_once; run_once()", "from app.workers.loop import main; main()"])
@pytest.mark.parametrize("kind", ["missing", "empty", "weak", "example"])
def test_the_payment_workers_refuse_a_production_start_without_a_strong_secret_with_payments_disabled(entry, kind):
    b = boot(entry, env=M.env_vars("production", False, kind))
    assert b.returncode != 0 and "PAYMENT_WEBHOOK_SECRET" in b.stderr, b.stderr[-800:]
