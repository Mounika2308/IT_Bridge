"""Runs scripts/audit_integration.py: frontend calls/links/imports must match real backend routes and React routes."""
import subprocess
import sys
from pathlib import Path


def test_frontend_backend_integration_audit_is_clean():
    script = Path(__file__).resolve().parents[2] / "scripts" / "audit_integration.py"
    r = subprocess.run([sys.executable, str(script)], capture_output=True, text=True)
    assert r.returncode == 0, r.stdout + r.stderr
