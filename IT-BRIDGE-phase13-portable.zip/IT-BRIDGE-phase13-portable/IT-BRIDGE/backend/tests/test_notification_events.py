"""Which events notify whom, with what text and which deep link (Phase 11). Nothing here sends email: see test_notification_delivery.py."""
import ast
import re
from datetime import datetime, time, timedelta
from pathlib import Path

from app.core.clock import today
from app.services import notification_types
from app.services.notification_types import TYPES, fmt_when
from app.workers.reminders import send_reminders
from tests.test_requirement_lifecycle import apply, fill, hire, move, trainer, world
from tests.test_phase10_sessions import attend, held_session, set_status
from tests.test_reviews import TRAINER_RATINGS
from tests.test_trainings import START, begin, db_of, req_body, session

TITLE = "Python workshop for 3rd years"


def inbox(client, h):
    return client.get("/api/v1/notifications?page_size=50", headers=h).json()["data"]["items"]


def of_type(client, h, t):
    return [n for n in inbox(client, h) if n["type"] == t]


# ---------- applications ----------
def test_application_events(client):
    ta, tb, tc, ih, rid, aid = world(client)
    got = of_type(client, ih, "APPLICATION_RECEIVED")
    assert len(got) == 3 and all(n["link"] == f"/institution/requirements/{rid}/applications" for n in got)
    assert any(n["body"] == f"A applied to {TITLE}" for n in got)
    shortlisted = of_type(client, ta, "APPLICATION_SHORTLISTED")
    assert len(shortlisted) == 1 and shortlisted[0]["link"] == "/trainer/applications" and TITLE in shortlisted[0]["body"]
    move(client, ih, aid["c"], "UNDER_REVIEW")
    move(client, ih, aid["c"], "REJECTED")
    assert len(of_type(client, tc, "APPLICATION_UPDATE")) == 1 and len(of_type(client, tc, "APPLICATION_REJECTED")) == 1


def test_withdrawing_notifies_the_institution(client):
    ta, tb, tc, ih, rid, aid = world(client)
    assert client.post(f"/api/v1/applications/{aid['b']}/withdraw", headers=tb).status_code == 200
    n = of_type(client, ih, "APPLICATION_WITHDRAWN")
    assert len(n) == 1 and n[0]["body"] == f"B withdrew from {TITLE}" and n[0]["link"] == f"/institution/requirements/{rid}/applications"


def test_interview_notification_has_date_time_and_link(client):
    ta, tb, tc, ih, rid, aid = world(client)
    first = datetime.combine(today() + timedelta(days=3), time(14, 30))
    assert move(client, ih, aid["b"], "INTERVIEW", interview_at=first.isoformat()).status_code == 200
    n = of_type(client, tb, "INTERVIEW_SCHEDULED")
    assert len(n) == 1 and fmt_when(first) in n[0]["body"] and "14:30" in n[0]["body"] and n[0]["link"] == "/trainer/applications"
    second = datetime.combine(today() + timedelta(days=4), time(11, 0))
    assert move(client, ih, aid["b"], "INTERVIEW", interview_at=second.isoformat()).status_code == 200
    u = of_type(client, tb, "INTERVIEW_UPDATED")
    assert len(u) == 1 and fmt_when(second) in u[0]["body"] and "11:00" in u[0]["body"]


# ---------- hiring, training created, requirement filled / reopened ----------
def test_hiring_events(client):
    ta, tb, tc, ih, rid, aid = world(client)
    hid = hire(client, ih, aid["a"]).json()["data"]["id"]
    assert [n["link"] for n in of_type(client, ta, "HIRING_REQUEST")] == ["/trainer/applications"]
    client.post(f"/api/v1/hiring-requests/{hid}/decline", headers=ta)
    assert [n["body"] for n in of_type(client, ih, "HIRING_DECLINED")] == [f"A declined: {TITLE}"]
    hid2 = hire(client, ih, aid["b"]).json()["data"]["id"]
    client.post(f"/api/v1/hiring-requests/{hid2}/cancel", headers=ih)
    assert [n["link"] for n in of_type(client, tb, "HIRING_CANCELLED")] == ["/trainer/applications"]


def test_accepting_creates_clear_training_and_acceptance_notifications(client):
    ta, tb, tc, ih, rid, aid = world(client)
    hid, tid = fill(client, ih, ta, aid["a"])
    created = of_type(client, ta, "TRAINING_CREATED")
    assert len(created) == 1 and created[0]["link"] == f"/trainings/{tid}"
    assert TITLE in created[0]["body"] and "Sunrise College" in created[0]["body"] and str(START) in created[0]["body"]
    accepted = of_type(client, ih, "HIRING_ACCEPTED")
    assert len(accepted) == 1 and accepted[0]["link"] == f"/trainings/{tid}" and accepted[0]["body"] == f"A accepted: {TITLE}"


def test_requirement_filled_notifies_only_applicants_still_waiting_and_names_nobody(client):
    ta, tb, tc, ih, rid, aid = world(client)
    fill(client, ih, ta, aid["a"])
    for h in (tb, tc):
        n = of_type(client, h, "REQUIREMENT_FILLED")
        assert len(n) == 1 and n[0]["link"] == "/trainer/applications"
        assert n[0]["body"] == f"{TITLE} has found its trainer. Your application can no longer be processed."
        assert "example.com" not in str(n[0])                                     # nothing private
    assert of_type(client, ta, "REQUIREMENT_FILLED") == [] and of_type(client, ih, "REQUIREMENT_FILLED") == []


def test_reopening_notifies_waiting_applicants_and_the_institution_when_the_trainer_cancelled(client):
    ta, tb, tc, ih, rid, aid = world(client)
    hid, tid = fill(client, ih, ta, aid["a"])
    client.post(f"/api/v1/trainings/{tid}/cancel", headers=ta, json={"reason": "Changed plans"})
    for h in (tb, tc):
        n = of_type(client, h, "REQUIREMENT_REOPENED")
        assert len(n) == 1 and n[0]["link"] == f"/requirements/{rid}"
    inst = of_type(client, ih, "REQUIREMENT_REOPENED")
    assert len(inst) == 1 and inst[0]["link"] == f"/institution/requirements/{rid}/applications"
    cancelled = of_type(client, ih, "TRAINING_CANCELLED")
    assert len(cancelled) == 1 and cancelled[0]["body"] == f"{TITLE}: Changed plans"
    assert of_type(client, ta, "REQUIREMENT_REOPENED") == []                      # the selected trainer is not a waiting applicant


def test_institution_cancelling_does_not_tell_itself_about_the_reopening(client):
    ta, tb, tc, ih, rid, aid = world(client)
    hid, tid = fill(client, ih, ta, aid["a"])
    client.post(f"/api/v1/trainings/{tid}/cancel", headers=ih, json={})
    assert of_type(client, ih, "REQUIREMENT_REOPENED") == [] and len(of_type(client, tb, "REQUIREMENT_REOPENED")) == 1
    assert len(of_type(client, ta, "TRAINING_CANCELLED")) == 1


def test_cancelling_after_the_start_sends_no_reopening_notice(client):
    ta, tb, tc, ih, rid, aid = world(client)
    hid, tid = fill(client, ih, ta, aid["a"])
    begin(client, tid)
    client.post(f"/api/v1/trainings/{tid}/cancel", headers=ih, json={})
    assert all(of_type(client, h, "REQUIREMENT_REOPENED") == [] for h in (ta, tb, tc, ih))


# ---------- training changes ----------
def online_training(client):
    from app.models.user import Skill
    from tests.test_trainings import reg
    db = db_of(client)
    db.add(Skill(name="Python"))
    db.commit()
    ta, ih = trainer(client, "a"), reg(client, "i@example.com", "INSTITUTION", institution_name="Sunrise College")
    rid = client.post("/api/v1/requirements", headers=ih, json=req_body(mode="ONLINE", location="Remote")).json()["data"]["id"]
    aid = apply(client, ta, rid).json()["data"]["id"]
    move(client, ih, aid, "SHORTLISTED")
    hid, tid = fill(client, ih, ta, aid)
    return ta, ih, rid, tid


def test_dates_changed_and_meeting_link_changed(client):
    ta, ih, rid, tid = online_training(client)
    r = client.patch(f"/api/v1/trainings/{tid}/dates", headers=ih, json={"start_date": str(START + timedelta(days=1)), "end_date": str(START + timedelta(days=12))})
    assert r.status_code == 200
    n = of_type(client, ta, "TRAINING_DATES_CHANGED")
    assert len(n) == 1 and n[0]["link"] == f"/trainings/{tid}" and str(START + timedelta(days=12)) in n[0]["body"]
    link = lambda v: client.patch(f"/api/v1/trainings/{tid}/details", headers=ta, json={"meeting_link": v})
    link("https://meet.example.com/secret-room"); link("https://meet.example.com/secret-room")          # the repeat changes nothing
    link("https://meet.example.com/other-room"); link(None)
    titles = [n["title"] for n in reversed(of_type(client, ih, "TRAINING_LINK_CHANGED"))]
    assert titles == ["Meeting link added", "Meeting link updated", "Meeting link removed"]
    assert "meet.example.com" not in str(of_type(client, ih, "TRAINING_LINK_CHANGED"))                   # the link itself is never in a notification


def test_completion_notifies_and_asks_for_reviews(client):
    ta, tb, tc, ih, rid, aid = world(client)
    hid, tid = fill(client, ih, ta, aid["a"])
    begin(client, tid)
    client.post(f"/api/v1/trainings/{tid}/complete", headers=ih)
    assert len(of_type(client, ta, "TRAINING_COMPLETED")) == 1
    assert len(of_type(client, ta, "REVIEW_REQUEST")) == 1 and len(of_type(client, ih, "REVIEW_REQUEST")) == 1
    r = client.post(f"/api/v1/trainings/{tid}/reviews", headers=ih, json={"ratings": TRAINER_RATINGS, "comment": None})
    assert r.status_code == 201
    n = of_type(client, ta, "REVIEW_RECEIVED")
    assert len(n) == 1 and n[0]["title"] == "You received a new review" and n[0]["link"] == f"/trainings/{tid}"


# ---------- sessions: scheduled / rescheduled / cancelled notify, internal changes stay quiet ----------
def test_session_events_and_quiet_changes(client):
    ta, tb, tc, ih, rid, aid = world(client)
    hid, tid = fill(client, ih, ta, aid["a"])
    sid = session(client, ta, tid).json()["data"]["id"]
    assert len(of_type(client, ih, "SESSION_SCHEDULED")) == 1
    client.patch(f"/api/v1/sessions/{sid}", headers=ih, json={"session_date": str(START + timedelta(days=1))})
    assert len(of_type(client, ta, "SESSION_RESCHEDULED")) == 1
    set_status(client, ta, sid, "CANCELLED")
    assert len(of_type(client, ih, "SESSION_CANCELLED")) == 1
    quiet = held_session(client, ta, tid, title="Held")
    baseline = len(inbox(client, ih)) + len(inbox(client, ta))
    attend(client, ta, quiet)
    client.put(f"/api/v1/sessions/{quiet}/notes", headers=ta, json={"notes": "Went well"})
    set_status(client, ta, quiet, "COMPLETED")
    assert len(inbox(client, ih)) + len(inbox(client, ta)) == baseline                                   # attendance, notes, completion: no noise


# ---------- reminders ----------
def test_day_before_reminders_are_created_once(client):
    ta, tb, tc, ih, rid, aid = world(client)
    hid, tid = fill(client, ih, ta, aid["a"])
    session(client, ta, tid)
    db = db_of(client)
    day_before = START - timedelta(days=1)
    assert send_reminders(db, today=day_before, kinds=("day_before",)) == 4          # a session and a training start, for both parties
    assert send_reminders(db, today=day_before, kinds=("day_before",)) == 0
    assert len(of_type(client, ta, "SESSION_REMINDER")) == 1 and len(of_type(client, ih, "TRAINING_REMINDER")) == 1


def test_interview_reminders_use_interview_at_and_are_idempotent(client):
    ta, tb, tc, ih, rid, aid = world(client)
    at = datetime.combine(today() + timedelta(days=1), time(10, 0))
    move(client, ih, aid["b"], "INTERVIEW", interview_at=at.isoformat())
    db = db_of(client)
    assert send_reminders(db, kinds=("interview",), now=at - timedelta(hours=30)) == 0   # too early: outside the 24 hour window
    assert send_reminders(db, kinds=("interview",), now=at + timedelta(minutes=1)) == 0  # already started
    assert send_reminders(db, kinds=("interview",), now=at - timedelta(hours=3)) == 2    # both parties
    assert send_reminders(db, kinds=("interview",), now=at - timedelta(hours=2)) == 0    # idempotent
    mine = of_type(client, tb, "INTERVIEW_REMINDER")
    assert len(mine) == 1 and mine[0]["link"] == "/trainer/applications" and "10:00" in mine[0]["body"]
    assert of_type(client, ih, "INTERVIEW_REMINDER")[0]["link"] == f"/institution/requirements/{rid}/applications"
    later = datetime.combine(today() + timedelta(days=2), time(15, 0))                   # rescheduled: a new key, so a new reminder
    move(client, ih, aid["b"], "INTERVIEW", interview_at=later.isoformat())
    assert send_reminders(db, kinds=("interview",), now=later - timedelta(hours=1)) == 2
    move(client, ih, aid["b"], "REJECTED")
    assert send_reminders(db, kinds=("interview",), now=later - timedelta(minutes=30)) == 0   # no reminder for a rejected application


# ---------- the registry is the single source of truth ----------
def _service_trees():
    root = Path(__file__).resolve().parents[1] / "app"
    return [ast.parse(f.read_text()) for f in list((root / "services").glob("*.py")) + list((root / "workers").glob("*.py")) if f.name != "notification_types.py"]


def test_no_registered_type_is_dead_and_no_emitted_type_is_unregistered():
    literals, called = set(), set()
    for tree in _service_trees():
        for n in ast.walk(tree):
            if isinstance(n, ast.Constant) and isinstance(n.value, str):
                literals.add(n.value)
            if isinstance(n, ast.Call) and getattr(n.func, "id", getattr(n.func, "attr", "")) in ("notify_event", "notify_event_safe", "_tell_other", "notify_waiting_applicants"):
                called |= {a.value for a in n.args if isinstance(a, ast.Constant) and isinstance(a.value, str) and re.fullmatch(r"[A-Z]+(_[A-Z]+)+", a.value)}
    assert set(TYPES) <= literals, f"registered but never emitted: {sorted(set(TYPES) - literals)}"
    assert called <= set(TYPES), f"emitted but not registered: {sorted(called - set(TYPES))}"
    status_mapped = {l for l in literals if re.fullmatch(r"(APPLICATION|INTERVIEW)_[A-Z]+", l)}
    assert status_mapped <= set(TYPES), f"status-mapped types not registered: {sorted(status_mapped - set(TYPES))}"


def test_every_deep_link_points_at_a_real_react_route():
    app_jsx = (Path(__file__).resolve().parents[2] / "frontend/src/App.jsx").read_text()
    routes = {re.sub(r":\w+", "{}", p) for p in re.findall(r'path="([^"*]+)"', app_jsx)}
    for spec in TYPES.values():
        if spec.link:
            assert re.sub(r"\{[^}]*\}", "{}", spec.link) in routes, f"{spec.key} links to {spec.link}, which is not a route"


def test_registry_renders_every_type_and_rejects_unknown_ones():
    ctx = dict(trainer="T", requirement="R", requirement_id=1, institution="I", when="soon", training_id=2, title="X", start="a", end="b", action="added",
               reason="", session="S", time="10:00", score=4.5, amount="₹1,000")
    for key in TYPES:
        r = notification_types.render(key, **ctx)
        assert r["title"] and (r["link"] or "").startswith("/")
    import pytest
    with pytest.raises(ValueError):
        notification_types.render("NOT_A_TYPE")
