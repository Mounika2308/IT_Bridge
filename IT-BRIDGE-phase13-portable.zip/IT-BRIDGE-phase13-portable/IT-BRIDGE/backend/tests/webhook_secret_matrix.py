"""One definition of the production webhook-secret matrix (13B.2), shared by the rule tests, the guard tests, the child-process start-up tests and the
webhook API tests, so they cannot drift apart. Standard library only.

Decision under test: ENVIRONMENT=production refuses to start if PAYMENT_WEBHOOK_SECRET is missing, empty, weak or a known example value, whether or
not PAYMENTS_ENABLED is on. Development and test accept any secret, including none (the sandbox then answers 503 on its webhook). The webhook request
handler applies the same test to the secret as defence in depth.
"""
from itertools import product
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def _example_secret() -> str:
    """The exact value shipped in .env.example, so a change to the file changes the test."""
    for line in (ROOT / ".env.example").read_text().splitlines():
        if line.startswith("PAYMENT_WEBHOOK_SECRET="):
            return line.split("=", 1)[1].strip()
    raise AssertionError(".env.example has no PAYMENT_WEBHOOK_SECRET line")


EXAMPLE_SECRET = _example_secret()
STRONG_SECRET = "Kq7vR2mZp9sT4wB8nC3dF6hJ1LaE5gY0xxxx"
SUITE_SECRET = "test-only-webhook-secret-for-the-pytest-suite-0123456789"      # what tests/conftest.py uses

ENVIRONMENTS = ("production", "development", "test")
PAYMENTS = (True, False)
SECRETS = {"missing": None, "empty": "", "weak": "change_me", "example": EXAMPLE_SECRET, "valid": STRONG_SECRET}
CASES = [(env, enabled, kind) for env, enabled, kind in product(ENVIRONMENTS, PAYMENTS, SECRETS)]


def case_id(case) -> str:
    env, enabled, kind = case
    return f"{env}-payments_{'on' if enabled else 'off'}-secret_{kind}"


def env_vars(env: str, enabled: bool, kind: str) -> dict:
    """Environment variables for one matrix cell (None = unset). Payments enabled use the only combination that can be safe: the sandbox with its
    opt-in in development/test; in production an implemented-looking provider and a confirmed commission, so the secret is the only variable under test
    (production with payments enabled can still never start while no real provider exists)."""
    e = {"ENVIRONMENT": env, "PAYMENTS_ENABLED": "true" if enabled else "false", "PAYMENT_WEBHOOK_SECRET": SECRETS[kind]}
    if enabled and env == "production":
        e.update(PAYMENT_PROVIDER="somegateway", PAYMENT_COMMISSION_CONFIRMED="true")
    elif enabled:
        e.update(PAYMENT_PROVIDER="sandbox", PAYMENT_SANDBOX_ENABLED="true")
    return e


def startup(env: str, enabled: bool, kind: str):
    """-> (starts, text the refusal must contain, text it must NOT contain)."""
    if env != "production":
        return True, None, None
    if kind in ("missing", "empty"):
        return False, "PAYMENT_WEBHOOK_SECRET is missing or empty", None
    if kind in ("weak", "example"):
        return False, "PAYMENT_WEBHOOK_SECRET is weak or a known example value", None
    if enabled:
        return False, "PAYMENT_PROVIDER", "PAYMENT_WEBHOOK_SECRET"       # a strong secret, but a real-money provider does not exist yet
    return True, None, None


def webhook_accepts(env: str, kind: str) -> bool:
    """Does the request handler authenticate deliveries with this secret? Independent of PAYMENTS_ENABLED."""
    if kind in ("missing", "empty"):
        return False
    return env != "production" or kind == "valid"
