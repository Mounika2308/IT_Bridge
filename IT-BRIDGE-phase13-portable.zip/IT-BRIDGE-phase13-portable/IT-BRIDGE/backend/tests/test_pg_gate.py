"""The safety rules of tests/pg.py, which sits in front of `DROP SCHEMA public CASCADE`. Standard library + pytest only: no database, no SQLAlchemy
(a fake `sqlalchemy.text` and a fake engine record what would be executed).

What this proves: which URLs and environments are refused, that the server-side guard is the FIRST statement of every transaction that does anything
destructive, and that when the guard raises nothing else runs.
What it does NOT prove: that a real PostgreSQL server raises from the guard (that was exercised by hand with psql against throw-away clusters, see the
Phase 13 handoff), or that SQLAlchemy builds the engine as assumed. Those need the PostgreSQL test files themselves.
"""
import sys
import types
from unittest import mock

import pytest

from tests import pg

PORT = 55432
GOOD = f"postgresql://postgres@127.0.0.1:{PORT}/itbridge_test"

REFUSED_URLS = [
    # a query string would override host/port/dbname/hostaddr/service/options inside SQLAlchemy/psycopg2
    GOOD + "?host=10.9.9.9", GOOD + "?port=5432", GOOD + "?dbname=itbridge", GOOD + "?hostaddr=10.9.9.9", GOOD + "?service=prod", GOOD + "?options=-csearch_path%3Dx",
    GOOD + "?", GOOD + "#x", GOOD + ";x=1",
    # hosts and aliases
    f"postgresql://postgres@localhost:{PORT}/itbridge_test", f"postgresql://postgres@LOCALHOST:{PORT}/itbridge_test", f"postgresql://postgres@127.0.0.2:{PORT}/itbridge_test",
    f"postgresql://postgres@127.1:{PORT}/itbridge_test", f"postgresql://postgres@0x7f.0.0.1:{PORT}/itbridge_test", f"postgresql://postgres@2130706433:{PORT}/itbridge_test",
    f"postgresql://postgres@0.0.0.0:{PORT}/itbridge_test", f"postgresql://postgres@[::ffff:127.0.0.1]:{PORT}/itbridge_test",
    f"postgresql://postgres@[0:0:0:0:0:0:0:1]:{PORT}/itbridge_test", f"postgresql://postgres@::1:{PORT}/itbridge_test", f"postgresql://postgres@127.0.0.1.:{PORT}/itbridge_test",
    f"postgresql://postgres@127.0.0.1.evil.example:{PORT}/itbridge_test", f"postgresql://postgres@db.internal:{PORT}/itbridge_test", f"postgresql://postgres@10.0.0.5:{PORT}/itbridge_test",
    f"postgresql://postgres@%2Fvar%2Frun%2Fpostgresql:{PORT}/itbridge_test", f"postgresql://postgres@127.0.0.1:{PORT},10.9.9.9:5432/itbridge_test",
    # userinfo and encoding
    f"postgresql://postgres:x@10.9.9.9:{PORT}@127.0.0.1:{PORT}/itbridge_test", f"postgresql://127.0.0.1:{PORT}@10.9.9.9:{PORT}/itbridge_test",
    f"postgresql://postgres:p@ss@127.0.0.1:{PORT}/itbridge_test", f"postgresql://postgres%40x@127.0.0.1:{PORT}/itbridge_test", f"postgresql://post%67res@127.0.0.1:{PORT}/itbridge_test",
    f"postgresql://127.0.0.1:{PORT}/itbridge_test",
    # ports
    "postgresql://postgres@127.0.0.1/itbridge_test", "postgresql://postgres@127.0.0.1:5432/itbridge_test", "postgresql://postgres@127.0.0.1:0/itbridge_test",
    "postgresql://postgres@127.0.0.1:1023/itbridge_test", "postgresql://postgres@127.0.0.1:65536/itbridge_test", "postgresql://postgres@127.0.0.1:99999/itbridge_test",
    f"postgresql://postgres@127.0.0.1:0{PORT}/itbridge_test", f"postgresql://postgres@127.0.0.1:+{PORT}/itbridge_test", f"postgresql://postgres@127.0.0.1:{PORT}.0/itbridge_test",
    "postgresql://postgres@127.0.0.1:５５４３２/itbridge_test", f"postgresql://postgres@127.0.0.1:{PORT}:5432/itbridge_test",
    # database names: only "contains test" is NOT a defence; these have none, or are not a plain name
    f"postgresql://postgres@127.0.0.1:{PORT}", f"postgresql://postgres@127.0.0.1:{PORT}/", f"postgresql://postgres@127.0.0.1:{PORT}/itbridge",
    f"postgresql://postgres@127.0.0.1:{PORT}/postgres", f"postgresql://postgres@127.0.0.1:{PORT}/ITBRIDGE_TEST", f"postgresql://postgres@127.0.0.1:{PORT}/itbridge%5ftest",
    f"postgresql://postgres@127.0.0.1:{PORT}/itbridge_test%00", f"postgresql://postgres@127.0.0.1:{PORT}/itbridge_test/extra", f"postgresql://postgres@127.0.0.1:{PORT}//itbridge_test",
    f'postgresql://postgres@127.0.0.1:{PORT}/"itbridge_test"', f"postgresql://postgres@127.0.0.1:{PORT}/itbridge_test;DROP", f"postgresql://postgres@127.0.0.1:{PORT}/itbridge_test x",
    f"postgresql://test@127.0.0.1:{PORT}/itbridge", f"postgresql://postgres:test@127.0.0.1:{PORT}/itbridge", f"postgresql://postgres@127.0.0.1:{PORT}/itbridge?application_name=test",
    # the project's own dev default
    "postgresql+psycopg2://itbridge:change_me@localhost:5432/itbridge",
    # schemes, whitespace, other shapes
    f"postgres://postgres@127.0.0.1:{PORT}/itbridge_test", f"postgresql+asyncpg://postgres@127.0.0.1:{PORT}/itbridge_test", f"POSTGRESQL://postgres@127.0.0.1:{PORT}/itbridge_test",
    "sqlite:///itbridge_test.db", " " + GOOD, GOOD + " ", GOOD + "\n", GOOD + "\nhost=10.9.9.9", "", "host=10.9.9.9 port=5432 dbname=itbridge_test",
]

ACCEPTED_URLS = [GOOD, f"postgresql+psycopg2://itb_user:pw-1.x~_@127.0.0.1:{PORT}/itbridge_test", f"postgresql://postgres@[::1]:{PORT}/itbridge_test",
                 f"postgresql://postgres@127.0.0.1:{PORT}/contest"]       # accepted by the GRAMMAR only: the marker decides on the server


@pytest.mark.parametrize("url", REFUSED_URLS)
def test_url_is_refused(url):
    with pytest.raises(ValueError):
        pg.parse_url(url)


@pytest.mark.parametrize("url", ACCEPTED_URLS)
def test_url_grammar_accepts_the_prepared_shape(url):
    c = pg.parse_url(url)
    assert c["host"] in ("127.0.0.1", "::1") and c["port"] == PORT and "test" in c["db"]


def test_non_string_is_refused():
    for bad in (None, 5, b"postgresql://postgres@127.0.0.1:55432/itbridge_test", ["x"]):
        with pytest.raises(ValueError):
            pg.parse_url(bad)


@pytest.mark.parametrize("name", ["PGHOST", "PGHOSTADDR", "PGPORT", "PGDATABASE", "PGUSER", "PGSERVICE", "PGSERVICEFILE", "PGSYSCONFDIR", "PGOPTIONS", "PGPASSFILE",
                                  "PGSSLMODE", "PGTARGETSESSIONATTRS", "PGCONNECT_TIMEOUT"])
def test_libpq_environment_variables_are_refused(name):
    assert pg.environment_problems({name: "x"}) == [f"{name} is set"]


def test_pgpassword_alone_is_accepted_and_unrelated_variables_are_ignored():
    assert pg.environment_problems({"PGPASSWORD": "x", "PATH": "/usr/bin", "DATABASE_URL": "sqlite://", "HOME": "/root"}) == []


def test_require_postgres_skips_without_the_variable_and_fails_on_a_bad_one():
    with mock.patch.object(pg, "URL", ""):
        with pytest.raises(pg.pytest.skip.Exception):
            pg.require_postgres()
    for bad in ("postgresql://itbridge:itbridge@localhost:5432/itbridge_test", GOOD + "?host=10.9.9.9", "sqlite://"):
        with mock.patch.object(pg, "URL", bad):
            with pytest.raises(pg.pytest.fail.Exception):
                pg.require_postgres()
    with mock.patch.object(pg, "URL", GOOD), mock.patch.dict("os.environ", {"PGHOSTADDR": "10.9.9.9"}):
        with pytest.raises(pg.pytest.fail.Exception):
            pg.require_postgres()
    with mock.patch.object(pg, "URL", GOOD), mock.patch.dict("os.environ", {}, clear=True):
        assert pg.require_postgres() == GOOD


def test_guard_sql_states_every_rule_and_quotes_only_a_checked_name():
    sql = pg.guard_sql("itbridge_test")
    for needle in ("current_database() <> 'itbridge_test'", "160000 AND 169999", "pg_is_in_recovery()", pg.MARKER, "datistemplate", "'postgres'"):
        assert needle in sql
    assert sql.count("RAISE EXCEPTION") == 5 and sql.startswith("DO $itbguard$") and sql.endswith("END $itbguard$")


# ---- wipe(): what is executed, in which order, on which engine ----
class Conn:
    def __init__(self, log, fail_on_guard):
        self.log, self.fail_on_guard = log, fail_on_guard

    def execute(self, clause):
        sql = str(clause)
        self.log.append(sql)
        if sql.startswith("DO $itbguard$") and self.fail_on_guard:
            raise RuntimeError("itb gate: simulated refusal by the server")


class Engine:
    def __init__(self, url=GOOD, fail_on_guard=False):
        from urllib.parse import urlsplit
        u = urlsplit(url.replace("+psycopg2", ""))
        self.url = types.SimpleNamespace(host=(u.hostname or ""), port=u.port, database=u.path.lstrip("/"), query={}, drivername="postgresql+psycopg2")
        self.log, self.fail_on_guard, self.transactions = [], fail_on_guard, []

    def begin(self):
        engine = self

        class Tx:
            def __enter__(self):
                engine.transactions.append([])
                return TxConn()

            def __exit__(self, *exc):
                return False

        class TxConn(Conn):
            def __init__(self):
                super().__init__(engine.transactions[-1], engine.fail_on_guard)
        return Tx()


def fake_sqlalchemy():
    return mock.patch.dict(sys.modules, {"sqlalchemy": types.SimpleNamespace(text=lambda s: s)})


def test_every_destructive_transaction_starts_with_the_guard():
    e = Engine()
    with fake_sqlalchemy(), mock.patch.object(pg, "URL", GOOD), mock.patch.dict("os.environ", {}, clear=True):
        pg.wipe(e)
    assert len(e.transactions) == 2
    for tx in e.transactions:
        assert tx[0].startswith("DO $itbguard$") and "'itbridge_test'" in tx[0] and len(tx) > 1
    assert e.transactions[0][1].startswith("SELECT pg_terminate_backend")
    assert e.transactions[1][1:] == ["DROP SCHEMA public CASCADE", "CREATE SCHEMA public"]


def test_a_guard_that_raises_stops_everything_after_it():
    e = Engine(fail_on_guard=True)
    with fake_sqlalchemy(), mock.patch.object(pg, "URL", GOOD), mock.patch.dict("os.environ", {}, clear=True):
        with pytest.raises(RuntimeError, match="itb gate"):
            pg.wipe(e)
    assert len(e.transactions) == 1 and len(e.transactions[0]) == 1          # nothing but the guard was sent; no terminate, no DROP


@pytest.mark.parametrize("engine_url", [f"postgresql://postgres@127.0.0.1:{PORT + 1}/itbridge_test", f"postgresql://postgres@127.0.0.1:{PORT}/itbridge_other_test",
                                        f"postgresql://postgres@10.9.9.9:{PORT}/itbridge_test", f"postgresql://postgres@localhost:{PORT}/itbridge_test"])
def test_an_engine_that_is_not_the_validated_url_is_refused_before_any_sql(engine_url):
    e = Engine(url=engine_url)
    with fake_sqlalchemy(), mock.patch.object(pg, "URL", GOOD), mock.patch.dict("os.environ", {}, clear=True):
        with pytest.raises(pg.Refused):
            pg.wipe(e)
    assert e.transactions == []


def test_an_engine_with_query_items_is_refused_before_any_sql():
    e = Engine()
    e.url.query = {"host": "10.9.9.9"}
    with fake_sqlalchemy(), mock.patch.object(pg, "URL", GOOD), mock.patch.dict("os.environ", {}, clear=True):
        with pytest.raises(pg.Refused):
            pg.wipe(e)
    assert e.transactions == []


def test_a_redirecting_environment_stops_wipe_before_any_sql():
    e = Engine()
    with fake_sqlalchemy(), mock.patch.object(pg, "URL", GOOD), mock.patch.dict("os.environ", {"PGHOSTADDR": "10.9.9.9"}, clear=True):
        with pytest.raises(pg.Refused):
            pg.wipe(e)
    assert e.transactions == []
