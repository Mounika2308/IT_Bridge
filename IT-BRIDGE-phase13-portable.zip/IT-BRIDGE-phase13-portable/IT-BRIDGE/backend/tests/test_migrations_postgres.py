"""Alembic against a REAL PostgreSQL 16 database: upgrade to head, model/migration drift, the financial triggers, the downgrade guards, downgrade to
base and a second upgrade. SKIPPED unless ITB_TEST_DATABASE_URL is set (see tests/pg.py). Not executed in the environment where it was written:
no SQLAlchemy, Alembic or PostgreSQL driver could be installed there (the psql-driven scripts/verify_postgres_sql.py is a separate, weaker check:
it exercises the SQL, not Alembic)."""
import importlib.util

import pytest
from alembic import command
from alembic.autogenerate import compare_metadata
from alembic.config import Config
from alembic.migration import MigrationContext
from sqlalchemy import create_engine, inspect, text

import app.models  # noqa: F401
from app.core.config import settings
from app.core.database import Base
from tests import pg
from tests.test_migrations import BACKEND

DESTROY = "I_UNDERSTAND_DATA_WILL_BE_DESTROYED"
TRIGGERS = {"trg_invoices_immutable", "trg_payment_transactions_immutable", "trg_payments_identity", "trg_invoices_check", "trg_trainer_earnings_check",
            "trg_platform_commissions_check", "trg_payment_refunds_check", "trg_payment_transactions_check"}


@pytest.fixture()
def migrated(monkeypatch):
    url = pg.require_postgres()
    engine = create_engine(url)
    pg.wipe(engine)
    original = settings.database_url
    settings.database_url = url                      # alembic/env.py reads settings.database_url
    cfg = Config()
    cfg.set_main_option("script_location", str(BACKEND / "alembic"))
    monkeypatch.delenv("ITB_ALLOW_FINANCIAL_DOWNGRADE", raising=False)
    yield engine, cfg
    settings.database_url = original
    engine.dispose()


def _migration_0007():
    spec = importlib.util.spec_from_file_location("migration_0007", BACKEND / "alembic" / "versions" / "0007_financial_integrity_triggers.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


_SNAPSHOT_QUERIES = {
    "tables": "SELECT tablename FROM pg_tables WHERE schemaname = 'public' ORDER BY 1",
    "columns": "SELECT table_name, column_name, data_type, is_nullable, column_default FROM information_schema.columns WHERE table_schema = 'public' ORDER BY 1, 2",
    "indexes": "SELECT indexname, indexdef FROM pg_indexes WHERE schemaname = 'public' ORDER BY 1",
    "constraints": "SELECT conrelid::regclass::text, conname, pg_get_constraintdef(oid) FROM pg_constraint WHERE connamespace = 'public'::regnamespace ORDER BY 1, 2",
    "triggers": "SELECT tgrelid::regclass::text, tgname, pg_get_triggerdef(oid) FROM pg_trigger WHERE NOT tgisinternal ORDER BY 1, 2",
    "functions": "SELECT proname, md5(prosrc) FROM pg_proc WHERE pronamespace = 'public'::regnamespace ORDER BY 1",
    "revision": "SELECT version_num FROM alembic_version",
}


def _snapshot(engine) -> dict:
    """Every table, column, index, constraint, trigger and function in the public schema (definitions included) plus the Alembic revision. Two equal
    snapshots mean the schema is exactly as it was: nothing from ANY migration was dropped, added or altered."""
    with engine.connect() as c:
        return {name: [tuple(r) for r in c.execute(text(q))] for name, q in _SNAPSHOT_QUERIES.items()}


def _triggers(engine):
    with engine.connect() as c:
        return {r[0] for r in c.execute(text("SELECT tgname FROM pg_trigger WHERE NOT tgisinternal"))}


def test_upgrade_head_matches_the_models_and_installs_the_triggers(migrated):
    engine, cfg = migrated
    command.upgrade(cfg, "head")
    assert set(Base.metadata.tables) <= set(inspect(engine).get_table_names())
    with engine.connect() as conn:
        diff = compare_metadata(MigrationContext.configure(conn), Base.metadata)
    assert diff == [], f"models and migrations disagree: {diff}"
    assert TRIGGERS <= _triggers(engine)


def test_the_downgrade_refuses_to_discard_financial_records_and_changes_nothing(migrated, monkeypatch):
    """`downgrade 0004` would run 0007's downgrade (drops every trigger and function), then 0006's (drops payment_review_flags and its indexes), then 0005's
    (the financial tables). Since the whole-path pre-flight (app/core/migration_guard.py) the run is refused before 0007 executes, because a financial table
    holds a row; and even if a later guard refused, Alembic on PostgreSQL runs the whole command in ONE transaction (alembic/env.py: a single
    context.begin_transaction(), PostgresqlImpl.transactional_ddl) so the earlier work would be rolled back. This test proves the end result against the real
    database by comparing a full schema snapshot before and after (it cannot tell the pre-flight from the rollback; the SQLite test in test_migrations.py,
    where DDL is not rolled back, can), and then names the objects that matter."""
    engine, cfg = migrated
    command.upgrade(cfg, "head")
    with engine.begin() as c:                         # the smallest financial row: an invoice counter (a 0005 table)
        c.execute(text("INSERT INTO invoice_counters (series, year, last_number) VALUES ('INV', 2099, 1)"))
    before = _snapshot(engine)
    assert before["revision"] == [("0007",)]
    assert "payment_review_flags" in {t for (t,) in before["tables"]} and TRIGGERS <= {t for (_, t, _) in before["triggers"]}    # the starting point is complete

    with pytest.raises(Exception) as err:
        command.downgrade(cfg, "0004")
    assert "Refusing to downgrade" in str(err.value) or "Refusing to downgrade" in repr(err.value.__cause__)

    # 1. the whole schema is exactly as before: no table, column, index, constraint, trigger or function from any migration was removed or altered
    after = _snapshot(engine)
    for kind in before:
        assert after[kind] == before[kind], f"{kind} changed after a REFUSED downgrade: {set(before[kind]) ^ set(after[kind])}"
    # 2. and, named explicitly: every model table (the financial ones and payment_review_flags included), the revision, the 0007 triggers and functions
    names = set(inspect(engine).get_table_names())
    assert set(Base.metadata.tables) <= names
    for financial in ("payments", "payment_transactions", "payment_webhook_events", "invoices", "invoice_counters", "payment_refunds", "trainer_earnings",
                      "platform_commissions", "payment_review_flags"):
        assert financial in names, financial
    assert TRIGGERS <= _triggers(engine)
    mod = _migration_0007()
    with engine.connect() as c:
        functions = {r[0] for r in c.execute(text("SELECT proname FROM pg_proc WHERE proname LIKE 'itb\\_%'"))}
        assert set(mod.FUNCTION_NAMES) <= functions
        assert {r[0] for r in c.execute(text("SELECT indexname FROM pg_indexes WHERE schemaname = 'public'"))} >= {"uq_review_flag_open", "uq_payment_one_in_flight"}
        assert MigrationContext.configure(c).get_current_revision() == "0007"
        assert c.execute(text("SELECT COUNT(*) FROM invoice_counters")).scalar() == 1
    # 3. installed is not the same as active: every 0007 trigger is still ENABLED ('O' = fires in the normal session role)
    with engine.connect() as c:
        enabled = dict(c.execute(text("SELECT tgname, tgenabled FROM pg_trigger WHERE NOT tgisinternal")).all())
    assert {name: enabled[name] for name in TRIGGERS} == {name: "O" for name in TRIGGERS}
    # 4. only with the explicit switch does the downgrade proceed
    monkeypatch.setenv("ITB_ALLOW_FINANCIAL_DOWNGRADE", DESTROY)
    command.downgrade(cfg, "0004")
    assert "payments" not in inspect(engine).get_table_names()


def test_downgrade_to_base_then_upgrade_again_on_an_empty_database(migrated):
    engine, cfg = migrated
    command.upgrade(cfg, "head")
    command.downgrade(cfg, "base")
    assert not (set(Base.metadata.tables) & set(inspect(engine).get_table_names()))
    assert not _triggers(engine)
    with engine.connect() as c:
        assert c.execute(text("SELECT COUNT(*) FROM pg_proc WHERE proname LIKE 'itb\\_%'")).scalar() == 0
    command.upgrade(cfg, "head")
    assert TRIGGERS <= _triggers(engine)


def test_0007_alone_can_be_reverted_without_touching_any_data(migrated):
    engine, cfg = migrated
    command.upgrade(cfg, "head")
    with engine.begin() as c:
        c.execute(text("INSERT INTO invoice_counters (series, year, last_number) VALUES ('INV', 2099, 1)"))
    command.downgrade(cfg, "0006")                    # drops triggers and functions only: no guard, no data loss
    assert not (TRIGGERS & _triggers(engine))
    with engine.connect() as c:
        assert c.execute(text("SELECT COUNT(*) FROM invoice_counters")).scalar() == 1
    command.upgrade(cfg, "head")
    assert TRIGGERS <= _triggers(engine)


_USER = ("INSERT INTO users (email, password_hash, full_name, role, is_active, email_verified, created_at) "
         "VALUES ('a@example.com', 'x', 'A', 'TRAINER', true, true, now())")
_PREFERENCE = "INSERT INTO notification_preferences (user_id, channel, enabled, updated_at) SELECT id, 'EMAIL', false, now() FROM users"


@pytest.mark.parametrize("inserts,target,named", [
    ([_USER, _PREFERENCE], "0003", "0004: notification_preferences 1 rows"),      # 0004's tables used to be dropped without any guard
    ([_USER], "base", "0001: users 1 rows"),                                        # the refusal that used to come last, after 0007 .. 0002 had run
])
def test_the_downgrade_refuses_to_discard_notification_and_core_data_and_changes_nothing(migrated, monkeypatch, inserts, target, named):
    engine, cfg = migrated
    command.upgrade(cfg, "head")
    with engine.begin() as c:
        for sql in inserts:
            c.execute(text(sql))
    before = _snapshot(engine)
    with pytest.raises(Exception) as err:
        command.downgrade(cfg, target)
    assert named in str(err.value) or named in repr(err.value.__cause__)
    after = _snapshot(engine)
    for kind in before:
        assert after[kind] == before[kind], f"{kind} changed after a REFUSED downgrade"
    with engine.connect() as c:
        assert c.execute(text("SELECT COUNT(*) FROM users")).scalar() == 1
    monkeypatch.setenv("ITB_ALLOW_FINANCIAL_DOWNGRADE", DESTROY)                   # only the explicit switch lets it through, and then it removes what it said
    command.downgrade(cfg, target)
    names = set(inspect(engine).get_table_names())
    assert "notification_preferences" not in names and (target == "base") == ("users" not in names)


@pytest.mark.parametrize("target,expected_revision", [("-1", "0006"), ("0006", "0006"), ("0005", "0005")])
def test_a_downgrade_that_removes_no_data_is_not_refused_on_postgres_because_of_data_in_lower_revisions(migrated, target, expected_revision):
    """The SQLite twin (tests/test_migrations.py) shows what real Alembic hands the guard for `-1` and for a named revision; this is the same on PostgreSQL, the
    database that matters. A user and a notification preference are held (0001 and 0004 tables), but these runs only remove 0007 (triggers and functions) and
    0006 (an empty table), so they must run, keep every row, and leave the database at the expected revision with the 0007 triggers gone (and 0006's empty table gone only for 0005)."""
    engine, cfg = migrated
    command.upgrade(cfg, "head")
    with engine.begin() as c:
        c.execute(text(_USER))
        c.execute(text(_PREFERENCE))
    command.downgrade(cfg, target)
    with engine.connect() as c:
        assert MigrationContext.configure(c).get_current_revision() == expected_revision
        assert c.execute(text("SELECT COUNT(*) FROM users")).scalar() == 1
        assert c.execute(text("SELECT COUNT(*) FROM notification_preferences")).scalar() == 1
    assert not (TRIGGERS & _triggers(engine))
    assert ("payment_review_flags" in inspect(engine).get_table_names()) == (expected_revision == "0006")     # 0006 stays for -1 / 0006, goes for 0005
