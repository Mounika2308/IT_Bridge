from datetime import timedelta

from app.core.clock import today
from app.core.database import get_db
from app.main import app
from app.models.user import Skill

D = today()
INST = {"full_name": "Ravi K", "email": "ravi@example.com", "password": "Passw0rd123", "role": "INSTITUTION", "institution_name": "Sunrise College"}
INST2 = {**INST, "email": "other@example.com", "institution_name": "Other College"}
TRAINER = {"full_name": "Asha Rao", "email": "asha@example.com", "password": "Passw0rd123", "role": "TRAINER"}


def hdr(client, body):
    d = client.post("/api/v1/auth/register", json=body).json()["data"]
    return {"Authorization": f"Bearer {d['access_token']}"}


def seed(client):
    db = next(app.dependency_overrides[get_db]())
    db.add_all([Skill(name="Python"), Skill(name="React")])
    db.commit()


def payload(**kw):
    base = dict(title="Python workshop for 3rd years", technology="Python", description="x" * 40, skill_ids=[1],
                student_count=60, student_level="BEGINNER", duration_days=10, sessions=10, location="Pune", mode="OFFLINE",
                start_date=str(D + timedelta(days=30)), end_date=str(D + timedelta(days=40)),
                budget_min=20000, budget_max=40000, application_deadline=str(D + timedelta(days=20)))
    base.update(kw)
    return base


def test_create_and_browse(client):
    seed(client)
    ih, th = hdr(client, INST), hdr(client, TRAINER)
    r = client.post("/api/v1/requirements", headers=ih, json=payload())
    assert r.status_code == 201 and r.json()["data"]["status"] == "OPEN"
    browse = client.get("/api/v1/requirements?q=python&mode=OFFLINE", headers=th).json()["data"]
    assert browse["total"] == 1 and browse["items"][0]["is_owner"] is False
    assert client.get("/api/v1/requirements?mode=ONLINE", headers=th).json()["data"]["total"] == 0


def test_trainer_cannot_post(client):
    seed(client)
    assert client.post("/api/v1/requirements", headers=hdr(client, TRAINER), json=payload()).status_code == 403


def test_validation_rules(client):
    seed(client)
    ih = hdr(client, INST)
    bad_dates = payload(end_date=str(D + timedelta(days=5)))
    assert client.post("/api/v1/requirements", headers=ih, json=bad_dates).status_code == 422
    late_deadline = payload(application_deadline=str(D + timedelta(days=35)))
    assert client.post("/api/v1/requirements", headers=ih, json=late_deadline).status_code == 422
    assert client.post("/api/v1/requirements", headers=ih, json=payload(budget_max=100)).status_code == 422
    assert client.post("/api/v1/requirements", headers=ih, json=payload(skill_ids=[])).status_code == 422
    assert client.post("/api/v1/requirements", headers=ih, json=payload(skill_ids=[99])).status_code == 422


def test_past_dates_rejected(client):
    seed(client)
    past = payload(start_date=str(D - timedelta(days=2)), end_date=str(D + timedelta(days=3)), application_deadline=str(D - timedelta(days=3)))
    assert client.post("/api/v1/requirements", headers=hdr(client, INST), json=past).status_code == 422


def test_closed_hidden_from_trainers_and_not_editable(client):
    seed(client)
    ih, th = hdr(client, INST), hdr(client, TRAINER)
    rid = client.post("/api/v1/requirements", headers=ih, json=payload()).json()["data"]["id"]
    client.post(f"/api/v1/requirements/{rid}/close", headers=ih)
    assert client.get("/api/v1/requirements", headers=th).json()["data"]["total"] == 0
    assert client.get(f"/api/v1/requirements/{rid}", headers=th).status_code == 404
    assert client.put(f"/api/v1/requirements/{rid}", headers=ih, json=payload()).status_code == 409
    assert client.get(f"/api/v1/requirements/{rid}", headers=ih).json()["data"]["status"] == "CLOSED"


def test_other_institution_cannot_modify(client):
    seed(client)
    ih, other = hdr(client, INST), hdr(client, INST2)
    rid = client.post("/api/v1/requirements", headers=ih, json=payload()).json()["data"]["id"]
    assert client.post(f"/api/v1/requirements/{rid}/close", headers=other).status_code == 404
    assert client.put(f"/api/v1/requirements/{rid}", headers=other, json=payload()).status_code == 404
    assert client.get("/api/v1/requirements/mine", headers=other).json()["data"]["total"] == 0


def test_pagination(client):
    seed(client)
    ih = hdr(client, INST)
    for i in range(3):
        client.post("/api/v1/requirements", headers=ih, json=payload(title=f"Python batch number {i}"))
    d = client.get("/api/v1/requirements/mine?page=2&page_size=2", headers=ih).json()["data"]
    assert d["total"] == 3 and len(d["items"]) == 1
