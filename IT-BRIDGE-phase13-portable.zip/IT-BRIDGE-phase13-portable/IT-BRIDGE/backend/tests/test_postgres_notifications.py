"""A failing notification write is isolated by its SAVEPOINT on a REAL PostgreSQL 16 database (13B.1).

WHY POSTGRESQL, AND WHY THE SQLITE TESTS DO NOT COVER THIS: the SQLite tests in test_payments_phase13.py prove the application logic around
notify_event_safe, but SQLite's savepoint and transaction semantics differ from PostgreSQL's. On PostgreSQL a failed statement ABORTS the whole
transaction ("current transaction is aborted, commands ignored until end of transaction block") unless the work ran inside a SAVEPOINT that is rolled
back. SQLite also does not enforce VARCHAR lengths, so the "value too long" failure used below cannot even happen there. Nothing in this file is
evidence for, or against, any other database.

SKIPPED unless ITB_TEST_DATABASE_URL points at a dedicated, wipeable PostgreSQL test database (tests/pg.py); a skip is never a pass.
STATUS WHEN WRITTEN: NOT RUN. The environment these tests were written in has no SQLAlchemy, FastAPI or PostgreSQL driver and none could be installed.

Two kinds of real database failure are used:
  * 'db'        : tests.test_payments_phase13._break_notifications writes a Notification without its title -> PostgreSQL NOT NULL violation (23502)
  * long dedupe : a 500-character dedupe_key for a VARCHAR(120) column -> PostgreSQL "value too long" (22001, a DataError)
Every outcome is read back through a SEPARATE connection, so only data that was really COMMITTED can satisfy an assertion.
"""
import logging

import pytest
from sqlalchemy import text
from sqlalchemy.orm import Session

from app.models.notification import Notification
from app.models.user import User
from app.services import notification_service
from tests.test_payments_phase13 import API, _break_notifications, _failure_logs, admin, finish, paid, refund, sandbox, setup, start
from tests.test_postgres_concurrency import client  # noqa: F401  (the PostgreSQL fixture: wiped schema + 0007 triggers + the real app)
from tests.test_trainings import db_of

LONG_KEY = "k" * 500
PAYMENT_KINDS = ("PAYMENT_SUCCEEDED", "PAYMENT_RECEIVED", "PAYMENT_FAILED", "PAYMENT_REFUNDED", "PAYMENT_NEEDS_REVIEW", "PAYOUT_RECORDED", "EARNING_AVAILABLE")


def engine_of(client):
    s = db_of(client)
    engine = s.get_bind()
    s.close()
    return engine


def scalar(client, sql, **params):
    """Runs on a brand-new connection: sees only committed data."""
    with engine_of(client).connect() as c:
        return c.execute(text(sql), params).scalar()


def payment_notification_count(client):
    return scalar(client, "SELECT count(*) FROM notifications WHERE type = ANY(:kinds)", kinds=list(PAYMENT_KINDS))


def app_session(client):
    return Session(engine_of(client), autoflush=False, expire_on_commit=False)       # same options as app/core/database.py


# ---------------------------------------------------------------- through the real API
@pytest.mark.parametrize("flow", ["settlement", "refund", "payout"])
def test_pg_a_database_error_in_the_notification_write_does_not_undo_the_financial_change(client, monkeypatch, caplog, flow):
    th, ih, tid = setup(client)
    ah = admin(client)
    if flow == "settlement":
        pid = start(client, ih, tid)["id"]
    else:
        pid = paid(client, ih, tid)
        if flow == "payout":
            finish(client, ih, tid)
    _break_notifications(monkeypatch, "db")
    with caplog.at_level(logging.ERROR, logger="itbridge.notifications"):
        if flow == "settlement":
            r = sandbox(client, ih, pid)
            assert r.status_code == 200 and r.json()["data"]["outcome"] == "succeeded", r.text
        elif flow == "refund":
            r = refund(client, ah, pid)
            assert r.status_code == 200 and r.json()["data"]["status"] == "SUCCEEDED", r.text
        else:
            eid = scalar(client, "SELECT id FROM trainer_earnings WHERE payment_id = :p", p=pid)
            r = client.post(f"{API}/admin/earnings/{eid}/payout", headers=ah, json={"reference": "BATCH-2026-10"})
            assert r.status_code == 200 and r.json()["data"]["status"] == "PAID", r.text

    # 1. the financial change is COMMITTED (read through another connection)
    if flow == "settlement":
        assert scalar(client, "SELECT status FROM payments WHERE id = :p", p=pid) == "SUCCEEDED"
        for table in ("invoices", "trainer_earnings", "platform_commissions", "payment_transactions"):
            assert scalar(client, f"SELECT count(*) FROM {table} WHERE payment_id = :p", p=pid) == 1, table
        assert scalar(client, "SELECT count(*) FROM audit_logs WHERE action = 'PAYMENT_SUCCEEDED' AND entity_id = :p", p=pid) == 1
    elif flow == "refund":
        assert scalar(client, "SELECT status FROM payment_refunds WHERE payment_id = :p", p=pid) == "SUCCEEDED"
        assert scalar(client, "SELECT status FROM trainer_earnings WHERE payment_id = :p", p=pid) == "REFUNDED"
        assert scalar(client, "SELECT status FROM platform_commissions WHERE payment_id = :p", p=pid) == "REVERSED"
    else:
        assert scalar(client, "SELECT status FROM trainer_earnings WHERE payment_id = :p", p=pid) == "PAID"
        assert scalar(client, "SELECT payout_reference FROM trainer_earnings WHERE payment_id = :p", p=pid) == "BATCH-2026-10"
    # 2. the failed notification left nothing behind, and the failure was a REAL database error that was logged with its traceback
    assert payment_notification_count(client) == 0
    logs = _failure_logs(caplog)
    assert logs and all(rec.exc_info for rec in logs)
    assert all("not-null constraint" in str(rec.exc_info[1]) for rec in logs), [str(rec.exc_info[1])[:200] for rec in logs]
    # 3. the outer transaction was not left broken: the very next requests (new sessions, but the same pool) work and still see the right state
    assert client.get(f"{API}/trainings/{tid}/payment-summary", headers=ih).status_code == 200
    if flow == "refund":
        assert refund(client, ah, pid).status_code == 200 and scalar(client, "SELECT count(*) FROM payment_refunds WHERE payment_id = :p", p=pid) == 1


def test_pg_a_notification_database_error_while_flagging_a_payment_still_records_the_flag(client, monkeypatch, caplog):
    from tests.test_payments_phase13 import deliver
    th, ih, tid = setup(client)
    p = start(client, ih, tid)
    client.post(f"{API}/payments/{p['id']}/cancel", headers=ih)
    _break_notifications(monkeypatch, "db")
    with caplog.at_level(logging.ERROR, logger="itbridge.notifications"):
        r = deliver(client, p["checkout"]["order_id"])
    assert r.status_code == 200 and r.json()["data"]["outcome"] == "succeeded_late"
    assert scalar(client, "SELECT count(*) FROM payment_review_flags WHERE payment_id = :p AND reason = 'LATE_SUCCESS' AND resolved_at IS NULL", p=p["id"]) == 1
    assert scalar(client, "SELECT needs_review FROM payments WHERE id = :p", p=p["id"]) is True
    assert any("PAYMENT_NEEDS_REVIEW" in rec.getMessage() for rec in _failure_logs(caplog))


# ---------------------------------------------------------------- directly on a Session
def test_pg_notify_event_safe_rolls_back_to_its_savepoint_and_the_outer_transaction_stays_usable(client, caplog):
    """A VARCHAR(120) column given 500 characters: PostgreSQL raises 'value too long' inside the SAVEPOINT. Afterwards the caller's session must still be
    in a healthy outer transaction (a following statement runs and the caller's pending change commits)."""
    th, ih, tid = setup(client)
    with app_session(client) as db:
        user = db.query(User).filter_by(email="ia@example.com").one()
        uid = user.id
        user.full_name = "Changed by the caller"                                      # pending when the notification is attempted
        with caplog.at_level(logging.ERROR, logger="itbridge.notifications"):
            ok = notification_service.notify_event_safe(db, uid, "PAYMENT_SUCCEEDED", dedupe_key=LONG_KEY, amount="Rs 1.00", title="T", training_id=tid)
        assert ok is False
        assert db.in_transaction() and not db.in_nested_transaction()                     # the savepoint is closed, the outer transaction is open
        assert db.execute(text("SELECT 1")).scalar() == 1                                 # on an aborted PostgreSQL transaction this raises InFailedSqlTransaction
        assert db.info.get("pending_push", []) == [], "no real-time push for a notification that was rolled back"
        db.commit()
    assert scalar(client, "SELECT full_name FROM users WHERE id = :u", u=uid) == "Changed by the caller"
    assert scalar(client, "SELECT count(*) FROM notifications WHERE user_id = :u AND dedupe_key IS NOT NULL", u=uid) == 0
    logs = _failure_logs(caplog)
    assert len(logs) == 1 and logs[0].exc_info and "value too long" in str(logs[0].exc_info[1])


def test_pg_a_later_notification_on_the_same_session_still_works_after_a_failed_one(client):
    th, ih, tid = setup(client)
    with app_session(client) as db:
        uid = db.query(User).filter_by(email="ia@example.com").one().id
        assert notification_service.notify_event_safe(db, uid, "PAYMENT_SUCCEEDED", dedupe_key=LONG_KEY, amount="Rs 1.00", title="T", training_id=tid) is False
        assert notification_service.notify_event_safe(db, uid, "PAYMENT_SUCCEEDED", dedupe_key="ok-key-1", amount="Rs 2.00", title="T", training_id=tid) is True
        db.commit()
    assert scalar(client, "SELECT count(*) FROM notifications WHERE user_id = :u AND dedupe_key = 'ok-key-1'", u=uid) == 1
    assert scalar(client, "SELECT count(*) FROM notifications WHERE user_id = :u AND dedupe_key IS NOT NULL AND length(dedupe_key) > 120", u=uid) == 0


def test_pg_control_the_same_failure_without_a_savepoint_does_destroy_the_outer_transaction(client):
    """Control for the two tests above: it shows the failure really happens on this database and what the SAVEPOINT is protecting. Without it, the
    failed flush rolls the caller's whole transaction back, including a change that had already been flushed."""
    th, ih, tid = setup(client)
    with app_session(client) as db:
        uid = db.query(User).filter_by(email="ia@example.com").one().id
        db.get(User, uid).full_name = "Lost with the transaction"
        db.flush()
        db.add(Notification(user_id=uid, type="PAYMENT_SUCCEEDED", title="T", dedupe_key=LONG_KEY))
        with pytest.raises(Exception) as err:
            db.flush()
        assert "value too long" in str(err.value)
        try:
            db.commit()                        # refused (PendingRollbackError) on current SQLAlchemy; either way nothing below may persist
        except Exception:
            db.rollback()
    assert scalar(client, "SELECT full_name FROM users WHERE id = :u", u=uid) != "Lost with the transaction"


def test_pg_notifications_still_work_when_nothing_is_broken(client):
    th, ih, tid = setup(client)
    paid(client, ih, tid)
    assert scalar(client, "SELECT count(*) FROM notifications WHERE type = 'PAYMENT_SUCCEEDED'") == 1
    assert scalar(client, "SELECT count(*) FROM notifications WHERE type = 'PAYMENT_RECEIVED'") == 1
