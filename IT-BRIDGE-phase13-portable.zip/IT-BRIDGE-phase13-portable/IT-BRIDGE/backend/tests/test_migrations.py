"""Proves the Alembic migrations build the same schema as the SQLAlchemy models (needs the backend dependencies)."""
import tempfile
from pathlib import Path

import pytest
from alembic import command
from alembic.autogenerate import compare_metadata
from alembic.config import Config
from alembic.migration import MigrationContext
from sqlalchemy import create_engine, inspect, text

import app.models  # noqa: F401
from app.core.config import settings
from app.core.database import Base

BACKEND = Path(__file__).resolve().parent.parent


def _upgrade(url: str):
    settings.database_url = url          # alembic/env.py reads settings.database_url
    cfg = Config()
    cfg.set_main_option("script_location", str(BACKEND / "alembic"))
    command.upgrade(cfg, "head")
    return cfg


def test_upgrade_head_creates_every_model_table_and_matches_models():
    original = settings.database_url
    with tempfile.TemporaryDirectory() as d:
        url = f"sqlite:///{d}/m.db"
        try:
            _upgrade(url)
        finally:
            settings.database_url = original
        engine = create_engine(url)
        assert set(Base.metadata.tables) <= set(inspect(engine).get_table_names())
        with engine.connect() as conn:
            diff = compare_metadata(MigrationContext.configure(conn), Base.metadata)
        assert diff == [], f"models and migrations disagree: {diff}"


def test_downgrade_to_base_drops_everything():
    original = settings.database_url
    with tempfile.TemporaryDirectory() as d:
        url = f"sqlite:///{d}/m.db"
        try:
            cfg = _upgrade(url)
            command.downgrade(cfg, "base")
        finally:
            settings.database_url = original
        assert set(inspect(create_engine(url)).get_table_names()) <= {"alembic_version"}


# ---- the downgrade policy (app/core/migration_guard.py): a downgrade that would delete data is refused BEFORE any revision runs ----
# Real Alembic on SQLite. SQLite cannot roll DDL back (each revision is its own transaction), so "nothing changed after the refusal" here proves the check
# happens up front, not that a transaction undid earlier work. On PostgreSQL the same property is tests/test_migrations_postgres.py.
SWITCH = "ITB_ALLOW_FINANCIAL_DOWNGRADE"
PHRASE = "I_UNDERSTAND_DATA_WILL_BE_DESTROYED"
SKILL = "INSERT INTO skills (name, category, is_active) VALUES ('Python', NULL, 1)"                                        # a 0001 table
PREFERENCE = "INSERT INTO notification_preferences (user_id, channel, enabled, updated_at) VALUES (1, 'EMAIL', 0, '2030-01-01 00:00:00')"    # a 0004 table
INVOICE_COUNTER = "INSERT INTO invoice_counters (series, year, last_number) VALUES ('INV', 2099, 1)"                      # a 0005 table


def _snapshot(engine) -> tuple:
    """Every schema object (with its SQL) and every row of every table, the alembic_version row included."""
    with engine.connect() as conn:
        schema = [tuple(r) for r in conn.execute(text("SELECT type, name, sql FROM sqlite_master ORDER BY 1, 2"))]
        tables = [r[0] for r in conn.execute(text("SELECT name FROM sqlite_master WHERE type = 'table' ORDER BY 1"))]
        rows = {t: [tuple(r) for r in conn.execute(text(f'SELECT * FROM "{t}" ORDER BY 1'))] for t in tables}
    return schema, rows


def _downgrade(monkeypatch, env: dict[str, str], inserts: list[str], target: str):
    """Upgrade a temp SQLite file to head, insert rows, try `downgrade <target>` with the given environment. Returns (error or None, snapshot before, snapshot after)."""
    monkeypatch.delenv(SWITCH, raising=False)
    for k, v in env.items():
        monkeypatch.setenv(k, v)
    original = settings.database_url
    with tempfile.TemporaryDirectory() as d:
        url = f"sqlite:///{d}/m.db"
        error = None
        try:
            cfg = _upgrade(url)
            engine = create_engine(url)
            with engine.begin() as conn:
                for sql in inserts:
                    conn.execute(text(sql))
            before = _snapshot(engine)
            try:
                command.downgrade(cfg, target)
            except RuntimeError as e:
                error = e
        finally:
            settings.database_url = original
        after = _snapshot(engine)
        engine.dispose()
        return error, before, after


WRONG_ENVIRONMENTS = [
    {},                                                    # no switch
    {SWITCH: "true"}, {SWITCH: "1"}, {SWITCH: "I_UNDERSTAND"}, {SWITCH: PHRASE.lower()}, {SWITCH: PHRASE + " "},   # a wrong value of the right variable
    {"ALLOW_DOWNGRADE": PHRASE}, {"ITB_ALLOW_DOWNGRADE": PHRASE}, {"ITB_ALLOW_FINANCIAL_DOWNGRADES": PHRASE},    # the right value of an unrelated variable
]


@pytest.mark.parametrize("env", WRONG_ENVIRONMENTS)
def test_downgrade_to_base_is_refused_up_front_while_core_tables_hold_data(monkeypatch, env):
    error, before, after = _downgrade(monkeypatch, env, [SKILL], "base")
    assert error is not None and "Refusing to downgrade" in str(error) and "0001: skills 1 rows" in str(error), error
    assert after == before        # not one revision ran: the 0004 .. 0002 work was not done and then left behind (the schema, every row and alembic_version are identical)


@pytest.mark.parametrize("insert,target,named", [
    (PREFERENCE, "0003", "0004: notification_preferences 1 rows"),          # 0004 used to drop the notification tables without any guard
    (INVOICE_COUNTER, "0004", "0005: invoice_counters 1 rows"),
    (SKILL, "base", "0001: skills 1 rows"),
])
def test_each_destructive_revision_is_refused_up_front_whatever_the_target(monkeypatch, insert, target, named):
    error, before, after = _downgrade(monkeypatch, {}, [insert], target)
    assert error is not None and named in str(error), error
    assert after == before


@pytest.mark.parametrize("target,expected_revision", [("-1", "0006"), ("0006", "0006"), ("0005", "0005")])
def test_a_downgrade_that_removes_no_data_is_not_refused_because_of_data_in_lower_revisions(monkeypatch, target, expected_revision):
    """Core, notification and nothing-else data is held, but these runs only remove 0007 (triggers, a no-op on SQLite) and 0006 (an empty table). `-1` also
    checks that real Alembic hands the guard a relative target in a form it can resolve."""
    error, before, after = _downgrade(monkeypatch, {}, [SKILL, PREFERENCE], target)
    assert error is None, error
    assert after[1]["skills"] == before[1]["skills"] and after[1]["notification_preferences"] == before[1]["notification_preferences"]
    assert after[1]["alembic_version"] == [(expected_revision,)]


def test_downgrade_to_base_proceeds_with_the_exact_switch_for_a_disposable_database(monkeypatch):
    error, before, after = _downgrade(monkeypatch, {SWITCH: PHRASE}, [SKILL, PREFERENCE, INVOICE_COUNTER], "base")
    assert error is None and set(after[1]) <= {"alembic_version"}      # every application table is gone, whatever it held
