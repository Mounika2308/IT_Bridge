"""Phase 9: training entity, snapshot, lifecycle phase, list/filter/pagination, summary, authorization."""
from datetime import timedelta

import pytest
from fastapi import HTTPException

from app.core.clock import today
from app.core.security import hash_password
from app.models.application import HiringRequest
from app.models.requirement import TrainingRequirement
from app.models.training import Training
from app.models.user import Skill, User
from app.services.training_service import create_for_hiring
from tests.test_trainings import D, START, begin, db_of, hire_flow, reg, req_body, world  # noqa: F401


def set_dates(client, tid, start=None, end=None):
    db = db_of(client)
    t = db.get(Training, tid)
    t.start_date, t.end_date = start or t.start_date, end or t.end_date
    db.commit()


def detail(client, h, tid):
    return client.get(f"/api/v1/trainings/{tid}", headers=h).json()["data"]


def test_training_stores_a_snapshot_of_the_agreement(client):
    th, ih, rid, tid = world(client)
    d = detail(client, ih, tid)
    assert (d["technology"], d["mode"], d["location"]) == ("Python", "OFFLINE", "Pune")
    assert len(d["description"]) >= 30 and d["terms"] is None and d["requirement_id"] == rid
    assert d["agreed_fee"] == 40000 and d["start_date"] == str(START)


def test_editing_the_requirement_later_does_not_change_the_training(client):
    th, ih, rid, tid = world(client)
    r = client.put(f"/api/v1/requirements/{rid}", headers=ih, json=req_body(location="Delhi", technology="Java", mode="ONLINE"))
    assert r.status_code == 409                                            # a filled requirement is locked against edits...
    db = db_of(client)                                                     # ...and even if its data changed some other way,
    row = db.get(TrainingRequirement, rid)                                 # the agreed training does not read it
    row.location, row.technology, row.mode = "Delhi", "Java", "ONLINE"
    db.commit()
    d = detail(client, th, tid)
    assert (d["technology"], d["mode"], d["location"]) == ("Python", "OFFLINE", "Pune")


def test_hiring_terms_are_copied_to_the_training(client):
    db = db_of(client)
    db.add(Skill(name="Python"))
    db.commit()
    th, ih = reg(client, "t@example.com"), reg(client, "i@example.com", "INSTITUTION", institution_name="Sunrise College")
    rid = client.post("/api/v1/requirements", headers=ih, json=req_body()).json()["data"]["id"]
    client.put("/api/v1/trainers/me", headers=th, json={"headline": "Python trainer", "location": "Pune", "experience_years": 5,
                                                      "training_mode": "OFFLINE", "expected_fee": 4000, "skill_ids": [1]})
    aid = client.post(f"/api/v1/requirements/{rid}/apply", headers=th, json={}).json()["data"]["id"]
    client.patch(f"/api/v1/applications/{aid}/status", headers=ih, json={"status": "SHORTLISTED"})
    hid = client.post(f"/api/v1/applications/{aid}/hire", headers=ih, json={"agreed_fee": 40000, "terms": "Travel covered"}).json()["data"]["id"]
    client.post(f"/api/v1/hiring-requests/{hid}/accept", headers=th)
    tid = client.get("/api/v1/trainings/mine", headers=th).json()["data"]["items"][0]["id"]
    assert detail(client, ih, tid)["terms"] == "Travel covered"


def test_lifecycle_phase_follows_dates_and_status(client):
    th, ih, rid, tid = world(client)
    assert detail(client, th, tid)["phase"] == "UPCOMING"
    set_dates(client, tid, start=today() - timedelta(days=1), end=today() + timedelta(days=5))
    assert detail(client, th, tid)["phase"] == "IN_PROGRESS"
    set_dates(client, tid, end=today() - timedelta(days=1))
    assert detail(client, th, tid)["phase"] == "ENDED"        # over, but still waiting to be completed
    assert client.post(f"/api/v1/trainings/{tid}/complete", headers=ih).json()["data"]["phase"] == "COMPLETED"


def test_cancelled_phase(client):
    th, ih, rid, tid = world(client)
    assert client.post(f"/api/v1/trainings/{tid}/cancel", headers=th, json={}).json()["data"]["phase"] == "CANCELLED"


def test_cannot_complete_before_start_but_can_cancel(client):
    th, ih, rid, tid = world(client)
    assert client.post(f"/api/v1/trainings/{tid}/complete", headers=ih).status_code == 409
    assert detail(client, ih, tid)["status"] == "ACTIVE"
    begin(client, tid)
    assert client.post(f"/api/v1/trainings/{tid}/complete", headers=ih).status_code == 200


def test_list_pagination_and_status_filter(client):
    th, ih, rid, tid = world(client)
    rid2 = client.post("/api/v1/requirements", headers=ih, json=req_body(title="Second Python workshop")).json()["data"]["id"]
    tid2 = hire_flow(client, th, ih, rid2)
    assert tid2 != tid
    page = client.get("/api/v1/trainings/mine?page_size=1", headers=th).json()["data"]
    assert page["total"] == 2 and len(page["items"]) == 1
    assert len(client.get("/api/v1/trainings/mine?page_size=1&page=2", headers=th).json()["data"]["items"]) == 1
    client.post(f"/api/v1/trainings/{tid}/cancel", headers=ih, json={})
    assert client.get("/api/v1/trainings/mine?status=CANCELLED", headers=th).json()["data"]["total"] == 1
    assert client.get("/api/v1/trainings/mine?status=ACTIVE", headers=ih).json()["data"]["total"] == 1
    assert client.get("/api/v1/trainings/mine?status=COMPLETED", headers=ih).json()["data"]["items"] == []
    assert client.get("/api/v1/trainings/mine?status=BOGUS", headers=ih).status_code == 422
    assert client.get("/api/v1/trainings/mine?page_size=500", headers=ih).status_code == 422


def test_summary_counts_for_both_roles(client):
    th, ih, rid, tid = world(client)
    for h in (th, ih):
        s = client.get("/api/v1/trainings/summary", headers=h).json()["data"]
        assert (s["active"], s["upcoming"], s["in_progress"], s["completed"], s["cancelled"]) == (1, 1, 0, 0, 0)
    begin(client, tid)
    assert client.get("/api/v1/trainings/summary", headers=th).json()["data"]["in_progress"] == 1
    client.post(f"/api/v1/trainings/{tid}/complete", headers=ih)
    s = client.get("/api/v1/trainings/summary", headers=ih).json()["data"]
    assert (s["active"], s["completed"]) == (0, 1)


def test_authorization_on_list_summary_and_detail(client):
    th, ih, rid, tid = world(client)
    assert client.get("/api/v1/trainings/mine").status_code == 401
    assert client.get("/api/v1/trainings/summary").status_code == 401
    other_trainer = reg(client, "other@example.com")
    other_inst = reg(client, "oi@example.com", "INSTITUTION", institution_name="Other College")
    for h in (other_trainer, other_inst):
        assert client.get("/api/v1/trainings/mine", headers=h).json()["data"]["total"] == 0
        assert client.get("/api/v1/trainings/summary", headers=h).json()["data"]["active"] == 0
        assert client.get(f"/api/v1/trainings/{tid}", headers=h).status_code == 404
        assert client.post(f"/api/v1/trainings/{tid}/cancel", headers=h, json={}).status_code == 404


# ---------- edge cases ----------

def _pending_hire(client):
    """Trainer and institution with a shortlisted application and a PENDING hiring request. Returns (th, ih, hiring_id)."""
    db = db_of(client)
    db.add(Skill(name="Python"))
    db.commit()
    th, ih = reg(client, "t@example.com"), reg(client, "i@example.com", "INSTITUTION", institution_name="Sunrise College")
    rid = client.post("/api/v1/requirements", headers=ih, json=req_body()).json()["data"]["id"]
    client.put("/api/v1/trainers/me", headers=th, json={"headline": "Python trainer", "location": "Pune", "experience_years": 5,
                                                      "training_mode": "OFFLINE", "expected_fee": 4000, "skill_ids": [1]})
    aid = client.post(f"/api/v1/requirements/{rid}/apply", headers=th, json={}).json()["data"]["id"]
    client.patch(f"/api/v1/applications/{aid}/status", headers=ih, json={"status": "SHORTLISTED"})
    hid = client.post(f"/api/v1/applications/{aid}/hire", headers=ih, json={"agreed_fee": 40000}).json()["data"]["id"]
    return th, ih, hid


def _trainings(client, h):
    return client.get("/api/v1/trainings/mine", headers=h).json()["data"]["total"]


def test_no_training_from_a_hiring_request_that_is_not_accepted(client):
    th, ih, hid = _pending_hire(client)
    assert _trainings(client, th) == 0 and _trainings(client, ih) == 0       # pending: nothing exists yet
    db = db_of(client)
    with pytest.raises(HTTPException) as e:
        create_for_hiring(db, db.get(HiringRequest, hid))                      # service-level guard
    assert e.value.status_code == 409


def test_duplicate_training_is_refused(client):
    th, ih, rid, tid = world(client)
    db = db_of(client)
    hr = db.query(HiringRequest).one()
    with pytest.raises(HTTPException) as e:
        create_for_hiring(db, hr)
    assert e.value.status_code == 409 and _trainings(client, th) == 1
    assert client.post(f"/api/v1/hiring-requests/{hr.id}/accept", headers=th).status_code == 409   # accepting twice
    assert _trainings(client, th) == 1


def test_cancelled_or_declined_hiring_never_creates_a_training(client):
    th, ih, hid = _pending_hire(client)
    assert client.post(f"/api/v1/hiring-requests/{hid}/cancel", headers=ih).status_code == 200
    assert client.post(f"/api/v1/hiring-requests/{hid}/accept", headers=th).status_code == 409
    assert _trainings(client, th) == 0 and _trainings(client, ih) == 0


def test_declined_hiring_creates_no_training(client):
    th, ih, hid = _pending_hire(client)
    client.post(f"/api/v1/hiring-requests/{hid}/decline", headers=th)
    assert _trainings(client, th) == 0


def test_inactive_users_are_blocked_from_trainings(client):
    th, ih, rid, tid = world(client)
    db = db_of(client)
    for email, h in (("t@example.com", th), ("i@example.com", ih)):
        db.query(User).filter(User.email == email).update({"is_active": False})
        db.commit()
        assert client.get("/api/v1/trainings/mine", headers=h).status_code == 403
        assert client.get(f"/api/v1/trainings/{tid}", headers=h).status_code == 403
        assert client.post(f"/api/v1/trainings/{tid}/cancel", headers=h, json={}).status_code == 403


def test_admin_has_no_access_to_private_trainings(client):
    th, ih, rid, tid = world(client)
    db = db_of(client)
    db.add(User(email="admin@example.com", password_hash=hash_password("Passw0rd123"), full_name="Admin", role="ADMIN"))
    db.commit()
    token = client.post("/api/v1/auth/login", json={"email": "admin@example.com", "password": "Passw0rd123"}).json()["data"]["access_token"]
    h = {"Authorization": f"Bearer {token}"}
    assert client.get("/api/v1/trainings/mine", headers=h).status_code == 403
    assert client.get(f"/api/v1/trainings/{tid}", headers=h).status_code == 403


def test_missing_training_is_404_everywhere(client):
    th, ih, rid, tid = world(client)
    assert client.get("/api/v1/trainings/999999", headers=th).status_code == 404
    assert client.patch("/api/v1/trainings/999999/dates", headers=ih, json={"start_date": str(START), "end_date": str(START)}).status_code == 404
    assert client.patch("/api/v1/trainings/999999/details", headers=ih, json={"meeting_link": None}).status_code == 404
    assert client.post("/api/v1/trainings/999999/complete", headers=ih).status_code == 404
    assert client.post("/api/v1/trainings/999999/cancel", headers=th, json={}).status_code == 404


def test_completed_and_cancelled_trainings_are_read_only(client):
    th, ih, rid, tid = world(client)
    begin(client, tid)
    assert client.post(f"/api/v1/trainings/{tid}/complete", headers=ih).status_code == 200
    dates = {"start_date": str(today() - timedelta(days=1)), "end_date": str(today() + timedelta(days=9))}
    assert client.patch(f"/api/v1/trainings/{tid}/dates", headers=ih, json=dates).status_code == 409
    assert client.patch(f"/api/v1/trainings/{tid}/details", headers=ih, json={"meeting_link": None}).status_code == 409
    assert client.post(f"/api/v1/trainings/{tid}/cancel", headers=th, json={}).status_code == 409   # completed cannot be cancelled
    assert client.post(f"/api/v1/trainings/{tid}/complete", headers=ih).status_code == 409           # nor completed twice
    # a cancelled training cannot be completed or reopened
    rid2 = client.post("/api/v1/requirements", headers=ih, json=req_body(title="Another Python workshop")).json()["data"]["id"]
    tid2 = hire_flow(client, th, ih, rid2)
    client.post(f"/api/v1/trainings/{tid2}/cancel", headers=ih, json={"reason": "No budget"})
    begin(client, tid2)
    assert client.post(f"/api/v1/trainings/{tid2}/complete", headers=ih).status_code == 409
    assert client.post(f"/api/v1/trainings/{tid2}/cancel", headers=ih, json={}).status_code == 409
    assert detail(client, th, tid2)["cancel_reason"] == "No budget"


def test_training_date_rules(client):
    th, ih, rid, tid = world(client)
    put = lambda s, e: client.patch(f"/api/v1/trainings/{tid}/dates", headers=ih, json={"start_date": str(s), "end_date": str(e)})
    assert put(START + timedelta(days=5), START).status_code == 422                                  # end before start
    assert put(today() - timedelta(days=3), START).status_code == 422                                # start moved into the past
    assert put(START + timedelta(days=2), END + timedelta(days=2)).status_code == 200                # moving an upcoming training is fine
    set_dates(client, tid, start=today() - timedelta(days=2), end=today() + timedelta(days=3))
    assert put(today() - timedelta(days=1), today() + timedelta(days=3)).status_code == 409          # started: start is fixed
    assert put(today() - timedelta(days=2), today() + timedelta(days=10)).status_code == 200         # but the end can be extended


def test_meeting_link_for_online_trainings_only(client):
    th, ih, rid, tid = world(client)                                                                  # OFFLINE training
    link = {"meeting_link": "https://meet.example.com/abc"}
    assert client.patch(f"/api/v1/trainings/{tid}/details", headers=th, json=link).status_code == 422
    rid2 = client.post("/api/v1/requirements", headers=ih, json=req_body(title="Online Python workshop", mode="ONLINE")).json()["data"]["id"]
    tid2 = hire_flow(client, th, ih, rid2)
    assert detail(client, th, tid2)["mode"] == "ONLINE"
    assert client.patch(f"/api/v1/trainings/{tid2}/details", headers=th, json=link).status_code == 200
    assert detail(client, ih, tid2)["meeting_link"] == "https://meet.example.com/abc"                 # both parties see it
    assert client.patch(f"/api/v1/trainings/{tid2}/details", headers=ih, json={"meeting_link": "http://insecure.example.com"}).status_code == 422
    assert client.patch(f"/api/v1/trainings/{tid2}/details", headers=ih, json={"meeting_link": "javascript:alert(1)"}).status_code == 422
    outsider = reg(client, "o@example.com")
    assert client.patch(f"/api/v1/trainings/{tid2}/details", headers=outsider, json=link).status_code == 404
    assert client.patch(f"/api/v1/trainings/{tid2}/details", headers=ih, json={"meeting_link": None}).status_code == 200
    assert detail(client, th, tid2)["meeting_link"] is None
