from datetime import timedelta

from app.core.clock import today
from app.core.database import get_db
from app.main import app
from app.models.user import Skill, TrainerProfile

D = today()
INST = {"full_name": "Ravi K", "email": "ravi@example.com", "password": "Passw0rd123", "role": "INSTITUTION", "institution_name": "Sunrise College"}


def user(client, email, role="TRAINER", **extra):
    body = {"full_name": email.split("@")[0].title(), "email": email, "password": "Passw0rd123", "role": role, **extra}
    d = client.post("/api/v1/auth/register", json=body).json()["data"]
    return {"Authorization": f"Bearer {d['access_token']}"}


def setup(client):
    db = next(app.dependency_overrides[get_db]())
    db.add_all([Skill(name="Python"), Skill(name="React")])
    db.commit()
    return db


def make_trainer(client, email, **profile):
    h = user(client, email)
    base = {"headline": "Trainer headline", "location": "Pune", "experience_years": 5, "training_mode": "OFFLINE",
            "expected_fee": 4000, "skill_ids": [1]}
    base.update(profile)
    assert client.put("/api/v1/trainers/me", headers=h, json=base).status_code == 200
    return h


def req_body(**kw):
    b = dict(title="Python workshop for 3rd years", technology="Python", description="x" * 40, skill_ids=[1], student_count=60,
             student_level="BEGINNER", duration_days=10, sessions=10, location="Pune", mode="OFFLINE",
             start_date=str(D + timedelta(days=30)), end_date=str(D + timedelta(days=40)), budget_min=20000,
             budget_max=50000, application_deadline=str(D + timedelta(days=20)))
    b.update(kw)
    return b


def test_matches_ranked_and_explained(client):
    setup(client)
    make_trainer(client, "best@example.com")
    make_trainer(client, "far@example.com", location="Delhi", expected_fee=9000)
    make_trainer(client, "noskill@example.com", skill_ids=[2])
    ih = user(client, "ravi@example.com", "INSTITUTION", institution_name="Sunrise College")
    rid = client.post("/api/v1/requirements", headers=ih, json=req_body()).json()["data"]["id"]
    d = client.get(f"/api/v1/requirements/{rid}/matches", headers=ih).json()["data"]
    assert [m["full_name"] for m in d["matches"]] == ["Best", "Far"]  # trainer without the skill is excluded
    assert d["matches"][0]["score"] > d["matches"][1]["score"]
    assert {f["key"] for f in d["matches"][0]["factors"]} == {"skill", "experience", "location", "availability", "mode", "budget"}
    assert "email" not in str(d)


def test_busy_trainer_loses_availability_points(client):
    setup(client)
    th = make_trainer(client, "busy@example.com")
    ih = user(client, "ravi@example.com", "INSTITUTION", institution_name="Sunrise College")
    rid = client.post("/api/v1/requirements", headers=ih, json=req_body()).json()["data"]["id"]
    before = client.get(f"/api/v1/requirements/{rid}/matches", headers=ih).json()["data"]["matches"][0]["score"]
    client.post("/api/v1/trainers/me/busy-periods", headers=th,
                json={"start_date": str(D + timedelta(days=32)), "end_date": str(D + timedelta(days=33))})
    after = client.get(f"/api/v1/requirements/{rid}/matches", headers=ih).json()["data"]["matches"][0]["score"]
    assert before - after == 15


def test_suspended_trainer_not_matched(client):
    db = setup(client)
    make_trainer(client, "gone@example.com")
    db.query(TrainerProfile).update({"verification_status": "SUSPENDED"})
    db.commit()
    ih = user(client, "ravi@example.com", "INSTITUTION", institution_name="Sunrise College")
    rid = client.post("/api/v1/requirements", headers=ih, json=req_body()).json()["data"]["id"]
    assert client.get(f"/api/v1/requirements/{rid}/matches", headers=ih).json()["data"]["matches"] == []


def test_only_owner_sees_matches(client):
    setup(client)
    ih = user(client, "ravi@example.com", "INSTITUTION", institution_name="Sunrise College")
    other = user(client, "o@example.com", "INSTITUTION", institution_name="Other")
    rid = client.post("/api/v1/requirements", headers=ih, json=req_body()).json()["data"]["id"]
    assert client.get(f"/api/v1/requirements/{rid}/matches", headers=other).status_code == 404


def test_trainer_search_filters_and_role_guard(client):
    setup(client)
    th = make_trainer(client, "a@example.com")
    make_trainer(client, "b@example.com", location="Delhi", expected_fee=9000, experience_years=1)
    ih = user(client, "ravi@example.com", "INSTITUTION", institution_name="Sunrise College")
    assert client.get("/api/v1/trainers", headers=th).status_code == 403
    assert client.get("/api/v1/trainers", headers=ih).json()["data"]["total"] == 2
    assert client.get("/api/v1/trainers?location=pune", headers=ih).json()["data"]["total"] == 1
    assert client.get("/api/v1/trainers?max_fee=5000&min_experience=3", headers=ih).json()["data"]["total"] == 1
    assert client.get("/api/v1/trainers?verified_only=true", headers=ih).json()["data"]["total"] == 0


def test_trainer_recommendations(client):
    setup(client)
    th = make_trainer(client, "a@example.com")
    ih = user(client, "ravi@example.com", "INSTITUTION", institution_name="Sunrise College")
    client.post("/api/v1/requirements", headers=ih, json=req_body())
    recs = client.get("/api/v1/trainers/me/recommendations", headers=th).json()["data"]
    assert len(recs) == 1 and recs[0]["score"] > 80


def test_matching_weights_admin_only_and_validated(client):
    th = user(client, "a@example.com")
    assert client.put("/api/v1/admin/settings/matching-weights", headers=th, json={}).status_code == 403
