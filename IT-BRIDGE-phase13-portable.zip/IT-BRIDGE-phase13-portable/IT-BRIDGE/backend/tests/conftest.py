import os
os.environ["DATABASE_URL"] = "sqlite://"
# Phase 13: the payment sandbox is on for tests, with a known (test-only) webhook secret. Set BEFORE app.main is imported.
os.environ["PAYMENTS_ENABLED"] = "true"
os.environ["PAYMENT_PROVIDER"] = "sandbox"
os.environ["PAYMENT_SANDBOX_ENABLED"] = "true"   # the explicit sandbox opt-in (Phase 13 remediation)
os.environ["PAYMENT_WEBHOOK_SECRET"] = "test-only-webhook-secret-for-the-pytest-suite-0123456789"
os.environ["PLATFORM_COMMISSION_BPS"] = "1000"
os.environ["ENVIRONMENT"] = "development"

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

import app.models  # noqa: F401
from app.core.database import Base, get_db
from app.main import app


@pytest.fixture()
def client():
    engine = create_engine("sqlite://", connect_args={"check_same_thread": False}, poolclass=StaticPool)
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine, expire_on_commit=False)

    def override():
        db = Session()
        try:
            yield db
        finally:
            db.close()

    app.dependency_overrides[get_db] = override
    yield TestClient(app)
    app.dependency_overrides.clear()
