"""The safety rules in front of scripts/verify_postgres_sql.py, which runs `DROP DATABASE IF EXISTS itb_verify_test` on whichever server libpq reaches.
Standard library + pytest only: no server is contacted. Proves which environments are refused and what the server-side guard says; that a real server
raises from the guard was exercised by hand with psql against throw-away clusters (Phase 13 handoff), not here."""
import importlib.util
import sys
from pathlib import Path

import pytest

SCRIPTS = Path(__file__).resolve().parents[2] / "scripts"
sys.path.insert(0, str(SCRIPTS))
_spec = importlib.util.spec_from_file_location("verify_postgres_sql_under_test", SCRIPTS / "verify_postgres_sql.py")
v = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(v)

OK = {"PGHOST": "127.0.0.1", "PGPORT": "55432", "PGUSER": "postgres"}


def test_a_prepared_environment_is_accepted():
    assert v.environment_problems(OK, "itb_verify_test") == []
    assert v.environment_problems({**OK, "PGHOST": "::1", "PGPASSWORD": "x", "PGCONNECT_TIMEOUT": "3"}, "itb_verify_test_2") == []


@pytest.mark.parametrize("env", [
    {}, {"PGPORT": "55432"}, {"PGHOST": "127.0.0.1"},
    {**OK, "PGHOST": "localhost"}, {**OK, "PGHOST": "LOCALHOST"}, {**OK, "PGHOST": "127.0.0.2"}, {**OK, "PGHOST": "/var/run/postgresql"}, {**OK, "PGHOST": "10.0.0.5"},
    {**OK, "PGHOST": "127.0.0.1,10.0.0.5"}, {**OK, "PGHOST": "0.0.0.0"}, {**OK, "PGHOST": ""},
    {**OK, "PGPORT": "5432"}, {**OK, "PGPORT": "0"}, {**OK, "PGPORT": "1023"}, {**OK, "PGPORT": "65536"}, {**OK, "PGPORT": "055432"}, {**OK, "PGPORT": "+55432"},
    {**OK, "PGPORT": "55432,5432"}, {**OK, "PGPORT": ""},
    {**OK, "PGHOSTADDR": "10.9.9.9"}, {**OK, "PGDATABASE": "itbridge"}, {**OK, "PGSERVICE": "prod"}, {**OK, "PGSERVICEFILE": "/etc/x"}, {**OK, "PGSYSCONFDIR": "/etc"},
    {**OK, "PGOPTIONS": "-c search_path=x"}, {**OK, "PGPASSFILE": "/root/.pgpass"}, {**OK, "PGSSLMODE": "disable"}, {**OK, "PGTARGETSESSIONATTRS": "any"},
    {**OK, "PGUSER": "post gres"}, {**OK, "PGUSER": "a;b"}, {**OK, "PGUSER": ""},
])
def test_a_redirecting_or_default_environment_is_refused(env):
    assert v.environment_problems(env, "itb_verify_test")


@pytest.mark.parametrize("db", ["itbridge", "itbridge_test", "postgres", "itb_verify", "itb_verify_tes", "ITB_VERIFY_TEST", "itb_verify_test;DROP", 'itb_verify_test"',
                                "itb_verify_test x", "itb_verify_test" + "a" * 21, "x_itb_verify_test", "", "itb_verify_test\n"])
def test_a_database_name_other_than_the_verify_database_is_refused(db):
    assert v.environment_problems(OK, db)


def test_the_guard_demands_version_primary_anchor_and_all_marked():
    sql = v.server_guard("itb_verify_test")
    for needle in ("160000 AND 169999", "pg_is_in_recovery()", v.MARKER, "datistemplate", "NOT IN ('postgres', 'itb_verify_test')", "<> 'postgres'"):
        assert needle in sql
    assert sql.count("RAISE EXCEPTION") == 4 and sql.startswith("DO $itbguard$") and sql.rstrip().endswith("$itbguard$;")


def test_create_database_sends_the_guard_before_the_drop_in_one_script():
    sent = []
    original_psql, original_env = v.psql, v.environment_problems
    v.psql = lambda sql, db=None, timeout=120: (sent.append((sql, db)) or (0, "", ""))
    v.environment_problems = lambda environ=None, db=None: []
    try:
        v.create_database()
    finally:
        v.psql, v.environment_problems = original_psql, original_env
    assert len(sent) == 1 and sent[0][1] == "postgres"
    script = sent[0][0]
    assert script.index("DO $itbguard$") < script.index("DROP DATABASE") < script.index("CREATE DATABASE") < script.index("COMMENT ON DATABASE")


def test_create_database_refuses_before_sending_anything_when_the_environment_is_wrong():
    sent = []
    original_psql, original_env = v.psql, v.environment_problems
    v.psql = lambda sql, db=None, timeout=120: (sent.append(sql) or (0, "", ""))
    v.environment_problems = lambda environ=None, db=None: ["PGHOSTADDR is set"]
    try:
        with pytest.raises(v.Refused):
            v.create_database()
    finally:
        v.psql, v.environment_problems = original_psql, original_env
    assert sent == []


def test_a_guard_error_from_the_server_is_a_refusal_not_a_failure():
    original_psql, original_env = v.psql, v.environment_problems
    v.psql = lambda sql, db=None, timeout=120: (3, "", "ERROR:  itb gate: the cluster holds a database without the comment")
    v.environment_problems = lambda environ=None, db=None: []
    try:
        with pytest.raises(v.Refused, match="holds a database"):
            v.create_database()
    finally:
        v.psql, v.environment_problems = original_psql, original_env
