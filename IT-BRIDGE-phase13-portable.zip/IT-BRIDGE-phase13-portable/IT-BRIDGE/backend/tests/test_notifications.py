import asyncio
from datetime import timedelta

from app.core.database import get_db
from app.main import app
from app.models.notification import Notification
from app.services.realtime import ConnectionManager
from app.workers.reminders import send_reminders
from tests.test_trainings import START, begin, hire_flow, req_body, reg, session, world  # noqa: F401


def notes(client, h, **params):
    return client.get("/api/v1/notifications", headers=h, params=params).json()["data"]


def test_application_notifies_institution_and_reads(client):
    th, ih, rid, tid = world(client)
    items = notes(client, ih)["items"]
    assert "APPLICATION_RECEIVED" in {n["type"] for n in items}
    assert notes(client, ih)["unread"] == len(items)
    nid = items[0]["id"]
    assert client.post(f"/api/v1/notifications/{nid}/read", headers=ih).status_code == 200
    assert client.get("/api/v1/notifications/unread-count", headers=ih).json()["data"]["unread"] == len(items) - 1
    assert client.post("/api/v1/notifications/read-all", headers=ih).status_code == 200
    assert client.get("/api/v1/notifications/unread-count", headers=ih).json()["data"]["unread"] == 0


def test_users_cannot_read_each_others_notifications(client):
    th, ih, rid, tid = world(client)
    nid = notes(client, ih)["items"][0]["id"]
    assert client.post(f"/api/v1/notifications/{nid}/read", headers=th).status_code == 404
    assert nid not in {n["id"] for n in notes(client, th)["items"]}
    assert client.get("/api/v1/notifications").status_code == 401


def test_hiring_flow_notifications(client):
    th, ih, rid, tid = world(client)
    assert {"HIRING_REQUEST"} <= {n["type"] for n in notes(client, th)["items"]}
    assert "HIRING_ACCEPTED" in {n["type"] for n in notes(client, ih)["items"]}
    assert "TRAINING_CREATED" in {n["type"] for n in notes(client, th)["items"]}


def test_session_and_completion_notifications(client):
    th, ih, rid, tid = world(client)
    session(client, th, tid)
    assert any(n["type"] == "SESSION_SCHEDULED" for n in notes(client, ih)["items"])
    begin(client, tid)
    client.post(f"/api/v1/trainings/{tid}/complete", headers=ih)
    assert any(n["type"] == "REVIEW_REQUEST" for n in notes(client, th)["items"])
    assert any(n["type"] == "REVIEW_REQUEST" for n in notes(client, ih)["items"])


def test_reminders_are_idempotent(client):
    th, ih, rid, tid = world(client)
    session(client, th, tid)
    db = next(app.dependency_overrides[get_db]())
    day_before = START - timedelta(days=1)
    first = send_reminders(db, today=day_before)
    assert first == 4  # session reminder + training-start reminder, for both parties
    assert send_reminders(db, today=day_before) == 0
    assert db.query(Notification).filter(Notification.type == "SESSION_REMINDER").count() == 2


def test_unread_filter_and_pagination(client):
    th, ih, rid, tid = world(client)
    client.post("/api/v1/notifications/read-all", headers=ih)
    assert notes(client, ih, unread_only=True)["total"] == 0
    assert notes(client, ih, page=1, page_size=1)["total"] >= 1


def test_realtime_manager_delivers_across_threads_and_limits_connections():
    async def run():
        m = ConnectionManager()
        q = await m.connect(7)
        await asyncio.get_running_loop().run_in_executor(None, m.push, 7, {"id": 1})  # push from another thread
        assert await asyncio.wait_for(q.get(), 1) == {"id": 1}
        m.push(8, {"id": 2})  # nobody listening: no error
        qs = [await m.connect(9) for _ in range(5)]
        assert await m.connect(9) is None  # sixth connection refused
        m.disconnect(9, qs[0])
        assert m.connection_count(9) == 4
        m.disconnect(7, q)
        assert m.connection_count(7) == 0
    asyncio.run(run())


def test_websocket_requires_valid_token_and_receives_push(client):
    th, ih, rid, tid = world(client)
    token = ih["Authorization"].split()[1]
    with client.websocket_connect("/ws/notifications") as bad:
        bad.send_json({"token": "nope"})
        closed = False
        try:
            bad.receive_json()
        except Exception:
            closed = True
        assert closed, "expected the server to close the socket"
    with client.websocket_connect("/ws/notifications") as ws:
        ws.send_json({"token": token})
        assert ws.receive_json() == {"type": "ready"}
        client.post(f"/api/v1/trainings/{tid}/sessions", headers=th,
                    json={"title": "Live", "session_date": str(START), "start_time": "09:00", "end_time": "10:00"})
        msg = ws.receive_json()
        assert msg["type"] == "notification" and msg["data"]["type"] == "SESSION_SCHEDULED"
