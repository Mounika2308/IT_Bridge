"""Runs the REAL start-up guard (app/core/payment_guard.py + app/services/payment_rules.py) against a stand-in for app.core.config (13B.1).

Why a stand-in: the guard only reads seven attributes of `settings`. Injecting an object that has them lets these tests run without pydantic-settings,
FastAPI or SQLAlchemy and without any .env file or ambient environment variable, so they behave identically on every machine. What they do NOT prove
is that the real pydantic-settings class loads the same values from the environment: that is covered by tests/test_startup_hermetic.py, which needs
the real dependencies and is skipped (not passed) without them.
"""
import importlib
import re
import sys
import types

import pytest

from tests.boot_env import CONFIG_FILE
from tests import webhook_secret_matrix as M
from tests.test_startup_hermetic import CASES, EXAMPLE_SECRET, STRONG

FIELDS = {  # env var -> (attribute, parser, default as declared in app/core/config.py)
    "ENVIRONMENT": ("environment", str, ""), "PAYMENTS_ENABLED": ("payments_enabled", lambda v: v.lower() == "true", False),
    "PAYMENT_PROVIDER": ("payment_provider", str, "sandbox"), "PAYMENT_WEBHOOK_SECRET": ("payment_webhook_secret", str, ""),
    "PLATFORM_COMMISSION_BPS": ("platform_commission_bps", int, 1000), "PAYMENT_COMMISSION_CONFIRMED": ("payment_commission_confirmed", lambda v: v.lower() == "true", False),
    "PAYMENT_SANDBOX_ENABLED": ("payment_sandbox_enabled", lambda v: v.lower() == "true", False),
}


def fake_settings(env: dict):
    values = {attr: default for attr, _, default in FIELDS.values()}
    for var, raw in env.items():
        if var in FIELDS and raw is not None:
            attr, parse, _ = FIELDS[var]
            values[attr] = parse(raw)
    return types.SimpleNamespace(**values)


@pytest.fixture
def guard_for():
    """guard_for(env) -> a freshly imported payment_guard bound to a stand-in settings object. sys.modules is restored afterwards."""
    saved = {k: sys.modules.get(k) for k in ("app.core.config", "app.core.payment_guard")}

    def build(env: dict):
        sys.modules.pop("app.core.payment_guard", None)
        sys.modules["app.core.config"] = types.SimpleNamespace(settings=fake_settings(env))
        return importlib.import_module("app.core.payment_guard")
    try:
        yield build
    finally:
        for k, v in saved.items():
            if v is None:
                sys.modules.pop(k, None)
            else:
                sys.modules[k] = v


def test_the_stand_in_defaults_are_the_ones_declared_in_config_py():
    """If someone changes a default in config.py (for example gives ENVIRONMENT a default again) this fails, so the stand-in cannot drift silently."""
    text = CONFIG_FILE.read_text()
    for var, (attr, _, default) in FIELDS.items():
        m = re.search(rf"^    {attr}\s*:\s*\w+\s*=\s*([^\s#]+)", text, flags=re.M)
        assert m, attr
        assert eval(m.group(1)) == default, (attr, m.group(1), default)


def test_config_py_has_no_default_environment_and_no_dependence_on_pydantic_internals():
    text = CONFIG_FILE.read_text()
    assert re.search(r'^    environment\s*:\s*str\s*=\s*""', text, flags=re.M)
    guard_src = (CONFIG_FILE.parent / "payment_guard.py").read_text()
    assert "model_fields_set" not in guard_src and "environment_explicit" not in guard_src


@pytest.mark.parametrize("name", list(CASES))
def test_the_guard_decision_for_every_start_up_case(guard_for, name):
    """The same table tests/test_startup_hermetic.py feeds to a real child process, evaluated here against the real guard code."""
    env, must_contain = CASES[name]
    guard = guard_for(env)
    if must_contain is None:
        guard.assert_safe_payment_config()
        assert guard.payment_config_problems() == []
    else:
        with pytest.raises(RuntimeError, match="Refusing to start with an unsafe payment configuration") as e:
            guard.assert_safe_payment_config()
        assert must_contain in str(e.value)


def test_a_missing_environment_is_refused_even_when_everything_else_is_perfectly_safe(guard_for):
    guard = guard_for({"PAYMENTS_ENABLED": "false"})
    with pytest.raises(RuntimeError, match="ENVIRONMENT is missing or not recognised"):
        guard.assert_safe_payment_config()


def test_the_example_secret_is_refused_in_production_with_payments_disabled_and_enabled(guard_for):
    for enabled in ("false", "true"):
        env = {"ENVIRONMENT": "production", "PAYMENTS_ENABLED": enabled, "PAYMENT_PROVIDER": "somegateway", "PAYMENT_COMMISSION_CONFIRMED": "true",
               "PAYMENT_WEBHOOK_SECRET": EXAMPLE_SECRET}
        with pytest.raises(RuntimeError, match="known example value"):
            guard_for(env).assert_safe_payment_config()


def test_production_with_a_missing_secret_is_refused_whether_or_not_payments_are_enabled(guard_for):
    for enabled in ("false", "true"):
        env = {"ENVIRONMENT": "production", "PAYMENTS_ENABLED": enabled, "PAYMENT_PROVIDER": "somegateway", "PAYMENT_COMMISSION_CONFIRMED": "true"}
        with pytest.raises(RuntimeError, match="PAYMENT_WEBHOOK_SECRET is missing or empty"):
            guard_for(env).assert_safe_payment_config()


@pytest.mark.parametrize("case", M.CASES, ids=M.case_id)
def test_the_webhook_secret_matrix_through_the_real_guard(guard_for, case):
    """environment x payments x secret (30 cells) against the real guard code with a stand-in config. Same table as the child-process tests."""
    starts, must, must_not = M.startup(*case)
    guard = guard_for(M.env_vars(*case))
    if starts:
        guard.assert_safe_payment_config()
    else:
        with pytest.raises(RuntimeError, match="Refusing to start with an unsafe payment configuration") as e:
            guard.assert_safe_payment_config()
        assert must in str(e.value)
        if must_not:
            assert must_not not in str(e.value)


def test_a_strong_secret_in_production_with_payments_off_starts(guard_for):
    guard_for({"ENVIRONMENT": "production", "PAYMENT_WEBHOOK_SECRET": STRONG}).assert_safe_payment_config()
