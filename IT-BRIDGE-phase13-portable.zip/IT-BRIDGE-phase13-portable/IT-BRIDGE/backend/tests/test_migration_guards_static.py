"""Static checks on the downgrade guards of the migrations and on the policy table that drives the whole-path check. Standard library only: no database,
no Alembic, no SQLAlchemy.

What they protect. Every revision's `downgrade()` must start with `preflight_downgrade("<its revision>")` (app/core/migration_guard.py), which refuses a
run BEFORE any revision executes unless the operator authorised it. That check is only as good as POLICY, the table of what each revision discards:
a table or column that a migration drops but POLICY does not list would be dropped silently. These tests read the migration source and compare it
with POLICY, so that drift (a new revision, a new drop_table / drop_column, a statement in front of the pre-flight) is caught without a database.
The older per-revision guards of 0001, 0005 and 0006 (`_refuse_to_discard`) stay as a second line of defence and are checked here too.

What they do NOT prove: that the guards refuse at run time. That is scripts/check_migrations_static.py (a stub-Alembic replay on SQLite: not Alembic, not
PostgreSQL), tests/test_migration_guard.py (the policy logic with sqlite3 and a fake Alembic), tests/test_migrations.py (real Alembic on SQLite) and
tests/test_migrations_postgres.py (real Alembic on PostgreSQL; needs ITB_TEST_DATABASE_URL).
"""
import ast
import re
from pathlib import Path

import pytest

from app.core import migration_guard as mg

VERSIONS = Path(__file__).resolve().parent.parent / "alembic" / "versions"
GUARDED = {"0001": 19, "0005": 8, "0006": 1}   # revision -> how many tables it creates (0001: the 19 core tables, 0005: "eight new tables", 0006: "one new table")


def _tree(rev: str) -> ast.Module:
    (path,) = sorted(VERSIONS.glob(f"{rev}_*.py"))
    return ast.parse(path.read_text(encoding="utf-8"), str(path))


def _function(tree: ast.Module, name: str) -> ast.FunctionDef:
    return next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == name)


def _op_calls(fn: ast.FunctionDef, method: str) -> list[ast.Call]:
    return [n for n in ast.walk(fn) if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute) and n.func.attr == method
            and isinstance(n.func.value, ast.Name) and n.func.value.id == "op"]


def _first_string(call: ast.Call) -> str:
    arg = call.args[0]
    assert isinstance(arg, ast.Constant) and isinstance(arg.value, str), ast.dump(call)
    return arg.value


def _guard_call(stmt: ast.stmt):
    return stmt.value if isinstance(stmt, ast.Expr) and isinstance(stmt.value, ast.Call) and isinstance(stmt.value.func, ast.Name) \
        and stmt.value.func.id == "_refuse_to_discard" else None


def _body(rev: str) -> list[ast.stmt]:
    return [s for s in _function(_tree(rev), "downgrade").body if not (isinstance(s, ast.Expr) and isinstance(s.value, ast.Constant))]   # without a docstring


def _is_preflight(stmt: ast.stmt, rev: str) -> bool:
    return (isinstance(stmt, ast.Expr) and isinstance(stmt.value, ast.Call) and isinstance(stmt.value.func, ast.Name) and stmt.value.func.id == "preflight_downgrade"
            and len(stmt.value.args) == 1 and isinstance(stmt.value.args[0], ast.Constant) and stmt.value.args[0].value == rev and not stmt.value.keywords)


def _imports_the_guard(stmt: ast.stmt) -> bool:
    return isinstance(stmt, ast.ImportFrom) and stmt.module == "app.core.migration_guard" and [a.name for a in stmt.names] == ["preflight_downgrade"] and stmt.level == 0


def _revisions() -> list[str]:
    return [p.name.split("_")[0] for p in sorted(VERSIONS.glob("[0-9][0-9][0-9][0-9]_*.py"))]


@pytest.mark.parametrize("rev", _revisions())
def test_every_downgrade_starts_with_the_whole_path_preflight_for_its_own_revision(rev):
    """First statements of EVERY revision, not only the destructive ones: whichever revision is the first step of a run must check the whole run, and 0007
    (or a future head that drops nothing) is often that first step. The import sits inside downgrade() on purpose (next test)."""
    body = _body(rev)
    assert _imports_the_guard(body[0]) and _is_preflight(body[1], rev), f'{rev}: downgrade() must start with the guard import and preflight_downgrade("{rev}")'


@pytest.mark.parametrize("rev", _revisions())
def test_loading_a_migration_never_imports_the_application(rev):
    """`alembic heads`, `history`, `revision` and `show` load the migration files without running env.py; `app` need not be importable for them (it is
    already imported by the time a downgrade runs). An import of `app` at module level would make all of those commands depend on it."""
    top = [n for n in _tree(rev).body if isinstance(n, (ast.Import, ast.ImportFrom))]
    names = [a.name for n in top for a in n.names] + [n.module or "" for n in top if isinstance(n, ast.ImportFrom)]
    assert not [x for x in names if x == "app" or x.startswith("app.")], f"{rev}: imports the application at module level"


@pytest.mark.parametrize("rev", sorted(GUARDED))
def test_the_older_per_revision_guard_is_still_the_next_statement(rev):
    assert _guard_call(_body(rev)[2]) is not None, f"{rev}: _refuse_to_discard(...) must follow the pre-flight (second line of defence)"
    assert len(_op_calls(_function(_tree(rev), "downgrade"), "drop_table")) >= 1


def test_alembic_ini_puts_the_working_directory_on_the_path_so_env_py_can_import_the_application():
    """The `alembic` console script does not have the current directory on sys.path, and env.py imports `app`; ScriptDirectory.from_config prepends this entry."""
    import configparser
    cfg = configparser.ConfigParser()
    cfg.read(Path(__file__).resolve().parent.parent / "alembic.ini")
    assert cfg.get("alembic", "prepend_sys_path") == "." and cfg.get("alembic", "script_location") == "alembic"


def test_env_py_runs_the_whole_command_in_one_transaction_and_has_no_offline_branch():
    """The documentation and the refusal-leaves-nothing-changed claim for PostgreSQL rest on these facts about alembic/env.py: ONE `context.begin_transaction()` around
    `run_migrations()`, no `transaction_per_migration`, and no separate offline code path. (Whether PostgreSQL then rolls the DDL back is tests/test_migrations_postgres.py.)"""
    src = (Path(__file__).resolve().parent.parent / "alembic" / "env.py").read_text(encoding="utf-8")
    tree = ast.parse(src)
    calls = [n for n in ast.walk(tree) if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute)]
    assert [c.func.attr for c in calls].count("begin_transaction") == 1
    assert [c.func.attr for c in calls].count("run_migrations") == 1
    assert "transaction_per_migration" not in src and "is_offline_mode" not in src
    configure = [c for c in calls if c.func.attr == "configure"]
    assert len(configure) == 1 and {k.arg for k in configure[0].keywords} == {"connection", "target_metadata"}


def test_the_revision_template_starts_a_new_downgrade_with_the_preflight():
    """`alembic revision` renders this template; without the call a new revision would sit outside the guard until someone noticed."""
    src = (Path(__file__).resolve().parent.parent / "alembic" / "script.py.mako").read_text(encoding="utf-8")
    down = src[src.index("def downgrade"):]
    assert "from app.core.migration_guard import preflight_downgrade" in down and "preflight_downgrade(${repr(up_revision)})" in down
    assert down.index("preflight_downgrade(${repr(up_revision)})") < down.index("${downgrades")
    assert "migration_guard" not in src[:src.index("def downgrade")], "the import must stay inside downgrade()"


@pytest.mark.parametrize("rev,count", sorted(GUARDED.items()))
def test_the_guard_lists_exactly_the_tables_the_migration_creates(rev, count):
    tree = _tree(rev)
    created = {_first_string(c) for c in _op_calls(_function(tree, "upgrade"), "create_table")}
    guard = _guard_call([s for s in _function(tree, "downgrade").body if _guard_call(s) is not None][0])
    guarded = {a.value for a in guard.args if isinstance(a, ast.Constant)}
    assert len(created) == count, f"{rev} creates {sorted(created)}; update GUARDED if the migration really changed"
    assert guarded == created, f"{rev}: created but not guarded: {sorted(created - guarded)}; guarded but not created: {sorted(guarded - created)}"


@pytest.mark.parametrize("rev", sorted(GUARDED))
def test_every_table_the_downgrade_drops_is_one_the_guard_covers(rev):
    tree = _tree(rev)
    down = _function(tree, "downgrade")
    guard = _guard_call([s for s in down.body if _guard_call(s) is not None][0])
    guarded = {a.value for a in guard.args if isinstance(a, ast.Constant)}
    dropped = {_first_string(c) for c in _op_calls(down, "drop_table")}
    assert dropped and dropped <= guarded, f"{rev}: dropped without a guard: {sorted(dropped - guarded)}"


@pytest.mark.parametrize("rev", sorted(GUARDED))
def test_the_guard_refuses_offline_sql_and_only_the_documented_override_skips_it(rev):
    source = ast.unparse(next(n for n in _tree(rev).body if isinstance(n, ast.FunctionDef) and n.name == "_refuse_to_discard"))
    assert "context.is_offline_mode()" in source and "RuntimeError" in source             # `alembic downgrade --sql` cannot count rows, so it must refuse
    assert source.count("ITB_ALLOW_FINANCIAL_DOWNGRADE") >= 1
    assert "I_UNDERSTAND_DATA_WILL_BE_DESTROYED" in source and "COUNT(*)" in source


def test_the_trigger_migration_drops_no_table_so_it_needs_no_data_guard():
    down = _function(_tree("0007"), "downgrade")
    assert not _op_calls(down, "drop_table") and not _op_calls(down, "drop_column")        # only DROP TRIGGER / DROP FUNCTION IF EXISTS


def test_the_override_is_read_only_through_one_exact_value_in_every_guard():
    """The bypass must not be triggerable by an unrelated variable or a loose value ("1", "true", a prefix): every environment read in a guard is
    `os.environ.get("ITB_ALLOW_FINANCIAL_DOWNGRADE")`, and every test of its value is an exact comparison with the one full phrase. (0005 / 0006 read it twice,
    redundantly but consistently; those historical migrations are deliberately left as they were.)"""
    phrase = "I_UNDERSTAND_DATA_WILL_BE_DESTROYED"
    for rev in sorted(GUARDED):
        fn = next(n for n in _tree(rev).body if isinstance(n, ast.FunctionDef) and n.name == "_refuse_to_discard")
        gets = [n for n in ast.walk(fn) if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute) and n.func.attr == "get"
                and isinstance(n.func.value, ast.Attribute) and n.func.value.attr == "environ"]
        assert gets, f"{rev}: the guard has no bypass at all (or reads the environment another way)"
        assert all(len(g.args) == 1 and isinstance(g.args[0], ast.Constant) and g.args[0].value == "ITB_ALLOW_FINANCIAL_DOWNGRADE" for g in gets), \
            f"{rev}: the guard reads an environment variable other than ITB_ALLOW_FINANCIAL_DOWNGRADE (or with a default)"
        assert len([n for n in ast.walk(fn) if isinstance(n, ast.Attribute) and n.attr == "environ"]) == len(gets), f"{rev}: environ is used other than through .get(name)"
        compared = [n for n in ast.walk(fn) if isinstance(n, ast.Compare) and any(isinstance(c, ast.Constant) and c.value == phrase for c in n.comparators)]
        assert compared and all(isinstance(o, (ast.Eq, ast.NotEq)) for n in compared for o in n.ops), f"{rev}: the switch must be an exact ==/!= comparison with the full phrase"


# ---------- the policy table (app/core/migration_guard.py) against the migration files ----------
def _assigned(rev: str, name: str):
    node = next(n for n in _tree(rev).body if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == name for t in n.targets))
    return node.value.value


def _dropped_columns(rev: str) -> dict[str, set[str]]:
    """{table: {column}} removed by downgrade(): `batch.drop_column(name)` inside `with op.batch_alter_table("t") as batch`, or `op.drop_column("t", name)`."""
    out: dict[str, set[str]] = {}
    down = _function(_tree(rev), "downgrade")
    for w in (n for n in ast.walk(down) if isinstance(n, ast.With)):
        for item in w.items:
            call = item.context_expr
            if isinstance(call, ast.Call) and isinstance(call.func, ast.Attribute) and call.func.attr == "batch_alter_table":
                table, var = call.args[0].value, item.optional_vars.id
                for c in (n for n in ast.walk(w) if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute) and n.func.attr == "drop_column"
                          and isinstance(n.func.value, ast.Name) and n.func.value.id == var):
                    arg = c.args[0]
                    if isinstance(arg, ast.Constant):
                        out.setdefault(table, set()).add(arg.value)
                    else:                                                                       # `for name in (...)`: take the literal tuple the loop walks
                        loop = next(n for n in ast.walk(w) if isinstance(n, ast.For))
                        out.setdefault(table, set()).update(e.value for e in loop.iter.elts)
    for c in _op_calls(down, "drop_column"):
        out.setdefault(c.args[0].value, set()).add(c.args[1].value)
    return out


def test_the_policy_chain_is_the_real_linear_migration_chain():
    order, rev = [], next(r for r in _revisions() if _assigned(r, "down_revision") is None)
    while rev:
        order.append(rev)
        rev = next((r for r in _revisions() if _assigned(r, "down_revision") == order[-1]), None)
    assert _revisions() == order, "the migrations are not one linear chain in file order"
    assert tuple(order) == mg.CHAIN, f"app/core/migration_guard.py CHAIN {mg.CHAIN} differs from the migrations {tuple(order)}"
    assert set(mg.POLICY) == set(mg.CHAIN), "every revision needs a POLICY entry (an empty Discard() if it drops no data)"


@pytest.mark.parametrize("rev", _revisions())
def test_the_policy_names_exactly_the_tables_and_columns_each_downgrade_removes(rev):
    down = _function(_tree(rev), "downgrade")
    dropped_tables = {_first_string(c) for c in _op_calls(down, "drop_table")}
    policy_tables = set(mg.POLICY[rev].tables)
    assert dropped_tables == policy_tables, f"{rev}: drops tables {sorted(dropped_tables)}, POLICY lists {sorted(policy_tables)}"
    policy_columns = {t: set(cols) for t, cols in mg.POLICY[rev].columns}
    assert _dropped_columns(rev) == policy_columns, f"{rev}: drops columns {_dropped_columns(rev)}, POLICY lists {policy_columns}"


@pytest.mark.parametrize("rev", ["0002", "0003"])
def test_the_column_migrations_discard_exactly_the_columns_their_upgrade_added(rev):
    tree, up = _tree(rev), _function(_tree(rev), "upgrade")
    looped: set[str] = set()                                   # 0002 adds four columns in `for name, typ in REQUIRED:`; take the names from that literal list
    for assign in (n for n in tree.body if isinstance(n, ast.Assign) and isinstance(n.value, ast.List)):
        looped |= {e.elts[0].value for e in assign.value.elts if isinstance(e, ast.Tuple) and isinstance(e.elts[0], ast.Constant)}
    added: dict[str, set[str]] = {}
    for c in _op_calls(up, "add_column"):
        name = c.args[1].args[0]
        added.setdefault(c.args[0].value, set()).update({name.value} if isinstance(name, ast.Constant) else looped)
    assert added and {t: set(c) for t, c in mg.POLICY[rev].columns} == added, f"{rev}: what the upgrade added and what POLICY says the downgrade discards have drifted apart"


def test_the_tables_each_migration_creates_are_all_in_the_policy_of_that_migration():
    for rev in ("0001", "0004", "0005", "0006"):
        created = {_first_string(c) for c in _op_calls(_function(_tree(rev), "upgrade"), "create_table")}
        assert created == set(mg.POLICY[rev].tables), rev
    for rev in ("0002", "0003", "0007"):
        assert not _op_calls(_function(_tree(rev), "upgrade"), "create_table"), f"{rev} now creates a table: its downgrade must drop it and POLICY must list it"


@pytest.mark.parametrize("rev", _revisions())
def test_no_downgrade_deletes_data_in_a_way_the_policy_cannot_see(rev):
    """Only drop_table / drop_column are modelled. Raw SQL that deletes rows, truncates, or drops a table or column would bypass the policy."""
    down = _function(_tree(rev), "downgrade")
    text = " ".join(n.value for n in ast.walk(down) if isinstance(n, ast.Constant) and isinstance(n.value, str)).upper()
    assert not re.search(r"\b(DELETE|TRUNCATE|DROP\s+TABLE|DROP\s+COLUMN|DROP\s+SCHEMA|DROP\s+DATABASE)\b", text), f"{rev}: raw destructive SQL in downgrade()"
    assert not _op_calls(down, "execute") or rev == "0007", f"{rev}: downgrade() runs raw SQL; check what it discards and extend this test"
    assert not any(isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute) and n.func.attr in ("alter_column", "drop_constraint") and rev != "0007" for n in ast.walk(down)), \
        f"{rev}: downgrade() alters a column or constraint; the policy does not model that"


def test_the_switch_and_phrase_are_the_documented_literals_and_nothing_else_reads_the_environment():
    tree = ast.parse(Path(mg.__file__).read_text(encoding="utf-8"))
    consts = {n.targets[0].id: n.value.value for n in tree.body if isinstance(n, ast.Assign) and isinstance(n.targets[0], ast.Name) and isinstance(n.value, ast.Constant)}
    assert consts["SWITCH"] == "ITB_ALLOW_FINANCIAL_DOWNGRADE" and consts["PHRASE"] == "I_UNDERSTAND_DATA_WILL_BE_DESTROYED"
    reads = [n for n in ast.walk(tree) if isinstance(n, ast.Attribute) and n.attr == "environ"]          # every os.environ in the module
    fn = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == "override_enabled")
    inside = [n for n in ast.walk(fn) if isinstance(n, ast.Attribute) and n.attr == "environ"]
    assert reads and len(reads) == len(inside), "os.environ is read outside override_enabled: the switch must have exactly one reader"
    equal = [n for n in ast.walk(fn) if isinstance(n, ast.Compare) and any(isinstance(o, (ast.Eq, ast.In, ast.NotEq, ast.NotIn)) for o in n.ops)]      # (`environ is None` is fine)
    assert len(equal) == 1 and isinstance(equal[0].ops[0], ast.Eq) and isinstance(equal[0].comparators[0], ast.Name) and equal[0].comparators[0].id == "PHRASE", \
        "override_enabled must be one exact == comparison with PHRASE"
    assert any(isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute) and n.func.attr == "get" and n.args and isinstance(n.args[0], ast.Name) and n.args[0].id == "SWITCH"
               for n in ast.walk(equal[0])), "override_enabled must read the SWITCH variable and no other"

