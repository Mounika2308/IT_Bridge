from datetime import datetime, time, timedelta

from app.core.clock import today
from app.core.database import get_db
from app.main import app
from app.models.audit import AuditLog
from app.models.requirement import TrainingRequirement
from app.models.user import Skill

D = today()


def reg(client, email, role="TRAINER", **extra):
    body = {"full_name": email.split("@")[0].title(), "email": email, "password": "Passw0rd123", "role": role, **extra}
    d = client.post("/api/v1/auth/register", json=body).json()["data"]
    return {"Authorization": f"Bearer {d['access_token']}"}


def db_of(client):
    return next(app.dependency_overrides[get_db]())


def trainer(client, email="t@example.com", complete=True):
    h = reg(client, email)
    if complete:
        client.put("/api/v1/trainers/me", headers=h, json={"headline": "Python trainer", "location": "Pune", "experience_years": 5,
                                                          "training_mode": "OFFLINE", "expected_fee": 4000, "skill_ids": [1]})
    return h


def institution(client, email="i@example.com", name="Sunrise College"):
    return reg(client, email, "INSTITUTION", institution_name=name)


def post_req(client, ih):
    body = dict(title="Python workshop for 3rd years", technology="Python", description="x" * 40, skill_ids=[1], student_count=60,
                student_level="BEGINNER", duration_days=10, sessions=10, location="Pune", mode="OFFLINE",
                start_date=str(D + timedelta(days=30)), end_date=str(D + timedelta(days=40)), budget_min=20000,
                budget_max=50000, application_deadline=str(D + timedelta(days=20)))
    return client.post("/api/v1/requirements", headers=ih, json=body).json()["data"]["id"]


def world(client):
    db = db_of(client)
    db.add(Skill(name="Python"))
    db.commit()
    th, ih = trainer(client), institution(client)
    return th, ih, post_req(client, ih)


def apply(client, th, rid, **body):
    return client.post(f"/api/v1/requirements/{rid}/apply", headers=th, json=body)


def test_apply_and_duplicate_blocked(client):
    th, ih, rid = world(client)
    assert apply(client, th, rid, cover_note="Hello").status_code == 201
    assert apply(client, th, rid).status_code == 409
    assert len(client.get("/api/v1/applications/mine", headers=th).json()["data"]) == 1


def test_profile_must_be_complete_and_only_trainers_apply(client):
    th, ih, rid = world(client)
    bare = trainer(client, "bare@example.com", complete=False)
    assert apply(client, bare, rid).status_code == 422
    assert apply(client, ih, rid).status_code == 403


def test_cannot_apply_to_closed_or_expired(client):
    th, ih, rid = world(client)
    db = db_of(client)
    db.query(TrainingRequirement).update({"application_deadline": D - timedelta(days=1)})
    db.commit()
    assert apply(client, th, rid).status_code == 409
    db.query(TrainingRequirement).update({"application_deadline": D + timedelta(days=5)})
    db.commit()
    client.post(f"/api/v1/requirements/{rid}/close", headers=ih)
    assert apply(client, th, rid).status_code == 409


def test_withdraw_and_reapply_reuses_row(client):
    th, ih, rid = world(client)
    aid = apply(client, th, rid).json()["data"]["id"]
    assert client.post(f"/api/v1/applications/{aid}/withdraw", headers=th).json()["data"]["status"] == "WITHDRAWN"
    assert client.post(f"/api/v1/applications/{aid}/withdraw", headers=th).status_code == 409
    again = apply(client, th, rid)
    assert again.status_code == 201 and again.json()["data"]["id"] == aid and again.json()["data"]["status"] == "APPLIED"


def test_institution_sees_ranked_applications_with_explanation(client):
    th, ih, rid = world(client)
    apply(client, th, rid, proposed_fee=45000)
    items = client.get(f"/api/v1/requirements/{rid}/applications", headers=ih).json()["data"]
    assert items[0]["score"] > 80 and items[0]["factors"] and "email" not in str(items[0]["trainer"])
    other = institution(client, "o@example.com", "Other")
    assert client.get(f"/api/v1/requirements/{rid}/applications", headers=other).status_code == 404


def test_status_transitions_enforced(client):
    th, ih, rid = world(client)
    aid = apply(client, th, rid).json()["data"]["id"]
    when = (datetime.combine(today() + timedelta(days=3), time(14, 30))).isoformat()
    move = lambda s, h=ih, **extra: client.patch(f"/api/v1/applications/{aid}/status", headers=h, json={"status": s, **extra})
    assert move("INTERVIEW", interview_at=when).status_code == 409   # cannot skip shortlisting
    assert move("SELECTED").status_code == 422         # selection only through hire
    assert move("SHORTLISTED").status_code == 200
    assert move("INTERVIEW").status_code == 422                       # an interview needs a date and time
    assert move("INTERVIEW", interview_at=when).status_code == 200
    assert move("SHORTLISTED", th).status_code == 403  # trainers cannot change status


def test_full_hiring_flow_and_contact_reveal(client):
    th, ih, rid = world(client)
    aid = apply(client, th, rid).json()["data"]["id"]
    assert client.post(f"/api/v1/applications/{aid}/hire", headers=ih, json={"agreed_fee": 40000}).status_code == 409  # not shortlisted
    client.patch(f"/api/v1/applications/{aid}/status", headers=ih, json={"status": "SHORTLISTED"})
    hire = client.post(f"/api/v1/applications/{aid}/hire", headers=ih, json={"agreed_fee": 40000, "terms": "Travel covered"})
    assert hire.status_code == 201
    hid = hire.json()["data"]["id"]
    assert hire.json()["data"]["contact"] is None
    seen = client.get("/api/v1/hiring-requests/mine", headers=th).json()["data"]
    assert seen[0]["status"] == "PENDING" and seen[0]["contact"] is None
    acc = client.post(f"/api/v1/hiring-requests/{hid}/accept", headers=th).json()["data"]
    assert acc["status"] == "ACCEPTED" and acc["contact"]["email"] == "i@example.com"
    inst_view = client.get("/api/v1/hiring-requests/mine", headers=ih).json()["data"][0]
    assert inst_view["contact"]["email"] == "t@example.com"
    assert client.post(f"/api/v1/hiring-requests/{hid}/accept", headers=th).status_code == 409


def test_decline_and_cancel_paths(client):
    th, ih, rid = world(client)
    aid = apply(client, th, rid).json()["data"]["id"]
    client.patch(f"/api/v1/applications/{aid}/status", headers=ih, json={"status": "SHORTLISTED"})
    hid = client.post(f"/api/v1/applications/{aid}/hire", headers=ih, json={"agreed_fee": 40000}).json()["data"]["id"]
    assert client.post(f"/api/v1/applications/{aid}/hire", headers=ih, json={"agreed_fee": 1}).status_code == 409  # already selected
    client.post(f"/api/v1/hiring-requests/{hid}/decline", headers=th)
    mine = client.get("/api/v1/applications/mine", headers=th).json()["data"][0]
    assert mine["status"] == "WITHDRAWN" and mine["hiring_request"]["status"] == "DECLINED"


def test_institution_cancel_returns_to_shortlist_and_can_reissue(client):
    th, ih, rid = world(client)
    aid = apply(client, th, rid).json()["data"]["id"]
    client.patch(f"/api/v1/applications/{aid}/status", headers=ih, json={"status": "SHORTLISTED"})
    hid = client.post(f"/api/v1/applications/{aid}/hire", headers=ih, json={"agreed_fee": 40000}).json()["data"]["id"]
    assert client.post(f"/api/v1/hiring-requests/{hid}/cancel", headers=ih).json()["data"]["status"] == "CANCELLED"
    again = client.post(f"/api/v1/applications/{aid}/hire", headers=ih, json={"agreed_fee": 42000})
    assert again.status_code == 201 and again.json()["data"]["id"] == hid and again.json()["data"]["status"] == "PENDING"


def test_closing_requirement_rejects_open_applications_and_cancels_pending_hire(client):
    th, ih, rid = world(client)
    aid = apply(client, th, rid).json()["data"]["id"]
    client.post(f"/api/v1/requirements/{rid}/close", headers=ih)
    assert client.get("/api/v1/applications/mine", headers=th).json()["data"][0]["status"] == "REJECTED"


def test_other_trainer_cannot_touch_application(client):
    th, ih, rid = world(client)
    aid = apply(client, th, rid).json()["data"]["id"]
    other = trainer(client, "x@example.com")
    assert client.post(f"/api/v1/applications/{aid}/withdraw", headers=other).status_code == 404


def test_audit_trail_written(client):
    th, ih, rid = world(client)
    aid = apply(client, th, rid).json()["data"]["id"]
    client.patch(f"/api/v1/applications/{aid}/status", headers=ih, json={"status": "SHORTLISTED"})
    actions = {a.action for a in db_of(client).query(AuditLog).all()}
    assert {"REQUIREMENT_CREATED", "APPLICATION_SUBMITTED", "APPLICATION_STATUS_CHANGED"} <= actions
