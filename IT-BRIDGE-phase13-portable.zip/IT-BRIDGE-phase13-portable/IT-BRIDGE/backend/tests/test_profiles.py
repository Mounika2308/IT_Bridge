from app.models.user import Skill

TRAINER = {"full_name": "Asha Rao", "email": "asha@example.com", "password": "Passw0rd123", "role": "TRAINER"}
INST = {"full_name": "Ravi K", "email": "ravi@example.com", "password": "Passw0rd123", "role": "INSTITUTION",
        "institution_name": "Sunrise Engineering College"}


def auth(client, body):
    d = client.post("/api/v1/auth/register", json=body).json()["data"]
    return {"Authorization": f"Bearer {d['access_token']}"}


def seed(client):
    from app.main import app
    from app.core.database import get_db
    db = next(app.dependency_overrides[get_db]())
    db.add_all([Skill(name="Python"), Skill(name="React")])
    db.commit()


def test_trainer_profile_completion_grows(client):
    seed(client)
    h = auth(client, TRAINER)
    assert client.get("/api/v1/trainers/me", headers=h).json()["data"]["completion"] == 0
    r = client.put("/api/v1/trainers/me", headers=h, json={
        "headline": "Python trainer", "location": "Pune", "experience_years": 5, "skill_ids": [1, 2],
        "languages": ["English", "english", "Hindi"]})
    d = r.json()["data"]
    assert d["completion"] == 50
    assert d["languages"] == ["English", "Hindi"]
    assert len(d["skills"]) == 2


def test_unknown_skill_rejected(client):
    h = auth(client, TRAINER)
    assert client.put("/api/v1/trainers/me", headers=h, json={"skill_ids": [99]}).status_code == 422


def test_institution_cannot_edit_trainer_profile(client):
    h = auth(client, INST)
    assert client.put("/api/v1/trainers/me", headers=h, json={"headline": "x"}).status_code == 403


def test_public_profile_hides_contact_details(client):
    th = auth(client, TRAINER)
    ih = auth(client, INST)
    r = client.get("/api/v1/trainers/1", headers=ih)
    assert r.status_code == 200
    assert "asha@example.com" not in r.text and "phone" not in r.text
    assert r.json()["data"]["verified"] is False


def test_institution_profile_update(client):
    h = auth(client, INST)
    r = client.put("/api/v1/institutions/me", headers=h, json={"location": "Hyderabad", "website": "https://sunrise.edu"})
    assert r.json()["data"]["location"] == "Hyderabad"
    assert client.put("/api/v1/institutions/me", headers=h, json={"website": "javascript:alert(1)"}).status_code == 422


def test_only_admin_can_create_skill(client):
    h = auth(client, TRAINER)
    assert client.post("/api/v1/skills", headers=h, json={"name": "Go"}).status_code == 403
