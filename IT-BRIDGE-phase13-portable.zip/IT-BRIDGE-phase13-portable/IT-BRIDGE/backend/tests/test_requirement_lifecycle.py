"""Requirement lifecycle. OPEN -> FILLED when the trainer accepts the hiring request. FILLED -> OPEN again only if that training is
cancelled BEFORE it starts. CLOSED, EXPIRED and completed trainings keep behaving as before."""
from datetime import datetime, time, timedelta

from app.core.clock import today
from app.models.application import Application, HiringRequest
from app.models.audit import AuditLog
from app.models.requirement import TrainingRequirement
from app.models.user import Skill
from tests.test_trainings import END, START, begin, db_of, reg, req_body

PROFILE = {"headline": "Python trainer", "location": "Pune", "experience_years": 5, "training_mode": "OFFLINE", "expected_fee": 4000, "skill_ids": [1]}


def when(days=3):
    return datetime.combine(today() + timedelta(days=days), time(14, 30)).isoformat()


def trainer(client, letter):
    h = reg(client, f"{letter}@example.com")
    assert client.put("/api/v1/trainers/me", headers=h, json=PROFILE).status_code == 200
    return h


def apply(client, h, rid):
    return client.post(f"/api/v1/requirements/{rid}/apply", headers=h, json={})


def move(client, ih, aid, status, **extra):
    return client.patch(f"/api/v1/applications/{aid}/status", headers=ih, json={"status": status, **extra})


def hire(client, ih, aid):
    return client.post(f"/api/v1/applications/{aid}/hire", headers=ih, json={"agreed_fee": 40000})


def state(client, ih, rid):
    return client.get(f"/api/v1/requirements/{rid}", headers=ih).json()["data"]["status"]


def training_id(client, h):
    return client.get("/api/v1/trainings/mine", headers=h).json()["data"]["items"][0]["id"]


def audit_count(client, action):
    return db_of(client).query(AuditLog).filter(AuditLog.action == action).count()


def world(client):
    """Requirement R with three applicants: A and B shortlisted, C only APPLIED. Nobody is hired yet."""
    db = db_of(client)
    db.add(Skill(name="Python"))
    db.commit()
    ta, tb, tc = trainer(client, "a"), trainer(client, "b"), trainer(client, "c")
    ih = reg(client, "i@example.com", "INSTITUTION", institution_name="Sunrise College")
    rid = client.post("/api/v1/requirements", headers=ih, json=req_body()).json()["data"]["id"]
    aid = {k: apply(client, h, rid).json()["data"]["id"] for k, h in (("a", ta), ("b", tb), ("c", tc))}
    for k in ("a", "b"):
        assert move(client, ih, aid[k], "SHORTLISTED").status_code == 200
    return ta, tb, tc, ih, rid, aid


def fill(client, ih, ta, aid_a):
    """Hire A and have A accept. Returns (hiring request id, training id)."""
    hid = hire(client, ih, aid_a).json()["data"]["id"]
    assert client.post(f"/api/v1/hiring-requests/{hid}/accept", headers=ta).status_code == 200
    return hid, training_id(client, ta)


# ---------- accept -> FILLED ----------
def test_accepting_the_hire_fills_the_requirement(client):
    ta, tb, tc, ih, rid, aid = world(client)
    assert state(client, ih, rid) == "OPEN"
    hid = hire(client, ih, aid["a"]).json()["data"]["id"]
    assert state(client, ih, rid) == "OPEN"                                   # a pending request does not fill it yet
    client.post(f"/api/v1/hiring-requests/{hid}/accept", headers=ta)
    assert state(client, ih, rid) == "FILLED"
    mine = client.get("/api/v1/requirements/mine", headers=ih).json()["data"]["items"]
    assert [r["status"] for r in mine] == ["FILLED"]
    assert client.get("/api/v1/requirements", headers=tc).json()["data"]["total"] == 0        # gone from trainer discovery
    assert client.get(f"/api/v1/requirements/{rid}", headers=tc).status_code == 404          # and from other trainers' detail view
    assert audit_count(client, "REQUIREMENT_FILLED") == 1


def test_declined_or_cancelled_hiring_does_not_fill_the_requirement(client):
    ta, tb, tc, ih, rid, aid = world(client)
    hid = hire(client, ih, aid["a"]).json()["data"]["id"]
    client.post(f"/api/v1/hiring-requests/{hid}/decline", headers=ta)
    assert state(client, ih, rid) == "OPEN"
    hid = hire(client, ih, aid["b"]).json()["data"]["id"]
    client.post(f"/api/v1/hiring-requests/{hid}/cancel", headers=ih)
    assert state(client, ih, rid) == "OPEN"


# ---------- FILLED rejects new applications, hires and further processing ----------
def test_filled_requirement_rejects_new_applications(client):
    ta, tb, tc, ih, rid, aid = world(client)
    fill(client, ih, ta, aid["a"])
    td = trainer(client, "d")
    r = apply(client, td, rid)
    assert r.status_code == 409 and "filled" in r.json()["message"].lower()
    assert db_of(client).query(Application).filter(Application.requirement_id == rid).count() == 3     # nothing was created


def test_filled_requirement_prevents_another_hire(client):
    ta, tb, tc, ih, rid, aid = world(client)
    hid = hire(client, ih, aid["a"]).json()["data"]["id"]
    assert hire(client, ih, aid["b"]).status_code == 409                     # already in progress while A is pending
    client.post(f"/api/v1/hiring-requests/{hid}/accept", headers=ta)
    r = hire(client, ih, aid["b"])
    assert r.status_code == 409 and "filled" in r.json()["message"].lower()
    assert db_of(client).query(HiringRequest).count() == 1


def test_non_selected_applications_cannot_continue_after_filling(client):
    ta, tb, tc, ih, rid, aid = world(client)
    fill(client, ih, ta, aid["a"])
    for k in ("b", "c"):                                                     # B shortlisted, C only applied: neither can move on
        for status, extra in (("UNDER_REVIEW", {}), ("SHORTLISTED", {}), ("REJECTED", {}), ("INTERVIEW", {"interview_at": when()})):
            assert move(client, ih, aid[k], status, **extra).status_code == 409, (k, status)
    assert hire(client, ih, aid["b"]).status_code == 409
    listed = client.get(f"/api/v1/requirements/{rid}/applications", headers=ih).json()["data"]
    by_id = {x["id"]: x for x in listed}
    assert {x["requirement_status"] for x in listed} == {"FILLED"}            # the UI is told, the server enforces it anyway
    assert by_id[aid["a"]]["status"] == "SELECTED" and by_id[aid["b"]]["status"] == "SHORTLISTED"   # nothing was destroyed
    mine_b = client.get("/api/v1/applications/mine", headers=tb).json()["data"][0]
    assert mine_b["requirement"]["status"] == "FILLED"
    assert client.post(f"/api/v1/applications/{aid['b']}/withdraw", headers=tb).status_code == 200  # a trainer may still step back


def test_the_selected_trainers_flow_keeps_working(client):
    ta, tb, tc, ih, rid, aid = world(client)
    hid, tid = fill(client, ih, ta, aid["a"])
    assert client.get(f"/api/v1/trainings/{tid}", headers=ih).json()["data"]["phase"] == "UPCOMING"
    sid = client.post(f"/api/v1/trainings/{tid}/sessions", headers=ta, json={"title": "Day 1", "session_date": str(START), "start_time": "10:00", "end_time": "12:00"})
    assert sid.status_code == 201
    begin(client, tid)
    assert client.post(f"/api/v1/trainings/{tid}/complete", headers=ih).status_code == 200
    assert state(client, ih, rid) == "FILLED"                                # completion never reopens it


# ---------- cancellation: before the start reopens, after the start does not ----------
def reopen_scenario(client, cancelled_by):
    ta, tb, tc, ih, rid, aid = world(client)
    hid, tid = fill(client, ih, ta, aid["a"])
    who = ta if cancelled_by == "trainer" else ih
    assert client.post(f"/api/v1/trainings/{tid}/cancel", headers=who, json={"reason": "Changed plans"}).status_code == 200
    assert state(client, ih, rid) == "OPEN"
    # the institution can continue: B (still shortlisted) is actionable again and can be hired
    assert move(client, ih, aid["b"], "INTERVIEW", interview_at=when()).status_code == 200
    # eligible trainers can apply again
    td = trainer(client, "d")
    assert apply(client, td, rid).status_code == 201
    assert client.get("/api/v1/requirements", headers=td).json()["data"]["total"] == 1
    hb = hire(client, ih, aid["b"])
    assert hb.status_code == 201
    assert client.post(f"/api/v1/hiring-requests/{hb.json()['data']['id']}/accept", headers=tb).status_code == 200
    assert state(client, ih, rid) == "FILLED"                                # filled again by the next trainer
    assert client.get("/api/v1/trainings/mine", headers=tb).json()["data"]["total"] == 1
    # the application behind the cancelled training stays as history; that trainer cannot simply re-apply
    assert db_of(client).get(Application, aid["a"]).status == "SELECTED"
    assert apply(client, ta, rid).status_code == 409
    assert audit_count(client, "REQUIREMENT_REOPENED") == 1 and audit_count(client, "REQUIREMENT_FILLED") == 2


def test_trainer_cancelling_before_the_start_reopens_the_requirement(client):
    reopen_scenario(client, "trainer")


def test_institution_cancelling_before_the_start_reopens_the_requirement(client):
    reopen_scenario(client, "institution")


def test_cancelling_after_the_start_does_not_reopen_the_requirement(client):
    ta, tb, tc, ih, rid, aid = world(client)
    hid, tid = fill(client, ih, ta, aid["a"])
    begin(client, tid)                                                        # the training has started
    assert client.post(f"/api/v1/trainings/{tid}/cancel", headers=ih, json={}).status_code == 200
    assert state(client, ih, rid) == "FILLED"
    assert apply(client, trainer(client, "d"), rid).status_code == 409
    assert hire(client, ih, aid["b"]).status_code == 409
    assert move(client, ih, aid["b"], "REJECTED").status_code == 409
    assert audit_count(client, "REQUIREMENT_REOPENED") == 0


def test_a_manually_closed_requirement_is_not_reopened(client):
    ta, tb, tc, ih, rid, aid = world(client)
    hid, tid = fill(client, ih, ta, aid["a"])
    assert client.post(f"/api/v1/requirements/{rid}/close", headers=ih).status_code == 200
    assert state(client, ih, rid) == "CLOSED"
    client.post(f"/api/v1/trainings/{tid}/cancel", headers=ta, json={})
    assert state(client, ih, rid) == "CLOSED"                                # closing was the institution's own decision
    assert apply(client, trainer(client, "d"), rid).status_code == 409


# ---------- existing states keep behaving ----------
def test_closed_requirement_behaviour_is_unchanged(client):
    ta, tb, tc, ih, rid, aid = world(client)
    assert client.post(f"/api/v1/requirements/{rid}/close", headers=ih).status_code == 200
    assert apply(client, trainer(client, "d"), rid).status_code == 409
    assert hire(client, ih, aid["b"]).status_code == 409                     # B was rejected by the close
    assert move(client, ih, aid["c"], "SHORTLISTED").status_code == 409
    assert client.put(f"/api/v1/requirements/{rid}", headers=ih, json=req_body()).status_code == 409


def test_an_expired_requirement_stays_workable_for_the_institution(client):
    ta, tb, tc, ih, rid, aid = world(client)
    db = db_of(client)
    db.get(TrainingRequirement, rid).application_deadline = today() - timedelta(days=1)
    db.commit()
    assert state(client, ih, rid) == "EXPIRED"
    td = trainer(client, "d")
    r = apply(client, td, rid)
    assert r.status_code == 409 and "no longer accepting" in r.json()["message"]          # no new applications...
    hid, tid = fill(client, ih, ta, aid["a"])                                              # ...but hiring still works
    assert db_of(client).get(TrainingRequirement, rid).status == "FILLED"
    client.post(f"/api/v1/trainings/{tid}/cancel", headers=ta, json={})
    assert state(client, ih, rid) == "EXPIRED"                                             # reopened (stored OPEN), still past its deadline
    assert apply(client, td, rid).status_code == 409                                       # nobody new can apply
    assert move(client, ih, aid["c"], "SHORTLISTED").status_code == 200                    # but the institution continues with its applicants
    hc = hire(client, ih, aid["c"])
    assert hc.status_code == 201
    assert client.post(f"/api/v1/hiring-requests/{hc.json()['data']['id']}/accept", headers=tc).status_code == 200
    assert db_of(client).get(TrainingRequirement, rid).status == "FILLED"


# ---------- authorization ----------
def test_unauthorized_users_cannot_change_the_lifecycle(client):
    ta, tb, tc, ih, rid, aid = world(client)
    other = reg(client, "o@example.com", "INSTITUTION", institution_name="Other College")
    hid = hire(client, ih, aid["a"]).json()["data"]["id"]
    assert client.post(f"/api/v1/hiring-requests/{hid}/accept", headers=tb).status_code == 404       # not B's request
    assert client.post(f"/api/v1/hiring-requests/{hid}/accept", headers=ih).status_code == 403       # the institution does not accept
    assert client.post(f"/api/v1/hiring-requests/{hid}/accept").status_code == 401
    assert client.post(f"/api/v1/requirements/{rid}/close", headers=ta).status_code == 403            # trainers cannot close
    assert client.post(f"/api/v1/requirements/{rid}/close", headers=other).status_code == 404
    assert client.put(f"/api/v1/requirements/{rid}", headers=other, json=req_body()).status_code == 404
    assert hire(client, other, aid["b"]).status_code == 404
    assert move(client, other, aid["c"], "SHORTLISTED").status_code == 404
    client.post(f"/api/v1/hiring-requests/{hid}/accept", headers=ta)
    tid = training_id(client, ta)
    for h in (tb, other):                                                                            # outsiders cannot cancel (and so cannot reopen)
        assert client.post(f"/api/v1/trainings/{tid}/cancel", headers=h, json={}).status_code == 404
    assert state(client, ih, rid) == "FILLED"


def test_status_cannot_be_set_through_the_requirement_form(client):
    ta, tb, tc, ih, rid, aid = world(client)
    r = client.put(f"/api/v1/requirements/{rid}", headers=ih, json={**req_body(), "status": "FILLED"})
    assert r.status_code == 200 and state(client, ih, rid) == "OPEN"          # unknown fields are ignored
    fill(client, ih, ta, aid["a"])
    r = client.put(f"/api/v1/requirements/{rid}", headers=ih, json={**req_body(), "status": "OPEN"})
    assert r.status_code == 409 and state(client, ih, rid) == "FILLED"


# ---------- duplicate / concurrent actions ----------
def test_duplicate_actions_cannot_double_fill_or_double_reopen(client):
    ta, tb, tc, ih, rid, aid = world(client)
    hid, tid = fill(client, ih, ta, aid["a"])
    assert client.post(f"/api/v1/hiring-requests/{hid}/accept", headers=ta).status_code == 409        # accepting twice
    assert client.get("/api/v1/trainings/mine", headers=ta).json()["data"]["total"] == 1
    assert audit_count(client, "REQUIREMENT_FILLED") == 1
    assert client.post(f"/api/v1/trainings/{tid}/cancel", headers=ta, json={}).status_code == 200
    assert client.post(f"/api/v1/trainings/{tid}/cancel", headers=ta, json={}).status_code == 409    # cancelling twice
    assert client.post(f"/api/v1/trainings/{tid}/cancel", headers=ih, json={}).status_code == 409
    assert state(client, ih, rid) == "OPEN" and audit_count(client, "REQUIREMENT_REOPENED") == 1


def test_a_second_accept_that_slipped_through_is_refused_by_the_server(client):
    """Simulates the race the row lock exists for: a second PENDING request for an already FILLED requirement."""
    ta, tb, tc, ih, rid, aid = world(client)
    fill(client, ih, ta, aid["a"])
    db = db_of(client)
    b_app = db.get(Application, aid["b"])
    ghost = HiringRequest(application_id=b_app.id, requirement_id=rid, trainer_id=b_app.trainer_id, agreed_fee=1, start_date=START, end_date=END, sessions=3, status="PENDING")
    db.add(ghost)
    db.commit()
    r = client.post(f"/api/v1/hiring-requests/{ghost.id}/accept", headers=tb)
    assert r.status_code == 409
    assert client.get("/api/v1/trainings/mine", headers=tb).json()["data"]["total"] == 0                # no second training
    assert db_of(client).get(HiringRequest, ghost.id).status == "CANCELLED"
    assert state(client, ih, rid) == "FILLED"
