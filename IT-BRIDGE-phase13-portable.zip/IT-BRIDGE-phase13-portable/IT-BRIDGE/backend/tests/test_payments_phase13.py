"""Phase 13 API tests: payments, webhooks, invoices, refunds, trainer earnings, payouts and their notifications.

Everything runs against the sandbox provider: NO REAL MONEY and no network. These tests need the full dependency set (pytest, FastAPI,
SQLAlchemy); the SQLite test database cannot show PostgreSQL row-lock behaviour, so simultaneous requests are NOT exercised here (the
unique indexes that back them are: see the last section). The pure rules are in test_payment_rules.py.
"""
import logging
import re
import time
import uuid
from datetime import timedelta
from pathlib import Path

import pytest

from app.core.clock import today
from app.core.config import settings
from app.core.security import hash_password
from app.models.audit import AuditLog
from app.models.notification import Notification
from app.models.payment import (Invoice, Payment, PaymentRefund, PaymentTransaction, PaymentWebhookEvent, PlatformCommission, TrainerEarning)
from app.models.training import Training
from app.models.user import Skill, User
from app.models.payment import PaymentReviewFlag
from app.models.review import Review
from app.services import notification_service, payment_providers as providers, payment_rules as rules
from app.services.payment_service import reconcile, utcnow
from tests import webhook_secret_matrix as WSM
from tests.boot_env import boot as hermetic_boot
from tests.test_reviews import INST_RATINGS, TRAINER_RATINGS, review as submit_review
from tests.test_trainings import begin, db_of, reg, req_body

FEE_RUPEES = 40_000
FEE = FEE_RUPEES * 100            # paise
SECRET = "test-only-webhook-secret-for-the-pytest-suite-0123456789"
API = "/api/v1"
BACKEND = Path(__file__).resolve().parents[1]


# ---------- helpers ----------
def setup(client, tag="a", fee=FEE_RUPEES):
    """A trainer and an institution with an ACTIVE training whose agreed fee is `fee` rupees. Returns (trainer headers, institution headers, training id)."""
    db = db_of(client)
    if not db.query(Skill).filter_by(name="Python").first():
        db.add(Skill(name="Python"))
        db.commit()
    th, ih = reg(client, f"t{tag}@example.com"), reg(client, f"i{tag}@example.com", "INSTITUTION", institution_name=f"College {tag}")
    rid = client.post(f"{API}/requirements", headers=ih, json=req_body()).json()["data"]["id"]
    client.put(f"{API}/trainers/me", headers=th, json={"headline": "Python trainer", "location": "Pune", "experience_years": 5,
                                                     "training_mode": "OFFLINE", "expected_fee": 4000, "skill_ids": [1]})
    aid = client.post(f"{API}/requirements/{rid}/apply", headers=th, json={}).json()["data"]["id"]
    client.patch(f"{API}/applications/{aid}/status", headers=ih, json={"status": "SHORTLISTED"})
    hid = client.post(f"{API}/applications/{aid}/hire", headers=ih, json={"agreed_fee": fee}).json()["data"]["id"]
    client.post(f"{API}/hiring-requests/{hid}/accept", headers=th)
    return th, ih, client.get(f"{API}/trainings/mine", headers=th).json()["data"]["items"][0]["id"]


def admin(client, email="admin@example.com"):
    db = db_of(client)
    db.add(User(email=email, password_hash=hash_password("Passw0rd123"), full_name="Admin", role="ADMIN", email_verified=True))
    db.commit()
    token = client.post(f"{API}/auth/login", json={"email": email, "password": "Passw0rd123"}).json()["data"]["access_token"]
    return {"Authorization": f"Bearer {token}"}


def new_key():
    return "key-" + uuid.uuid4().hex[:20]


def pay(client, h, tid, amount=FEE, key=None, **extra):
    return client.post(f"{API}/trainings/{tid}/payments", headers={**h, "Idempotency-Key": key or new_key()}, json={"amount_paise": amount, **extra})


def start(client, h, tid, amount=FEE):
    r = pay(client, h, tid, amount)
    assert r.status_code == 201, r.text
    return r.json()["data"]


def sandbox(client, h, pid, outcome="success"):
    return client.post(f"{API}/payments/{pid}/sandbox/{outcome}", headers=h)


def paid(client, ih, tid, amount=FEE):
    p = start(client, ih, tid, amount)
    r = sandbox(client, ih, p["id"])
    assert r.status_code == 200 and r.json()["data"]["payment"]["status"] == "SUCCEEDED", r.text
    return p["id"]


def signed(order_id, type_="payment.succeeded", amount=FEE, currency="INR", event_id=None, txn_id="auto", ts=None, secret=SECRET, reason=None):
    body, headers = providers.build_signed_event(
        secret, event_id=event_id or "evt_" + uuid.uuid4().hex[:12], type_=type_, order_id=order_id, amount_paise=amount, currency=currency,
        txn_id=("txn_" + uuid.uuid4().hex[:12]) if txn_id == "auto" else txn_id, reason=reason, timestamp=int(time.time()) if ts is None else ts)
    return body, headers


def deliver(client, order_id, **kw):
    body, headers = signed(order_id, **kw)
    return client.post(f"{API}/payments/webhook", content=body, headers=headers)


def row(client, model, **where):
    return db_of(client).query(model).filter_by(**where).one()


def count(client, model, **where):
    return db_of(client).query(model).filter_by(**where).count()


def types_of(client, h, t):
    return [n for n in client.get(f"{API}/notifications?page_size=50", headers=h).json()["data"]["items"] if n["type"] == t]


def finish(client, ih, tid):
    begin(client, tid)
    assert client.post(f"{API}/trainings/{tid}/complete", headers=ih).status_code == 200


class FlakyProvider(providers.SandboxProvider):
    """A sandbox whose refunds can be made to fail and whose fetch_status can be scripted, to exercise recovery paths."""
    fail_refund = False
    statuses: dict = {}
    explode: set = set()                  # order ids whose lookup raises an unexpected error (a poison payment)
    refund_calls: list = []

    def refund(self, **kw):
        FlakyProvider.refund_calls.append(kw)
        if FlakyProvider.fail_refund:
            raise providers.ProviderError("gateway timeout")
        return super().refund(**kw)

    def fetch_status(self, order_id):
        if order_id in FlakyProvider.explode:
            raise RuntimeError("unexpected provider failure")
        return FlakyProvider.statuses.get(order_id)


@pytest.fixture()
def flaky(monkeypatch):
    FlakyProvider.fail_refund, FlakyProvider.statuses, FlakyProvider.refund_calls, FlakyProvider.explode = False, {}, [], set()
    monkeypatch.setitem(providers._PROVIDERS, "sandbox", FlakyProvider)
    return FlakyProvider


# ---------- creating a payment ----------
def test_institution_starts_a_pending_sandbox_payment(client):
    th, ih, tid = setup(client)
    r = pay(client, ih, tid)
    assert r.status_code == 201
    p = r.json()["data"]
    assert (p["status"], p["amount_paise"], p["currency"], p["attempt_no"], p["sandbox"]) == ("PENDING", FEE, "INR", 1, True)
    assert p["checkout"]["sandbox"] is True and "no real money" in p["checkout"]["notice"].lower()
    assert p["invoice_number"] is None and p["refund"] is None


def test_the_client_cannot_set_status_amount_or_commission(client):
    th, ih, tid = setup(client)
    r = pay(client, ih, tid, status="SUCCEEDED", platform_fee_paise=0, net_paise=FEE, commission_bps=0, paid_at="2030-01-01T00:00:00")
    assert r.status_code == 201
    stored = row(client, Payment, id=r.json()["data"]["id"])
    assert stored.status == "PENDING" and stored.paid_at is None and stored.commission_bps == 1000 and stored.platform_fee_paise == FEE // 10
    assert count(client, Invoice) == 0 and count(client, TrainerEarning) == 0


def test_there_is_no_endpoint_that_marks_a_payment_paid(client):
    from app.main import app
    th, ih, tid = setup(client)
    pid = start(client, ih, tid)["id"]
    for method in ("patch", "put", "delete"):
        assert getattr(client, method)(f"{API}/payments/{pid}", headers=ih).status_code == 405
    for word in ("succeed", "success", "paid", "confirm", "complete", "status"):
        assert client.post(f"{API}/payments/{pid}/{word}", headers=ih, json={"status": "SUCCEEDED"}).status_code in (404, 405)
    assert row(client, Payment, id=pid).status == "PENDING"
    # the only routes that can change a payment's state: create, cancel, the signed webhook, and the sandbox (which signs its own event)
    posts = sorted(r.path for r in app.routes if "POST" in getattr(r, "methods", ()) and "/payments" in r.path)
    assert posts == ["/api/v1/admin/payments/{pid}/refund", "/api/v1/admin/payments/{pid}/resolve-review", "/api/v1/payments/webhook",
                     "/api/v1/payments/{pid}/cancel", "/api/v1/payments/{pid}/sandbox/{outcome}", "/api/v1/trainings/{tid}/payments"]


@pytest.mark.parametrize("amount", [0, -100, 100.5, "100", None, True, 10 ** 15])
def test_invalid_amounts_are_rejected(client, amount):
    th, ih, tid = setup(client)
    assert pay(client, ih, tid, amount).status_code == 422
    assert count(client, Payment) == 0


def test_the_amount_can_never_exceed_the_agreed_fee(client):
    th, ih, tid = setup(client)
    r = pay(client, ih, tid, FEE + 1)
    assert r.status_code == 409 and r.json()["data"]["code"] == "OVER_FEE"
    assert count(client, Payment) == 0
    assert pay(client, ih, tid, 50).status_code == 422 and pay(client, ih, tid, 50).json()["data"]["code"] == "TOO_SMALL"


def test_the_idempotency_key_is_required_and_validated(client):
    th, ih, tid = setup(client)
    assert client.post(f"{API}/trainings/{tid}/payments", headers=ih, json={"amount_paise": FEE}).status_code == 422
    for bad in ("short", "has spaces in it", "x" * 81):
        r = client.post(f"{API}/trainings/{tid}/payments", headers={**ih, "Idempotency-Key": bad}, json={"amount_paise": FEE})
        assert r.status_code == 422 and r.json()["data"]["code"] == "INVALID_IDEMPOTENCY_KEY"
    assert count(client, Payment) == 0


def test_repeating_a_request_with_the_same_key_returns_the_same_payment(client):
    th, ih, tid = setup(client)
    key = new_key()
    first = pay(client, ih, tid, key=key)
    again = pay(client, ih, tid, key=key)
    assert first.status_code == 201 and again.status_code == 200
    assert again.json()["data"]["id"] == first.json()["data"]["id"] and again.json()["data"]["checkout"]["order_id"] == first.json()["data"]["checkout"]["order_id"]
    assert count(client, Payment) == 1


def test_the_same_key_with_different_parameters_is_a_conflict_not_a_replay(client):
    th, ih, tid = setup(client)
    key = new_key()
    assert pay(client, ih, tid, FEE // 2, key=key).status_code == 201
    r = pay(client, ih, tid, FEE // 4, key=key)
    assert r.status_code == 409 and r.json()["data"]["code"] == "IDEMPOTENCY_CONFLICT"
    assert count(client, Payment) == 1


def test_a_replay_still_answers_after_the_payment_has_settled(client):
    th, ih, tid = setup(client)
    key = new_key()
    pid = pay(client, ih, tid, key=key).json()["data"]["id"]
    sandbox(client, ih, pid)
    again = pay(client, ih, tid, key=key)
    assert again.status_code == 200 and again.json()["data"]["id"] == pid and again.json()["data"]["status"] == "SUCCEEDED"
    assert count(client, Payment) == 1 and count(client, Invoice) == 1


def test_idempotency_keys_are_scoped_to_the_payer(client):
    ta, ia, tida = setup(client, "a")
    tb, ib, tidb = setup(client, "b")
    key = new_key()
    assert pay(client, ia, tida, key=key).status_code == 201
    assert pay(client, ib, tidb, key=key).status_code == 201          # same key, different institution: independent
    assert count(client, Payment) == 2


def test_only_one_payment_may_be_in_flight_per_training(client):
    th, ih, tid = setup(client)
    first = start(client, ih, tid, FEE // 2)
    r = pay(client, ih, tid, FEE // 4)
    assert r.status_code == 409 and r.json()["data"]["code"] == "IN_PROGRESS"
    assert client.post(f"{API}/payments/{first['id']}/cancel", headers=ih).status_code == 200
    assert pay(client, ih, tid, FEE // 4).status_code == 201


def test_a_retry_is_a_new_attempt_and_never_rewrites_the_old_one(client):
    th, ih, tid = setup(client)
    first = start(client, ih, tid)
    assert sandbox(client, ih, first["id"], "fail").json()["data"]["payment"]["status"] == "FAILED"
    second = start(client, ih, tid)
    assert second["attempt_no"] == 2 and second["id"] != first["id"] and second["checkout"]["order_id"] != first["checkout"]["order_id"]
    old = row(client, Payment, id=first["id"])
    assert old.status == "FAILED" and old.attempt_no == 1 and old.failure_reason and old.provider_order_id == first["checkout"]["order_id"]
    assert [p["attempt_no"] for p in client.get(f"{API}/payments", headers=ih).json()["data"]["items"]] == [2, 1]


def test_a_free_training_cannot_be_charged(client):
    th, ih, tid = setup(client, fee=0)
    r = pay(client, ih, tid, 100)
    assert r.status_code == 409 and r.json()["data"]["code"] == "NO_FEE"
    s = client.get(f"{API}/trainings/{tid}/payment-summary", headers=ih).json()["data"]
    assert s["fee_paise"] == 0 and s["can_pay"] is False and s["block_reason"] == "NO_FEE"
    assert count(client, Payment) == 0


def test_a_cancelled_training_cannot_be_paid_for(client):
    th, ih, tid = setup(client)
    assert client.post(f"{API}/trainings/{tid}/cancel", headers=ih, json={"reason": "x"}).status_code == 200
    r = pay(client, ih, tid)
    assert r.status_code == 409 and r.json()["data"]["code"] == "TRAINING_CANCELLED"


def test_a_fully_paid_training_cannot_be_paid_again(client):
    th, ih, tid = setup(client)
    paid(client, ih, tid)
    r = pay(client, ih, tid, 100)
    assert r.status_code == 409 and r.json()["data"]["code"] == "FULLY_PAID"


def test_instalments_can_never_total_more_than_the_fee(client):
    th, ih, tid = setup(client)
    paid(client, ih, tid, FEE // 4)
    s = client.get(f"{API}/trainings/{tid}/payment-summary", headers=ih).json()["data"]
    assert (s["collected_paise"], s["remaining_paise"], s["can_pay"]) == (FEE // 4, FEE * 3 // 4, True)
    assert pay(client, ih, tid, FEE * 3 // 4 + 1).json()["data"]["code"] == "OVER_FEE"
    paid(client, ih, tid, FEE * 3 // 4)
    s = client.get(f"{API}/trainings/{tid}/payment-summary", headers=ih).json()["data"]
    assert (s["collected_paise"], s["remaining_paise"], s["can_pay"], s["block_reason"]) == (FEE, 0, False, "FULLY_PAID")
    assert sum(p.amount_paise for p in db_of(client).query(Payment).filter_by(status="SUCCEEDED")) == FEE


def test_payments_can_be_switched_off(client, monkeypatch):
    th, ih, tid = setup(client)
    pid = start(client, ih, tid)["id"]
    monkeypatch.setattr(settings, "payments_enabled", False)
    r = pay(client, ih, tid)
    assert r.status_code == 503 and r.json()["data"]["code"] == "DISABLED"
    assert sandbox(client, ih, pid).status_code == 403
    assert deliver(client, row(client, Payment, id=pid).provider_order_id).status_code == 503
    assert client.get(f"{API}/payments/summary", headers=ih).json()["data"]["enabled"] is False
    assert client.get(f"{API}/trainings/{tid}/payment-summary", headers=ih).json()["data"]["block_reason"] == "DISABLED"
    assert row(client, Payment, id=pid).status == "PENDING"


def test_a_suspended_institution_cannot_pay(client):
    th, ih, tid = setup(client)
    from app.models.user import InstitutionProfile
    db = db_of(client)
    db.query(InstitutionProfile).update({"verification_status": "SUSPENDED"})
    db.commit()
    r = pay(client, ih, tid)
    assert r.status_code == 403 and r.json()["data"]["code"] == "SUSPENDED"


# ---------- results arrive only through the trusted path ----------
def test_sandbox_success_settles_the_payment_with_an_invoice_an_earning_and_a_commission(client):
    th, ih, tid = setup(client)
    pid = start(client, ih, tid)["id"]
    r = sandbox(client, ih, pid)
    assert r.status_code == 200 and r.json()["data"]["outcome"] == "succeeded"
    p = r.json()["data"]["payment"]
    assert p["status"] == "SUCCEEDED" and p["paid_at"] and re.fullmatch(rf"ITB-{today().year}-000001", p["invoice_number"]) and p["under_review"] is False
    stored = row(client, Payment, id=pid)
    assert (stored.amount_paise, stored.platform_fee_paise, stored.net_paise, stored.commission_bps) == (FEE, FEE // 10, FEE - FEE // 10, 1000)
    e = row(client, TrainerEarning, payment_id=pid)
    assert (e.gross_paise, e.commission_paise, e.net_paise, e.status) == (FEE, FEE // 10, FEE - FEE // 10, "PENDING")   # training not completed yet
    c = row(client, PlatformCommission, payment_id=pid)
    assert (c.amount_paise, c.rate_bps, c.status) == (FEE // 10, 1000, "RECORDED")
    t = row(client, PaymentTransaction, payment_id=pid)
    assert (t.type, t.amount_paise) == ("CHARGE", FEE)
    assert count(client, PaymentWebhookEvent, payment_id=pid, source="SANDBOX") == 1


def test_sandbox_actions_are_replays_not_second_charges(client):
    th, ih, tid = setup(client)
    pid = start(client, ih, tid)["id"]
    assert sandbox(client, ih, pid).json()["data"]["outcome"] == "succeeded"
    assert sandbox(client, ih, pid).json()["data"]["outcome"] == "replay"
    assert (count(client, Invoice), count(client, TrainerEarning), count(client, PaymentTransaction), count(client, PlatformCommission)) == (1, 1, 1, 1)


def test_a_failure_report_can_never_undo_a_success(client):
    th, ih, tid = setup(client)
    pid = paid(client, ih, tid)
    r = sandbox(client, ih, pid, "fail")
    assert r.json()["data"]["outcome"] == "stale_ignored" and r.json()["data"]["payment"]["status"] == "SUCCEEDED"


def test_processing_then_success(client):
    th, ih, tid = setup(client)
    pid = start(client, ih, tid)["id"]
    assert sandbox(client, ih, pid, "processing").json()["data"]["payment"]["status"] == "PROCESSING"
    assert client.post(f"{API}/payments/{pid}/cancel", headers=ih).status_code == 409           # the provider has it now
    assert sandbox(client, ih, pid).json()["data"]["payment"]["status"] == "SUCCEEDED"


def test_a_failed_payment_sends_a_failure_notification_and_no_invoice(client):
    th, ih, tid = setup(client)
    pid = start(client, ih, tid)["id"]
    sandbox(client, ih, pid, "fail")
    n = types_of(client, ih, "PAYMENT_FAILED")
    assert len(n) == 1 and n[0]["link"] == "/institution/payments"
    assert count(client, Invoice) == 0 and count(client, TrainerEarning) == 0
    assert client.get(f"{API}/payments/{pid}/invoice", headers=ih).status_code == 404


def test_late_success_after_cancel_is_recorded_flagged_and_never_discarded(client):
    th, ih, tid = setup(client)
    ah = admin(client)
    pid = start(client, ih, tid)["id"]
    assert client.post(f"{API}/payments/{pid}/cancel", headers=ih).json()["data"]["status"] == "CANCELLED"
    r = sandbox(client, ih, pid)
    assert r.json()["data"]["outcome"] == "succeeded_late" and r.json()["data"]["payment"]["status"] == "SUCCEEDED"
    stored = row(client, Payment, id=pid)
    assert stored.needs_review and stored.review_reason == "LATE_SUCCESS"
    assert count(client, Invoice) == 1 and count(client, TrainerEarning) == 1
    listed = client.get(f"{API}/admin/payments?needs_review=true", headers=ah).json()["data"]["items"]
    assert [p["id"] for p in listed] == [pid] and listed[0]["review_reason"] == "LATE_SUCCESS"
    assert len(types_of(client, ah, "PAYMENT_NEEDS_REVIEW")) == 1


def test_late_success_after_failure_and_after_expiry(client):
    th, ih, tid = setup(client)
    p1 = start(client, ih, tid)
    sandbox(client, ih, p1["id"], "fail")
    r = deliver(client, p1["checkout"]["order_id"])                    # the provider later reports it did succeed
    assert r.status_code == 200 and r.json()["data"]["outcome"] == "succeeded_late"
    assert row(client, Payment, id=p1["id"]).status == "SUCCEEDED"
    th2, ih2, tid2 = setup(client, "b")
    p2 = start(client, ih2, tid2)
    db = db_of(client)
    q = db.get(Payment, p2["id"])
    q.created_at, q.expires_at = utcnow() - timedelta(hours=3), utcnow() - timedelta(hours=2)
    db.commit()
    assert reconcile(db_of(client))["expired"] == 1 and row(client, Payment, id=p2["id"]).status == "EXPIRED"
    assert deliver(client, p2["checkout"]["order_id"]).json()["data"]["outcome"] == "succeeded_late"
    assert row(client, Payment, id=p2["id"]).status == "SUCCEEDED" and row(client, Payment, id=p2["id"]).needs_review


def test_a_second_different_charge_for_a_paid_payment_is_flagged_not_settled_twice(client):
    th, ih, tid = setup(client)
    pid = start(client, ih, tid)
    assert deliver(client, pid["checkout"]["order_id"], txn_id="txn_first").json()["data"]["outcome"] == "succeeded"
    r = deliver(client, pid["checkout"]["order_id"], txn_id="txn_second")
    assert r.json()["data"]["outcome"] == "duplicate_charge"
    stored = row(client, Payment, id=pid["id"])
    assert stored.needs_review and stored.review_reason == "DUPLICATE_CHARGE"
    assert (count(client, Invoice), count(client, TrainerEarning), count(client, PaymentTransaction)) == (1, 1, 1)
    assert count(client, PaymentWebhookEvent, payment_id=pid["id"]) == 2          # the evidence of the second charge is kept


def test_success_that_would_exceed_the_fee_is_recorded_and_flagged_with_an_invoice_but_no_earning_or_commission(client):
    th, ih, tid = setup(client)
    first = start(client, ih, tid)
    sandbox(client, ih, first["id"], "fail")
    paid(client, ih, tid)                                              # the whole fee is now held
    r = deliver(client, first["checkout"]["order_id"])                 # ...and the provider says the failed attempt also went through
    assert r.json()["data"]["outcome"] == "succeeded_over_cap"
    stored = row(client, Payment, id=first["id"])
    assert stored.status == "SUCCEEDED" and stored.needs_review and stored.review_reason == "OVER_CAP"
    assert count(client, PaymentTransaction, payment_id=first["id"]) == 1
    assert count(client, Invoice) == 2 and count(client, Invoice, payment_id=first["id"]) == 1       # every successful payment has its invoice, also this one
    assert count(client, TrainerEarning) == 1 and count(client, TrainerEarning, payment_id=first["id"]) == 0
    assert count(client, PlatformCommission) == 1 and count(client, PlatformCommission, payment_id=first["id"]) == 0
    assert (stored.platform_fee_paise, stored.net_paise) == (0, stored.amount_paise)               # no commission is claimed on money waiting for a refund


def test_an_over_cap_review_cannot_be_closed_until_the_payment_is_refunded_and_the_credit_note_reaches_the_institution(client):
    th, ih, tid = setup(client)
    ah = admin(client)
    first = start(client, ih, tid)
    sandbox(client, ih, first["id"], "fail")
    settled_id = paid(client, ih, tid)
    deliver(client, first["checkout"]["order_id"])
    r = client.post(f"{API}/admin/payments/{first['id']}/resolve-review", headers=ah, json={"note": "looked at it"})
    assert r.status_code == 409 and r.json()["data"]["code"] == "REFUND_REQUIRED" and row(client, Payment, id=first["id"]).needs_review
    assert refund(client, ah, first["id"]).status_code == 200
    inv = client.get(f"{API}/payments/{first['id']}/invoice", headers=ih).json()["data"]
    assert inv["credit_note"]["number"].startswith("ITB-CN-") and inv["credit_note"]["amount_paise"] == FEE
    assert client.post(f"{API}/admin/payments/{first['id']}/resolve-review", headers=ah, json={"note": "refunded"}).status_code == 200
    assert row(client, TrainerEarning, payment_id=settled_id).status == "PENDING" and row(client, PlatformCommission, payment_id=settled_id).status == "RECORDED"   # the real payment is untouched


def test_the_sandbox_is_unavailable_outside_development_and_test(client, monkeypatch):
    th, ih, tid = setup(client)
    pid = start(client, ih, tid)["id"]
    monkeypatch.setattr(settings, "environment", "production")
    r = sandbox(client, ih, pid)
    assert r.status_code == 403 and r.json()["data"]["code"] == "SANDBOX_DISABLED"
    assert row(client, Payment, id=pid).status == "PENDING"
    assert client.get(f"{API}/payments/summary", headers=ih).json()["data"]["sandbox"] is False


def test_only_the_payer_can_use_the_sandbox_for_a_payment(client):
    ta, ia, tida = setup(client, "a")
    tb, ib, tidb = setup(client, "b")
    pid = start(client, ia, tida)["id"]
    assert sandbox(client, ib, pid).status_code == 404
    assert sandbox(client, ta, pid).status_code == 403
    assert sandbox(client, ia, pid, "explode").status_code == 422
    assert row(client, Payment, id=pid).status == "PENDING"


# ---------- webhook authentication ----------
def test_webhook_rejects_bad_signatures_and_changes_nothing(client):
    th, ih, tid = setup(client)
    p = start(client, ih, tid)
    order = p["checkout"]["order_id"]
    body, headers = signed(order)
    url = f"{API}/payments/webhook"
    cases = {
        "no signature": {k: v for k, v in headers.items() if k != providers.SIGNATURE_HEADER},
        "no timestamp": {k: v for k, v in headers.items() if k != providers.TIMESTAMP_HEADER},
        "wrong signature": {**headers, providers.SIGNATURE_HEADER: "0" * 64},
        "garbage signature": {**headers, providers.SIGNATURE_HEADER: "not-hex"},
        "bad timestamp": {**headers, providers.TIMESTAMP_HEADER: "yesterday"},
    }
    for label, h in cases.items():
        r = client.post(url, content=body, headers=h)
        assert r.status_code == 401 and r.json()["data"]["code"] == "WEBHOOK_REJECTED", label
    other_body, other_headers = signed(order, amount=FEE - 1)
    assert client.post(url, content=body, headers=other_headers).status_code == 401           # signature of another body
    wrong_secret_body, wrong_secret_headers = signed(order, secret="y" * 40)
    assert client.post(url, content=wrong_secret_body, headers=wrong_secret_headers).status_code == 401
    old_body, old_headers = signed(order, ts=int(time.time()) - 3600)
    assert client.post(url, content=old_body, headers=old_headers).status_code == 401           # correctly signed but stale
    future_body, future_headers = signed(order, ts=int(time.time()) + 3600)
    assert client.post(url, content=future_body, headers=future_headers).status_code == 401
    assert row(client, Payment, id=p["id"]).status == "PENDING"
    assert count(client, PaymentWebhookEvent) == 0 and count(client, Invoice) == 0                # nothing was recorded or settled


def test_webhook_with_no_secret_configured_accepts_nothing(client, monkeypatch):
    th, ih, tid = setup(client)
    order = start(client, ih, tid)["checkout"]["order_id"]
    body, headers = signed(order)
    monkeypatch.setattr(settings, "payment_webhook_secret", "")
    r = client.post(f"{API}/payments/webhook", content=body, headers=headers)
    assert r.status_code == 503 and count(client, PaymentWebhookEvent) == 0
    body, headers = signed(order, secret="")
    assert client.post(f"{API}/payments/webhook", content=body, headers=headers).status_code == 503      # an empty secret does not "match" an empty signature


EXAMPLE_SECRET = "dev-only-sandbox-webhook-secret-do-not-use-in-production"        # the value shipped in .env.example


@pytest.mark.parametrize("payments_enabled", [True, False])
@pytest.mark.parametrize("secret", [EXAMPLE_SECRET, "", "change_me"])
def test_in_production_the_webhook_never_accepts_a_missing_weak_or_example_secret_whatever_payments_enabled_says(client, monkeypatch, payments_enabled, secret):
    """13B.1: the start-up guard refuses these in production, and the endpoint itself is a second line of defence: a delivery signed with the public
    example secret is answered 503 and changes nothing. (Payments are created in development first, then the process is 'moved' to production.)"""
    th, ih, tid = setup(client)
    order = start(client, ih, tid)["checkout"]["order_id"]
    monkeypatch.setattr(settings, "environment", "production")
    monkeypatch.setattr(settings, "payments_enabled", payments_enabled)
    monkeypatch.setattr(settings, "payment_webhook_secret", secret)
    body, headers = signed(order, secret=secret)
    r = client.post(f"{API}/payments/webhook", content=body, headers=headers)
    assert r.status_code == 503 and r.json()["data"]["code"] == "WEBHOOK_REJECTED", r.text
    assert count(client, PaymentWebhookEvent) == 0
    assert row(client, Payment, provider_order_id=order).status != "SUCCEEDED"


def test_in_production_a_strong_secret_is_accepted_by_the_webhook_even_with_payments_disabled(client, monkeypatch):
    """Evidence of a charge made earlier is still recorded after the feature is switched off (unchanged Phase 13 behaviour)."""
    th, ih, tid = setup(client)
    order = start(client, ih, tid)["checkout"]["order_id"]
    strong = "Kq7vR2mZp9sT4wB8nC3dF6hJ1LaE5gY0xxxx"
    monkeypatch.setattr(settings, "environment", "production")
    monkeypatch.setattr(settings, "payments_enabled", False)
    monkeypatch.setattr(settings, "payment_webhook_secret", strong)
    r = deliver(client, order, secret=strong)
    assert r.status_code == 200, r.text


@pytest.mark.parametrize("env", ["development", "test"])
def test_in_development_and_test_the_example_secret_is_a_valid_webhook_secret(client, monkeypatch, env):
    th, ih, tid = setup(client)
    order = start(client, ih, tid)["checkout"]["order_id"]
    monkeypatch.setattr(settings, "environment", env)
    monkeypatch.setattr(settings, "payment_webhook_secret", EXAMPLE_SECRET)
    assert deliver(client, order, secret=EXAMPLE_SECRET).status_code == 200


@pytest.mark.parametrize("case", [c for c in WSM.CASES if c[2] != "missing"], ids=WSM.case_id)
def test_webhook_handler_secret_matrix_environment_x_payments_x_secret(client, monkeypatch, case):
    """13B.2, defence in depth behind the start-up guard: the handler authenticates a delivery only with a usable secret. Production: only a strong one.
    Development / test: any non-empty one. PAYMENTS_ENABLED makes no difference. ('missing' and 'empty' both reach the handler as the empty default,
    so the 'empty' cells cover them.)"""
    env, enabled, kind = case
    th, ih, tid = setup(client)
    order = start(client, ih, tid)["checkout"]["order_id"]                               # created under the suite's development configuration
    secret = WSM.SECRETS[kind]
    monkeypatch.setattr(settings, "environment", env)
    monkeypatch.setattr(settings, "payments_enabled", enabled)
    monkeypatch.setattr(settings, "payment_webhook_secret", secret)
    body, headers = signed(order, secret=secret)
    r = client.post(f"{API}/payments/webhook", content=body, headers=headers)
    if WSM.webhook_accepts(env, kind):
        assert r.status_code == 200, r.text
        assert row(client, Payment, provider_order_id=order).status == "SUCCEEDED"
    else:
        assert r.status_code == 503 and r.json()["data"]["code"] == "WEBHOOK_REJECTED", r.text
        assert count(client, PaymentWebhookEvent) == 0 and row(client, Payment, provider_order_id=order).status != "SUCCEEDED"


def test_a_signed_but_malformed_event_is_a_400(client):
    body = b'{"id": "evt_1", "type": "payment.succeeded"}'
    ts = str(int(time.time()))
    headers = {providers.SIGNATURE_HEADER: rules.sign(SECRET, ts, body), providers.TIMESTAMP_HEADER: ts}
    r = client.post(f"{API}/payments/webhook", content=body, headers=headers)
    assert r.status_code == 400 and r.json()["data"]["code"] == "BAD_EVENT"
    body = b"not json"
    headers = {providers.SIGNATURE_HEADER: rules.sign(SECRET, ts, body), providers.TIMESTAMP_HEADER: ts}
    assert client.post(f"{API}/payments/webhook", content=body, headers=headers).status_code == 400


def test_replaying_a_webhook_event_is_idempotent(client):
    th, ih, tid = setup(client)
    order = start(client, ih, tid)["checkout"]["order_id"]
    body, headers = signed(order, event_id="evt_fixed_1", txn_id="txn_fixed_1")
    first = client.post(f"{API}/payments/webhook", content=body, headers=headers)
    second = client.post(f"{API}/payments/webhook", content=body, headers=headers)
    assert first.json()["data"]["outcome"] == "succeeded" and second.status_code == 200 and second.json()["data"]["outcome"] == "replay"
    assert (count(client, Invoice), count(client, TrainerEarning), count(client, PaymentTransaction), count(client, PaymentWebhookEvent)) == (1, 1, 1, 1)
    assert len(types_of(client, ih, "PAYMENT_SUCCEEDED")) == 1


def test_amount_mismatch_is_recorded_flagged_and_does_not_settle(client):
    th, ih, tid = setup(client)
    p = start(client, ih, tid)
    r = deliver(client, p["checkout"]["order_id"], amount=FEE - 100)
    assert r.json()["data"]["outcome"] == "amount_mismatch"
    stored = row(client, Payment, id=p["id"])
    assert stored.status == "PENDING" and stored.needs_review and stored.review_reason == "AMOUNT_MISMATCH"
    assert count(client, Invoice) == 0 and count(client, PaymentTransaction) == 0 and count(client, PaymentWebhookEvent, outcome="amount_mismatch") == 1


def test_currency_mismatch_is_recorded_flagged_and_does_not_settle(client):
    th, ih, tid = setup(client)
    p = start(client, ih, tid)
    assert deliver(client, p["checkout"]["order_id"], currency="USD").json()["data"]["outcome"] == "currency_mismatch"
    stored = row(client, Payment, id=p["id"])
    assert stored.status == "PENDING" and stored.review_reason == "CURRENCY_MISMATCH" and count(client, Invoice) == 0


def test_an_unknown_order_is_kept_as_evidence_answered_with_an_error_so_the_provider_retries_and_matched_when_it_arrives(client):
    th, ih, tid = setup(client)
    p = start(client, ih, tid)
    r = deliver(client, "order_not_committed_yet", event_id="evt_unknown_1")
    assert r.status_code == 404 and r.json()["data"]["code"] == "UNKNOWN_ORDER"           # an error, so the provider delivers the same event again
    assert count(client, PaymentWebhookEvent, event_id="evt_unknown_1") == 1 and count(client, Invoice) == 0
    assert row(client, PaymentWebhookEvent, event_id="evt_unknown_1").outcome == "unknown_order"
    assert deliver(client, "order_not_committed_yet", event_id="evt_unknown_1").status_code == 404      # still unknown: nothing new is stored
    assert count(client, PaymentWebhookEvent, event_id="evt_unknown_1") == 1
    assert db_of(client).query(AuditLog).filter_by(action="PAYMENT_EVENT_UNKNOWN_ORDER").count() == 1
    db = db_of(client)                                                  # the order's commit has now happened: the SAME event id is matched
    db.get(Payment, p["id"]).provider_order_id = "order_not_committed_yet"
    db.commit()
    r = deliver(client, "order_not_committed_yet", event_id="evt_unknown_1")
    assert r.status_code == 200 and r.json()["data"]["outcome"] == "succeeded"
    ev = row(client, PaymentWebhookEvent, event_id="evt_unknown_1")
    assert ev.payment_id == p["id"] and ev.outcome == "succeeded" and count(client, PaymentWebhookEvent, event_id="evt_unknown_1") == 1
    assert row(client, Payment, id=p["id"]).status == "SUCCEEDED" and count(client, Invoice) == 1
    assert deliver(client, "order_not_committed_yet", event_id="evt_unknown_1").json()["data"]["outcome"] == "replay"


def test_an_unknown_event_type_is_ignored(client):
    th, ih, tid = setup(client)
    p = start(client, ih, tid)
    assert deliver(client, p["checkout"]["order_id"], type_="payment.refunded").json()["data"]["outcome"] == "ignored_unknown_type"
    assert row(client, Payment, id=p["id"]).status == "PENDING"


# ---------- commission ----------
def test_commission_is_taken_from_the_trainers_share_not_added_to_the_institutions(client):
    th, ih, tid = setup(client)
    pid = paid(client, ih, tid)
    inst = client.get(f"{API}/payments/{pid}", headers=ih).json()["data"]
    assert inst["amount_paise"] == FEE                                     # the institution pays exactly the agreed fee
    e = client.get(f"{API}/earnings", headers=th).json()["data"]["items"][0]
    assert (e["gross_paise"], e["commission_paise"], e["net_paise"], e["commission_bps"]) == (FEE, FEE // 10, FEE - FEE // 10, 1000)
    s = client.get(f"{API}/earnings/summary", headers=th).json()["data"]
    assert s["pending_paise"] == FEE - FEE // 10 and s["commission_paise"] == FEE // 10 and s["commission_is_placeholder"] is True


def test_instalment_commission_adds_up_exactly_whatever_the_split(client, monkeypatch):
    monkeypatch.setattr(settings, "platform_commission_bps", 333)
    ta, ia, tida = setup(client, "a", fee=10)                              # Rs 10 = 1000 paise
    tb, ib, tidb = setup(client, "b", fee=10)
    paid(client, ib, tidb, 1000)
    paid(client, ia, tida, 500)
    paid(client, ia, tida, 500)
    one = row(client, Payment, training_id=tidb).platform_fee_paise
    two = sum(p.platform_fee_paise for p in db_of(client).query(Payment).filter_by(training_id=tida))
    assert one == two == rules.commission_total(1000, 333) == 33
    assert sum(e.net_paise for e in db_of(client).query(TrainerEarning).filter_by(training_id=tida)) == 1000 - 33


def test_a_training_keeps_the_rate_of_its_first_money_even_if_the_configured_rate_changes(client, monkeypatch):
    th, ih, tid = setup(client)
    paid(client, ih, tid, FEE // 2)
    monkeypatch.setattr(settings, "platform_commission_bps", 2500)
    paid(client, ih, tid, FEE // 2)
    assert [p.commission_bps for p in db_of(client).query(Payment).order_by(Payment.id)] == [1000, 1000]
    th2, ih2, tid2 = setup(client, "b")
    paid(client, ih2, tid2)
    assert row(client, Payment, training_id=tid2).commission_bps == 2500    # a different training uses the new rate


# ---------- authorization and isolation ----------
def test_payment_endpoints_need_the_right_role(client):
    th, ih, tid = setup(client)
    ah = admin(client)
    pid = start(client, ih, tid)["id"]
    assert client.get(f"{API}/payments").status_code == 401
    assert pay(client, th, tid).status_code == 403                          # a trainer cannot pay
    assert pay(client, ah, tid).status_code == 403                          # nor can an admin
    for url in (f"{API}/payments", f"{API}/payments/summary", f"{API}/payments/{pid}", f"{API}/payments/{pid}/invoice"):
        assert client.get(url, headers=ih).status_code in (200, 404), url
        assert client.get(url, headers=th).status_code == 403 and client.get(url, headers=ah).status_code == 403, url
    for url in (f"{API}/earnings", f"{API}/earnings/summary"):
        assert client.get(url, headers=th).status_code == 200, url
        assert client.get(url, headers=ih).status_code == 403 and client.get(url, headers=ah).status_code == 403, url
    for url in (f"{API}/admin/payments", f"{API}/admin/earnings"):
        assert client.get(url, headers=ah).status_code == 200
        assert client.get(url, headers=ih).status_code == 403 and client.get(url, headers=th).status_code == 403 and client.get(url).status_code == 401
    assert client.post(f"{API}/admin/payments/{pid}/refund", headers=ih, json={}).status_code == 403
    assert client.post(f"{API}/admin/payments/{pid}/refund", headers=th, json={}).status_code == 403
    assert client.post(f"{API}/admin/earnings/1/payout", headers=th, json={"reference": "BATCH-1"}).status_code == 403
    assert client.post(f"{API}/admin/payments/{pid}/resolve-review", headers=ih, json={"note": "fine"}).status_code == 403
    assert client.post(f"{API}/payments/{pid}/cancel", headers=th).status_code == 403


def test_another_institution_cannot_see_or_touch_my_payments(client):
    ta, ia, tida = setup(client, "a")
    tb, ib, tidb = setup(client, "b")
    pid = paid(client, ia, tida)
    assert pay(client, ib, tida).status_code == 404                         # not their training
    assert client.get(f"{API}/payments/{pid}", headers=ib).status_code == 404
    assert client.get(f"{API}/payments/{pid}/invoice", headers=ib).status_code == 404
    assert client.get(f"{API}/trainings/{tida}/payment-summary", headers=ib).status_code == 404
    assert client.get(f"{API}/payments", headers=ib).json()["data"]["total"] == 0
    assert client.get(f"{API}/payments/summary", headers=ib).json()["data"]["paid_paise"] == 0
    other = start(client, ib, tidb, 100)["id"]
    assert client.post(f"{API}/payments/{other}/cancel", headers=ia).status_code == 404
    assert sandbox(client, ia, other).status_code == 404


def test_a_trainer_sees_only_their_own_earnings_and_no_payer_details(client):
    ta, ia, tida = setup(client, "a")
    tb, ib, tidb = setup(client, "b")
    paid(client, ia, tida)
    paid(client, ib, tidb, FEE // 2)
    mine = client.get(f"{API}/earnings", headers=ta).json()["data"]
    assert mine["total"] == 1 and mine["items"][0]["training_id"] == tida
    text = str(mine) + str(client.get(f"{API}/earnings/summary", headers=ta).json())
    for leak in ("College", "payer", "provider_order_id", "idempotency", "sbx_", "i" + "a@example.com", "request_fingerprint"):
        assert leak not in text, leak
    assert client.get(f"{API}/earnings", headers=tb).json()["data"]["items"][0]["gross_paise"] == FEE // 2


def test_the_institutions_payment_view_never_shows_commission_or_the_trainers_net(client):
    th, ih, tid = setup(client)
    pid = paid(client, ih, tid)
    text = str(client.get(f"{API}/payments", headers=ih).json()) + str(client.get(f"{API}/payments/{pid}", headers=ih).json()) + str(client.get(f"{API}/trainings/{tid}/payment-summary", headers=ih).json())
    for leak in ("commission", "platform_fee", "net_paise", "provider_order_id", "idempotency_key", "review_note", "payer_user_id"):
        assert leak not in text, leak


def test_the_trainer_payment_summary_shows_the_fee_and_their_earning_but_no_payment_attempts(client):
    th, ih, tid = setup(client)
    paid(client, ih, tid, FEE // 2)
    s = client.get(f"{API}/trainings/{tid}/payment-summary", headers=th).json()["data"]
    assert (s["viewer_role"], s["fee_paise"], s["collected_paise"], s["remaining_paise"]) == ("TRAINER", FEE, FEE // 2, FEE // 2)
    assert "attempts" not in s and "can_pay" not in s and "in_progress" not in s
    assert len(s["earnings"]) == 1 and s["earnings"][0]["gross_paise"] == FEE // 2
    assert client.get(f"{API}/trainings/{tid}/payment-summary", headers=reg(client, "stranger@example.com")).status_code == 404


def test_payment_listing_paginates_and_filters(client):
    th, ih, tid = setup(client)
    ids = []
    for _ in range(3):
        p = start(client, ih, tid, 1000)
        ids.append(p["id"])
        client.post(f"{API}/payments/{p['id']}/cancel", headers=ih)
    paid_id = paid(client, ih, tid, 1000)
    page1 = client.get(f"{API}/payments?page=1&page_size=3", headers=ih).json()["data"]
    page2 = client.get(f"{API}/payments?page=2&page_size=3", headers=ih).json()["data"]
    assert (page1["total"], len(page1["items"]), len(page2["items"])) == (4, 3, 1)
    assert [p["id"] for p in page1["items"] + page2["items"]] == [paid_id] + ids[::-1]
    assert client.get(f"{API}/payments?status=SUCCEEDED", headers=ih).json()["data"]["total"] == 1
    assert client.get(f"{API}/payments?status=CANCELLED", headers=ih).json()["data"]["total"] == 3
    assert client.get(f"{API}/payments?status=PAID", headers=ih).status_code == 422
    assert client.get(f"{API}/payments?page_size=500", headers=ih).status_code == 422
    assert client.get(f"{API}/payments/summary", headers=ih).json()["data"]["net_paid_paise"] == 1000


# ---------- invoices ----------
def test_one_immutable_invoice_per_successful_payment_with_sequential_numbers(client):
    th, ih, tid = setup(client)
    p1, p2 = paid(client, ih, tid, FEE // 2), paid(client, ih, tid, FEE // 2)
    year = today().year
    assert [row(client, Invoice, payment_id=p).number for p in (p1, p2)] == [f"ITB-{year}-000001", f"ITB-{year}-000002"]
    before = {i.id: (i.number, i.amount_paise, i.snapshot, i.issued_at) for i in db_of(client).query(Invoice)}
    sandbox(client, ih, p1)                                                # replays and late reports never create or change an invoice
    deliver(client, row(client, Payment, id=p1).provider_order_id, txn_id="txn_other")
    after = {i.id: (i.number, i.amount_paise, i.snapshot, i.issued_at) for i in db_of(client).query(Invoice)}
    assert before == after and count(client, Invoice) == count(client, Payment, status="SUCCEEDED") == 2


def test_the_invoice_is_a_platform_invoice_not_a_tax_invoice_and_hides_the_commission(client):
    th, ih, tid = setup(client)
    pid = paid(client, ih, tid)
    inv = client.get(f"{API}/payments/{pid}/invoice", headers=ih).json()["data"]
    assert inv["amount_paise"] == FEE and inv["billed_to"]["name"] == "College a" and inv["issued_by"] == "IT BRIDGE (platform)"
    assert inv["training"]["title"] and inv["trainer_name"] and inv["sandbox"] is True and "no real money" in inv["sandbox_notice"].lower()
    assert "not a gst or tax invoice" in inv["notice"].lower() and "gst" not in inv["issued_by"].lower()
    text = str(inv).lower()
    for leak in ("commission", "platform_fee", "net_paise", "gstin", "gst number"):
        assert leak not in text, leak
    assert inv["credit_note"] is None


def test_invoices_are_private_to_the_paying_institution(client):
    ta, ia, tida = setup(client, "a")
    tb, ib, tidb = setup(client, "b")
    ah = admin(client)
    pid = paid(client, ia, tida)
    assert client.get(f"{API}/payments/{pid}/invoice", headers=ia).status_code == 200
    for h in (ib, ta, tb, ah):
        assert client.get(f"{API}/payments/{pid}/invoice", headers=h).status_code in (403, 404)
    assert client.get(f"{API}/payments/{pid}/invoice").status_code == 401
    assert client.get(f"{API}/payments/999999/invoice", headers=ia).status_code == 404


# ---------- earnings across completion and cancellation ----------
def test_earning_becomes_available_when_the_training_is_completed(client):
    th, ih, tid = setup(client)
    paid(client, ih, tid)
    assert client.get(f"{API}/earnings", headers=th).json()["data"]["items"][0]["status"] == "PENDING"
    assert types_of(client, th, "EARNING_AVAILABLE") == []
    finish(client, ih, tid)
    e = client.get(f"{API}/earnings", headers=th).json()["data"]["items"][0]
    assert e["status"] == "AVAILABLE" and e["available_at"]
    assert len(types_of(client, th, "EARNING_AVAILABLE")) == 1
    s = client.get(f"{API}/earnings/summary", headers=th).json()["data"]
    assert s["available_paise"] == FEE - FEE // 10 and s["pending_paise"] == 0


def test_paying_after_completion_makes_the_earning_available_immediately(client):
    th, ih, tid = setup(client)
    finish(client, ih, tid)
    paid(client, ih, tid)
    assert client.get(f"{API}/earnings", headers=th).json()["data"]["items"][0]["status"] == "AVAILABLE"
    assert len(types_of(client, th, "EARNING_AVAILABLE")) == 1


def test_a_hold_period_delays_availability_until_it_has_elapsed(client, monkeypatch):
    monkeypatch.setattr(settings, "earning_hold_days", 2)
    th, ih, tid = setup(client)
    paid(client, ih, tid)
    finish(client, ih, tid)
    assert client.get(f"{API}/earnings", headers=th).json()["data"]["items"][0]["status"] == "PENDING"
    db = db_of(client)
    db.get(Training, tid).completed_at = utcnow() - timedelta(days=3)
    db.commit()
    assert reconcile(db_of(client))["earnings_available"] == 1
    assert client.get(f"{API}/earnings", headers=th).json()["data"]["items"][0]["status"] == "AVAILABLE"
    assert reconcile(db_of(client))["earnings_available"] == 0                # idempotent
    assert len(types_of(client, th, "EARNING_AVAILABLE")) == 1


def test_cancelling_a_paid_training_flags_it_for_review_and_never_refunds_automatically(client):
    th, ih, tid = setup(client)
    ah = admin(client)
    pid = paid(client, ih, tid)
    assert client.post(f"{API}/trainings/{tid}/cancel", headers=th, json={"reason": "ill"}).status_code == 200
    stored = row(client, Payment, id=pid)
    assert stored.status == "SUCCEEDED" and stored.needs_review and stored.review_reason == "TRAINING_CANCELLED"
    assert count(client, PaymentRefund) == 0 and count(client, PaymentTransaction, type="REFUND") == 0
    assert row(client, TrainerEarning, payment_id=pid).status == "PENDING"            # a cancelled training can never complete
    assert len(types_of(client, ah, "PAYMENT_NEEDS_REVIEW")) == 1
    assert client.get(f"{API}/payments/{pid}", headers=ih).json()["data"]["under_review"] is True
    assert count(client, Invoice, payment_id=pid) == 1                                 # the record and its invoice are preserved
    assert db_of(client).query(AuditLog).filter_by(action="PAYMENT_FLAGGED", entity_id=pid).count() == 1


def test_cancelling_a_training_cancels_an_unstarted_payment_but_keeps_it(client):
    th, ih, tid = setup(client)
    pid = start(client, ih, tid)["id"]
    client.post(f"{API}/trainings/{tid}/cancel", headers=ih, json={})
    assert row(client, Payment, id=pid).status == "CANCELLED" and count(client, Payment) == 1


# ---------- Phase 12 reviews x Phase 13 payments ----------
# What the repository DEFINES: a review needs a COMPLETED training, its own institution or trainer, and an active account (review_service._eligibility); completing a
# training releases the trainer's earnings and requests the reviews in ONE transaction (training_service.complete); a cancelled training flags received money for
# an administrator (payment_service.on_training_cancelled) and is closed to reviews. What the requirements leave UNSPECIFIED, so that NOTHING below asserts it either
# way: whether a review should require the fee to be paid, whether a refund should affect an existing review, and whether earnings should depend on reviews. The
# tests below only use a PAID training where a review is possible under every one of those policies.
def _money_state(client, pid):
    p, e = row(client, Payment, id=pid), row(client, TrainerEarning, payment_id=pid)
    return (p.status, p.amount_paise, p.platform_fee_paise, p.net_paise, p.needs_review, e.status, e.net_paise, e.available_at,
            count(client, PaymentTransaction), count(client, Invoice), count(client, PaymentRefund), count(client, PlatformCommission), count(client, TrainerEarning))


def test_completing_a_paid_training_releases_the_earning_and_requests_both_reviews_which_can_then_be_submitted(client):
    th, ih, tid = setup(client)
    pid = paid(client, ih, tid)
    assert row(client, TrainerEarning, payment_id=pid).status == "PENDING"
    finish(client, ih, tid)
    assert row(client, TrainerEarning, payment_id=pid).status == "AVAILABLE"                                  # released by the completion itself
    assert len(types_of(client, th, "REVIEW_REQUEST")) == 1 and len(types_of(client, ih, "REVIEW_REQUEST")) == 1
    assert client.get(f"{API}/trainings/{tid}/reviews", headers=ih).json()["data"]["can_review"] is True
    assert submit_review(client, ih, tid, TRAINER_RATINGS).status_code == 201
    assert submit_review(client, th, tid, INST_RATINGS).status_code == 201
    assert count(client, Review) == 2


def test_a_notification_that_cannot_be_built_does_not_undo_the_completion_or_the_release_of_the_earning(client, monkeypatch):
    from app.services import notification_types as nt
    th, ih, tid = setup(client)
    pid = paid(client, ih, tid)
    begin(client, tid)
    for key in ("TRAINING_COMPLETED", "REVIEW_REQUEST", "EARNING_AVAILABLE"):                                     # all three are emitted by the completion transaction
        monkeypatch.setitem(nt.TYPES, key, nt.NotificationType(key, "Broken", "{missing_field}", "/trainings/{training_id}"))
    assert client.post(f"{API}/trainings/{tid}/complete", headers=ih).status_code == 200
    assert row(client, Training, id=tid).status == "COMPLETED"
    assert row(client, TrainerEarning, payment_id=pid).status == "AVAILABLE"                                      # the money change was kept
    assert types_of(client, th, "EARNING_AVAILABLE") == [] and types_of(client, th, "REVIEW_REQUEST") == [] and types_of(client, ih, "REVIEW_REQUEST") == []
    monkeypatch.undo()
    assert submit_review(client, ih, tid, TRAINER_RATINGS).status_code == 201                                     # reviewing still works


def test_a_cancelled_paid_training_is_flagged_for_the_payment_and_closed_to_reviews_without_moving_any_money(client):
    th, ih, tid = setup(client)
    pid = paid(client, ih, tid)
    assert client.post(f"{API}/trainings/{tid}/cancel", headers=th, json={"reason": "ill"}).status_code == 200
    stored = row(client, Payment, id=pid)
    assert stored.status == "SUCCEEDED" and stored.needs_review and stored.review_reason == "TRAINING_CANCELLED"
    before = _money_state(client, pid)
    for h, ratings in ((ih, TRAINER_RATINGS), (th, INST_RATINGS)):
        assert submit_review(client, h, tid, ratings).status_code == 409
        state = client.get(f"{API}/trainings/{tid}/reviews", headers=h).json()["data"]
        assert state["can_review"] is False and state["reason"] == "CANCELLED"
    assert count(client, Review) == 0 and _money_state(client, pid) == before and count(client, PaymentRefund) == 0


def test_an_admin_resolves_a_review_flag_with_a_note(client):
    th, ih, tid = setup(client)
    ah = admin(client)
    pid = paid(client, ih, tid)
    client.post(f"{API}/trainings/{tid}/cancel", headers=ih, json={})
    assert client.post(f"{API}/admin/payments/{pid}/resolve-review", headers=ah, json={"note": "x"}).status_code == 422
    r = client.post(f"{API}/admin/payments/{pid}/resolve-review", headers=ah, json={"note": "Checked with both parties"})
    assert r.status_code == 200 and r.json()["data"]["under_review"] is False and r.json()["data"]["review_note"] == "Checked with both parties"
    assert client.post(f"{API}/admin/payments/{pid}/resolve-review", headers=ah, json={"note": "again please"}).status_code == 409
    assert db_of(client).query(AuditLog).filter_by(action="PAYMENT_REVIEW_RESOLVED", entity_id=pid).count() == 1


# ---------- refunds ----------
def refund(client, ah, pid, reason="Requested by the institution"):
    return client.post(f"{API}/admin/payments/{pid}/refund", headers=ah, json={"reason": reason})


def test_an_admin_can_fully_refund_a_payment_once(client):
    th, ih, tid = setup(client)
    ah = admin(client)
    pid = paid(client, ih, tid)
    inv_before = client.get(f"{API}/payments/{pid}/invoice", headers=ih).json()["data"]
    r = refund(client, ah, pid)
    assert r.status_code == 200 and r.json()["data"]["status"] == "SUCCEEDED" and r.json()["data"]["amount_paise"] == FEE
    assert re.fullmatch(rf"ITB-CN-{today().year}-000001", r.json()["data"]["credit_note_number"])
    assert row(client, Payment, id=pid).status == "SUCCEEDED"                           # the payment record is preserved
    assert row(client, TrainerEarning, payment_id=pid).status == "REFUNDED"
    assert row(client, PlatformCommission, payment_id=pid).status == "REVERSED"
    assert count(client, PaymentTransaction, payment_id=pid, type="REFUND") == 1 and count(client, PaymentTransaction, payment_id=pid, type="CHARGE") == 1
    inv_after = client.get(f"{API}/payments/{pid}/invoice", headers=ih).json()["data"]
    assert inv_after["credit_note"]["number"].startswith("ITB-CN-") and {k: v for k, v in inv_after.items() if k != "credit_note"} == {k: v for k, v in inv_before.items() if k != "credit_note"}
    assert client.get(f"{API}/payments/{pid}", headers=ih).json()["data"]["refund"]["status"] == "SUCCEEDED"
    assert db_of(client).query(AuditLog).filter_by(action="REFUND_COMPLETED", entity_id=pid).count() == 1


def test_a_refund_requested_twice_is_never_executed_twice(client, flaky):
    th, ih, tid = setup(client)
    ah = admin(client)
    pid = paid(client, ih, tid)
    first, second = refund(client, ah, pid), refund(client, ah, pid)
    assert first.status_code == second.status_code == 200
    assert first.json()["data"]["credit_note_number"] == second.json()["data"]["credit_note_number"]
    assert (count(client, PaymentRefund), count(client, PaymentTransaction, type="REFUND")) == (1, 1)
    assert len(flaky.refund_calls) == 1                                                  # the provider was asked once
    assert flaky.refund_calls[0]["idempotency_key"] == f"refund-{pid}"


def test_only_a_successful_payment_can_be_refunded_and_never_partially(client):
    th, ih, tid = setup(client)
    ah = admin(client)
    pending = start(client, ih, tid)["id"]
    assert refund(client, ah, pending).status_code == 409
    assert refund(client, ah, 999999).status_code == 404
    sandbox(client, ih, pending)
    assert client.post(f"{API}/admin/payments/{pending}/refund", headers=ah, json={"amount_paise": 100}).json()["data"]["amount_paise"] == FEE   # no partial refunds: the amount is ignored
    assert count(client, PaymentRefund) == 1


def test_a_refund_after_the_payout_was_recorded_is_refused(client):
    th, ih, tid = setup(client)
    ah = admin(client)
    pid = paid(client, ih, tid)
    finish(client, ih, tid)
    eid = row(client, TrainerEarning, payment_id=pid).id
    assert client.post(f"{API}/admin/earnings/{eid}/payout", headers=ah, json={"reference": "BATCH-2026-10"}).status_code == 200
    r = refund(client, ah, pid)
    assert r.status_code == 409 and r.json()["data"]["code"] == "ALREADY_PAID_OUT"
    assert count(client, PaymentRefund) == 0 and row(client, TrainerEarning, id=eid).status == "PAID"


def test_a_provider_outage_leaves_a_pending_refund_that_can_be_resumed(client, flaky):
    th, ih, tid = setup(client)
    ah = admin(client)
    pid = paid(client, ih, tid)
    flaky.fail_refund = True
    r = refund(client, ah, pid)
    assert r.status_code == 502 and r.json()["data"]["code"] == "REFUND_PENDING"
    stored = row(client, PaymentRefund, payment_id=pid)
    assert (stored.status, stored.attempts, stored.last_error) == ("PENDING", 1, "gateway timeout") and stored.credit_note_number is None
    assert row(client, TrainerEarning, payment_id=pid).status == "PENDING" and count(client, PaymentTransaction, type="REFUND") == 0
    flaky.fail_refund = False
    done = refund(client, ah, pid)                                                       # the same request resumes the same refund
    assert done.status_code == 200 and done.json()["data"]["status"] == "SUCCEEDED" and count(client, PaymentRefund) == 1
    assert {c["idempotency_key"] for c in flaky.refund_calls} == {f"refund-{pid}"}       # every attempt used the same key


def test_the_worker_finishes_a_refund_that_was_left_pending(client, flaky):
    th, ih, tid = setup(client)
    ah = admin(client)
    pid = paid(client, ih, tid)
    flaky.fail_refund = True
    refund(client, ah, pid)
    flaky.fail_refund = False
    assert reconcile(db_of(client))["refunds_retried"] == 0                              # too recent: the worker leaves it for a minute
    db = db_of(client)
    db.query(PaymentRefund).update({"created_at": utcnow() - timedelta(minutes=5)})
    db.commit()
    assert reconcile(db_of(client))["refunds_retried"] == 1
    assert row(client, PaymentRefund, payment_id=pid).status == "SUCCEEDED" and row(client, TrainerEarning, payment_id=pid).status == "REFUNDED"
    assert reconcile(db_of(client))["refunds_retried"] == 0


def test_a_refund_that_keeps_failing_is_flagged_for_an_administrator(client, flaky):
    th, ih, tid = setup(client)
    ah = admin(client)
    pid = paid(client, ih, tid)
    flaky.fail_refund = True
    for _ in range(5):
        refund(client, ah, pid)
    stored = row(client, Payment, id=pid)
    assert stored.needs_review and stored.review_reason == "REFUND_STUCK"
    assert row(client, PaymentRefund, payment_id=pid).attempts == 5


def test_after_a_refund_the_money_is_no_longer_held_so_a_new_payment_is_possible(client):
    th, ih, tid = setup(client)
    ah = admin(client)
    pid = paid(client, ih, tid)
    refund(client, ah, pid)
    assert client.get(f"{API}/trainings/{tid}/payment-summary", headers=ih).json()["data"]["collected_paise"] == 0
    again = start(client, ih, tid)
    assert again["attempt_no"] == 2 and client.get(f"{API}/payments/summary", headers=ih).json()["data"]["refunded_paise"] == FEE


def test_refund_notifications_go_to_both_parties_once(client):
    th, ih, tid = setup(client)
    ah = admin(client)
    pid = paid(client, ih, tid)
    refund(client, ah, pid)
    refund(client, ah, pid)
    inst, trainer = types_of(client, ih, "PAYMENT_REFUNDED"), types_of(client, th, "PAYMENT_REFUNDED")
    assert len(inst) == 1 and inst[0]["link"] == "/institution/payments" and len(trainer) == 1 and trainer[0]["link"] == "/trainer/earnings"


# ---------- payouts ----------
def test_an_admin_records_a_payout_once_for_an_available_earning(client):
    th, ih, tid = setup(client)
    ah = admin(client)
    pid = paid(client, ih, tid)
    eid = row(client, TrainerEarning, payment_id=pid).id
    early = client.post(f"{API}/admin/earnings/{eid}/payout", headers=ah, json={"reference": "BATCH-2026-10"})
    assert early.status_code == 409 and early.json()["data"]["code"] == "NOT_AVAILABLE"      # the training is not completed yet
    finish(client, ih, tid)
    r = client.post(f"{API}/admin/earnings/{eid}/payout", headers=ah, json={"reference": "BATCH-2026-10"})
    assert r.status_code == 200 and r.json()["data"]["status"] == "PAID" and r.json()["data"]["payout_reference"] == "BATCH-2026-10"
    again = client.post(f"{API}/admin/earnings/{eid}/payout", headers=ah, json={"reference": "BATCH-2026-11"})
    assert again.status_code == 409 and again.json()["data"]["code"] == "ALREADY_PAID"
    e = row(client, TrainerEarning, id=eid)
    assert e.payout_reference == "BATCH-2026-10" and e.paid_at and e.paid_by
    mine = client.get(f"{API}/earnings", headers=th).json()["data"]["items"][0]
    assert mine["status"] == "PAID" and mine["payout_reference"] == "BATCH-2026-10"
    assert client.get(f"{API}/earnings/summary", headers=th).json()["data"]["paid_paise"] == FEE - FEE // 10
    assert len(types_of(client, th, "PAYOUT_RECORDED")) == 1
    assert db_of(client).query(AuditLog).filter_by(action="PAYOUT_RECORDED", entity_id=eid).count() == 1


@pytest.mark.parametrize("ref", ["12", "123456789012", "1234 5678 9012 3456", "someone@upi", "name@okbank", "x" * 81])
def test_a_payout_reference_cannot_carry_bank_or_upi_details(client, ref):
    th, ih, tid = setup(client)
    ah = admin(client)
    pid = paid(client, ih, tid)
    finish(client, ih, tid)
    eid = row(client, TrainerEarning, payment_id=pid).id
    assert client.post(f"{API}/admin/earnings/{eid}/payout", headers=ah, json={"reference": ref}).status_code == 422
    assert row(client, TrainerEarning, id=eid).status == "AVAILABLE"


def test_no_payout_while_a_payment_is_under_review_or_refunded(client):
    th, ih, tid = setup(client)
    ah = admin(client)
    pid = start(client, ih, tid)
    client.post(f"{API}/payments/{pid['id']}/cancel", headers=ih)
    sandbox(client, ih, pid["id"])                                                         # late success: flagged
    finish(client, ih, tid)
    eid = row(client, TrainerEarning, payment_id=pid["id"]).id
    r = client.post(f"{API}/admin/earnings/{eid}/payout", headers=ah, json={"reference": "BATCH-1"})
    assert r.status_code == 409 and r.json()["data"]["code"] == "UNDER_REVIEW"
    client.post(f"{API}/admin/payments/{pid['id']}/resolve-review", headers=ah, json={"note": "Checked, it is genuine"})
    refund(client, ah, pid["id"])
    r = client.post(f"{API}/admin/earnings/{eid}/payout", headers=ah, json={"reference": "BATCH-1"})
    assert r.status_code == 409 and r.json()["data"]["code"] in ("REFUND_EXISTS", "REFUNDED")


def test_admin_lists_show_money_details_and_paginate(client):
    th, ih, tid = setup(client)
    ah = admin(client)
    paid(client, ih, tid, FEE // 2)
    paid(client, ih, tid, FEE // 2)
    pays = client.get(f"{API}/admin/payments?page=1&page_size=1", headers=ah).json()["data"]
    assert pays["total"] == 2 and len(pays["items"]) == 1 and pays["items"][0]["platform_fee_paise"] == FEE // 20 and pays["items"][0]["provider"] == "sandbox"
    ears = client.get(f"{API}/admin/earnings?status=PENDING", headers=ah).json()["data"]
    assert ears["total"] == 2 and ears["items"][0]["trainer_name"] and ears["items"][0]["training_title"]
    assert client.get(f"{API}/admin/payments?status=NOPE", headers=ah).status_code == 422


# ---------- reconciliation ----------
def test_reconcile_settles_a_result_the_webhook_never_delivered(client, flaky):
    th, ih, tid = setup(client)
    p = start(client, ih, tid)
    db = db_of(client)
    db.get(Payment, p["id"]).created_at = utcnow() - timedelta(minutes=30)
    db.commit()
    flaky.statuses[p["checkout"]["order_id"]] = providers.ProviderEvent(event_id="recon-1", type="payment.succeeded", order_id=p["checkout"]["order_id"],
                                                                        amount_paise=FEE, currency="INR", txn_id="txn_recon_1")
    assert reconcile(db_of(client))["settled"] == 1
    assert row(client, Payment, id=p["id"]).status == "SUCCEEDED" and count(client, Invoice) == 1
    assert count(client, PaymentWebhookEvent, source="RECONCILE") == 1
    assert reconcile(db_of(client))["settled"] == 0                                        # nothing open any more


def test_reconcile_does_not_touch_recent_attempts_and_flags_stuck_processing_once(client):
    th, ih, tid = setup(client)
    p = start(client, ih, tid)
    assert reconcile(db_of(client))["expired"] == 0 and row(client, Payment, id=p["id"]).status == "PENDING"
    sandbox(client, ih, p["id"], "processing")
    db = db_of(client)
    db.get(Payment, p["id"]).created_at = utcnow() - timedelta(hours=5)
    db.commit()
    first = reconcile(db_of(client))
    assert first["stuck"] == 1 and first["expired"] == 0
    assert reconcile(db_of(client))["stuck"] == 0
    stored = row(client, Payment, id=p["id"])
    assert stored.status == "PROCESSING" and stored.review_reason == "STUCK_PROCESSING"      # flagged, but money might still be moving: not closed yet


# ---------- notifications ----------
def test_settlement_notifies_both_parties_once_with_working_links(client):
    th, ih, tid = setup(client)
    paid(client, ih, tid)
    inst, trainer = types_of(client, ih, "PAYMENT_SUCCEEDED"), types_of(client, th, "PAYMENT_RECEIVED")
    assert len(inst) == 1 and inst[0]["link"] == "/institution/payments" and "₹40,000" in inst[0]["body"]
    assert len(trainer) == 1 and trainer[0]["link"] == "/trainer/earnings"
    assert types_of(client, th, "PAYMENT_SUCCEEDED") == [] and types_of(client, ih, "PAYMENT_RECEIVED") == []


def test_an_over_cap_payment_tells_the_admin_and_the_payer_but_not_the_trainer(client):
    th, ih, tid = setup(client)
    ah = admin(client)
    first = start(client, ih, tid)
    sandbox(client, ih, first["id"], "fail")
    paid(client, ih, tid)
    deliver(client, first["checkout"]["order_id"])
    assert len(types_of(client, ih, "PAYMENT_SUCCEEDED")) == 2        # each successful payment has its own invoice and notice (different dedupe keys)
    assert len(types_of(client, th, "PAYMENT_RECEIVED")) == 1         # the trainer is told only about the payment they are actually owed
    assert len(types_of(client, ah, "PAYMENT_NEEDS_REVIEW")) == 1


def test_payment_notifications_never_contain_card_or_bank_details(client):
    th, ih, tid = setup(client)
    ah = admin(client)
    pid = paid(client, ih, tid)
    finish(client, ih, tid)
    refund(client, ah, pid)
    everything = " ".join(f"{n.title} {n.body}" for n in db_of(client).query(Notification).filter(Notification.type.like("PAY%")).all()).lower()
    assert everything and not any(w in everything for w in ("card", "cvv", "upi", "account number", "ifsc"))


# ---------- audit trail ----------
def test_every_financial_step_is_audited(client):
    th, ih, tid = setup(client)
    ah = admin(client)
    pid = paid(client, ih, tid)
    finish(client, ih, tid)
    eid = row(client, TrainerEarning, payment_id=pid).id
    client.post(f"{API}/admin/earnings/{eid}/payout", headers=ah, json={"reference": "BATCH-9"})
    actions = {a.action for a in db_of(client).query(AuditLog).all()}
    assert {"PAYMENT_CREATED", "PAYMENT_SUCCEEDED", "EARNING_AVAILABLE", "PAYOUT_RECORDED"} <= actions
    created = db_of(client).query(AuditLog).filter_by(action="PAYMENT_CREATED").one()
    assert created.user_id and created.details["amount_paise"] == FEE and created.details["commission_bps"] == 1000
    assert db_of(client).query(AuditLog).filter_by(action="PAYOUT_RECORDED").one().user_id == db_of(client).query(User).filter_by(email="admin@example.com").one().id


# ---------- database backstops (these run the real model constraints on SQLite; they are not concurrency tests) ----------
def test_the_database_itself_refuses_a_second_in_flight_payment_and_a_second_invoice(client):
    from sqlalchemy.exc import IntegrityError
    th, ih, tid = setup(client)
    started = start(client, ih, tid, FEE // 2)
    p = row(client, Payment, id=started["id"])
    db = db_of(client)
    db.add(Payment(training_id=p.training_id, institution_id=p.institution_id, trainer_id=p.trainer_id, payer_user_id=p.payer_user_id, attempt_no=9,
                   amount_paise=100, currency="INR", commission_bps=1000, platform_fee_paise=10, net_paise=90, status="PENDING", provider="sandbox",
                   provider_order_id="dup-" + uuid.uuid4().hex, request_fingerprint="f" * 64, needs_review=False))
    with pytest.raises(IntegrityError):
        db.flush()                                                     # the partial unique index, bypassing the service
    db.rollback()
    sandbox(client, ih, started["id"])
    db = db_of(client)
    inv = db.query(Invoice).filter_by(payment_id=started["id"]).one()
    db.add(Invoice(payment_id=started["id"], number="ITB-2999-000001", institution_id=inv.institution_id, trainer_id=inv.trainer_id, training_id=inv.training_id,
                   amount_paise=1, currency="INR", snapshot={}))
    with pytest.raises(IntegrityError):
        db.flush()                                                     # one invoice per payment
    db.rollback()


# ---------- production safety ----------
def _boot(code="import app.main", **env):
    """Runs `code` (by default: imports app.main) in a fresh interpreter so the start-up guard runs for real. Hermetic (13B.1): the child runs in an
    empty temporary directory with every Settings variable scrubbed from its environment, so neither backend/.env nor the developer's shell can
    change the outcome (tests/boot_env.py; tests/test_startup_hermetic.py proves it). ENVIRONMENT defaults to production here; ENVIRONMENT=None
    leaves it UNSET."""
    b = hermetic_boot(code, env={"ENVIRONMENT": "production", **env})
    return b.returncode, b.stderr


def test_production_refuses_to_start_with_the_sandbox_enabled():
    code, err = _boot(PAYMENTS_ENABLED="true", PAYMENT_PROVIDER="sandbox", PAYMENT_WEBHOOK_SECRET="Kq7vR2mZp9sT4wB8nC3dF6hJ1LaE5gY0xxxx", PAYMENT_COMMISSION_CONFIRMED="true")
    assert code != 0 and "unsafe payment configuration" in err and "sandbox" in err


def test_production_refuses_a_weak_or_missing_webhook_secret_and_an_unconfirmed_commission():
    for secret in ("", "change_me", "short"):
        code, err = _boot(PAYMENTS_ENABLED="true", PAYMENT_PROVIDER="somegateway", PAYMENT_WEBHOOK_SECRET=secret, PAYMENT_COMMISSION_CONFIRMED="true")
        assert code != 0 and "WEBHOOK_SECRET" in err, secret
    code, err = _boot(PAYMENTS_ENABLED="true", PAYMENT_PROVIDER="somegateway", PAYMENT_WEBHOOK_SECRET="Kq7vR2mZp9sT4wB8nC3dF6hJ1LaE5gY0xxxx")
    assert code != 0 and "COMMISSION" in err


def test_production_starts_with_payments_disabled_which_is_the_default_but_only_with_a_strong_webhook_secret():
    code, err = _boot(PAYMENT_WEBHOOK_SECRET="Kq7vR2mZp9sT4wB8nC3dF6hJ1LaE5gY0xxxx")
    assert code == 0, err
    code, err = _boot()                                                      # 13B.2: no secret at all is refused even with payments disabled
    assert code != 0 and "PAYMENT_WEBHOOK_SECRET is missing or empty" in err, err[-300:]


def test_an_invalid_commission_rate_stops_the_app_in_any_environment():
    code, err = _boot(ENVIRONMENT="development", PLATFORM_COMMISSION_BPS="10001")
    assert code != 0 and "PLATFORM_COMMISSION_BPS" in err


def test_the_production_guard_does_not_depend_on_how_the_environment_is_spelled():
    for env in ("Production", " PRODUCTION ", "prod"):
        code, err = _boot(ENVIRONMENT=env, PAYMENTS_ENABLED="true", PAYMENT_PROVIDER="sandbox", PAYMENT_WEBHOOK_SECRET="Kq7vR2mZp9sT4wB8nC3dF6hJ1LaE5gY0xxxx", PAYMENT_COMMISSION_CONFIRMED="true")
        assert code != 0 and "unsafe payment configuration" in err, env


def test_the_workers_refuse_an_unsafe_payment_configuration_just_like_the_api():
    unsafe = dict(PAYMENTS_ENABLED="true", PAYMENT_PROVIDER="sandbox", PAYMENT_WEBHOOK_SECRET="Kq7vR2mZp9sT4wB8nC3dF6hJ1LaE5gY0xxxx", PAYMENT_COMMISSION_CONFIRMED="true")
    for code_ in ("from app.workers.payments import run_once; run_once()", "from app.workers.loop import main; main()"):
        code, err = _boot(code_, **unsafe)
        assert code != 0 and "unsafe payment configuration" in err, code_


def test_the_documented_example_webhook_secret_is_refused_in_production():
    code, err = _boot(PAYMENTS_ENABLED="true", PAYMENT_PROVIDER="somegateway", PAYMENT_COMMISSION_CONFIRMED="true",
                      PAYMENT_WEBHOOK_SECRET="dev-only-sandbox-webhook-secret-do-not-use-in-production")
    assert code != 0 and "WEBHOOK_SECRET" in err


# ---------- fixes found by the independent review ----------
def test_the_commission_is_finalised_when_a_payment_succeeds_so_a_late_success_cannot_make_the_total_drift(client):
    """Fee Rs 3 (300 paise) at 10%. A (105 paise) fails, B (195 paise) is created, then A's success arrives late and B succeeds. The estimate stored
    when B was created (20) plus A's 11 would total 31 paise; the finalised commissions must total commission_total(300) = 30."""
    th, ih, tid = setup(client, fee=3)
    a = start(client, ih, tid, 105)
    sandbox(client, ih, a["id"], "fail")
    b = start(client, ih, tid, 195)
    assert row(client, Payment, id=b["id"]).platform_fee_paise == 20           # the estimate made at creation time
    assert deliver(client, a["checkout"]["order_id"], amount=105).json()["data"]["outcome"] == "succeeded_late"
    assert sandbox(client, ih, b["id"]).json()["data"]["payment"]["status"] == "SUCCEEDED"
    fees = {pid: row(client, Payment, id=pid).platform_fee_paise for pid in (a["id"], b["id"])}
    assert fees == {a["id"]: 11, b["id"]: 19} and sum(fees.values()) == rules.commission_total(300, 1000)
    for pid in (a["id"], b["id"]):
        pay_, earn, comm = row(client, Payment, id=pid), row(client, TrainerEarning, payment_id=pid), row(client, PlatformCommission, payment_id=pid)
        assert pay_.net_paise == pay_.amount_paise - pay_.platform_fee_paise
        assert (earn.commission_paise, earn.net_paise, comm.amount_paise) == (pay_.platform_fee_paise, pay_.net_paise, pay_.platform_fee_paise)


def test_after_a_refund_and_a_new_payment_the_live_commissions_still_total_the_commission_on_the_money_held(client):
    th, ih, tid = setup(client, fee=3)
    ah = admin(client)
    a, b = paid(client, ih, tid, 105), paid(client, ih, tid, 195)
    assert (row(client, Payment, id=a).platform_fee_paise, row(client, Payment, id=b).platform_fee_paise) == (11, 19)
    assert refund(client, ah, a).status_code == 200
    c = paid(client, ih, tid, 105)
    live = [row(client, PlatformCommission, payment_id=pid) for pid in (b, c)]
    assert all(x.status == "RECORDED" for x in live) and sum(x.amount_paise for x in live) == rules.commission_total(300, 1000) == 30


def test_a_payment_stuck_in_processing_is_flagged_then_closed_and_the_training_can_be_paid_again(client):
    th, ih, tid = setup(client)
    ah = admin(client)
    p = start(client, ih, tid)
    sandbox(client, ih, p["id"], "processing")
    assert client.post(f"{API}/payments/{p['id']}/cancel", headers=ih).status_code == 409           # the payer can never cancel a payment being processed
    db = db_of(client)
    db.get(Payment, p["id"]).created_at = utcnow() - timedelta(hours=30)
    db.commit()
    result = reconcile(db_of(client))
    assert result["expired"] == 1 and result["errors"] == 0
    stored = row(client, Payment, id=p["id"])
    assert stored.status == "EXPIRED" and stored.needs_review and stored.review_reason == "STUCK_PROCESSING"
    assert client.get(f"{API}/trainings/{tid}/payment-summary", headers=ih).json()["data"]["can_pay"] is True
    again = start(client, ih, tid)
    assert again["attempt_no"] == 2 and again["status"] == "PENDING"
    late = deliver(client, p["checkout"]["order_id"])                      # the provider finally reports the old one: recorded, not discarded
    assert late.json()["data"]["outcome"] == "succeeded_late" and row(client, Payment, id=p["id"]).status == "SUCCEEDED"
    assert row(client, Payment, id=p["id"]).review_reason == "STUCK_PROCESSING"          # the first reason stays; the late success is on the audit trail
    assert db_of(client).query(AuditLog).filter_by(action="PAYMENT_EXPIRED", entity_id=p["id"]).count() == 1
    assert sandbox(client, ih, again["id"]).json()["data"]["outcome"] == "succeeded_over_cap"      # and now the new attempt would exceed the fee: flagged for a refund
    assert row(client, Payment, id=again["id"]).review_reason == "OVER_CAP"


def test_one_payment_that_cannot_be_processed_does_not_stop_the_others_or_the_later_steps(client, flaky):
    ta, ia, tida = setup(client, "a")
    tb, ib, tidb = setup(client, "b")
    pa, pb = start(client, ia, tida), start(client, ib, tidb)
    db = db_of(client)
    for pid in (pa["id"], pb["id"]):
        db.get(Payment, pid).created_at = utcnow() - timedelta(minutes=30)
    db.commit()
    flaky.explode.add(pa["checkout"]["order_id"])                          # the first (lowest id) payment is a poison row
    flaky.statuses[pb["checkout"]["order_id"]] = providers.ProviderEvent(event_id="recon-b", type="payment.succeeded", order_id=pb["checkout"]["order_id"],
                                                                         amount_paise=FEE, currency="INR", txn_id="txn_recon_b")
    result = reconcile(db_of(client))
    assert result["errors"] == 1 and result["settled"] == 1
    assert row(client, Payment, id=pb["id"]).status == "SUCCEEDED" and row(client, Payment, id=pa["id"]).status == "PENDING"


def test_a_long_transaction_id_is_a_clean_400_not_a_server_error_and_a_maximum_one_is_accepted(client):
    th, ih, tid = setup(client)
    order = start(client, ih, tid)["checkout"]["order_id"]
    r = deliver(client, order, txn_id="t" * 121)
    assert r.status_code == 400 and r.json()["data"]["code"] == "BAD_EVENT" and count(client, PaymentWebhookEvent) == 0
    ok = deliver(client, order, txn_id="t" * 120, event_id="e" * 80)
    assert ok.status_code == 200 and ok.json()["data"]["outcome"] == "succeeded"
    th2, ih2, tid2 = setup(client, "b")
    order2 = start(client, ih2, tid2)["checkout"]["order_id"]
    assert deliver(client, order2, txn_id=None, event_id="f" * 80).json()["data"]["outcome"] == "succeeded"       # the "evt:" + id fallback fits too


def test_a_result_for_a_payment_is_still_recorded_after_payments_are_switched_off(client, monkeypatch):
    th, ih, tid = setup(client)
    order = start(client, ih, tid)["checkout"]["order_id"]
    monkeypatch.setattr(settings, "payments_enabled", False)
    r = deliver(client, order)
    assert r.status_code == 200 and r.json()["data"]["outcome"] == "succeeded" and count(client, Invoice) == 1        # evidence of a charge is never discarded
    finish(client, ih, tid)
    assert row(client, TrainerEarning, payment_id=db_of(client).query(Payment).one().id).status == "AVAILABLE"
    assert reconcile(db_of(client))["errors"] == 0                          # the worker still runs its non-provider steps


def test_a_sandbox_outside_development_and_test_is_treated_as_off_instead_of_leaving_payments_that_can_never_finish(client, monkeypatch):
    th, ih, tid = setup(client)
    monkeypatch.setattr(settings, "environment", "staging")
    r = pay(client, ih, tid)
    assert r.status_code == 503 and r.json()["data"]["code"] == "DISABLED"
    summary = client.get(f"{API}/trainings/{tid}/payment-summary", headers=ih).json()["data"]
    assert summary["enabled"] is False and summary["sandbox"] is False and summary["can_pay"] is False
    assert client.get(f"{API}/payments/summary", headers=ih).json()["data"]["enabled"] is False
    monkeypatch.setattr(settings, "environment", " Development ")                   # spelling does not matter
    assert pay(client, ih, tid).status_code == 201


def test_an_oversized_webhook_body_is_refused_before_it_is_read(client):
    big = b"x" * (64 * 1024 + 1)
    r = client.post(f"{API}/payments/webhook", content=big, headers={"Content-Type": "application/json"})
    assert r.status_code == 413 and count(client, PaymentWebhookEvent) == 0


def test_a_chunked_webhook_body_with_no_content_length_is_refused_at_the_limit_too(client):
    def pieces():                                                                   # an iterator body is sent chunked: there is no Content-Length to check first
        for _ in range(64):                                                         # 4 MiB in 64 KiB pieces
            yield b"x" * 65536
    r = client.post(f"{API}/payments/webhook", content=pieces(), headers={"Content-Type": "application/json"})
    assert r.status_code == 413 and r.json()["data"]["code"] == "TOO_LARGE" and count(client, PaymentWebhookEvent) == 0


def _stream_request(chunks, headers=()):
    """A real Starlette Request fed piece by piece; `pulled` records how many bytes the code under test actually asked for."""
    from starlette.requests import Request
    pulled = []

    async def receive():
        i = len(pulled)
        if i < len(chunks):
            pulled.append(len(chunks[i]))
            return {"type": "http.request", "body": chunks[i], "more_body": i < len(chunks) - 1}
        return {"type": "http.disconnect"}
    scope = {"type": "http", "method": "POST", "path": "/payments/webhook", "headers": [(k.encode(), v.encode("latin-1")) for k, v in headers]}
    return Request(scope, receive), pulled


def test_the_webhook_body_reader_stops_pulling_data_at_the_limit_instead_of_buffering_it_all():
    import asyncio
    from app.api.v1.payments import MAX_WEBHOOK_BYTES, raw_body
    from app.services.payment_service import PaymentError
    chunk = b"x" * 65536
    req, pulled = _stream_request([chunk] * 160)                                   # 10 MiB without a Content-Length
    with pytest.raises(PaymentError) as e:
        asyncio.run(raw_body(req))
    assert e.value.status_code == 413 and sum(pulled) <= MAX_WEBHOOK_BYTES + len(chunk), sum(pulled)
    exact, _ = _stream_request([b"y" * MAX_WEBHOOK_BYTES])                         # exactly the limit is accepted, one byte more is not
    assert len(asyncio.run(raw_body(exact))) == MAX_WEBHOOK_BYTES
    over, _ = _stream_request([b"y" * MAX_WEBHOOK_BYTES, b"z"])
    with pytest.raises(PaymentError):
        asyncio.run(raw_body(over))
    declared, pulled = _stream_request([chunk] * 4, headers=[("content-length", str(10 * 2**20))])
    with pytest.raises(PaymentError):
        asyncio.run(raw_body(declared))
    assert sum(pulled) == 0                                                         # a declared oversize length is refused before reading anything


def test_a_content_length_that_is_not_plain_ascii_digits_is_not_a_server_error():
    import asyncio
    from app.api.v1.payments import raw_body
    req, _ = _stream_request([b"{}"], headers=[("content-length", "²")])      # "²".isdigit() is True but int("²") raises
    assert asyncio.run(raw_body(req)) == b"{}"


def test_a_webhook_timestamp_too_large_for_a_float_is_a_401_not_a_server_error(client):
    th, ih, tid = setup(client)
    body, headers = signed(start(client, ih, tid)["checkout"]["order_id"])
    for stamp in ("9" * 400, "-" + "9" * 400):
        r = client.post(f"{API}/payments/webhook", content=body, headers={**headers, providers.TIMESTAMP_HEADER: stamp})
        assert r.status_code == 401 and r.json()["data"]["code"] == "WEBHOOK_REJECTED", stamp
    assert count(client, PaymentWebhookEvent) == 0 and count(client, Invoice) == 0


def test_who_pressed_the_sandbox_button_is_recorded(client):
    th, ih, tid = setup(client)
    pid = start(client, ih, tid)["id"]
    sandbox(client, ih, pid)
    me = db_of(client).query(User).filter_by(email="ia@example.com").one().id
    entry = db_of(client).query(AuditLog).filter_by(action="PAYMENT_SANDBOX_SIMULATED", entity_id=pid).one()
    assert entry.user_id == me and entry.details["outcome"] == "success"


def test_a_cancelled_training_is_reported_even_when_the_payment_already_carries_another_flag(client):
    th, ih, tid = setup(client)
    ah = admin(client)
    p = start(client, ih, tid)
    sandbox(client, ih, p["id"], "fail")
    assert deliver(client, p["checkout"]["order_id"]).json()["data"]["outcome"] == "succeeded_late"       # first flag: LATE_SUCCESS
    assert row(client, Payment, id=p["id"]).review_reason == "LATE_SUCCESS"
    assert client.post(f"{API}/trainings/{tid}/cancel", headers=ih, json={"reason": "no longer needed"}).status_code == 200
    stored = row(client, Payment, id=p["id"])
    assert stored.review_reason == "LATE_SUCCESS"                                                          # the first reason stays...
    flags = [a.details["reason"] for a in db_of(client).query(AuditLog).filter_by(action="PAYMENT_FLAGGED", entity_id=p["id"]).all()]
    assert "TRAINING_CANCELLED" in flags                                                                   # ...but the cancellation is on record
    assert len(types_of(client, ah, "PAYMENT_NEEDS_REVIEW")) == 2


def test_money_arriving_for_a_cancelled_training_is_flagged_for_both_reasons(client):
    th, ih, tid = setup(client)
    p = start(client, ih, tid)
    sandbox(client, ih, p["id"], "fail")
    assert client.post(f"{API}/trainings/{tid}/cancel", headers=ih, json={"reason": "x"}).status_code == 200
    assert deliver(client, p["checkout"]["order_id"]).json()["data"]["outcome"] == "succeeded_late"
    flags = {a.details["reason"] for a in db_of(client).query(AuditLog).filter_by(action="PAYMENT_FLAGGED", entity_id=p["id"]).all()}
    assert flags == {"LATE_SUCCESS", "TRAINING_CANCELLED"}



# =====================================================================================================================
# Phase 13 remediation. These tests need the full dependency set (pytest, FastAPI, SQLAlchemy). They have NOT been executed in the environment
# where they were written (no packages could be installed there); see PROJECT_PROGRESS.md for the exact status.
# =====================================================================================================================
def _expire(client, pid):
    """Makes an open attempt overdue and lets the reconciliation job expire it (the sandbox provider reports no final result)."""
    db = db_of(client)
    q = db.get(Payment, pid)
    q.created_at, q.expires_at = utcnow() - timedelta(hours=3), utcnow() - timedelta(hours=2)
    db.commit()
    assert reconcile(db_of(client))["expired"] >= 1
    assert row(client, Payment, id=pid).status == "EXPIRED"


def _open_flags(client, pid):
    return [f.reason for f in db_of(client).query(PaymentReviewFlag).filter_by(payment_id=pid, resolved_at=None).order_by(PaymentReviewFlag.id)]


# ---------- B1: an over-cap payment must not make a later legitimate payment over-cap ----------
FEE100 = 100                      # rupees
A_PAISE, B_PAISE, C_PAISE = 6_000, 6_000, 4_000


def _b1_to_c_open(client):
    """Fee Rs 100. B (Rs 60) is created first and expires (only one attempt can be in flight and the cap applies at creation, so the payment that
    expires must have existed before A succeeded); A (Rs 60) is created and succeeds; C (Rs 40) is created and stays open."""
    th, ih, tid = setup(client, fee=FEE100)
    ah = admin(client)
    b = start(client, ih, tid, B_PAISE)
    _expire(client, b["id"])
    a_id = paid(client, ih, tid, A_PAISE)
    c = start(client, ih, tid, C_PAISE)
    return th, ih, ah, tid, a_id, b, c


def test_B1_over_cap_late_success_of_an_expired_payment_does_not_flag_the_later_legitimate_payment(client):
    th, ih, ah, tid, a_id, b, c = _b1_to_c_open(client)
    r = deliver(client, b["checkout"]["order_id"], amount=B_PAISE)                                   # B reports a late success
    assert r.status_code == 200 and r.json()["data"]["outcome"] == "succeeded_over_cap"
    assert row(client, Payment, id=b["id"]).review_reason == "OVER_CAP" and _open_flags(client, b["id"]) == ["OVER_CAP"]
    assert (count(client, TrainerEarning), count(client, PlatformCommission)) == (1, 1)               # only A so far

    r = sandbox(client, ih, c["id"])                                                                  # C succeeds
    assert r.status_code == 200 and r.json()["data"]["outcome"] == "succeeded", r.text
    c_row = row(client, Payment, id=c["id"])
    assert c_row.status == "SUCCEEDED" and not c_row.needs_review and c_row.review_reason is None, "C must not be flagged because of B"
    assert _open_flags(client, c["id"]) == [] and _open_flags(client, a_id) == []
    review_queue = client.get(f"{API}/admin/payments?needs_review=true", headers=ah).json()["data"]["items"]
    assert [x["id"] for x in review_queue] == [b["id"]]                                               # only B is waiting for an administrator

    # every total: settled money is exactly the fee, commission is exactly 10% of it, B carries an invoice and nothing else
    ok_ids = [a_id, c["id"]]
    assert count(client, Payment, status="SUCCEEDED") == 3 and count(client, Invoice) == 3
    assert count(client, Invoice, payment_id=b["id"]) == 1
    assert count(client, TrainerEarning) == 2 and count(client, TrainerEarning, payment_id=b["id"]) == 0
    assert count(client, PlatformCommission) == 2 and count(client, PlatformCommission, payment_id=b["id"]) == 0
    assert sum(row(client, TrainerEarning, payment_id=i).gross_paise for i in ok_ids) == 10_000
    assert sum(row(client, TrainerEarning, payment_id=i).net_paise for i in ok_ids) == 9_000
    assert sum(row(client, PlatformCommission, payment_id=i).amount_paise for i in ok_ids) == 1_000 == rules.commission_total(10_000, 1000)
    assert (row(client, Payment, id=a_id).platform_fee_paise, row(client, Payment, id=c["id"]).platform_fee_paise) == (600, 400)
    b_row = row(client, Payment, id=b["id"])
    assert (b_row.platform_fee_paise, b_row.net_paise) == (0, B_PAISE)
    assert count(client, PaymentTransaction, type="CHARGE") == 3                                      # three real charges: the third must be refunded


def test_B1_after_the_over_cap_payment_is_refunded_the_books_are_unchanged(client):
    th, ih, ah, tid, a_id, b, c = _b1_to_c_open(client)
    deliver(client, b["checkout"]["order_id"], amount=B_PAISE)
    sandbox(client, ih, c["id"])
    before = ({e.payment_id: (e.status, e.net_paise) for e in db_of(client).query(TrainerEarning)},
              {k.payment_id: (k.status, k.amount_paise) for k in db_of(client).query(PlatformCommission)})
    r = refund(client, ah, b["id"])
    assert r.status_code == 200 and r.json()["data"]["status"] == "SUCCEEDED" and r.json()["data"]["amount_paise"] == B_PAISE
    after = ({e.payment_id: (e.status, e.net_paise) for e in db_of(client).query(TrainerEarning)},
             {k.payment_id: (k.status, k.amount_paise) for k in db_of(client).query(PlatformCommission)})
    assert after == before, "refunding the over-cap payment must not touch the settled payments"
    assert count(client, PaymentRefund) == 1 and row(client, PaymentRefund, payment_id=b["id"]).amount_paise == B_PAISE
    assert count(client, PaymentTransaction, type="REFUND") == 1
    inv = client.get(f"{API}/payments/{b['id']}/invoice", headers=ih).json()["data"]
    assert inv["credit_note"]["amount_paise"] == B_PAISE
    summary = client.get(f"{API}/trainings/{tid}/payment-summary", headers=ih).json()["data"]
    assert summary["collected_paise"] == 10_000, "the money held is back at the agreed fee"
    assert client.post(f"{API}/admin/payments/{b['id']}/resolve-review", headers=ah, json={"note": "refunded"}).status_code == 200
    assert client.get(f"{API}/admin/payments?needs_review=true", headers=ah).json()["data"]["items"] == []
    assert pay(client, ih, tid, 100).status_code == 409                                              # nothing more may be paid: the fee is covered


def test_B1_refunding_the_over_cap_payment_before_C_succeeds_gives_the_same_books(client):
    th, ih, ah, tid, a_id, b, c = _b1_to_c_open(client)
    deliver(client, b["checkout"]["order_id"], amount=B_PAISE)
    assert refund(client, ah, b["id"]).status_code == 200
    r = sandbox(client, ih, c["id"])
    assert r.json()["data"]["outcome"] == "succeeded" and not row(client, Payment, id=c["id"]).needs_review
    assert sum(row(client, PlatformCommission, payment_id=i).amount_paise for i in (a_id, c["id"])) == 1_000
    assert count(client, TrainerEarning) == 2 and count(client, Invoice) == 3


def test_B1_replaying_the_late_success_or_the_success_creates_nothing_new(client):
    th, ih, ah, tid, a_id, b, c = _b1_to_c_open(client)
    first = deliver(client, b["checkout"]["order_id"], amount=B_PAISE, event_id="evt_b_late", txn_id="txn_b")
    assert first.json()["data"]["outcome"] == "succeeded_over_cap"
    for _ in range(2):
        again = deliver(client, b["checkout"]["order_id"], amount=B_PAISE, event_id="evt_b_late", txn_id="txn_b")
        assert again.status_code == 200 and again.json()["data"]["outcome"] in ("replay", "duplicate")
    sandbox(client, ih, c["id"])
    sandbox(client, ih, c["id"])
    assert (count(client, Invoice), count(client, TrainerEarning), count(client, PlatformCommission), count(client, PaymentRefund)) == (3, 2, 2, 0)
    assert count(client, PaymentTransaction, type="CHARGE") == 3


# ---------- B2: several different review reasons on one payment ----------
def _three_flags(client):
    th, ih, tid = setup(client)
    ah = admin(client)
    p = start(client, ih, tid)
    order = p["checkout"]["order_id"]
    assert deliver(client, order, txn_id="txn_first").json()["data"]["outcome"] == "succeeded"
    assert deliver(client, order, txn_id="txn_second").json()["data"]["outcome"] == "duplicate_charge"          # DUPLICATE_CHARGE
    assert deliver(client, order, amount=FEE - 100).json()["data"]["outcome"] == "amount_mismatch"              # AMOUNT_MISMATCH
    assert client.post(f"{API}/trainings/{tid}/cancel", headers=ih, json={"reason": "no longer needed"}).status_code == 200   # TRAINING_CANCELLED
    assert _open_flags(client, p["id"]) == ["DUPLICATE_CHARGE", "AMOUNT_MISMATCH", "TRAINING_CANCELLED"]
    return th, ih, ah, tid, p["id"]


def resolve(client, ah, pid, note="Checked with both parties", **extra):
    return client.post(f"{API}/admin/payments/{pid}/resolve-review", headers=ah, json={"note": note, **extra})


def _queue(client, ah):
    return [x["id"] for x in client.get(f"{API}/admin/payments?needs_review=true", headers=ah).json()["data"]["items"]]


def test_B2_each_review_reason_is_its_own_durable_row_and_all_are_visible_to_the_admin(client):
    th, ih, ah, tid, pid = _three_flags(client)
    item = client.get(f"{API}/admin/payments?needs_review=true", headers=ah).json()["data"]["items"][0]
    assert [f["reason"] for f in item["review_flags"]] == ["DUPLICATE_CHARGE", "AMOUNT_MISMATCH", "TRAINING_CANCELLED"] and item["review_history"] == []
    assert item["under_review"] is True and item["review_reason"] == "DUPLICATE_CHARGE"                  # the oldest open reason summarises
    assert count(client, PaymentReviewFlag, payment_id=pid) == 3
    flagged = [a.details["reason"] for a in db_of(client).query(AuditLog).filter_by(action="PAYMENT_FLAGGED", entity_id=pid)]
    assert sorted(flagged) == ["AMOUNT_MISMATCH", "DUPLICATE_CHARGE", "TRAINING_CANCELLED"]


def test_B2_resolving_one_reason_never_hides_the_others(client):
    th, ih, ah, tid, pid = _three_flags(client)
    r = resolve(client, ah, pid, reason="AMOUNT_MISMATCH")                                              # the middle one
    assert r.status_code == 200 and r.json()["data"]["under_review"] is True
    assert [f["reason"] for f in r.json()["data"]["review_flags"]] == ["DUPLICATE_CHARGE", "TRAINING_CANCELLED"]
    assert [f["reason"] for f in r.json()["data"]["review_history"]] == ["AMOUNT_MISMATCH"]
    assert _queue(client, ah) == [pid], "still in the review queue"
    assert row(client, Payment, id=pid).needs_review and row(client, Payment, id=pid).review_reason == "DUPLICATE_CHARGE"
    r = resolve(client, ah, pid, reason="DUPLICATE_CHARGE")
    assert r.json()["data"]["under_review"] is True and [f["reason"] for f in r.json()["data"]["review_flags"]] == ["TRAINING_CANCELLED"]
    assert _queue(client, ah) == [pid] and row(client, Payment, id=pid).review_reason == "TRAINING_CANCELLED"
    r = resolve(client, ah, pid)                                                                         # one left: no reason needed
    assert r.status_code == 200 and r.json()["data"]["under_review"] is False and r.json()["data"]["review_flags"] == []
    assert sorted(f["reason"] for f in r.json()["data"]["review_history"]) == ["AMOUNT_MISMATCH", "DUPLICATE_CHARGE", "TRAINING_CANCELLED"]
    assert _queue(client, ah) == [] and not row(client, Payment, id=pid).needs_review and row(client, Payment, id=pid).review_reason is None
    assert resolve(client, ah, pid).status_code == 409                                                   # nothing left to resolve


def test_B2_with_several_open_reasons_the_administrator_must_name_one(client):
    th, ih, ah, tid, pid = _three_flags(client)
    r = resolve(client, ah, pid)
    assert r.status_code == 409 and r.json()["data"]["code"] == "REASON_REQUIRED"
    r = resolve(client, ah, pid, reason="OVER_CAP")                                                      # a real reason, but not open on this payment
    assert r.status_code == 409 and r.json()["data"]["code"] == "FLAG_NOT_OPEN"
    assert resolve(client, ah, pid, reason="NOT_A_REASON").status_code == 422
    assert _open_flags(client, pid) == ["DUPLICATE_CHARGE", "AMOUNT_MISMATCH", "TRAINING_CANCELLED"]    # nothing changed
    assert db_of(client).query(AuditLog).filter_by(action="PAYMENT_REVIEW_RESOLVED", entity_id=pid).count() == 0


def test_B2_resolving_is_audited_per_reason_with_what_is_still_open(client):
    th, ih, ah, tid, pid = _three_flags(client)
    resolve(client, ah, pid, note="Provider confirmed the second charge was a test", reason="DUPLICATE_CHARGE")
    entries = db_of(client).query(AuditLog).filter_by(action="PAYMENT_REVIEW_RESOLVED", entity_id=pid).all()
    assert len(entries) == 1 and entries[0].details["reason"] == "DUPLICATE_CHARGE"
    assert sorted(entries[0].details["still_open"]) == ["AMOUNT_MISMATCH", "TRAINING_CANCELLED"]
    flag = db_of(client).query(PaymentReviewFlag).filter_by(payment_id=pid, reason="DUPLICATE_CHARGE").one()
    assert flag.resolved_at and flag.resolved_by and flag.resolution_note == "Provider confirmed the second charge was a test"


def test_B2_the_same_reason_is_one_open_flag_not_two(client):
    th, ih, ah, tid, pid = _three_flags(client)
    notified = len(types_of(client, ah, "PAYMENT_NEEDS_REVIEW"))
    deliver(client, db_of(client).get(Payment, pid).provider_order_id, txn_id="txn_third")              # another duplicate charge
    assert _open_flags(client, pid).count("DUPLICATE_CHARGE") == 1 and count(client, PaymentReviewFlag, payment_id=pid) == 3
    assert len(types_of(client, ah, "PAYMENT_NEEDS_REVIEW")) == notified, "an already-open reason is not announced again"
    resolve(client, ah, pid, reason="DUPLICATE_CHARGE")
    deliver(client, db_of(client).get(Payment, pid).provider_order_id, txn_id="txn_fourth")             # after it was resolved, a new duplicate is a new flag
    assert _open_flags(client, pid).count("DUPLICATE_CHARGE") == 1 and count(client, PaymentReviewFlag, payment_id=pid) == 4


def test_B2_payout_stays_blocked_until_every_flag_is_resolved(client):
    th, ih, tid = setup(client)
    ah = admin(client)
    pid = start(client, ih, tid)
    sandbox(client, ih, pid["id"], "fail")
    deliver(client, pid["checkout"]["order_id"])                                                         # LATE_SUCCESS
    deliver(client, pid["checkout"]["order_id"], txn_id="txn_other")                                     # DUPLICATE_CHARGE
    assert _open_flags(client, pid["id"]) == ["LATE_SUCCESS", "DUPLICATE_CHARGE"]
    finish(client, ih, tid)
    eid = row(client, TrainerEarning, payment_id=pid["id"]).id
    pay_out = lambda: client.post(f"{API}/admin/earnings/{eid}/payout", headers=ah, json={"reference": "BATCH-9"})
    assert pay_out().json()["data"]["code"] == "UNDER_REVIEW"
    resolve(client, ah, pid["id"], reason="LATE_SUCCESS")
    assert pay_out().json()["data"]["code"] == "UNDER_REVIEW"                                            # one flag remains
    resolve(client, ah, pid["id"], reason="DUPLICATE_CHARGE")
    assert pay_out().status_code == 200 and row(client, TrainerEarning, id=eid).status == "PAID"


def test_B2_an_over_cap_flag_still_needs_the_refund_even_when_other_reasons_are_open(client):
    th, ih, ah, tid, a_id, b, c = _b1_to_c_open(client)
    deliver(client, b["checkout"]["order_id"], amount=B_PAISE)                                           # OVER_CAP on B
    deliver(client, b["checkout"]["order_id"], amount=B_PAISE, txn_id="txn_b_again")                     # DUPLICATE_CHARGE on B
    assert _open_flags(client, b["id"]) == ["OVER_CAP", "DUPLICATE_CHARGE"]
    r = resolve(client, ah, b["id"], reason="OVER_CAP")
    assert r.status_code == 409 and r.json()["data"]["code"] == "REFUND_REQUIRED"
    assert resolve(client, ah, b["id"], reason="DUPLICATE_CHARGE").status_code == 200                    # the other reason can be closed meanwhile
    assert _queue(client, ah) == [b["id"]]
    assert refund(client, ah, b["id"]).status_code == 200
    assert resolve(client, ah, b["id"], reason="OVER_CAP").json()["data"]["under_review"] is False


def test_B2_only_an_administrator_can_resolve_and_a_payment_without_flags_cannot_be_resolved(client):
    th, ih, ah, tid, pid = _three_flags(client)
    for h in (ih, th):
        assert resolve(client, h, pid, reason="AMOUNT_MISMATCH").status_code == 403
    assert client.post(f"{API}/admin/payments/{pid}/resolve-review", json={"note": "anonymous"}).status_code == 401
    assert resolve(client, ah, pid, reason="AMOUNT_MISMATCH").status_code == 200
    assert resolve(client, ah, 999_999, reason="AMOUNT_MISMATCH").status_code == 404
    th2, ih2, tid2 = setup(client, "z")
    clean = paid(client, ih2, tid2)
    r = resolve(client, ah, clean)
    assert r.status_code == 409 and r.json()["data"]["code"] == "NOT_FLAGGED"


def test_B2_the_database_allows_one_open_flag_per_reason_and_payment(client):
    from sqlalchemy.exc import IntegrityError
    th, ih, ah, tid, pid = _three_flags(client)
    db = db_of(client)
    db.add(PaymentReviewFlag(payment_id=pid, reason="AMOUNT_MISMATCH", note="second open one", created_at=utcnow()))
    with pytest.raises(IntegrityError):
        db.flush()
    db.rollback()
    db.add(PaymentReviewFlag(payment_id=pid, reason="NOT_A_REASON", created_at=utcnow()))
    with pytest.raises(IntegrityError):
        db.flush()
    db.rollback()


# ---------- sandbox configuration ----------
def test_the_sandbox_needs_its_explicit_opt_in_even_when_payments_are_enabled(client, monkeypatch):
    th, ih, tid = setup(client)
    monkeypatch.setattr(settings, "payment_sandbox_enabled", False)
    r = pay(client, ih, tid)
    assert r.status_code == 503 and r.json()["data"]["code"] == "DISABLED"
    summary = client.get(f"{API}/trainings/{tid}/payment-summary", headers=ih).json()["data"]
    assert summary["enabled"] is False and summary["sandbox"] is False and summary["can_pay"] is False
    assert client.get(f"{API}/payments/summary", headers=ih).json()["data"]["enabled"] is False
    assert count(client, Payment) == 0
    monkeypatch.setattr(settings, "payment_sandbox_enabled", True)
    assert pay(client, ih, tid).status_code == 201


def test_without_the_opt_in_a_signed_webhook_is_refused_and_the_simulator_is_unavailable(client, monkeypatch):
    th, ih, tid = setup(client)
    pid = start(client, ih, tid)
    monkeypatch.setattr(settings, "payment_sandbox_enabled", False)
    assert sandbox(client, ih, pid["id"]).status_code == 403
    assert deliver(client, pid["checkout"]["order_id"]).status_code == 503
    assert row(client, Payment, id=pid["id"]).status == "PENDING"


def test_the_example_environment_file_leaves_payments_and_the_sandbox_off():
    text = (BACKEND.parent / ".env.example").read_text()
    values = dict(line.split("=", 1) for line in text.splitlines() if "=" in line and not line.lstrip().startswith("#"))
    assert values["PAYMENTS_ENABLED"].strip() == "false" and values["PAYMENT_SANDBOX_ENABLED"].strip() == "false"
    assert values["PAYMENT_COMMISSION_CONFIRMED"].strip() == "false"


STRONG = "Kq7vR2mZp9sT4wB8nC3dF6hJ1LaE5gY0xxxx"


def test_boot_with_payments_disabled_needs_no_other_payment_settings_in_a_recognised_environment():
    for env in ("production", "development", "test"):
        code, err = _boot(ENVIRONMENT=env, PAYMENT_WEBHOOK_SECRET="Kq7vR2mZp9sT4wB8nC3dF6hJ1LaE5gY0xxxx")      # production needs the secret; the others do not care
        assert code == 0, (env, err)
    for env in ("development", "test"):
        code, err = _boot(ENVIRONMENT=env)                                                                      # no secret at all is fine outside production
        assert code == 0, (env, err)


def test_boot_with_an_unknown_or_missing_environment_is_refused_even_with_payments_disabled():
    for env in ("staging", "", None):
        code, err = _boot(ENVIRONMENT=env)
        assert code != 0 and "ENVIRONMENT is missing or not recognised" in err, (env, err[-300:])


def test_boot_with_a_missing_environment_and_payments_enabled_fails_closed():
    code, err = _boot(ENVIRONMENT=None, PAYMENTS_ENABLED="true", PAYMENT_PROVIDER="sandbox", PAYMENT_SANDBOX_ENABLED="true", PAYMENT_WEBHOOK_SECRET=STRONG)
    assert code != 0 and "ENVIRONMENT is missing or not recognised" in err


def test_boot_with_the_sandbox_enabled_but_not_opted_in_fails_closed():
    code, err = _boot(ENVIRONMENT="development", PAYMENTS_ENABLED="true", PAYMENT_PROVIDER="sandbox")
    assert code != 0 and "PAYMENT_SANDBOX_ENABLED" in err


def test_boot_with_an_unrecognised_environment_and_payments_enabled_fails_closed():
    for env in ("staging", "prodution", "live"):
        code, err = _boot(ENVIRONMENT=env, PAYMENTS_ENABLED="true", PAYMENT_PROVIDER="sandbox", PAYMENT_SANDBOX_ENABLED="true")
        assert code != 0 and "missing or not recognised" in err, env


def test_boot_in_development_with_payments_and_the_explicit_sandbox_opt_in_starts():
    code, err = _boot(ENVIRONMENT="development", PAYMENTS_ENABLED="true", PAYMENT_PROVIDER="sandbox", PAYMENT_SANDBOX_ENABLED="true")
    assert code == 0, err
    code, err = _boot(ENVIRONMENT="test", PAYMENTS_ENABLED="true", PAYMENT_PROVIDER="sandbox", PAYMENT_SANDBOX_ENABLED="true")
    assert code == 0, err


def test_boot_in_production_refuses_the_sandbox_opt_in_with_or_without_payments_enabled():
    for enabled in ("true", "false"):
        code, err = _boot(ENVIRONMENT="production", PAYMENTS_ENABLED=enabled, PAYMENT_PROVIDER="sandbox", PAYMENT_SANDBOX_ENABLED="true",
                          PAYMENT_WEBHOOK_SECRET=STRONG, PAYMENT_COMMISSION_CONFIRMED="true")
        assert code != 0 and "PAYMENT_SANDBOX_ENABLED" in err, enabled


def test_boot_in_production_with_payments_enabled_never_starts_while_no_real_provider_exists():
    for provider in ("sandbox", "somegateway"):
        code, err = _boot(ENVIRONMENT="production", PAYMENTS_ENABLED="true", PAYMENT_PROVIDER=provider, PAYMENT_WEBHOOK_SECRET=STRONG, PAYMENT_COMMISSION_CONFIRMED="true")
        assert code != 0 and "unsafe payment configuration" in err, provider


def test_boot_in_production_names_every_missing_secret():
    code, err = _boot(ENVIRONMENT="production", PAYMENTS_ENABLED="true", PAYMENT_PROVIDER="somegateway", PAYMENT_WEBHOOK_SECRET=None)
    assert code != 0 and "WEBHOOK_SECRET" in err and "COMMISSION" in err


def test_the_workers_also_refuse_a_missing_opt_in_and_a_missing_environment():
    for code_ in ("from app.workers.payments import run_once; run_once()", "from app.workers.loop import main; main()"):
        for env in (dict(ENVIRONMENT="development", PAYMENTS_ENABLED="true", PAYMENT_PROVIDER="sandbox"),
                    dict(ENVIRONMENT=None, PAYMENTS_ENABLED="true", PAYMENT_PROVIDER="sandbox", PAYMENT_SANDBOX_ENABLED="true")):
            code, err = _boot(code_, **env)
            assert code != 0 and "unsafe payment configuration" in err, (code_, env)


# ---------- 13B.1: an over-cap payment on hold is not "the fee paid in full" ----------
def _summary(client, h, tid):
    return client.get(f"{API}/trainings/{tid}/payment-summary", headers=h).json()["data"]


def test_money_on_hold_pending_refund_is_not_reported_as_the_fee_paid_in_full_and_the_amount_still_due_is_named(client):
    """Fee Rs 100. A (Rs 60) settles. B (Rs 60) expired earlier and its success arrives late: it is over the cap, so it is HELD awaiting a refund. Held money
    (Rs 120) already reaches the fee, which blocks a new attempt, but only Rs 60 counts towards it: Rs 40 of the agreed fee is still due."""
    th, ih, tid = setup(client, fee=FEE100)
    ah = admin(client)
    b = start(client, ih, tid, B_PAISE)
    _expire(client, b["id"])
    paid(client, ih, tid, A_PAISE)
    assert deliver(client, b["checkout"]["order_id"], amount=B_PAISE).json()["data"]["outcome"] == "succeeded_over_cap"
    s = _summary(client, ih, tid)
    assert (s["collected_paise"], s["settled_paise"], s["remaining_paise"], s["due_paise"]) == (A_PAISE + B_PAISE, A_PAISE, 0, FEE100 * 100 - A_PAISE)
    assert s["can_pay"] is False and s["block_reason"] == "AWAITING_REFUND"
    assert "paid in full" not in s["block_message"] and "₹40" in s["block_message"] and "refund" in s["block_message"]
    r = pay(client, ih, tid, 4_000)                                                       # the cap rules are unchanged: nothing new can start yet
    assert r.status_code == 409 and r.json()["data"]["code"] == "AWAITING_REFUND"
    assert "paid in full" not in r.json()["message"] and "₹40" in r.json()["message"]
    assert refund(client, ah, b["id"]).status_code == 200                                 # the administrator refunds the held payment
    s = _summary(client, ih, tid)
    assert (s["collected_paise"], s["settled_paise"], s["due_paise"], s["can_pay"], s["block_reason"]) == (A_PAISE, A_PAISE, 4_000, True, None)
    assert pay(client, ih, tid, 4_000).status_code == 201                                 # and the remaining Rs 40 can now be paid


def test_the_fully_paid_message_is_unchanged_when_the_settled_money_reaches_the_fee_even_if_an_extra_payment_is_on_hold(client):
    th, ih, tid = setup(client)
    first = start(client, ih, tid)
    sandbox(client, ih, first["id"], "fail")
    paid(client, ih, tid)
    deliver(client, first["checkout"]["order_id"])                                          # an over-cap payment is held on top of the fully paid fee
    s = _summary(client, ih, tid)
    assert (s["settled_paise"], s["due_paise"], s["block_reason"]) == (FEE, 0, "FULLY_PAID")
    assert s["block_message"] == "The agreed fee has been paid in full."


# ---------- provider order id ----------
@pytest.mark.parametrize("bad", ["o" * 81, "", " padded ", "new\nline", None])
def test_an_unusable_provider_order_id_is_a_clean_502_and_nothing_is_stored(client, monkeypatch, bad):
    th, ih, tid = setup(client)
    monkeypatch.setattr(providers.SandboxProvider, "create_order", lambda self, **kw: providers.ProviderOrder(order_id=bad, meta={}))
    r = pay(client, ih, tid)
    assert r.status_code == 502 and r.json()["data"]["code"] == "PROVIDER_ERROR"
    assert count(client, Payment) == 0
    monkeypatch.undo()
    assert pay(client, ih, tid).status_code == 201                                                       # and the training can still be paid for


def test_a_maximum_length_order_id_is_accepted(client, monkeypatch):
    th, ih, tid = setup(client)
    monkeypatch.setattr(providers.SandboxProvider, "create_order", lambda self, **kw: providers.ProviderOrder(order_id="o" * 80, meta={}))
    assert pay(client, ih, tid).status_code == 201 and len(row(client, Payment, attempt_no=1).provider_order_id) == 80


# ---------- the provider fails or times out while a payment is being started ----------
# create_payment calls provider.create_order while it holds the training row lock and BEFORE it inserts the payment row. These tests pin what that order of
# operations guarantees (and they run on SQLite with a scripted provider: they do NOT show PostgreSQL lock or concurrency behaviour). What they cover:
#   a refusal by the provider leaves nothing behind and does not burn the Idempotency-Key;
#   an order the provider created but whose answer we never received (a timeout after acceptance) stays an unreachable orphan: the retry gets a NEW order, and
#   a result reported for the orphan cannot create, settle or move anything.
def test_a_provider_failure_while_starting_a_payment_is_a_clean_502_leaves_nothing_behind_and_the_same_key_can_be_retried(client, monkeypatch):
    th, ih, tid = setup(client)
    key = new_key()

    def refuse_order(self, **kw):
        raise providers.ProviderError("gateway timeout")
    with monkeypatch.context() as m:
        m.setattr(providers.SandboxProvider, "create_order", refuse_order)
        r = pay(client, ih, tid, key=key)
    assert r.status_code == 502 and r.json()["data"]["code"] == "PROVIDER_ERROR" and "Nothing was charged" in r.text
    assert count(client, Payment) == 0 and count(client, PaymentTransaction) == 0 and count(client, TrainerEarning) == 0
    assert db_of(client).query(AuditLog).filter_by(action="PAYMENT_CREATED").count() == 0
    again = pay(client, ih, tid, key=key)                                                                 # the failed attempt did not use up the key
    assert again.status_code == 201 and again.json()["data"]["attempt_no"] == 1
    assert pay(client, ih, tid, key=key).status_code == 200 and count(client, Payment) == 1               # and a repeat after success is a replay, not a second payment


def test_an_order_the_provider_created_but_never_confirmed_is_an_orphan_that_cannot_move_money_and_the_retry_gets_a_new_order(client, monkeypatch):
    th, ih, tid = setup(client)
    key, orphans = new_key(), []

    real_create_order = providers.SandboxProvider.create_order                  # captured BEFORE the patch: calling the class again inside it would recurse

    def accept_then_time_out(self, **kw):
        order = real_create_order(self, **kw)                                   # the provider has now created (and may later accept money on) this order
        orphans.append(order.order_id)
        raise providers.ProviderError("timeout waiting for the response")      # ...but we never learned its id
    with monkeypatch.context() as m:
        m.setattr(providers.SandboxProvider, "create_order", accept_then_time_out)
        assert pay(client, ih, tid, key=key).status_code == 502 and count(client, Payment) == 0
    retry = pay(client, ih, tid, key=key)
    assert retry.status_code == 201
    real = retry.json()["data"]["checkout"]["order_id"]
    assert real != orphans[0] and count(client, Payment) == 1

    for etype in ("payment.succeeded", "payment.failed"):                       # the provider reports a result for the orphan, with a valid signature
        r = deliver(client, orphans[0], type_=etype)
        assert r.status_code == 404 and r.json()["data"]["code"] == "UNKNOWN_ORDER"         # kept as evidence, answered with an error, matched to nothing
    stored = row(client, Payment, id=retry.json()["data"]["id"])
    assert stored.status == "PENDING" and stored.provider_order_id == real
    assert count(client, PaymentTransaction) == 0 and count(client, Invoice) == 0 and count(client, TrainerEarning) == 0 and count(client, PlatformCommission) == 0
    assert db_of(client).query(PaymentWebhookEvent).filter_by(outcome="unknown_order").count() == 2

    assert deliver(client, real).status_code == 200                              # only the order we actually stored can settle the training's fee
    assert row(client, Payment, id=stored.id).status == "SUCCEEDED" and count(client, PaymentTransaction, type="CHARGE") == 1 and count(client, Invoice) == 1


# ---------- reconciliation fairness ----------
def test_reconcile_visits_every_open_attempt_and_rotates_even_a_payment_that_always_fails(client, flaky):
    """Reconcile takes the least recently visited attempts first (updated_at, id). Every visited attempt, including one whose lookup always raises
    an unexpected error, is marked as visited, so a poison payment cannot sit at the front of the queue forever."""
    ids = []
    for i in range(3):
        th, ih, tid = setup(client, f"r{i}")
        ids.append(start(client, ih, tid)["id"])
    db = db_of(client)
    for pid in ids:
        db.get(Payment, pid).created_at = utcnow() - timedelta(hours=1)                                   # old enough to look up, not yet expired
    db.commit()
    flaky.explode = {row(client, Payment, id=ids[0]).provider_order_id}
    before = {i: row(client, Payment, id=i).updated_at for i in ids}
    counts = reconcile(db_of(client))
    after = {i: row(client, Payment, id=i).updated_at for i in ids}
    assert counts["errors"] == 1
    assert all(after[i] > before[i] for i in ids), "every open attempt was visited and marked, the failing one included"
    assert all(row(client, Payment, id=i).status == "PENDING" for i in ids)                              # nothing was wrongly settled or expired


# ---------- notification failures never undo a valid financial change ----------
def _break_notifications(monkeypatch, how):
    """how='raise': the dispatch fails before anything is written. how='db': it writes an invalid row, so the DATABASE rejects it."""
    def broken(db, user_id, type_, title, body, link, dedupe_key):
        if how == "raise":
            raise RuntimeError("notification backend is down")
        db.add(Notification(user_id=user_id, type=type_, title=None))                                  # NOT NULL violation, raised by the flush
        db.flush()
    monkeypatch.setattr(notification_service, "_dispatch", broken)


def payment_notifications(client):
    """Notifications that belong to payments (the set-up requests create unrelated ones, so a plain count would be wrong)."""
    kinds = ["PAYMENT_SUCCEEDED", "PAYMENT_RECEIVED", "PAYMENT_FAILED", "PAYMENT_REFUNDED", "PAYMENT_NEEDS_REVIEW", "PAYOUT_RECORDED", "EARNING_AVAILABLE"]
    return db_of(client).query(Notification).filter(Notification.type.in_(kinds)).count()


def _failure_logs(caplog):
    return [r for r in caplog.records if r.name == "itbridge.notifications" and r.levelno >= logging.ERROR and "failed and was skipped" in r.getMessage()]


@pytest.mark.parametrize("how", ["raise", "db"])
def test_a_notification_failure_does_not_undo_a_settlement(client, monkeypatch, caplog, how):
    th, ih, tid = setup(client)
    pid = start(client, ih, tid)["id"]
    _break_notifications(monkeypatch, how)
    with caplog.at_level(logging.ERROR, logger="itbridge.notifications"):
        r = sandbox(client, ih, pid)
    assert r.status_code == 200 and r.json()["data"]["outcome"] == "succeeded" and r.json()["data"]["payment"]["status"] == "SUCCEEDED"
    stored = row(client, Payment, id=pid)
    assert stored.status == "SUCCEEDED" and not stored.needs_review
    assert (count(client, Invoice, payment_id=pid), count(client, TrainerEarning, payment_id=pid), count(client, PlatformCommission, payment_id=pid),
            count(client, PaymentTransaction, payment_id=pid, type="CHARGE")) == (1, 1, 1, 1)
    assert (stored.platform_fee_paise, stored.net_paise) == (FEE // 10, FEE - FEE // 10)
    assert payment_notifications(client) == 0, "nothing is claimed as delivered when the dispatch failed"
    logs = _failure_logs(caplog)
    assert {r.getMessage().split()[1] for r in logs} >= {"PAYMENT_SUCCEEDED", "PAYMENT_RECEIVED"} and all(r.exc_info for r in logs)
    assert db_of(client).query(AuditLog).filter_by(action="PAYMENT_SUCCEEDED", entity_id=pid).count() == 1


def test_a_notification_failure_while_flagging_a_payment_still_records_the_flag(client, monkeypatch, caplog):
    th, ih, tid = setup(client)
    p = start(client, ih, tid)
    client.post(f"{API}/payments/{p['id']}/cancel", headers=ih)
    _break_notifications(monkeypatch, "db")
    with caplog.at_level(logging.ERROR, logger="itbridge.notifications"):
        r = deliver(client, p["checkout"]["order_id"])
    assert r.status_code == 200 and r.json()["data"]["outcome"] == "succeeded_late"
    assert _open_flags(client, p["id"]) == ["LATE_SUCCESS"] and row(client, Payment, id=p["id"]).needs_review
    assert count(client, Invoice, payment_id=p["id"]) == 1 and count(client, TrainerEarning, payment_id=p["id"]) == 1
    assert any("PAYMENT_NEEDS_REVIEW" in r.getMessage() for r in _failure_logs(caplog))


@pytest.mark.parametrize("how", ["raise", "db"])
def test_a_notification_failure_does_not_undo_a_refund(client, monkeypatch, caplog, how):
    th, ih, tid = setup(client)
    ah = admin(client)
    pid = paid(client, ih, tid)
    _break_notifications(monkeypatch, how)
    with caplog.at_level(logging.ERROR, logger="itbridge.notifications"):
        r = refund(client, ah, pid)
    assert r.status_code == 200 and r.json()["data"]["status"] == "SUCCEEDED"
    assert row(client, PaymentRefund, payment_id=pid).status == "SUCCEEDED" and row(client, PaymentRefund, payment_id=pid).credit_note_number
    assert row(client, TrainerEarning, payment_id=pid).status == "REFUNDED" and row(client, PlatformCommission, payment_id=pid).status == "REVERSED"
    assert count(client, PaymentTransaction, payment_id=pid, type="REFUND") == 1
    assert types_of(client, ih, "PAYMENT_REFUNDED") == [] and types_of(client, th, "PAYMENT_REFUNDED") == []
    assert {r.getMessage().split()[1] for r in _failure_logs(caplog)} == {"PAYMENT_REFUNDED"}
    assert refund(client, ah, pid).status_code == 200 and count(client, PaymentRefund) == 1             # and a repeat is still not a second refund


@pytest.mark.parametrize("how", ["raise", "db"])
def test_a_notification_failure_does_not_undo_a_payout_record(client, monkeypatch, caplog, how):
    th, ih, tid = setup(client)
    ah = admin(client)
    pid = paid(client, ih, tid)
    finish(client, ih, tid)
    eid = row(client, TrainerEarning, payment_id=pid).id
    _break_notifications(monkeypatch, how)
    with caplog.at_level(logging.ERROR, logger="itbridge.notifications"):
        r = client.post(f"{API}/admin/earnings/{eid}/payout", headers=ah, json={"reference": "BATCH-2026-10"})
    assert r.status_code == 200 and r.json()["data"]["status"] == "PAID"
    e = row(client, TrainerEarning, id=eid)
    assert e.status == "PAID" and e.payout_reference == "BATCH-2026-10" and e.paid_at and e.paid_by
    assert db_of(client).query(AuditLog).filter_by(action="PAYOUT_RECORDED", entity_id=eid).count() == 1
    assert types_of(client, th, "PAYOUT_RECORDED") == []
    assert {r.getMessage().split()[1] for r in _failure_logs(caplog)} == {"PAYOUT_RECORDED"}


def test_notify_event_safe_keeps_the_callers_unflushed_changes_when_the_notification_fails(client, monkeypatch, caplog):
    th, ih, tid = setup(client)
    db = db_of(client)
    user = db.query(User).filter_by(email="ia@example.com").one()
    user.full_name = "Changed by the caller"                                                             # pending, not yet flushed
    _break_notifications(monkeypatch, "db")
    with caplog.at_level(logging.ERROR, logger="itbridge.notifications"):
        assert notification_service.notify_event_safe(db, user.id, "PAYMENT_SUCCEEDED", amount="Rs 1.00", title="T", training_id=tid) is False
    db.commit()
    assert db_of(client).query(User).filter_by(email="ia@example.com").one().full_name == "Changed by the caller"
    assert payment_notifications(client) == 0 and len(_failure_logs(caplog)) == 1
    assert "pending_push" not in db.info or db.info["pending_push"] == []                                # no push for a rolled-back notification


def test_notifications_still_work_when_nothing_is_broken(client):
    th, ih, tid = setup(client)
    paid(client, ih, tid)
    assert len(types_of(client, ih, "PAYMENT_SUCCEEDED")) == 1 and len(types_of(client, th, "PAYMENT_RECEIVED")) == 1


# ---------- earnings promotion ----------
def test_an_earning_whose_refund_is_still_pending_is_not_promoted(client, flaky):
    from app.services.earning_service import promote_available
    th, ih, tid = setup(client)
    ah = admin(client)
    pid = paid(client, ih, tid)
    flaky.fail_refund = True
    assert refund(client, ah, pid).status_code == 502                                                     # the refund stays PENDING
    finish(client, ih, tid)
    assert row(client, TrainerEarning, payment_id=pid).status == "PENDING"                                # a refund exists: the completion did not promote it
    assert promote_available(db_of(client)) == 0 and row(client, TrainerEarning, payment_id=pid).status == "PENDING"
    assert reconcile(db_of(client))["earnings_available"] == 0
    flaky.fail_refund = False
    assert refund(client, ah, pid).status_code == 200 and row(client, TrainerEarning, payment_id=pid).status == "REFUNDED"


def test_promotion_ignores_earnings_inside_the_hold_and_still_reaches_those_behind_them(client, monkeypatch):
    """The held earning has the lowest id. It is filtered in SQL, so it can never fill the 500-row window ahead of a promotable one."""
    from app.services.earning_service import promote_available
    monkeypatch.setattr(settings, "earning_hold_days", 2)
    th1, ih1, tid1 = setup(client, "h1")
    th2, ih2, tid2 = setup(client, "h2")
    p1, p2 = paid(client, ih1, tid1), paid(client, ih2, tid2)
    finish(client, ih1, tid1)
    finish(client, ih2, tid2)
    db = db_of(client)
    db.get(Training, tid2).completed_at = utcnow() - timedelta(days=3)                                    # only the second hold has elapsed
    db.commit()
    assert promote_available(db_of(client)) == 1
    assert row(client, TrainerEarning, payment_id=p1).status == "PENDING" and row(client, TrainerEarning, payment_id=p2).status == "AVAILABLE"
    assert promote_available(db_of(client)) == 0                                                          # idempotent


def test_real_time_pushes_are_sent_only_after_the_outermost_commit_and_a_failed_notification_keeps_the_earlier_ones(client, monkeypatch):
    th, ih, tid = setup(client)                                  # (the set-up requests push too, so the recorder is installed afterwards)
    pushed = []
    monkeypatch.setattr(notification_service.manager, "push", lambda user_id, payload: pushed.append((user_id, payload["type"])))
    db = db_of(client)
    uid = db.query(User).filter_by(email="ia@example.com").one().id
    assert notification_service.notify_event_safe(db, uid, "PAYMENT_SUCCEEDED", amount="Rs 1.00", title="T", training_id=tid) is True
    assert pushed == [], "releasing the SAVEPOINT is not a commit: nothing may be pushed yet"
    real = notification_service._dispatch
    monkeypatch.setattr(notification_service, "_dispatch", lambda *a, **k: (_ for _ in ()).throw(RuntimeError("down")))
    assert notification_service.notify_event_safe(db, uid, "PAYMENT_FAILED", amount="Rs 1.00", title="T", training_id=tid) is False
    monkeypatch.setattr(notification_service, "_dispatch", real)
    assert pushed == []
    db.commit()
    assert pushed == [(uid, "PAYMENT_SUCCEEDED")], "the first notification is pushed once, after the commit; the failed one never"
    assert payment_notifications(client) == 1


def test_a_rolled_back_transaction_pushes_nothing(client, monkeypatch):
    th, ih, tid = setup(client)
    pushed = []
    monkeypatch.setattr(notification_service.manager, "push", lambda user_id, payload: pushed.append(user_id))
    db = db_of(client)
    uid = db.query(User).filter_by(email="ia@example.com").one().id
    notification_service.notify_event_safe(db, uid, "PAYMENT_SUCCEEDED", amount="Rs 1.00", title="T", training_id=tid)
    db.rollback()
    assert pushed == [] and payment_notifications(client) == 0


def test_B2_the_payment_level_resolution_fields_are_set_only_when_the_last_flag_closes(client):
    th, ih, ah, tid, pid = _three_flags(client)
    first = resolve(client, ah, pid, note="first note", reason="AMOUNT_MISMATCH").json()["data"]
    assert first["review_note"] is None and first["reviewed_by"] is None and first["under_review"] is True
    assert [h["resolution_note"] for h in first["review_history"]] == ["first note"]                       # per-flag detail is always there
    resolve(client, ah, pid, note="second note", reason="DUPLICATE_CHARGE")
    last = resolve(client, ah, pid, note="last note").json()["data"]
    assert last["under_review"] is False and last["review_note"] == "last note" and last["reviewed_by"] is not None
    assert sorted(h["resolution_note"] for h in last["review_history"]) == ["first note", "last note", "second note"]
