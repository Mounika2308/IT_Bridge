"""Phase 12: review eligibility, validation, rating rules, institution reviews, pending counts, notifications and the review reminder.
Written for pytest + FastAPI's TestClient (SQLite). These have NOT been executed in the authoring environment (no packages)."""
from datetime import datetime, timedelta, timezone

import pytest
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError

from app.models.notification import Notification
from app.models.review import Review
from app.models.training import Training
from app.models.user import InstitutionProfile, TrainerProfile
from app.services import notification_types
from app.services.review_service import MIN_REVIEWS_FOR_RATING_FILTER, round_rating
from app.workers.loop import due_tasks
from app.workers.reminders import send_reminders
from tests.test_reviews import INST_RATINGS, TRAINER_RATINGS, finish, review
from tests.test_trainings import begin, db_of, reg, world  # noqa: F401


def ids(client):
    db = db_of(client)
    return db.scalars(select(TrainerProfile.id)).first(), db.scalars(select(InstitutionProfile.id)).first()


def add_reviews(client, overalls, direction="INSTITUTION_TO_TRAINER", hidden=(), start=100):
    """Inserts reviews straight into the database (SQLite does not enforce the training foreign key) to test aggregates."""
    db = db_of(client)
    trainer_id, inst_id = ids(client)
    for i, overall in enumerate(overalls):
        db.add(Review(training_id=start + i, direction=direction, reviewer_user_id=1, trainer_id=trainer_id, institution_id=inst_id,
                      ratings={}, overall=overall, comment=None, is_hidden=i in hidden))
    db.commit()


def complete_ago(client, tid, **delta):
    db = db_of(client)
    db.get(Training, tid).completed_at = datetime.now(timezone.utc) - timedelta(**delta)
    db.commit()


def inbox(client, h, t=None):
    items = client.get("/api/v1/notifications?page_size=50", headers=h).json()["data"]["items"]
    return [n for n in items if t is None or n["type"] == t]


# ---------- eligibility ----------
def test_active_training_cannot_be_reviewed_and_says_why(client):
    th, ih, rid, tid = world(client)
    r = review(client, ih, tid, TRAINER_RATINGS)
    assert r.status_code == 409 and "still in progress" in r.json()["message"]
    d = client.get(f"/api/v1/trainings/{tid}/reviews", headers=ih).json()["data"]
    assert d["can_review"] is False and d["reason"] == "ACTIVE" and "in progress" in d["reason_text"]


def test_cancelled_training_cannot_be_reviewed_and_says_why(client):
    th, ih, rid, tid = world(client)
    assert client.post(f"/api/v1/trainings/{tid}/cancel", headers=th, json={"reason": "Family emergency"}).status_code == 200
    r = review(client, th, tid, INST_RATINGS)
    assert r.status_code == 409 and "cancelled" in r.json()["message"]
    assert client.get(f"/api/v1/trainings/{tid}/reviews", headers=ih).json()["data"]["reason"] == "CANCELLED"


def test_both_directions_work_and_reason_changes_after_reviewing(client):
    th, ih, rid, tid = world(client)
    finish(client, ih, tid)
    assert client.get(f"/api/v1/trainings/{tid}/reviews", headers=th).json()["data"]["reason"] is None
    assert review(client, ih, tid, TRAINER_RATINGS).status_code == 201
    assert review(client, th, tid, INST_RATINGS).status_code == 201
    d = client.get(f"/api/v1/trainings/{tid}/reviews", headers=th).json()["data"]
    assert d["can_review"] is False and d["reason"] == "ALREADY_REVIEWED" and len(d["reviews"]) == 2 and d["comment_max_length"] == 2000


def test_unrelated_and_unauthenticated_users_are_refused(client):
    th, ih, rid, tid = world(client)
    finish(client, ih, tid)
    other_trainer = reg(client, "x@example.com")
    other_inst = reg(client, "o@example.com", "INSTITUTION", institution_name="Other")
    for h in (other_trainer, other_inst):
        assert review(client, h, tid, TRAINER_RATINGS).status_code == 404
        assert review(client, h, tid, INST_RATINGS).status_code == 404
        assert client.get(f"/api/v1/trainings/{tid}/reviews", headers=h).status_code == 404
    assert client.post(f"/api/v1/trainings/{tid}/reviews", json={"ratings": TRAINER_RATINGS}).status_code == 401
    assert client.get("/api/v1/reviews/me").status_code == 401
    assert review(client, ih, 9999, TRAINER_RATINGS).status_code == 404


def test_reviewer_identity_comes_from_the_token_not_the_body(client):
    th, ih, rid, tid = world(client)
    finish(client, ih, tid)
    r = client.post(f"/api/v1/trainings/{tid}/reviews", headers=ih, json={"ratings": TRAINER_RATINGS, "reviewer_user_id": 999, "direction": "TRAINER_TO_INSTITUTION"})
    assert r.status_code == 201
    row = db_of(client).scalars(select(Review)).one()
    assert row.reviewer_user_id != 999 and row.direction == "INSTITUTION_TO_TRAINER"


def test_inactive_and_suspended_accounts_cannot_review(client):
    th, ih, rid, tid = world(client)
    finish(client, ih, tid)
    db = db_of(client)
    db.scalars(select(TrainerProfile)).first().verification_status = "SUSPENDED"
    db.commit()
    r = review(client, th, tid, INST_RATINGS)
    assert r.status_code == 403 and "Suspended" in r.json()["message"]
    assert client.get(f"/api/v1/trainings/{tid}/reviews", headers=th).json()["data"]["reason"] == "SUSPENDED"
    db.scalars(select(TrainerProfile)).first().verification_status = "VERIFIED"
    prof = db.scalars(select(InstitutionProfile)).first()
    prof.user.is_active = False
    db.commit()
    assert review(client, ih, tid, TRAINER_RATINGS).status_code == 403          # "Account deactivated" from the auth dependency


# ---------- validation ----------
@pytest.mark.parametrize("bad", [True, False, 4.5, 4.0, "4", None, 0, 6, -1])
def test_non_integer_boolean_and_out_of_range_ratings_are_rejected(client, bad):
    th, ih, rid, tid = world(client)
    finish(client, ih, tid)
    assert review(client, ih, tid, {**TRAINER_RATINGS, "punctuality": bad}).status_code == 422
    assert db_of(client).scalars(select(Review)).first() is None


def test_category_sets_must_match_exactly(client):
    th, ih, rid, tid = world(client)
    finish(client, ih, tid)
    assert review(client, ih, tid, {}).status_code == 422
    assert review(client, ih, tid, {**TRAINER_RATINGS, "coordination": 3}).status_code == 422       # extra category
    assert review(client, ih, tid, INST_RATINGS).status_code == 422                                  # the other direction's categories
    assert review(client, th, tid, TRAINER_RATINGS).status_code == 422


def test_comment_is_trimmed_limited_and_never_blank(client):
    th, ih, rid, tid = world(client)
    finish(client, ih, tid)
    for blank in ("", "   ", "\n\t "):
        assert review(client, ih, tid, TRAINER_RATINGS, blank).status_code == 422
    r = review(client, ih, tid, TRAINER_RATINGS, "x" * 2001)
    assert r.status_code == 422 and "comment" in r.json()["data"]                                    # field-level detail for the form
    assert review(client, ih, tid, TRAINER_RATINGS, "  " + "x" * 2000 + "  ").status_code == 201     # the limit applies after trimming
    assert db_of(client).scalars(select(Review)).one().comment == "x" * 2000


def test_duplicate_is_blocked_by_the_service_and_by_the_database(client):
    th, ih, rid, tid = world(client)
    finish(client, ih, tid)
    assert review(client, ih, tid, TRAINER_RATINGS).status_code == 201
    assert review(client, ih, tid, TRAINER_RATINGS).status_code == 409
    db = db_of(client)
    first = db.scalars(select(Review)).one()
    db.add(Review(training_id=first.training_id, direction=first.direction, reviewer_user_id=first.reviewer_user_id, trainer_id=first.trainer_id,
                  institution_id=first.institution_id, ratings={}, overall=3.0))
    with pytest.raises(IntegrityError):              # the constraint is the final guard against a concurrent double submit
        db.commit()
    db.rollback()


# ---------- ratings ----------
def test_round_rating_is_half_up_and_ignores_float_noise():
    assert round_rating(4.25) == 4.3 and round_rating(4.24) == 4.2 and round_rating(4.2499999999) == 4.3     # float noise is removed first
    assert round_rating(3.9667) == 4.0 and round_rating(1.0) == 1.0 and round_rating(0.05) == 0.1


def test_aggregate_over_several_reviews_and_hidden_reviews_are_excluded(client):
    th, ih, rid, tid = world(client)
    add_reviews(client, [5.0, 4.0, 3.0])
    d = client.get("/api/v1/trainers/1", headers=ih).json()["data"]
    assert d["rating"] == 4.0 and d["review_count"] == 3
    add_reviews(client, [1.0], start=200, hidden=(0,))                                               # hidden: must not move the average
    d = client.get("/api/v1/trainers/1", headers=ih).json()["data"]
    assert d["rating"] == 4.0 and d["review_count"] == 3
    assert client.get("/api/v1/trainers/1/reviews", headers=ih).json()["data"]["total"] == 3


def test_user_without_reviews_shows_no_rating(client):
    th, ih, rid, tid = world(client)
    d = client.get("/api/v1/trainers/1", headers=ih).json()["data"]
    assert d["rating"] is None and d["review_count"] == 0
    page = client.get("/api/v1/trainers/1/reviews", headers=ih).json()["data"]
    assert page["items"] == [] and page["total"] == 0 and page["rating"] is None
    assert client.get("/api/v1/trainers", headers=ih).json()["data"]["items"][0]["rating"] is None


def test_min_rating_uses_the_displayed_rounded_value(client):
    th, ih, rid, tid = world(client)
    add_reviews(client, [4.0, 4.0, 3.9])                                                             # average 3.9667 is displayed as 4.0
    assert client.get("/api/v1/trainers/1", headers=ih).json()["data"]["rating"] == 4.0
    assert client.get("/api/v1/trainers?min_rating=4", headers=ih).json()["data"]["total"] == 1      # before Phase 12 this excluded the trainer
    assert client.get("/api/v1/trainers?min_rating=4.5", headers=ih).json()["data"]["total"] == 0


def test_min_rating_boundary_at_a_half_step(client):
    th, ih, rid, tid = world(client)
    add_reviews(client, [4.2, 4.3])                                                                  # 4.25 is displayed as 4.3
    assert client.get("/api/v1/trainers/1", headers=ih).json()["data"]["rating"] == 4.3
    assert client.get("/api/v1/trainers?min_rating=4.3", headers=ih).json()["data"]["total"] == 1
    assert client.get("/api/v1/trainers?min_rating=4.4", headers=ih).json()["data"]["total"] == 0


def test_filter_needs_two_reviews_but_one_review_is_still_displayed(client):
    assert MIN_REVIEWS_FOR_RATING_FILTER == 2
    th, ih, rid, tid = world(client)
    add_reviews(client, [5.0])
    d = client.get("/api/v1/trainers/1", headers=ih).json()["data"]
    assert d["rating"] == 5.0 and d["review_count"] == 1                                             # shown truthfully
    assert client.get("/api/v1/trainers?min_rating=4", headers=ih).json()["data"]["total"] == 0      # but not yet counted by the filter
    add_reviews(client, [4.0], start=300)
    assert client.get("/api/v1/trainers?min_rating=4", headers=ih).json()["data"]["total"] == 1
    add_reviews(client, [1.0, 1.0], start=400, hidden=(0, 1))                                        # hidden reviews never count towards the two
    assert client.get("/api/v1/trainers?min_rating=4", headers=ih).json()["data"]["total"] == 1


# ---------- institution reviews ----------
def test_institution_reviews_endpoint_summary_pagination_and_privacy(client):
    th, ih, rid, tid = world(client)
    finish(client, ih, tid)
    assert review(client, th, tid, INST_RATINGS, "Well organised").status_code == 201
    trainer_id, inst_id = ids(client)
    add_reviews(client, [5.0], direction="TRAINER_TO_INSTITUTION", start=500)
    d = client.get(f"/api/v1/institutions/{inst_id}/reviews", headers=th).json()["data"]
    assert d["institution_name"] == "Sunrise College" and d["review_count"] == 2 and d["rating"] == round_rating((4.0 + 5.0) / 2)
    assert d["completed_trainings"] == 1 and d["total"] == 2
    assert {r["reviewer"] for r in d["items"]} >= {"T"}
    flat = str(d).lower()
    for secret in ("email", "phone", "password", "user_id", "training_id", "i@example.com", "t@example.com"):
        assert secret not in flat
    p2 = client.get(f"/api/v1/institutions/{inst_id}/reviews?page=2&page_size=1", headers=ih).json()["data"]
    assert len(p2["items"]) == 1 and p2["page"] == 2 and p2["total"] == 2
    assert client.get(f"/api/v1/institutions/{inst_id}/reviews?page_size=51", headers=ih).status_code == 422


def test_institution_reviews_hide_hidden_suspended_and_unknown(client):
    th, ih, rid, tid = world(client)
    trainer_id, inst_id = ids(client)
    add_reviews(client, [3.0, 5.0], direction="TRAINER_TO_INSTITUTION", hidden=(0,))
    d = client.get(f"/api/v1/institutions/{inst_id}/reviews", headers=th).json()["data"]
    assert d["review_count"] == 1 and d["rating"] == 5.0
    assert client.get("/api/v1/institutions/9999/reviews", headers=th).status_code == 404
    assert client.get(f"/api/v1/institutions/{inst_id}/reviews").status_code == 401
    db = db_of(client)
    db.get(InstitutionProfile, inst_id).verification_status = "SUSPENDED"
    db.commit()
    assert client.get(f"/api/v1/institutions/{inst_id}/reviews", headers=th).status_code == 404


def test_institution_without_reviews_has_no_rating(client):
    th, ih, rid, tid = world(client)
    trainer_id, inst_id = ids(client)
    d = client.get(f"/api/v1/institutions/{inst_id}/reviews", headers=th).json()["data"]
    assert d["rating"] is None and d["review_count"] == 0 and d["items"] == []


# ---------- pending reviews ----------
def test_pending_review_counts_for_both_roles(client):
    th, ih, rid, tid = world(client)
    for h in (th, ih):
        d = client.get("/api/v1/reviews/me", headers=h).json()["data"]
        assert d["my_pending_reviews"] == 0 and d["pending"] == [] and d["rating"] is None
    finish(client, ih, tid)
    for h in (th, ih):
        d = client.get("/api/v1/reviews/me", headers=h).json()["data"]
        assert d["my_pending_reviews"] == 1 and d["pending"][0]["training_id"] == tid and d["can_review"] is True
    review(client, ih, tid, TRAINER_RATINGS)
    assert client.get("/api/v1/reviews/me", headers=ih).json()["data"]["my_pending_reviews"] == 0
    t = client.get("/api/v1/reviews/me", headers=th).json()["data"]
    assert t["my_pending_reviews"] == 1 and t["rating"] == 4.6 and t["review_count"] == 1 and t["completed_trainings"] == 1


def test_pending_count_is_zero_for_suspended_users_and_cancelled_trainings(client):
    th, ih, rid, tid = world(client)
    client.post(f"/api/v1/trainings/{tid}/cancel", headers=ih, json={"reason": "No budget"})
    assert client.get("/api/v1/reviews/me", headers=th).json()["data"]["my_pending_reviews"] == 0
    db = db_of(client)
    db.scalars(select(TrainerProfile)).first().verification_status = "SUSPENDED"
    db.commit()
    d = client.get("/api/v1/reviews/me", headers=th).json()["data"]
    assert d["my_pending_reviews"] == 0 and d["can_review"] is False


# ---------- notifications and transactions ----------
def test_review_notifications_carry_dedupe_keys(client):
    th, ih, rid, tid = world(client)
    finish(client, ih, tid)
    review(client, ih, tid, TRAINER_RATINGS)
    db = db_of(client)
    rid_ = db.scalars(select(Review.id)).one()
    keys = {n.dedupe_key for n in db.scalars(select(Notification)) if n.type in ("REVIEW_REQUEST", "REVIEW_RECEIVED")}
    assert f"review-received:{rid_}" in keys and any(k and k.startswith(f"review-request:{tid}:") for k in keys)
    assert len(inbox(client, th, "REVIEW_RECEIVED")) == 1 and len(inbox(client, th, "REVIEW_REQUEST")) == 1


def test_a_failure_inside_the_transaction_leaves_no_review_and_no_notification(client, monkeypatch):
    th, ih, rid, tid = world(client)
    finish(client, ih, tid)

    def boom(*a, **k):
        raise RuntimeError("audit store down")
    monkeypatch.setattr("app.services.review_service.audit", boom)
    with pytest.raises(RuntimeError):
        review(client, ih, tid, TRAINER_RATINGS)
    monkeypatch.undo()
    assert db_of(client).scalars(select(Review)).first() is None
    assert inbox(client, th, "REVIEW_RECEIVED") == []
    assert review(client, ih, tid, TRAINER_RATINGS).status_code == 201                               # and the user can simply try again


def test_a_notification_that_cannot_be_built_does_not_undo_the_review(client, monkeypatch):
    th, ih, rid, tid = world(client)
    finish(client, ih, tid)
    broken = notification_types.NotificationType("REVIEW_RECEIVED", "New review", "{missing_field}", "/trainings/{training_id}")
    monkeypatch.setitem(notification_types.TYPES, "REVIEW_RECEIVED", broken)
    assert review(client, ih, tid, TRAINER_RATINGS).status_code == 201
    assert db_of(client).scalars(select(Review)).one() is not None
    assert inbox(client, th, "REVIEW_RECEIVED") == []


# ---------- review reminder ----------
def test_reminder_timing_one_per_participant_and_idempotent(client):
    th, ih, rid, tid = world(client)
    finish(client, ih, tid)
    db = db_of(client)
    complete_ago(client, tid, days=2, hours=23)
    assert send_reminders(db, kinds=("review",)) == 0                                                # not three days yet
    complete_ago(client, tid, days=3, minutes=1)
    assert send_reminders(db, kinds=("review",)) == 2                                                # both have not reviewed
    assert send_reminders(db, kinds=("review",)) == 0                                                # repeated worker run
    assert send_reminders(db, kinds=("review",), utc_now=datetime.now(timezone.utc) + timedelta(days=2)) == 0   # and on a later day
    assert len(inbox(client, th, "REVIEW_REMINDER")) == 1 and len(inbox(client, ih, "REVIEW_REMINDER")) == 1
    n = inbox(client, th, "REVIEW_REMINDER")[0]
    assert n["link"] == f"/trainings/{tid}"


def test_reminder_skips_participants_who_reviewed_cancelled_old_and_suspended(client):
    th, ih, rid, tid = world(client)
    finish(client, ih, tid)
    db = db_of(client)
    review(client, ih, tid, TRAINER_RATINGS)                                                         # the institution has reviewed
    complete_ago(client, tid, days=4)
    assert send_reminders(db, kinds=("review",)) == 1
    assert inbox(client, ih, "REVIEW_REMINDER") == [] and len(inbox(client, th, "REVIEW_REMINDER")) == 1
    complete_ago(client, tid, days=30)                                                               # too old to nag about
    for n in db.scalars(select(Notification).where(Notification.type == "REVIEW_REMINDER")):
        db.delete(n)
    db.commit()
    assert send_reminders(db, kinds=("review",)) == 0


def test_reminder_skips_suspended_trainer_and_cancelled_training(client):
    th, ih, rid, tid = world(client)
    finish(client, ih, tid)
    db = db_of(client)
    db.scalars(select(TrainerProfile)).first().verification_status = "SUSPENDED"
    db.commit()
    complete_ago(client, tid, days=4)
    assert send_reminders(db, kinds=("review",)) == 1                                                # only the institution
    assert inbox(client, th, "REVIEW_REMINDER") == []
    db.get(Training, tid).status = "CANCELLED"
    db.commit()
    for n in db.scalars(select(Notification).where(Notification.type == "REVIEW_REMINDER")):
        db.delete(n)
    db.commit()
    assert send_reminders(db, kinds=("review",)) == 0


def test_the_loop_schedules_the_review_reminder_hourly():
    now = datetime(2030, 1, 1, 10, 0)
    assert "review" in due_tasks(now, {})
    assert "review" not in due_tasks(now, {"review": now - timedelta(minutes=10)})
    assert "review" in due_tasks(now, {"review": now - timedelta(minutes=61)})
