"""Preferences, the external-delivery outbox, retries and privacy. No real provider exists: these tests use fakes and the console provider."""
import logging
from dataclasses import replace
from datetime import datetime, timedelta, timezone

import pytest

from app.models.notification import Notification, NotificationDelivery
from app.models.user import User
from app.services import delivery_service, notification_service, notification_types
from app.services.channels import DeliveryError
from app.services.notification_service import notify_event
from app.workers.reminders import send_reminders
from tests.test_requirement_lifecycle import apply, fill, hire, trainer, world
from tests.test_trainings import START, db_of, session


def inbox(client, h):
    return client.get("/api/v1/notifications?page_size=50", headers=h).json()["data"]["items"]


def prefs(client, h):
    return client.get("/api/v1/notifications/preferences", headers=h).json()["data"]


def put(client, h, **body):
    return client.put("/api/v1/notifications/preferences", headers=h, json=body)


def deliveries(client):
    return db_of(client).query(NotificationDelivery).order_by(NotificationDelivery.id).all()


def user_id(client, email):
    return db_of(client).query(User).filter(User.email == email).one().id


def verify(client, *emails):
    db = db_of(client)
    for e in emails:
        db.query(User).filter(User.email == e).update({"email_verified": True})
    db.commit()


def run(client, seconds=1):
    return delivery_service.process_pending(db_of(client), now=datetime.now(timezone.utc) + timedelta(seconds=seconds))


class FakeProvider:
    name = "fake"

    def __init__(self, fail_first=0, fail_for=None, fail_subject=None):
        self.calls, self.fail_first, self.fail_for, self.fail_subject, self.failed_subject = [], fail_first, fail_for, fail_subject, 0

    def send(self, to, subject, body, *, idempotency_key):
        self.calls.append((to, subject, body, idempotency_key))
        if self.fail_subject and subject == self.fail_subject[0] and self.failed_subject < self.fail_subject[1]:
            self.failed_subject += 1
            raise DeliveryError(f"provider refused {to}")
        if len(self.calls) <= self.fail_first or (self.fail_for and to == self.fail_for):
            raise DeliveryError(f"provider refused {to}")


@pytest.fixture()
def provider(monkeypatch):
    p = FakeProvider()
    monkeypatch.setattr(delivery_service, "get_email_provider", lambda: p)
    return p


# ---------- preferences ----------
def test_preferences_default_to_enabled_and_can_be_changed_per_channel(client):
    ta, tb, tc, ih, rid, aid = world(client)
    assert prefs(client, ta) == {"in_app": True, "email": True, "email_verified": False}
    r = put(client, ta, email=False)
    assert r.status_code == 200 and r.json()["data"]["in_app"] is True and r.json()["data"]["email"] is False
    assert prefs(client, ta)["email"] is False and prefs(client, tb)["email"] is True                 # persisted, and only for this user
    assert put(client, ta, in_app=False, email=True).json()["data"] == {"in_app": False, "email": True, "email_verified": False}


def test_preferences_validation_and_authentication(client):
    ta, tb, tc, ih, rid, aid = world(client)
    assert put(client, ta).status_code == 422                                  # nothing to change
    assert put(client, ta, email=None).status_code == 422                      # explicit null
    assert put(client, ta, sms=True).status_code == 422                        # SMS does not exist yet, unknown fields change nothing
    assert put(client, ta, email="maybe").status_code == 422
    assert client.get("/api/v1/notifications/preferences").status_code == 401
    assert client.put("/api/v1/notifications/preferences", json={"email": False}).status_code == 401


def test_in_app_off_creates_no_row_but_email_is_still_queued_and_email_off_does_the_reverse(client):
    ta, tb, tc, ih, rid, aid = world(client)
    a, i = user_id(client, "a@example.com"), user_id(client, "i@example.com")
    queued = lambda uid: len([d for d in deliveries(client) if d.user_id == uid])
    stored = lambda uid: db_of(client).query(Notification).filter(Notification.user_id == uid).count()
    base = queued(a)                                                          # the shortlist email queued while building the world
    put(client, ta, in_app=False)
    before = len(inbox(client, ta))
    hid = hire(client, ih, aid["a"]).json()["data"]["id"]                     # HIRING_REQUEST is in-app and email eligible
    assert len(inbox(client, ta)) == before                                   # no in-app row...
    assert queued(a) == base + 1 and deliveries(client)[-1].type == "HIRING_REQUEST"   # ...but the email is queued
    put(client, ta, in_app=True, email=False)
    put(client, ih, in_app=False, email=False)
    in_app_i, queued_i = stored(i), queued(i)
    client.post(f"/api/v1/hiring-requests/{hid}/accept", headers=ta)
    assert any(n["type"] == "TRAINING_CREATED" for n in inbox(client, ta))    # in-app on, email off: row yes...
    assert queued(a) == base + 1                                              # ...nothing queued
    assert stored(i) == in_app_i and queued(i) == queued_i                    # both off: HIRING_ACCEPTED reached the institution in no form


def test_a_mandatory_type_cannot_be_switched_off(client, monkeypatch):
    ta, tb, tc, ih, rid, aid = world(client)
    monkeypatch.setitem(notification_types.TYPES, "APPLICATION_RECEIVED", replace(notification_types.TYPES["APPLICATION_RECEIVED"], mandatory=True))
    put(client, ih, in_app=False)
    td = trainer(client, "d")
    before = len(inbox(client, ih))
    assert apply(client, td, rid).status_code == 201
    assert len(inbox(client, ih)) == before + 1                                # delivered despite the preference


# ---------- the outbox: eligibility, verified email, preference at send time ----------
def test_only_email_eligible_types_are_queued(client):
    ta, tb, tc, ih, rid, aid = world(client)
    types = {d.type for d in deliveries(client)}
    assert types == {"APPLICATION_SHORTLISTED"}                                # applications received etc. are in-app only
    hire(client, ih, aid["a"])
    assert "HIRING_REQUEST" in {d.type for d in deliveries(client)} and all(notification_types.TYPES[d.type].email for d in deliveries(client))


def test_unverified_email_is_never_attempted(client, provider):
    ta, tb, tc, ih, rid, aid = world(client)
    hire(client, ih, aid["a"])
    out = run(client)
    assert out["sent"] == 0 and out["skipped"] >= 1 and provider.calls == []
    skipped = [d for d in deliveries(client) if d.status == "SKIPPED"]
    assert skipped and all(d.last_error == "email address is not verified" for d in skipped)


def test_verified_user_gets_each_email_exactly_once_through_the_provider(client, provider):
    ta, tb, tc, ih, rid, aid = world(client)
    verify(client, "a@example.com")
    hire(client, ih, aid["a"])
    assert run(client)["sent"] == 2                                           # the earlier shortlist email and the hiring request
    hiring = [c for c in provider.calls if c[1] == "You have a hiring request"]
    assert len(hiring) == 1
    to, subject, body, key = hiring[0]
    assert to == "a@example.com" and "http://localhost:5173/trainer/applications" in body and key.startswith("delivery-")
    assert all(c[0] == "a@example.com" for c in provider.calls)               # b and the institution are unverified: never contacted
    assert run(client, 5)["sent"] == 0 and len(provider.calls) == 2            # running again sends nothing: the rows are SENT
    assert all(d.attempts == 1 and d.sent_at is not None for d in deliveries(client) if d.status == "SENT")


def test_preference_is_checked_again_at_send_time_and_inactive_users_are_skipped(client, provider):
    ta, tb, tc, ih, rid, aid = world(client)
    verify(client, "a@example.com", "b@example.com")
    hire(client, ih, aid["a"])
    put(client, ta, email=False)                                               # switched off after the email was queued
    db = db_of(client)
    db.query(User).filter(User.email == "b@example.com").update({"is_active": False})
    db.commit()
    verify(client, "b@example.com")
    out = run(client)
    assert provider.calls == []
    assert {d.last_error for d in deliveries(client) if d.status == "SKIPPED"} >= {"email notifications are switched off", "account is not active"}


def test_console_provider_never_logs_the_recipient_address(client, caplog):
    ta, tb, tc, ih, rid, aid = world(client)
    verify(client, "a@example.com")
    hire(client, ih, aid["a"])
    caplog.set_level(logging.INFO)
    assert run(client)["sent"] >= 1
    assert "NOT SENT" in caplog.text and "a@example.com" not in caplog.text


# ---------- reliability: a failing provider never breaks the business transaction ----------
def test_provider_failure_does_not_break_the_request_and_is_retried_with_backoff(client, monkeypatch):
    broken = FakeProvider(fail_first=99)
    monkeypatch.setattr(delivery_service, "get_email_provider", lambda: broken)
    ta, tb, tc, ih, rid, aid = world(client)
    verify(client, "a@example.com")
    hid = hire(client, ih, aid["a"]).json()["data"]["id"]
    assert client.post(f"/api/v1/hiring-requests/{hid}/accept", headers=ta).status_code == 200      # the business flow succeeded
    assert broken.calls == []                                                   # and nothing was sent inside the request
    assert all(d.status == "PENDING" and d.attempts == 0 for d in deliveries(client) if d.user_id == user_id(client, "a@example.com"))
    base = datetime.now(timezone.utc)
    delivery_service.process_pending(db_of(client), now=base + timedelta(seconds=1))
    first = [d for d in deliveries(client) if d.attempts == 1]
    assert first and all(d.status == "PENDING" and d.next_attempt_at.replace(tzinfo=timezone.utc) > base + timedelta(seconds=1) for d in first)
    assert all("a@example.com" not in (d.last_error or "") and "[email]" in d.last_error for d in first)
    calls = len(broken.calls)
    delivery_service.process_pending(db_of(client), now=base + timedelta(seconds=2))          # not due yet
    assert len(broken.calls) == calls


def test_gives_up_after_the_maximum_attempts_and_never_retries_a_failed_row(client, monkeypatch):
    broken = FakeProvider(fail_first=999)
    monkeypatch.setattr(delivery_service, "get_email_provider", lambda: broken)
    ta, tb, tc, ih, rid, aid = world(client)
    verify(client, "a@example.com")
    hire(client, ih, aid["a"])
    t = datetime.now(timezone.utc)
    for i in range(1, 9):
        delivery_service.process_pending(db_of(client), now=t + timedelta(days=i))
    row = [d for d in deliveries(client) if d.type == "HIRING_REQUEST"][0]
    assert row.status == "FAILED" and row.attempts == 5 and len([c for c in broken.calls if c[1] == "You have a hiring request"]) == 5


def test_a_later_success_after_failures_sends_once(client, monkeypatch):
    flaky = FakeProvider(fail_subject=("You have a hiring request", 2))
    monkeypatch.setattr(delivery_service, "get_email_provider", lambda: flaky)
    ta, tb, tc, ih, rid, aid = world(client)
    verify(client, "a@example.com")
    hire(client, ih, aid["a"])
    t = datetime.now(timezone.utc)
    for i in range(1, 6):
        delivery_service.process_pending(db_of(client), now=t + timedelta(days=i))
    row = [d for d in deliveries(client) if d.type == "HIRING_REQUEST"][0]
    attempts = [c for c in flaky.calls if c[1] == "You have a hiring request"]
    assert row.status == "SENT" and row.attempts == 3 and len(attempts) == 3
    assert len({c[3] for c in attempts}) == 1                                  # every attempt carried the same idempotency key


def test_one_failing_recipient_does_not_block_the_others(client, monkeypatch):
    p = FakeProvider(fail_for="a@example.com")
    monkeypatch.setattr(delivery_service, "get_email_provider", lambda: p)
    ta, tb, tc, ih, rid, aid = world(client)
    verify(client, "a@example.com", "b@example.com")
    db = db_of(client)
    for email in ("a@example.com", "b@example.com"):
        delivery_service.enqueue(db, user_id(client, email), "email", "SESSION_REMINDER", "Reminder", None, None)
    db.commit()
    out = run(client)
    assert out["sent"] == 2 and out["retry"] == 2                              # a's two emails retry; b's two are sent
    assert {d.status for d in deliveries(client) if d.type == "SESSION_REMINDER"} == {"SENT", "PENDING"}


def test_unimplemented_provider_is_an_operator_error_and_burns_no_attempts(client, monkeypatch):
    from app.core.config import settings
    ta, tb, tc, ih, rid, aid = world(client)
    hire(client, ih, aid["a"])
    monkeypatch.setattr(settings, "email_provider", "ses")
    with pytest.raises(RuntimeError):
        delivery_service.process_pending(db_of(client), now=datetime.now(timezone.utc) + timedelta(seconds=1))
    assert all(d.attempts == 0 for d in deliveries(client))


# ---------- transaction safety, deduplication ----------
def test_rollback_publishes_and_queues_nothing_and_commit_does(client, monkeypatch):
    ta, tb, tc, ih, rid, aid = world(client)
    pushes = []
    monkeypatch.setattr(notification_service.manager, "push", lambda uid, payload: pushes.append((uid, payload)))
    uid = user_id(client, "a@example.com")
    db = db_of(client)
    before_n = db.query(Notification).filter(Notification.user_id == uid).count()
    before_d = db.query(NotificationDelivery).filter(NotificationDelivery.user_id == uid).count()
    assert notify_event(db, uid, "HIRING_REQUEST", institution="X", requirement="Y") is True
    db.rollback()
    assert pushes == [] and db.query(Notification).filter(Notification.user_id == uid).count() == before_n
    assert db.query(NotificationDelivery).filter(NotificationDelivery.user_id == uid).count() == before_d
    notify_event(db, uid, "HIRING_REQUEST", institution="X", requirement="Y")
    db.commit()
    assert len(pushes) == 1 and set(pushes[0][1]) == {"id", "type", "title", "body", "link", "is_read", "created_at"}


def test_dedupe_applies_to_in_app_rows_and_to_the_outbox(client):
    ta, tb, tc, ih, rid, aid = world(client)
    db = db_of(client)
    uid = user_id(client, "a@example.com")
    assert notify_event(db, uid, "SESSION_REMINDER", dedupe_key="k1", session="S", title="T", time="10:00", training_id=1) is True
    db.commit()
    assert notify_event(db, uid, "SESSION_REMINDER", dedupe_key="k1", session="S", title="T", time="10:00", training_id=1) is False
    assert db.query(Notification).filter(Notification.user_id == uid, Notification.dedupe_key == "k1").count() == 1
    assert db.query(NotificationDelivery).filter(NotificationDelivery.user_id == uid, NotificationDelivery.dedupe_key == "k1").count() == 1


def test_reminders_stay_idempotent_even_when_in_app_is_switched_off(client):
    ta, tb, tc, ih, rid, aid = world(client)
    hid, tid = fill(client, ih, ta, aid["a"])
    session(client, ta, tid)
    put(client, ta, in_app=False)
    put(client, ih, in_app=False)
    db = db_of(client)
    day_before = START - timedelta(days=1)
    before = len(deliveries(client))
    assert send_reminders(db, today=day_before, kinds=("day_before",)) == 2    # the two session emails are queued; training reminders are in-app only
    assert send_reminders(db, today=day_before, kinds=("day_before",)) == 0
    assert len(deliveries(client)) == before + 2


def test_unknown_types_are_refused(client):
    ta, tb, tc, ih, rid, aid = world(client)
    with pytest.raises(ValueError):
        notification_service.notify(db_of(client), user_id(client, "a@example.com"), "MADE_UP", "x")
    with pytest.raises(ValueError):
        notify_event(db_of(client), user_id(client, "a@example.com"), "MADE_UP")
