TRAINER = {"full_name": "Asha Rao", "email": "asha@example.com", "password": "Passw0rd123", "role": "TRAINER"}


def test_register_and_login(client):
    r = client.post("/api/v1/auth/register", json=TRAINER)
    assert r.status_code == 201
    assert "password" not in r.text
    r = client.post("/api/v1/auth/login", json={"email": TRAINER["email"], "password": TRAINER["password"]})
    assert r.status_code == 200
    token = r.json()["data"]["access_token"]
    me = client.get("/api/v1/auth/me", headers={"Authorization": f"Bearer {token}"})
    assert me.json()["data"]["role"] == "TRAINER"


def test_duplicate_email_rejected(client):
    client.post("/api/v1/auth/register", json=TRAINER)
    assert client.post("/api/v1/auth/register", json=TRAINER).status_code == 409


def test_wrong_password(client):
    client.post("/api/v1/auth/register", json=TRAINER)
    r = client.post("/api/v1/auth/login", json={"email": TRAINER["email"], "password": "nope12345"})
    assert r.status_code == 401


def test_cannot_self_register_admin(client):
    r = client.post("/api/v1/auth/register", json={**TRAINER, "role": "ADMIN"})
    assert r.status_code == 422


def test_institution_requires_name(client):
    r = client.post("/api/v1/auth/register", json={**TRAINER, "role": "INSTITUTION"})
    assert r.status_code == 422


def test_me_requires_token(client):
    assert client.get("/api/v1/auth/me").status_code == 401


def test_refresh_token_cannot_be_used_as_access(client):
    d = client.post("/api/v1/auth/register", json=TRAINER).json()["data"]
    r = client.get("/api/v1/auth/me", headers={"Authorization": f"Bearer {d['refresh_token']}"})
    assert r.status_code == 401
