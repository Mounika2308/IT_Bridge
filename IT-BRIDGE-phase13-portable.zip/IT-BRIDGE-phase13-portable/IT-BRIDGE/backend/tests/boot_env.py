"""Hermetic child-process helper for start-up / configuration tests (Phase 13B.1). Standard library only.

Why it exists: pydantic-settings reads `.env` relative to the CURRENT WORKING DIRECTORY and the parent process's environment variables. A test that
ran the app from backend/ with a copy of the parent environment therefore depended on whatever backend/.env and shell variables the developer had.

What `boot` guarantees:
  * the child runs in a fresh, empty temporary directory (never backend/ and never the developer's cwd); the app is found through PYTHONPATH;
  * every variable the application's Settings class can read is REMOVED from the child's environment first (the list is parsed from
    app/core/config.py, so a newly added setting is scrubbed automatically), and only the variables passed to `boot` are set;
  * a `.env` file exists in the child's cwd only when the test passes `dotenv=`; its contents are exactly what the test wrote.
"""
from __future__ import annotations

import importlib.util
import os
import re
import subprocess
import sys
import tempfile
from dataclasses import dataclass
from pathlib import Path

BACKEND = Path(__file__).resolve().parents[1]
CONFIG_FILE = BACKEND / "app" / "core" / "config.py"
# Not Settings fields, but still read by the app's start-up code or by libraries it imports.
EXTRA_SCRUBBED = ("PYTHONSTARTUP",)
DEFAULT_ENV = {"DATABASE_URL": "sqlite://", "JWT_SECRET": "j" * 40}      # neutral values every child needs; ENVIRONMENT is deliberately NOT here
REQUIRED_MODULES = ("fastapi", "pydantic_settings", "sqlalchemy")


def settings_variable_names() -> set[str]:
    """Upper-case names of every field of Settings, parsed from the source so this file needs no third-party imports."""
    names = set(re.findall(r"^    ([a-z][a-z0-9_]*)\s*:\s*[A-Za-z]", CONFIG_FILE.read_text(), flags=re.M))
    names.discard("model_config")
    return {n.upper() for n in names}


def missing_modules() -> list[str]:
    return [m for m in REQUIRED_MODULES if importlib.util.find_spec(m) is None]


@dataclass
class Boot:
    returncode: int
    stdout: str
    stderr: str
    cwd: str


def clean_environ(env: dict | None = None, parent: dict | None = None) -> dict:
    """The parent environment minus everything Settings could read, plus DEFAULT_ENV, plus `env`. A value of None UNSETS that variable (used to prove
    that a missing ENVIRONMENT is refused rather than defaulted)."""
    scrub = settings_variable_names() | set(EXTRA_SCRUBBED)
    out = {k: v for k, v in (os.environ if parent is None else parent).items() if k.upper() not in scrub}
    out.update(DEFAULT_ENV)
    out.update(env or {})
    return {k: v for k, v in out.items() if v is not None}


def boot(code: str = "import app.main", env: dict | None = None, dotenv: dict | str | None = None) -> Boot:
    """Runs `code` in a fresh interpreter in an empty temporary directory. `dotenv` (a dict or raw text) is written to `.env` there; None writes no file."""
    child_env = clean_environ(env)
    path = str(BACKEND)
    child_env["PYTHONPATH"] = path + (os.pathsep + child_env["PYTHONPATH"] if child_env.get("PYTHONPATH") else "")
    child_env["PYTHONDONTWRITEBYTECODE"] = "1"
    with tempfile.TemporaryDirectory(prefix="itb_boot_") as cwd:
        if dotenv is not None:
            text = dotenv if isinstance(dotenv, str) else "".join(f"{k}={v}\n" for k, v in dotenv.items())
            (Path(cwd) / ".env").write_text(text)
        r = subprocess.run([sys.executable, "-c", code], cwd=cwd, env=child_env, capture_output=True, text=True, timeout=120)
        return Boot(r.returncode, r.stdout, r.stderr, cwd)
