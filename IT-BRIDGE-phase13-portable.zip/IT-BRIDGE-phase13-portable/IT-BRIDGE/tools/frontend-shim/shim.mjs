#!/usr/bin/env node
// IT BRIDGE frontend CHECK SHIM (Phase 13 remediation). A stop-gap for machines where `npm ci` / vitest / vite cannot run. It is NOT Vitest and NOT Vite.
//
//   node tools/frontend-shim/shim.mjs check            parse every .js/.jsx file with esbuild and bundle the app and each test file (imports resolve, named imports exist)
//   node tools/frontend-shim/shim.mjs test [files...]  run the *.test.js(x) files (all of them by default) on a small Vitest-compatible harness
//
// What it can show: syntax, import resolution, and the assertions of the existing tests (rendering with react-dom/server, URL/method recording for the
// API layer, REAL zod for schema tests). What it cannot show: jsdom, @testing-library, user events, the real router/query/axios behaviour (they are replaced by
// the stubs in ./stubs), CSS/Tailwind or a production build. Those need `npm ci && npm test && npm run build` (see README.md in this folder).
//
// Portable: paths come from this file's location; esbuild, react, react-dom and zod are looked up in ITB_SHIM_MODULES, frontend/node_modules, ./node_modules
// and NODE_PATH, in that order. If zod cannot be found the schema tests are reported as BLOCKED instead of being run against a fake.
import fs from "fs";
import os from "os";
import path from "path";
import { createRequire } from "module";
import { execFileSync } from "child_process";
import { fileURLToPath } from "url";

const here = path.dirname(fileURLToPath(import.meta.url));
const SRC = process.env.ITB_FRONTEND_SRC || path.resolve(here, "../../frontend/src");
const STUBS = path.join(here, "stubs");
const DIRS = [process.env.ITB_SHIM_MODULES, path.resolve(here, "../../frontend/node_modules"), path.resolve(here, "node_modules"), ...(process.env.NODE_PATH || "").split(path.delimiter)]
  .filter((d) => d && fs.existsSync(d));

function find(name) {
  for (const d of DIRS) { try { return createRequire(path.join(d, "/")).resolve(name); } catch { /* try the next directory */ } }
  return null;
}
function need(name) {
  const p = find(name);
  if (!p) { console.error(`BLOCKED: cannot find "${name}" in ${DIRS.join(", ") || "(no module directory exists)"}. Set ITB_SHIM_MODULES to a node_modules folder that has it (npm i esbuild react react-dom zod).`); process.exit(2); }
  return createRequire(path.join(DIRS.find((d) => { try { createRequire(path.join(d, "/")).resolve(name); return true; } catch { return false; } }), "/"))(name);
}
const esbuild = need("esbuild");
for (const m of ["react", "react-dom/server"]) need(m);
const haveZod = !!find("zod");

const walk = (d, out = []) => { for (const e of fs.readdirSync(d, { withFileTypes: true })) { const p = path.join(d, e.name); e.isDirectory() ? walk(p, out) : out.push(p); } return out; };
const files = walk(SRC).filter((f) => /\.jsx?$/.test(f));
const tests = files.filter((f) => /\.test\.jsx?$/.test(f));

const work = fs.mkdtempSync(path.join(os.tmpdir(), "itb-shim-"));
// lucide-react: one placeholder component per icon the sources import (generated, so it can never go stale)
const icons = new Set();
for (const f of files) for (const m of fs.readFileSync(f, "utf8").matchAll(/import\s*\{([^}]*)\}\s*from\s*["']lucide-react["']/g)) m[1].split(",").map((s) => s.trim().split(/\s+as\s+/)[0]).filter(Boolean).forEach((i) => icons.add(i));
fs.writeFileSync(path.join(work, "icons.js"), `import { createElement as h } from "react";\nconst Icon = () => h("svg", { "aria-hidden": "true" });\n${[...icons].map((i) => `export const ${i} = Icon;`).join("\n")}\nexport default Icon;\n`);

const stubFor = { "react-router-dom": path.join(STUBS, "router.js"), "@tanstack/react-query": path.join(STUBS, "query.js"), "lucide-react": path.join(work, "icons.js"),
  axios: path.join(STUBS, "axios.js"), vitest: path.join(STUBS, "vitest.js") };
const plugin = { name: "stubs", setup(b) {
  b.onResolve({ filter: /^(react-router-dom|@tanstack\/react-query|lucide-react|axios|vitest)$/ }, (a) => ({ path: stubFor[a.path] }));
  b.onResolve({ filter: /context\/AuthContext\.jsx$/ }, () => ({ path: path.join(STUBS, "auth.js") }));
  b.onResolve({ filter: /layouts\/AppLayout\.jsx$/ }, () => ({ path: path.join(STUBS, "layout.js") }));
} };
const common = { bundle: true, jsx: "automatic", logLevel: "silent", loader: { ".css": "empty" }, nodePaths: DIRS, define: { "import.meta.env": "{}" } };

async function check() {
  let bad = 0;
  for (const f of files) {
    try { esbuild.transformSync(fs.readFileSync(f, "utf8"), { loader: f.endsWith(".jsx") ? "jsx" : "js", jsx: "automatic" }); }
    catch (e) { bad++; console.log("SYNTAX ERROR", path.relative(SRC, f), e.errors?.[0]?.text, e.errors?.[0]?.location?.line); }
  }
  console.log(`syntax: ${files.length - bad}/${files.length} files parse`);
  // the real packages that are not installed are external here: their imports are not checked
  const external = ["react-router-dom", "@tanstack/react-query", "lucide-react", "axios", "react-hook-form", "@hookform/resolvers/zod", ...(haveZod ? [] : ["zod"])];
  for (const entry of [path.join(SRC, "main.jsx"), ...tests]) {
    const isTest = entry !== path.join(SRC, "main.jsx");
    const r = await esbuild.build({ ...common, entryPoints: [entry], write: false, format: "esm", external: [...external, ...(isTest ? ["vitest", "react-dom/server"] : [])] }).catch((e) => e);
    if (r.errors?.length) { bad++; r.errors.forEach((e) => console.log("BUNDLE ERROR", path.relative(SRC, entry), e.text, e.location ? `${path.relative(SRC, e.location.file)}:${e.location.line}` : "")); }
    else console.log(`${isTest ? "test file resolves" : "bundle of main.jsx"}: OK ${path.relative(SRC, entry)}`);
  }
  process.exitCode = bad ? 1 : 0;
}

async function run(selected) {
  let passed = 0, failed = 0, blocked = 0;
  for (const t of selected) {
    const rel = path.relative(SRC, t);
    const usesZod = /from\s+["'](zod|@hookform\/resolvers\/zod)["']/.test(fs.readFileSync(t, "utf8")) || /schemas\//.test(fs.readFileSync(t, "utf8"));
    if (usesZod && !haveZod) { console.log(`--- ${rel}\nBLOCKED  zod is not installed here; this file needs the real library`); blocked++; continue; }
    const out = path.join(work, rel.replace(/[\\/]/g, "_") + ".cjs");
    try { await esbuild.build({ ...common, entryPoints: [t], outfile: out, platform: "node", format: "cjs", plugins: [plugin] }); }
    catch (e) { console.log(`--- ${rel}\nFAIL  does not bundle: ${e.errors?.[0]?.text}`); failed++; continue; }
    const script = `require(${JSON.stringify(out)}); globalThis.__done().then(() => { for (const [n, ok, m] of globalThis.__results) console.log((ok ? "PASS " : "FAIL ") + n + (ok ? "" : "  <- " + m)); });`;
    let text;
    try { text = execFileSync("node", ["-e", script], { encoding: "utf8", env: { ...process.env, NODE_PATH: DIRS.join(path.delimiter) } }); }
    catch (e) { console.log(`--- ${rel}\nFAIL  crashed: ${String(e.stderr || e.message).split("\n")[0]}`); failed++; continue; }
    console.log(`--- ${rel}\n${text.trim()}`);
    for (const l of text.split("\n")) { if (l.startsWith("PASS")) passed++; if (l.startsWith("FAIL")) failed++; }
  }
  console.log(`\nTOTAL: ${passed} passed, ${failed} failed, ${blocked} file(s) blocked   (shim harness: NOT Vitest)`);
  process.exitCode = failed ? 1 : 0;
}

const [cmd, ...rest] = process.argv.slice(2);
if (cmd === "check") await check();
else if (cmd === "test") await run(rest.length ? rest.map((f) => path.resolve(SRC, f.replace(/^frontend\/src\//, ""))) : tests);
else { console.error("usage: node shim.mjs check | test [file...]"); process.exitCode = 64; }
fs.rmSync(work, { recursive: true, force: true });
