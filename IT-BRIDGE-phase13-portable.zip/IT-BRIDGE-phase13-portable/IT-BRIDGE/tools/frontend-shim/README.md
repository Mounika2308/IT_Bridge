# Frontend check shim (stop-gap, NOT Vitest, NOT Vite)

Use only when `npm ci` cannot run. On a provisioned machine run the real thing instead:

    cd frontend && npm ci && npm test && npm run build

```
node tools/frontend-shim/shim.mjs check          # parse all .js/.jsx files; bundle main.jsx and every test file with esbuild
node tools/frontend-shim/shim.mjs test           # run every *.test.js(x) on a small Vitest-compatible harness
node tools/frontend-shim/shim.mjs test utils/payments.test.js
```

Needs `esbuild`, `react`, `react-dom` and (for `src/schemas`) `zod` in one `node_modules` folder, found in this order:
`$ITB_SHIM_MODULES`, `frontend/node_modules`, `tools/frontend-shim/node_modules`, `$NODE_PATH`. Without `zod`, the schema tests are reported as BLOCKED
(the previous shim silently replaced zod with a fake). `$ITB_FRONTEND_SRC` overrides the source folder. Paths are relative to this file; nothing is hard-coded.

Replaced by stubs in `stubs/` (so their real behaviour is NOT tested): react-router-dom, @tanstack/react-query, axios, the auth context and the app layout, vitest itself.
lucide-react icons are generated from what the sources import. There is no jsdom and no @testing-library: components are rendered with `react-dom/server`.

Last run (see PROJECT_PROGRESS.md for the dated record): `check` 83/83 files parse and all bundles resolve; `test` 187 passed, 0 failed, 0 blocked, with the real zod.

Blind spot (found in 13B.3): the shim's `vi.mock` is a no-op and its stubs define globals (`globalThis.__calls`, `__apiData`, `__role`). A test that silently depends on a stub's global passes here and fails under real Vitest. `services/notificationService.test.js` did exactly that and now carries its own `vi.mock("axios", ...)`. A green shim run is never evidence for real Vitest.
