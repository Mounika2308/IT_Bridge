import { createElement as h } from "react";
export const Link = ({ to, children, ...rest }) => h("a", { href: to, ...rest }, children);
export const MemoryRouter = ({ children }) => children;
export const useNavigate = () => () => {};
export const Navigate = () => null;
export const useParams = () => ({});
export const useSearchParams = () => [new URLSearchParams()];
