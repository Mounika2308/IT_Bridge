export const useAuth = () => ({ user: { role: globalThis.__role || "TRAINER", full_name: "Test User" } });
