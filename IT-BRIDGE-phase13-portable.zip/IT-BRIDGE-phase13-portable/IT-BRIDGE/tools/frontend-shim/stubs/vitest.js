import assert from "node:assert";
export const results = (globalThis.__results ||= []);
const scope = [], hooks = [[]];
let chain = Promise.resolve();                      // tests run one after another, so tests sharing a recorder cannot interleave
globalThis.__done = () => chain;
export const describe = (name, fn) => { scope.push(name); hooks.push([...hooks[hooks.length - 1]]); fn(); hooks.pop(); scope.pop(); };
export const beforeEach = (fn) => { hooks[hooks.length - 1].push(fn); };
export const it = (name, fn) => {
  const full = [...scope, name].join(" > "), pre = [...hooks[hooks.length - 1]];
  chain = chain.then(async () => { try { for (const h of pre) await h(); await fn(); results.push([full, true]); } catch (e) { results.push([full, false, String(e.message).split("\n")[0]]); } });
};
export const vi = { mock() {} };      // modules are replaced by the bundler here, so mock() has nothing to do
const matchers = (actual, neg) => {
  const check = (ok, msg) => { if (neg ? ok : !ok) throw new Error((neg ? "NOT " : "") + msg); };
  return {
    toContain: (x) => check(actual.includes(x), `expected ${JSON.stringify(String(actual).slice(0, 120))}... to contain ${JSON.stringify(x)}`),
    toBe: (x) => check(Object.is(actual, x), `expected ${JSON.stringify(actual)} to be ${JSON.stringify(x)}`),
    toEqual: (x) => { let ok = true; try { assert.deepStrictEqual(actual, x); } catch { ok = false; } check(ok, `expected ${JSON.stringify(actual)} to equal ${JSON.stringify(x)}`); },
    toHaveLength: (n) => check(actual != null && actual.length === n, `expected length ${n}, got ${actual && actual.length}`),
    toMatch: (re) => check(re.test(actual), `expected ${JSON.stringify(actual)} to match ${re}`),
    toBeTruthy: () => check(!!actual, `expected truthy, got ${JSON.stringify(actual)}`),
    toBeNull: () => check(actual === null, `expected null, got ${JSON.stringify(actual)}`),
    toHaveProperty: (k) => check(actual != null && k in actual, `expected property ${k}`),
  };
};
export const expect = (actual) => ({ ...matchers(actual, false), not: matchers(actual, true) });
