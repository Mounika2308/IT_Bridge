import { createContext, createElement as h, useContext } from "react";
const Ctx = createContext(null);
export class QueryClient { constructor() { this.data = new Map(); } setQueryData(key, v) { this.data.set(JSON.stringify(key), v); } }
export const QueryClientProvider = ({ client, children }) => h(Ctx.Provider, { value: client }, children);
export const useQueryClient = () => useContext(Ctx);
export const keepPreviousData = Symbol("keepPreviousData");
export const useQuery = ({ queryKey }) => {                       // renders what the cache holds, otherwise the loading state
  const c = useContext(Ctx); const k = JSON.stringify(queryKey);
  return c && c.data.has(k) ? { data: c.data.get(k), isLoading: false, isError: false, error: null, refetch() {} }
                            : { data: undefined, isLoading: true, isError: false, error: null, refetch() {} };
};
export const useMutation = () => ({ mutate() {}, isPending: false, isError: false, error: null });
