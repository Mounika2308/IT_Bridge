// Records every call so tests can assert the method and URL; replies with globalThis.__apiData.
export const calls = (globalThis.__calls ||= []);
const reply = () => Promise.resolve({ data: { success: true, data: globalThis.__apiData ?? {} } });
const rec = (m) => (url, a, b) => { calls.push([m, url, m === "get" ? a : b ?? a]); return reply(); };
const inst = { defaults: { baseURL: "" }, interceptors: { request: { use() {} }, response: { use() {} } }, get: rec("get"), post: rec("post"), put: rec("put"), patch: rec("patch"), delete: rec("delete") };
export default { create: () => inst, post() {} };
