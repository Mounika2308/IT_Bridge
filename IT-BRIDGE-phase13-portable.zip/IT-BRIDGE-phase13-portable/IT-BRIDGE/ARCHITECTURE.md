# Architecture

## Layers
    Browser (React 18, React Router, TanStack Query, React Hook Form + Zod)
        |  services/*.js  (one Axios client: bearer token, one refresh retry, error mapping)
        v
    FastAPI routers      backend/app/api/v1/*.py     thin: parse request, call a service, wrap in {success, message, data}
        v
    Services             backend/app/services/*.py   all business rules, transactions, audit rows, notifications
        v
    Repositories / ORM   repositories/user_repo.py + SQLAlchemy 2 models (app/models)
        v
    PostgreSQL           schema owned by Alembic (alembic/versions)
Only users have a repository class; other services query through the session directly (accepted for now, not duplicated logic).

## Authentication and roles
    register/login -> bcrypt check -> access JWT (15 min) + refresh JWT (7 d) -> stored in browser localStorage
    request -> Authorization: Bearer -> deps.current_user (decodes, checks type=access, loads user, rejects inactive)
    deps.require_roles("TRAINER", ...) -> 403 for other roles; missing/invalid/expired token -> 401
    expired access token -> client calls /auth/refresh once, retries; failure -> session cleared, redirect to /login
Roles: TRAINER, INSTITUTION, ADMIN. ADMIN is never self-registered (seed script only). Frontend `ProtectedRoute` mirrors the roles but the backend is the authority.

## Matching (single source of truth)
    services/matching.py        pure functions, no database: compute_match(requirement, trainer, busy, weights) -> score + factors
    services/match_service.py   loads candidates and weights, stores rows in match_scores, trainer_card(), busy_map(), recommendations
    services/discovery_service.py   filtered trainer search (no scoring)
Weights default to skill 40, experience 15, location 15, availability 15, mode 10, budget 5; stored in `platform_settings`, must total 100.
Each factor yields a ratio 0..1 times its weight; missing data scores 0 for that factor. The UI only displays backend numbers.
Busy dates = manual unavailable periods + active trainings.

## Flows and statuses
    Requirement  OPEN -> FILLED (the trainer accepts the hire) -> OPEN again (that training cancelled BEFORE its start date)
                 OPEN -> CLOSED (manual, final) ; EXPIRED is derived from the deadline (OPEN past it) ; see Requirement lifecycle below
    Application  APPLIED -> UNDER_REVIEW -> SHORTLISTED -> INTERVIEW(date+time; INTERVIEW->INTERVIEW reschedules) -> (hire) SELECTED ; REJECTED ; WITHDRAWN
                 institution moves: forward steps and REJECTED only; SELECTED only through hire; trainer may withdraw while active
    Hiring       PENDING -> ACCEPTED | DECLINED | CANCELLED ; ACCEPTED -> COMPLETED | CANCELLED (follows the training)
    Training     created on ACCEPT -> ACTIVE -> COMPLETED | CANCELLED   (see Training management below)
    Session      SCHEDULED -> ONGOING -> COMPLETED ; SCHEDULED/ONGOING -> CANCELLED   (rules in Sessions below)
    Review       one per direction per COMPLETED training (unique constraint). No edit, no delete. is_hidden exists, nothing sets it yet
Accepting a hire creates the Training in the same transaction. Completing early cancels sessions that never ran.

## Requirement lifecycle (Checkpoint C)
    institution sends hire -> trainer accepts -> respond(): [lock requirement row] Training created, requirement.status = FILLED   (one transaction)
    FILLED : apply refused ("already filled") | hire refused | change_status refused for every application of the requirement | edit refused | not in trainer discovery
             applications are neither rejected nor deleted (so they survive a reopen); the selected trainer's flow is unchanged
    training.cancel(): if start_date > today -> [lock] requirement FILLED -> OPEN (audit REQUIREMENT_REOPENED); started training -> no reopen; CLOSED stays CLOSED
    EXPIRED requirements stay workable for the institution (shortlist, interview, hire): the deadline only stops new applications
    Locks: Session.get(..., with_for_update=True, populate_existing=True) in apply, hire, respond(accept), cancel. Unique constraints still back this up.
    The application behind a cancelled training stays SELECTED (history); that trainer cannot re-apply to the same requirement.

## Training management (Phase 9)
    Hiring ACCEPTED --(same transaction)--> Training ACTIVE
        training_service.create_for_hiring refuses a hiring request that is not ACCEPTED and a second training for the same request (also unique in the database)
        snapshot copied at that moment: title, technology, mode, location, description, terms, dates, agreed fee, student count, planned sessions
    Stored status:  ACTIVE -> COMPLETED (institution, only once started)   ACTIVE -> CANCELLED (either party)   COMPLETED/CANCELLED are final
    Derived phase (training_service.phase): UPCOMING (start in future) | IN_PROGRESS | ENDED (end passed, still ACTIVE) | COMPLETED | CANCELLED
    Dates: only the institution changes them; a started training's start is fixed; an upcoming start cannot move into the past; sessions must stay inside the range
    Online details: meeting_link (https only) on ONLINE/HYBRID trainings, settable by either party while ACTIVE
    Access: only the trainer and the institution of that training (404 otherwise); inactive users 403 on every endpoint; admins have no access yet
    Reads:  GET /trainings/mine (paginated, status filter), /trainings/summary, /trainings/{id}
There is deliberately no PENDING training: the pending stage is the hiring request. Training responses are plain dicts built in `training_out`, like the other modules.

## Sessions, attendance and calendar (Phase 10)
    Time: clock.now()/today() give platform-local time (APP_TIMEZONE). Session and interview times are stored as naive local date + time.
    Create / reschedule : inside the training dates, end after start, not in the past, no date+time overlap with any other live session of the same trainer
                          (join over the trainer's ACTIVE trainings; touching times allowed). Either party may schedule; only SCHEDULED sessions can be changed.
    Status              : Start and Complete are trainer only and wait for the scheduled start; Cancel by either party, never once attendance exists.
    Attendance          : trainer only, ACTIVE training only, session started, present + absent <= total_students <= training.student_count; one row per session, updated in place.
    Notes               : sessions.notes, trainer writes, both read, ACTIVE training only.
    Planned sessions    : institution only, never below the non-cancelled sessions already created.
    Close-out (complete or cancel a training), _close_out_sessions:
        started + attendance -> COMPLETED (history kept)     not started -> CANCELLED
        ONGOING, no attendance -> COMPLETED on completion / CANCELLED on cancellation     past SCHEDULED, no attendance -> untouched
    Calendar (GET /calendar, max 100 days): TRAINING, SESSION, INTERVIEW, DEADLINE, BUSY events, always scoped to the caller's own profile.
        TRAINING/SESSION events carry phase, mode, location and meeting_link (online/hybrid only); INTERVIEW events come from applications in the INTERVIEW stage.
    Queries: list_mine and the calendar eager-load (selectinload/joinedload) so query counts do not grow with the rows returned (tested).
Session logic lives in training_service.py next to the training lifecycle; a separate module would need a lazy import to avoid a cycle, so it stays.

## Notifications (Phase 11)
    service -> notify_event(user, TYPE, **context)           services/notification_types.py is the only list of types
        render title / body / deep link from the registry
        per-user dedupe_key check (notifications + outbox)
        preferences (in_app, email; `mandatory` types ignore the in-app switch)
        -> INSERT notifications row (in-app)            -> remembered in session.info for a push after COMMIT
        -> INSERT notification_deliveries row (email, only email-eligible types) status PENDING
    COMMIT -> WebSocket push to the user's open sockets.   ROLLBACK -> nothing was stored and nothing is pushed.

    Worker (python -m app.workers.outbox | loop, or cron)   never inside a request
        SELECT PENDING and due ... FOR UPDATE SKIP LOCKED
        re-check: account active, email switched on, address present and verified
        EmailProvider.send(..., idempotency_key)   ->  SENT | SKIPPED(reason) | PENDING again with backoff | FAILED after N attempts
    Provider today: ConsoleEmailProvider (DEVELOPMENT, sends nothing, logs only the delivery id).

    Reminders (workers/reminders.py, idempotent through dedupe keys)
        interview  : every 15 min, interviews in the next INTERVIEW_REMINDER_HOURS, key includes the interview time
        day_before : daily from DAY_BEFORE_REMINDER_HOUR, sessions and trainings starting tomorrow

    WebSocket: connect /ws/notifications, first message {"token": <access>} (never in the URL), then {"type":"ready"}.
        On every (re)connect the frontend refetches the list and the unread count. Before each message the server re-checks the user is
        active and closes with 4403 if not. At most 5 sockets per user. Payloads hold the notification only: no email, no phone.
    Frontend: hooks/useLiveNotifications -> utils/notifications.js (handleSocketMessage, notificationTarget, openNotification)
        -> NotificationBell (badge, list), pages/Notifications, pages/NotificationSettings (/notifications/settings).

## Reviews and ratings (Phase 12)
    POST /trainings/{id}/reviews   token user -> participant? (404) -> account allowed? (403) -> COMPLETED? (409 + reason) -> payload (422) -> duplicate? (409)
        -> INSERT review + audit row + REVIEW_RECEIVED notification (dedupe key review-received:{id}) -> one COMMIT
    rating of a profile = round_half_up_1dp( mean( stored overall of visible reviews ) )     overall = round_half_up_1dp( mean(category scores) )
    min_rating filter   = reviews >= 2 AND the same rounded value >= min_rating            (SQL narrows, review_service.round_rating decides)
    reads: GET /trainers/{id}/reviews, GET /institutions/{id}/reviews (paged, public fields only), GET /reviews/me (own summary + pending count)
    reminder: workers/reminders.py --kind review (hourly): COMPLETED 3 to 14 days ago, per participant with no review and allowed to review,
        dedupe key review-reminder:{training}:{user} -> same outbox and preferences as every other notification
    Frontend: ReviewSection (form, states), ReviewList (paged), RatingSummary, ReviewSummaryCard (dashboards), pages/InstitutionPublicProfile,
        utils/reviews.js (wording, counter, submit rules, 422 field errors). The API reports why a review is not possible (reason).

## Payments, invoices and trainer earnings (Phase 13): sandbox only
    POST /trainings/{id}/payments   Idempotency-Key + amount_paise -> owner institution? -> payments_on()? -> LOCK training -> same key? (replay or 409)
        -> rules.check_create (blocked? fee cap, minimum, one in flight) -> provider.create_order -> INSERT payment (PENDING) + audit -> COMMIT
    result of an attempt (the ONLY way a status changes):
        provider -> POST /payments/webhook -> body size -> HMAC(timestamp.body) + tolerance (fails closed) -> parse (lengths) -> process_event
        sandbox button -> signed event built server-side -> handle_webhook (source SANDBOX)         reconcile worker -> provider.fetch_status -> process_event (RECONCILE)
        process_event: event already stored? (replay) -> order known? (else store once + 404, the provider retries) -> LOCK training, LOCK payment
            -> rules.decide_event (late, over-cap, duplicate, amount/currency mismatch, cancelled training...) -> status + CHARGE transaction + event row + flag(s)
               cap basis = settled_totals(training, excluding this payment) = money of SUCCEEDED payments WITH a recorded commission (an over-cap success has none, so it never inflates the basis);
               collected_paise = money HELD (every non-failed attempt) and is used only to block new attempts
            -> invoice always; earning + commission record unless over-cap (commission finalised here from what is already settled) -> notifications (notify_event_safe: SAVEPOINT, failure logged and skipped, money kept) -> COMMIT
    states: PENDING -> PROCESSING -> SUCCEEDED | FAILED ; PENDING -> CANCELLED | EXPIRED ; PROCESSING -> EXPIRED (system, after the timeout) ;
            FAILED / CANCELLED / EXPIRED -> SUCCEEDED only for a verified late success ; SUCCEEDED is final (a refund is a separate record)
    commission = (amount * bps + 5000) // 10000, taken from the trainer's share; instalment commission = target(total live money) - commission already settled
    earnings: PENDING -> AVAILABLE (training COMPLETED, hold elapsed) -> PAID (admin records a reference) | REFUNDED ; PAID is final
    refund (admin, full only):  A) INSERT payment_refunds PENDING (unique per payment) + COMMIT   B) provider.refund(idempotency key) with NO lock held
        -> LOCK training, payment, earning -> REFUND transaction, credit note (locked counter), earning REFUNDED, commission REVERSED -> COMMIT ; the worker resumes a stuck B
    LOCK ORDER everywhere: training row -> payment row -> earning / refund rows (record_payout: payment then earning). Probed as plain SQL on PostgreSQL 16 (verify_postgres_sql.py, with a deadlock control);
        the Python code that takes the locks has NOT been run against PostgreSQL (test_postgres_concurrency.py is written, not executed).
    training hooks (inside training_service's own transaction): complete -> earnings AVAILABLE ; cancel -> unstarted attempts CANCELLED, received money flagged TRAINING_CANCELLED (never refunded automatically)
    review flags (migration 0006): table payment_review_flags, ONE ROW PER REASON, partial unique index (payment_id, reason) WHERE resolved_at IS NULL.
        reasons: LATE_SUCCESS, OVER_CAP, DUPLICATE_CHARGE, AMOUNT_MISMATCH, CURRENCY_MISMATCH, TRAINING_CANCELLED, STUCK_PROCESSING, REFUND_STUCK.
        payments.needs_review / review_reason are only a SUMMARY (oldest open reason) written by sync_review_state; resolving needs a named reason when >1 is open (rules.pick_flag);
        OVER_CAP cannot be closed before a refund; the payment-level note/reviewer are set when the LAST flag closes; every resolution is audited; admin only.
    notification isolation: notify_event_safe flushes, runs the dispatch in db.begin_nested() (SAVEPOINT), and on any exception logs it, drops pushes queued inside it and returns False;
        the push-after-commit listeners ignore nested transactions. SQLite tests cover the logic; PostgreSQL savepoint behaviour is covered only by test_postgres_notifications.py (written, NOT RUN). UNPROTECTED (non-financial): training date-change notice, requirement-reopened notice, notify_waiting_applicants.
    sandbox gate: rules.sandbox_usable(enabled, provider, sandbox_opt_in, environment) = PAYMENTS_ENABLED and provider implemented and PAYMENT_SANDBOX_ENABLED and ENVIRONMENT in (development, test)
    guard: core/payment_guard.assert_safe_payment_config() in main.py, the payment worker and the loop (NOT the standalone outbox / reminders workers), FAIL CLOSED.
        ENVIRONMENT has NO default: config.Settings.environment = "" and rules.environment_kind() maps anything but development / test / production (prod) to "unknown", which is refused
        whether or not payments are enabled (no pydantic-settings internals are consulted). Also refused: the sandbox without the opt-in (development/test with payments enabled); in production the sandbox
        and its opt-in, an unimplemented provider (with payments enabled), an unconfirmed commission (with payments enabled), and (13B.2) a MISSING, empty, weak or example
        webhook secret WHETHER OR NOT PAYMENTS ARE ENABLED. Development and test accept any secret, including none. A bad commission rate is refused everywhere.
    webhook secret: rules.webhook_secret_usable(secret, environment): empty never; in production (or an unknown environment) only a non-weak secret. handle_webhook passes "" to check_webhook otherwise (503 not_configured): defence in depth behind the start-up refusal.
        The 30-cell matrix (production/development/test x payments on/off x missing/empty/weak/example/valid) lives in tests/webhook_secret_matrix.py and is exercised by rule, guard, child-process and API tests.
    start-up tests: tests/boot_env.py (empty temp cwd, every Settings variable scrubbed, optional explicit .env) + test_startup_hermetic.py (needs the real dependencies; skips without them)
        and test_payment_guard_unit.py (the real guard against an injected stand-in config; pure pytest).
    fee message: rules.block_reason(..., settled) returns AWAITING_REFUND (not FULLY_PAID) when money HELD reaches the fee but money SETTLED does not (an over-cap payment waits for its refund);
        rules.block_text names the amount still due (fee - settled). The summary adds settled_paise and due_paise. The cap rules are unchanged.
    provider order id: validated (<= 80 chars) BEFORE the insert ; reconcile: attempts ordered by (updated_at, id), limit 200, each examined attempt is touched so a failing one rotates to the back
    Frontend: utils/payments.js (paise formatting that mirrors the backend, string-based rupee parsing, statuses, polling rule, idempotency key holder),
        PaymentSection (pure PaymentPanel + container; refetch while a payment is open), SandboxBanner, pages InstitutionPayments / TrainerEarnings / InvoiceView.
    Tables (all ON DELETE RESTRICT): payments, payment_transactions, payment_webhook_events, invoices, invoice_counters, payment_refunds, trainer_earnings, platform_commissions (0005), payment_review_flags (0006).
    Migration 0007 (PostgreSQL ONLY, no-op elsewhere). What it does and does NOT do (details: its docstring; limits executed by scripts/verify_postgres_sql.py group F):
        REJECTS every UPDATE/DELETE: invoices, payment_transactions (the ledger)  |  payments: UPDATE may not change the identity columns (amount, currency, training, institution, trainer, payer, provider,
        order id, attempt, idempotency key, fingerprint); every other column, status included, can change  |  CHECKED AT INSERT ONLY against the row's own payment (ERRCODE 23000): invoices, trainer_earnings,
        platform_commissions, payment_refunds (full amount, payment SUCCEEDED), payment_transactions (amount)  |  VALIDATED cross-table relationships: only those child-vs-own-payment checks; the payer is not
        validated against any child, nothing re-checks a child after the payment changes  |  STILL EDITABLE / DELETABLE by hand-written SQL (only CHECK / FK / UNIQUE apply): platform_commissions,
        trainer_earnings (a self-consistent edit passes), payment_refunds, payment_webhook_events, payment_review_flags, invoice_counters, payments outside the identity columns.
        "Financial ledger immutability" therefore means payment_transactions and issued invoices only. upgrade() is not idempotent (CREATE TRIGGER without OR REPLACE).
        Validated by DDL on PostgreSQL 16 through psql, NOT yet through Alembic.
    Deploy order: `alembic upgrade head` BEFORE starting api / worker / loop (compose: worker waits for the backend health check). 0006 refuses to upgrade over a needs_review row with no reason.
    Downgrades (app/core/migration_guard.py): EVERY revision's downgrade() begins with preflight_downgrade("<rev>"). The first call of a run takes the revisions the run removes from the CHAIN
        and the target, unioned with script.iterate_revisions(<first>, <target>, select_for_downgrade=True) (the wider answer wins; an unrecognised target, or a relative `-N` Alembic cannot confirm, checks everything down to base), looks each up in POLICY (what it drops: 0001 the 19 core tables, 0002 trainings snapshot columns + meeting_link, 0003 session notes +
        interview_at, 0004 notification_preferences + notification_deliveries, 0005 / 0006 the financial tables, 0007 nothing), counts the rows held and refuses the WHOLE run before any revision executes; the run is then
        checked once (a relative target such as -3 is counted from where the run starts). Only revisions in the path count: `downgrade -1` is not blocked by users. Unknown path or unknown revision -> refused (fail closed).
        Why up front: Alembic runs a downgrade as ONE transaction only where the dialect has transactional DDL (PostgreSQL: yes; SQLite: no, each revision is its own transaction and pysqlite does not roll DDL back), so a
        late refusal at 0001 used to leave 0004-0002 applied on SQLite; 0002-0004 had no guard. The per-revision _refuse_to_discard in 0001 / 0005 / 0006 remains as a second line. Offline --sql is refused when the path drops data.
        ITB_ALLOW_FINANCIAL_DOWNGRADE=I_UNDERSTAND_DATA_WILL_BE_DESTROYED (name kept for compatibility, NOT renamed) authorises ALL of it - core data, notifications, snapshot columns, notes, interview times and financial
        records. Exact match on that variable only. WITH it the checks return first and `alembic downgrade --sql` DOES emit the destructive DDL. Tests: test_migration_guards_static.py (policy vs migration files),
        test_migration_guard.py (logic, fake Alembic), scripts/check_migrations_static.py (stub replay on SQLite), test_migrations.py (real Alembic, SQLite) and test_migrations_postgres.py (real Alembic, PostgreSQL); the last two NOT RUN.
    Earnings: promote_available never promotes an earning whose payment has a refund row (a Python check inside the loop, present since the original Phase 13; the SQL pre-filters added later only keep such rows, and rows still inside the hold, from filling the 500-row window). Cancelled-training earnings stay PENDING (policy undecided) - see PROJECT_PROGRESS.md.
    Not built: a real provider adapter, partial refunds, payout execution, an admin dashboard, tax (GST) invoicing.
    Verification status: pure rules ran under real pytest; services/routes/API tests/Alembic/PostgreSQL integration tests/Vitest/Vite/Docker are BLOCKED here (see PROJECT_PROGRESS.md for the exact commands).

## API structure (all under /api/v1, plus /ws/notifications)
auth, profiles (skills, trainers/me, institutions/me), requirements, matching (trainer search, matches, recommendations, busy periods, weights),
applications (+ hiring requests), trainings (+ sessions, attendance, calendar), notifications, reviews (+ institution reviews, own summary),
payments (institution payments and invoices, trainer earnings, the signed webhook, admin refund / payout / review). Interactive docs at /docs.

## Docker
    db (postgres:16, healthcheck) + redis (healthcheck, unused) -> backend (alembic upgrade head, seed, uvicorn) -> frontend (vite dev server)
A small `worker` service runs `python -m app.workers.loop` (outbox, reminders and payment reconciliation); it starts only after the backend health check passes, i.e. after `alembic upgrade head` finished (compose parses as YAML; `docker compose up` itself has not been run). There is no Celery. Production images, secrets management and CI/CD are not done.

## Known design gaps
Start-up guard coverage (13B.3): `main.py`, `app.workers.payments` and `app.workers.loop` run `assert_safe_payment_config()`; the stand-alone `app.workers.outbox` and `app.workers.reminders` entry points do not, so they accept a missing or unknown `ENVIRONMENT` that the API refuses (they never touch payments). Dependencies are unpinned and the frontend has no lockfile.
Session times are naive local times with no per-user timezone. Accepting a hire does not check the trainer's availability. The application behind a cancelled training stays SELECTED.
WebSocket fan-out is per process (Redis pub/sub is a later phase). Logout does not revoke tokens. No email provider, SMS or WhatsApp exists and nothing sets `email_verified`, so email delivery cannot reach real users yet.
