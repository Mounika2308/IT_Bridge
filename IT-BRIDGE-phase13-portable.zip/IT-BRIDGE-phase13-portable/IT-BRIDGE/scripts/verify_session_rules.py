#!/usr/bin/env python3
"""Interim logic check for the Phase 10 session rules (stdlib only).

Extracts the REAL functions from backend/app/services/training_service.py and calendar_service.py with `ast` and runs them
against test doubles for the database, the clock and the helpers that need SQLAlchemy. So it exercises the actual rule code,
but NOT: the ORM statements themselves, Pydantic request validation (nulls, negative numbers), HTTP routing or authorization
dependencies. Those need the real dependencies and are covered by backend/tests (pytest) once they can be run.
Usage: python scripts/verify_session_rules.py   (exit code 1 on any failure)
"""
import ast
import sqlite3
import sys
import types
from datetime import date, datetime, time, timezone
from pathlib import Path
from types import SimpleNamespace as NS

SERVICES = Path(__file__).resolve().parent.parent / "backend/app/services"
RESULTS: list[tuple[str, bool, str]] = []


# ---------- doubles ----------
class HTTPException(Exception):
    def __init__(self, status_code, detail=None):
        super().__init__(f"{status_code} {detail}")
        self.status_code, self.detail = status_code, detail


class Col:
    def _op(self, *a):
        return Col()
    __eq__ = __ne__ = __lt__ = __gt__ = __le__ = __ge__ = _op
    __hash__ = object.__hash__

    def in_(self, *a):
        return Col()

    def is_not(self, *a):
        return Col()

    def is_(self, *a):
        return Col()


class Meta(type):
    def __getattr__(cls, name):
        return Col()


class Chain:
    def __getattr__(self, name):
        return lambda *a, **k: self


class Model(metaclass=Meta):
    defaults: dict = {}

    def __init__(self, **kw):
        self.__dict__.update({"id": 99, "status": "SCHEDULED", "notes": None, "attendance": None, **self.defaults, **kw})


class TrainingSession(Model):
    pass


class Attendance(Model):
    pass


class Training(Model):
    pass


class TrainingRequirement(Model):
    pass


class DB:
    def __init__(self, overlap=None, got=None, rows=None, users=None, now=None):
        self.overlap, self.got, self.added, self.commits, self.info = overlap, got, [], 0, {}
        self.rows, self.users, self.now = rows, users, now

    def scalar(self, stmt):
        return self.overlap

    def scalars(self, stmt):
        if self.rows is not None:               # emulates the outbox query: PENDING rows that are due
            return [d for d in self.rows if d.status == "PENDING" and d.next_attempt_at <= self.now]
        return []

    def get(self, model, ident, **kw):          # stands in for Session.get(..., with_for_update=True, populate_existing=True)
        if self.users is not None and getattr(model, "__name__", "") == "User":
            return self.users.get(ident)
        return self.got

    def add(self, o):
        self.added.append(o)

    def refresh(self, obj, **kw):               # stands in for Session.refresh(obj, with_for_update=True): the harness objects are already current
        return None

    def flush(self):
        if getattr(self, "flush_error", None):
            raise self.flush_error

    def commit(self):
        self.commits += 1

    def rollback(self):
        self.rolled_back = True

    def execute(self, stmt):                    # canned result rows for aggregate queries
        return list(getattr(self, "exec_rows", []))


# ---------- load the real code ----------
def extract(filename, names, constants=(), base=SERVICES):
    tree = ast.parse((base / filename).read_text())
    keep = []
    for n in tree.body:
        if isinstance(n, ast.FunctionDef) and n.name in names:
            n.returns = None
            for a in n.args.args:
                a.annotation = None
            keep.append(n)
        elif isinstance(n, ast.Assign) and getattr(n.targets[0], "id", None) in constants:
            keep.append(n)
    found = {n.name for n in keep if isinstance(n, ast.FunctionDef)}
    assert found == set(names), f"functions not found in {filename}: {set(names) - found}"
    return ast.Module(body=keep, type_ignores=[])


TRAINING_FUNCS = ["update_details", "phase", "session_start", "_started", "_t", "session_out", "training_out", "_require_active", "_check_session", "create_session",
                  "update_session", "set_session_status", "record_attendance", "update_notes", "update_planned_sessions",
                  "_close_out_sessions", "complete", "cancel"]


# Phase 13: complete() and cancel() call payment hooks lazily (`from app.services.payment_service import ...`). The real module needs SQLAlchemy, so the
# harness registers a recording stand-in: it proves WHEN the hooks run (once, inside a successful complete/cancel, never on a refused one).
PAYMENT_HOOKS: list = []
_payment_stub = types.ModuleType("app.services.payment_service")
_payment_stub.on_training_completed = lambda db, t: PAYMENT_HOOKS.append(("completed", t.id))
_payment_stub.on_training_cancelled = lambda db, t, actor: PAYMENT_HOOKS.append(("cancelled", t.id))
sys.modules["app.services.payment_service"] = _payment_stub


def load(now: datetime) -> dict:
    ns = {"HTTPException": HTTPException, "datetime": datetime, "date": date, "timezone": timezone, "select": lambda *a, **k: Chain(),
          "func": Chain(), "TrainingRequirement": TrainingRequirement, "TrainingSession": TrainingSession, "Attendance": Attendance, "Training": Training,
          "now": lambda: now, "today": lambda: now.date(), "audit": lambda *a, **k: None, "notify": lambda *a, **k: None, "notify_event": lambda *a, **k: None, "notify_event_safe": lambda *a, **k: None, "notify_waiting_applicants": lambda *a, **k: None, "fmt_when": lambda d: str(d),
          "_tell_other": lambda *a, **k: None}
    exec(compile(extract("training_service.py", TRAINING_FUNCS, ("SESSION_MOVES",)), "training_service", "exec"), ns)
    return ns


# ---------- helpers ----------
def sess(day, hh, end_h=None, status="SCHEDULED", attendance=None, sid=1, title="S", mm=0):
    return NS(id=sid, title=title, session_date=day, start_time=time(hh, mm), end_time=time(end_h if end_h is not None else hh + 1, mm),
              status=status, attendance=attendance, notes=None)


def att(present=45, total=60, absent=15):
    return NS(total_students=total, present=present, absent=absent)


def training(**kw):
    base = dict(id=1, title="Python workshop", status="ACTIVE", start_date=date(2030, 3, 1), end_date=date(2030, 3, 10), planned_sessions=3,
                student_count=60, trainer_id=1, sessions=[], mode="OFFLINE", location="Pune", description="d", terms=None, meeting_link=None,
                requirement_id=1, technology="Python", agreed_fee=1, cancel_reason=None,
                hiring_request=NS(status="ACCEPTED"), trainer=NS(user_id=10, user=NS(full_name="Asha", email="a@x", phone=None)),
                institution=NS(user_id=20, institution_name="Sunrise", user=NS(full_name="Ravi", email="r@x", phone=None)))
    base.update(kw)
    return NS(**base)


def wire(ns, s=None, t=None, role="TRAINER"):
    ns["_get_session"] = lambda db, u, sid: (s, t, role)
    ns["get_training"] = lambda db, u, tid: (t, role)


def check(name, fn):
    try:
        fn()
        RESULTS.append((name, True, ""))
    except Exception as e:
        RESULTS.append((name, False, f"{type(e).__name__}: {e}"))


def status_of(fn):
    try:
        fn()
        return 200
    except HTTPException as e:
        return e.status_code


def must(got, want, what=""):
    assert got == want, f"{what}: expected {want}, got {got}"


D = date(2030, 3, 5)
M10 = datetime(2030, 3, 5, 10, 0)


# ---------- 1. session creation and rescheduling ----------
def t_check_session():
    ns = load(M10)
    t, db = training(), DB()
    chk = lambda d, s, e, **k: status_of(lambda: ns["_check_session"](db, t, d, s, e, **k))
    must(chk(date(2030, 2, 28), time(10), time(11)), 422, "before the training starts")
    must(chk(date(2030, 3, 11), time(10), time(11)), 422, "after the training ends")
    must(chk(D, time(12), time(10)), 422, "end before start")
    must(chk(D, time(10), time(10)), 422, "zero length")
    must(chk(D, time(9, 59), time(11)), 422, "starts one minute in the past")
    must(chk(D, time(10), time(11)), 200, "starts exactly now is allowed")
    must(chk(D, time(10, 1), time(11)), 200, "later today")
    must(chk(D, time(9), time(10), check_past=False), 200, "rename-only skips the past check")
    db.overlap = 1
    must(chk(D, time(11), time(12)), 409, "overlap reported by the database")
check("create/reschedule rules: range, order, past (to the minute), overlap", t_check_session)


def t_create_session():
    ns = load(M10)
    t = training(sessions=[sess(D, 14, status="CANCELLED"), sess(D, 15, sid=2), sess(D, 16, sid=3)])
    wire(ns, t=t, role="INSTITUTION")
    fields = dict(title="Day", session_date=D, start_time=time(11), end_time=time(12))
    data = NS(**fields, model_dump=lambda: dict(fields))          # what a validated SessionIn offers
    db = DB()
    must(status_of(lambda: ns["create_session"](db, None, 1, data)), 200, "2 live of 3 planned (cancelled does not count)")
    t.sessions.append(sess(D, 17, sid=4))
    must(status_of(lambda: ns["create_session"](db, None, 1, data)), 409, "3 live of 3 planned")
    t.sessions.pop()
    t.status = "COMPLETED"
    must(status_of(lambda: ns["create_session"](db, None, 1, data)), 409, "completed training")
    t.status, t.sessions = "ACTIVE", []
    past_fields = dict(title="Day", session_date=D, start_time=time(9), end_time=time(9, 30))
    past = NS(**past_fields, model_dump=lambda: dict(past_fields))
    must(status_of(lambda: ns["create_session"](db, None, 1, past)), 422, "past session")
check("create_session: planned count (cancelled excluded), completed training, past", t_create_session)


def t_update_session():
    ns = load(M10)
    s = sess(D, 9, 10)                      # a SCHEDULED session whose time has already passed
    t = training(sessions=[s])
    wire(ns, s=s, t=t)
    db = DB()
    upd = lambda **c: NS(model_dump=lambda exclude_unset=True: c)
    must(status_of(lambda: ns["update_session"](db, None, 1, upd(title="Renamed"))), 200, "rename only")
    s.start_time = time(12); s.end_time = time(13)
    must(status_of(lambda: ns["update_session"](db, None, 1, upd(start_time=time(9)))), 422, "move into the past")
    must(status_of(lambda: ns["update_session"](db, None, 1, upd(start_time=time(14), end_time=time(15)))), 200, "move later today")
    must(status_of(lambda: ns["update_session"](db, None, 1, upd(start_time=time(16)))), 422, "start after the (old) end")
    s.status = "COMPLETED"
    must(status_of(lambda: ns["update_session"](db, None, 1, upd(title="x"))), 409, "only SCHEDULED sessions change")
check("update_session: rename vs reschedule, past, order, non-scheduled", t_update_session)


# ---------- 2. start / complete / cancel ----------
def t_status():
    s = sess(D, 10, 12)
    t = training(sessions=[s])
    def run(now, status, role="TRAINER", sess_=None, train=None):
        ns = load(now)
        wire(ns, s=sess_ or s, t=train or t, role=role)
        return status_of(lambda: ns["set_session_status"](DB(), None, 1, status))
    must(run(datetime(2030, 3, 5, 9, 59), "ONGOING"), 409, "start one minute early")
    must(run(datetime(2030, 3, 5, 9, 59), "COMPLETED"), 409, "complete one minute early")
    must(run(datetime(2030, 3, 4, 23, 0), "ONGOING"), 409, "start the evening before")
    must(run(M10, "ONGOING"), 200, "start at the scheduled time")
    s.status = "SCHEDULED"
    must(run(M10, "COMPLETED"), 200, "complete at the scheduled time")
    s.status = "SCHEDULED"
    must(run(M10, "ONGOING", role="INSTITUTION"), 403, "only the trainer starts")
    must(run(datetime(2030, 3, 5, 9, 0), "CANCELLED", role="INSTITUTION"), 200, "either party cancels (even before the start)")
    for frm, to in (("COMPLETED", "ONGOING"), ("COMPLETED", "CANCELLED"), ("CANCELLED", "ONGOING"), ("CANCELLED", "COMPLETED"), ("ONGOING", "ONGOING")):
        s.status = frm
        must(run(M10, to), 409, f"{frm} -> {to}")
    s.status, s.attendance = "SCHEDULED", att()
    must(run(M10, "CANCELLED"), 409, "a session with attendance cannot be cancelled")
    must(run(M10, "CANCELLED", role="INSTITUTION"), 409, "...for the institution either")
    s.attendance = None
    t.status = "COMPLETED"
    must(run(M10, "ONGOING"), 409, "completed training is read-only")
    t.status = "CANCELLED"
    must(run(M10, "CANCELLED"), 409, "cancelled training is read-only")
check("set_session_status: time rules, roles, transitions, attendance blocks cancel, read-only trainings", t_status)


# ---------- 3. attendance ----------
def t_attendance():
    data = lambda total=60, present=45, absent=15: NS(total_students=total, present=present, absent=absent)
    s = sess(D, 9, 10)                        # started at 09:00, now is 10:00
    t = training(sessions=[s])
    def run(d, role="TRAINER", now=M10):
        ns = load(now)
        wire(ns, s=s, t=t, role=role)
        return status_of(lambda: ns["record_attendance"](DB(), None, 1, d)), ns
    must(run(data(), role="INSTITUTION")[0], 403, "institution is read only")
    must(run(data(), now=datetime(2030, 3, 5, 8, 59))[0], 409, "before the session starts")
    must(run(data(total=61, present=40, absent=10))[0], 422, "total above the 60 students")
    must(run(data(total=61, present=61, absent=0))[0], 422, "present above the student count")
    must(run(data(total=60, present=40, absent=21))[0], 422, "present + absent above the student count")
    s.status = "CANCELLED"
    must(run(data())[0], 409, "cancelled session")
    s.status = "SCHEDULED"
    for st in ("COMPLETED", "CANCELLED"):
        t.status = st
        must(run(data())[0], 409, f"{st} training is read-only")
    t.status = "ACTIVE"
    code, ns = run(data(60, 45, 15))
    must(code, 200, "valid")
    first = s.attendance
    assert (first.present, first.absent, first.total_students) == (45, 15, 60)
    code, ns = run(data(60, 50, 10))
    must(code, 200, "re-save")
    assert s.attendance is first and (first.present, first.absent) == (50, 10), "re-saving must update the same record"
    must(ns["session_out"](s)["attendance"]["percent"], 83, "percentage after re-save (50/60)")
    must(run(data(50, 30, 20))[0], 200, "fewer than enrolled is fine")
    must(run(data(60, 60, 0))[0], 200, "everyone present")
check("record_attendance: roles, start time, student-count cap, read-only trainings, re-save, percentage", t_attendance)


# ---------- 4. notes and planned sessions ----------
def t_notes_and_plan():
    s = sess(D, 9, 10)
    t = training(sessions=[s])
    def notes(text, role="TRAINER"):
        ns = load(M10)
        wire(ns, s=s, t=t, role=role)
        return status_of(lambda: ns["update_notes"](DB(), None, 1, text)), ns
    must(notes("Covered loops")[0], 200); must(s.notes, "Covered loops", "stored on the session")
    must(notes("  ")[0], 200); must(s.notes, None, "blank clears")
    must(notes("x", role="INSTITUTION")[0], 403, "institution cannot write notes")
    s.status = "CANCELLED"; must(notes("x")[0], 409, "cancelled session"); s.status = "SCHEDULED"
    t.status = "COMPLETED"; must(notes("x")[0], 409, "completed training"); t.status = "ACTIVE"

    t.sessions = [sess(D, 9, sid=1), sess(D, 10, sid=2), sess(D, 11, sid=3, status="CANCELLED")]
    def plan(n, role="INSTITUTION"):
        ns = load(M10)
        wire(ns, t=t, role=role)
        return status_of(lambda: ns["update_planned_sessions"](DB(), None, 1, n))
    must(plan(1), 409, "below the 2 live sessions"); must(plan(2), 200, "equal to the live sessions (cancelled not counted)")
    must(t.planned_sessions, 2); must(plan(10), 200); must(plan(5, role="TRAINER"), 403, "trainer cannot change the plan")
    t.status = "COMPLETED"; must(plan(5), 409, "completed training")
check("notes (trainer only, read-only after end) and planned sessions (floor = live sessions)", t_notes_and_plan)


# ---------- 5. completion / cancellation preserve history ----------
def t_close_out():
    def build():
        return training(sessions=[
            sess(date(2030, 3, 4), 10, attendance=att(), sid=1, title="held, attendance"),
            sess(date(2030, 3, 4), 14, sid=2, title="past, nothing recorded"),
            sess(date(2030, 3, 6), 10, sid=3, title="future"),
            sess(D, 9, status="ONGOING", sid=4, title="ongoing, no attendance"),
            sess(date(2030, 3, 3), 10, status="COMPLETED", attendance=att(), sid=5, title="already completed"),
            sess(date(2030, 3, 2), 10, status="CANCELLED", sid=6, title="already cancelled"),
            sess(D, 8, status="ONGOING", attendance=att(), sid=7, title="ongoing, attendance")])
    states = lambda t: [x.status for x in t.sessions]
    now = datetime(2030, 3, 5, 12, 0)
    t = build(); ns = load(now); wire(ns, t=t, role="INSTITUTION")
    ns["training_out"] = lambda t, role: {"status": t.status}
    PAYMENT_HOOKS.clear()
    must(status_of(lambda: ns["complete"](DB(), NS(id=1), 1)), 200, "complete")
    must(PAYMENT_HOOKS, [("completed", 1)], "complete() releases the trainer's earnings exactly once")
    must(states(t), ["COMPLETED", "SCHEDULED", "CANCELLED", "COMPLETED", "COMPLETED", "CANCELLED", "COMPLETED"], "sessions after completion")
    must((t.status, t.hiring_request.status, len(t.sessions)), ("COMPLETED", "COMPLETED", 7), "training/hiring status, nothing deleted")
    assert t.sessions[0].attendance is not None and t.sessions[6].attendance is not None, "attendance must survive completion"
    t = build(); ns = load(now); wire(ns, t=t, role="TRAINER"); ns["training_out"] = lambda t, role: {"status": t.status}
    PAYMENT_HOOKS.clear()
    must(status_of(lambda: ns["cancel"](DB(), NS(id=2), 1, "Budget")), 200, "cancel by trainer")
    must(PAYMENT_HOOKS, [("cancelled", 1)], "cancel() flags received payments exactly once")
    must(states(t), ["COMPLETED", "SCHEDULED", "CANCELLED", "CANCELLED", "COMPLETED", "CANCELLED", "COMPLETED"], "sessions after cancellation")
    must((t.status, t.cancel_reason, t.hiring_request.status), ("CANCELLED", "Budget", "CANCELLED"))
    PAYMENT_HOOKS.clear()
    for st in ("COMPLETED", "CANCELLED"):
        t = build(); t.status = st; ns = load(now); wire(ns, t=t, role="INSTITUTION")
        must(status_of(lambda: ns["complete"](DB(), NS(id=1), 1)), 409, f"complete a {st} training")
        must(status_of(lambda: ns["cancel"](DB(), NS(id=1), 1, None)), 409, f"cancel a {st} training")
    t = build(); t.start_date = date(2030, 3, 6); ns = load(now); wire(ns, t=t, role="INSTITUTION")
    must(status_of(lambda: ns["complete"](DB(), NS(id=1), 1)), 409, "complete before the training starts")
    t = build(); ns = load(now); wire(ns, t=t, role="TRAINER")
    must(status_of(lambda: ns["complete"](DB(), NS(id=1), 1)), 403, "only the institution completes")
    must(PAYMENT_HOOKS, [], "a refused complete/cancel never touches payments")
check("complete/cancel keep held sessions + attendance, cancel only what never started, final states", t_close_out)


# ---------- 6. phase, progress, list payload, calendar fields ----------
def t_phase_progress_calendar():
    ns = load(M10)
    ph = lambda **kw: ns["phase"](training(**kw))
    must(ph(start_date=date(2030, 3, 6)), "UPCOMING"); must(ph(start_date=date(2030, 3, 5), end_date=date(2030, 3, 5)), "IN_PROGRESS", "ends today")
    must(ph(start_date=date(2030, 3, 1), end_date=date(2030, 3, 4)), "ENDED"); must(ph(status="COMPLETED"), "COMPLETED"); must(ph(status="CANCELLED"), "CANCELLED")

    t = training(planned_sessions=3, sessions=[
        sess(D, 9, status="COMPLETED", attendance=att(45, 60, 15), sid=1), sess(D, 11, status="COMPLETED", attendance=att(30, 40, 10), sid=2),
        sess(D, 13, status="CANCELLED", attendance=att(1, 60, 59), sid=3)])
    listed = ns["training_out"](t, "TRAINER", with_sessions=False)
    must(listed["progress"], {"scheduled": 2, "completed": 2, "percent": 67}, "progress counts non-cancelled sessions out of the plan")
    must(listed["attendance_percent"], 75, "(45+30)/(60+40), the cancelled session is ignored")
    assert "contact" not in listed and "sessions" not in listed, "list items carry no contact details or sessions"
    full = ns["training_out"](t, "TRAINER")
    must(full["contact"]["email"], "r@x", "detail view contact is the institution's for a trainer")
    must(ns["training_out"](t, "INSTITUTION")["contact"]["email"], "a@x", "...and the trainer's for an institution")

    cal = extract("calendar_service.py", ["_ev"])
    cns = {"phase": ns["phase"], "date": date}
    exec(compile(cal, "calendar_service", "exec"), cns)
    ev = cns["_ev"]
    online = cns["_ev"]("SESSION", D, "Day 1", "Python workshop", "/trainings/1", "SCHEDULED", time(14), time(15, 30), training=training(mode="ONLINE", location="Remote", meeting_link="https://meet.example.com/a"))
    must((online["phase"], online["mode"], online["location"], online["meeting_link"], online["start_time"], online["end_time"], online["status"]),
         ("IN_PROGRESS", "ONLINE", "Remote", "https://meet.example.com/a", "14:00", "15:30", "SCHEDULED"))
    hybrid = ev("TRAINING", D, "x", training=training(mode="HYBRID", meeting_link="https://meet.example.com/h"))
    must(hybrid["meeting_link"], "https://meet.example.com/h", "hybrid keeps its link")
    offline = ev("TRAINING", D, "x", training=training(mode="OFFLINE", meeting_link="https://meet.example.com/stale"))
    must((offline["mode"], offline["meeting_link"]), ("OFFLINE", None), "an offline training never exposes a link")
    upcoming = ev("TRAINING", D, "x", training=training(start_date=date(2030, 4, 1), end_date=date(2030, 4, 5)))
    must(upcoming["phase"], "UPCOMING", "calendar shows the Phase 9 lifecycle phase")
    interview = ev("INTERVIEW", D, "Interview", "Sunrise", "/x", "INTERVIEW", time(14, 30))
    must((interview["start_time"], interview["end_time"], interview["phase"], interview["meeting_link"]), ("14:30", None, None, None), "interview has a start only")
    deadline = ev("DEADLINE", D, "Deadline")
    must((deadline["phase"], deadline["mode"], deadline["location"], deadline["meeting_link"]), (None, None, None, None), "non-training events carry no training details")
check("phase, progress/attendance maths, list payload privacy, calendar phase/mode/location/meeting link", t_phase_progress_calendar)


# ---------- 6b. meeting link rules (the https-only pattern is Pydantic's job and is not exercised here) ----------
def t_meeting_link():
    def run(mode, link, role="TRAINER", status="ACTIVE"):
        ns = load(M10)
        t = training(mode=mode, status=status)
        wire(ns, t=t, role=role)
        code = status_of(lambda: ns["update_details"](DB(), None, 1, link))
        return code, t
    must(run("OFFLINE", "https://meet.example.com/a")[0], 422, "an offline training has no meeting link")
    must(run("OFFLINE", None)[0], 200, "clearing on an offline training is harmless")
    for mode in ("ONLINE", "HYBRID"):
        code, t = run(mode, "https://meet.example.com/a")
        must((code, t.meeting_link), (200, "https://meet.example.com/a"), f"{mode} stores the link")
        must(run(mode, "https://meet.example.com/a", role="INSTITUTION")[0], 200, f"{mode}: either party may set it")
    code, t = run("ONLINE", None); must((code, t.meeting_link), (200, None), "clearing")
    for st in ("COMPLETED", "CANCELLED"):
        must(run("ONLINE", "https://meet.example.com/a", status=st)[0], 409, f"{st} training is read-only")
check("meeting link: online/hybrid only, either party, cleared with null, read-only after the end", t_meeting_link)


# ---------- 6c. interview scheduling in the application flow ----------
def t_interviews():
    tree = extract("application_service.py", ["change_status"], ("INSTITUTION_MOVES",))
    def run(status, new, interview_at=None, now=M10, existing=None):
        app = NS(id=1, status=status, interview_at=existing, trainer=NS(user_id=1), requirement=NS(title="Python workshop", status="OPEN"))
        ns = {"HTTPException": HTTPException, "now": lambda: now, "audit": lambda *a, **k: None, "notify": lambda *a, **k: None, "notify_event": lambda *a, **k: None, "notify_event_safe": lambda *a, **k: None, "notify_waiting_applicants": lambda *a, **k: None, "fmt_when": lambda d: str(d),
              "_owned_application": lambda db, user, app_id: app}
        exec(compile(tree, "application_service", "exec"), ns)
        code = status_of(lambda: ns["change_status"](DB(), None, 1, new, interview_at))
        return code, app
    later = datetime(2030, 3, 7, 14, 30)
    code, app = run("SHORTLISTED", "INTERVIEW", later)
    must((code, app.status, app.interview_at), (200, "INTERVIEW", later), "schedule from SHORTLISTED")
    must(run("APPLIED", "INTERVIEW", later)[0], 409, "cannot skip shortlisting")
    must(run("UNDER_REVIEW", "INTERVIEW", later)[0], 409, "cannot skip shortlisting from review")
    must(run("SHORTLISTED", "INTERVIEW", None)[0], 422, "an interview needs a date and time")
    must(run("SHORTLISTED", "INTERVIEW", datetime(2030, 3, 5, 9, 59))[0], 422, "not in the past")
    must(run("SHORTLISTED", "INTERVIEW", M10)[0], 200, "exactly now is allowed")
    code, app = run("INTERVIEW", "INTERVIEW", datetime(2030, 3, 8, 11, 0), existing=later)
    must((code, app.interview_at), (200, datetime(2030, 3, 8, 11, 0)), "INTERVIEW -> INTERVIEW reschedules")
    must(run("INTERVIEW", "INTERVIEW", datetime(2030, 3, 1, 11, 0), existing=later)[0], 422, "rescheduling into the past")
    code, app = run("INTERVIEW", "REJECTED", existing=later)
    must((code, app.status), (200, "REJECTED"), "reject after the interview")
    for frm in ("REJECTED", "WITHDRAWN", "SELECTED"):
        must(run(frm, "INTERVIEW", later)[0], 409, f"no interview from {frm}")
    must(run("SHORTLISTED", "REJECTED")[0], 200, "other transitions need no date")
check("interviews: need a future date/time, only after shortlisting, can be rescheduled", t_interviews)


# ---------- 6d. requirement lifecycle: OPEN -> FILLED on accept, reopen only if the training is cancelled before it starts ----------
def t_requirement_lifecycle():
    import sys, types
    from datetime import timedelta
    req_tree = extract("requirement_service.py", ["effective_status"])
    app_tree = extract("application_service.py", ["apply", "change_status", "hire", "respond"], ("INSTITUTION_MOVES", "BLOCKING_HIRES", "ACTIVE"))
    NOW = datetime(2030, 3, 5, 9, 0)

    def requirement(status="OPEN", deadline=date(2030, 3, 20)):
        return NS(id=1, status=status, application_deadline=deadline, title="Python workshop", technology="Python", mode="OFFLINE", location="Pune",
                  description="d", start_date=date(2030, 4, 1), end_date=date(2030, 4, 10), sessions=3, student_count=60, institution_id=7,
                  institution=NS(user_id=20, user=NS(is_active=True), institution_name="Sunrise"))

    def app_ns(req, hr=None):
        base = {"HTTPException": HTTPException, "select": lambda *a, **k: Chain(), "HiringRequest": type("HR", (Model,), {"defaults": {"status": "PENDING", "id": 5}}),
                "Application": Model, "TrainingRequirement": TrainingRequirement, "now": lambda: NOW, "today": lambda: NOW.date(), "_now": lambda: NOW,
                "audit": lambda *a, **k: None, "notify": lambda *a, **k: None, "notify_event": lambda *a, **k: None, "notify_event_safe": lambda *a, **k: None, "notify_waiting_applicants": lambda *a, **k: None, "fmt_when": lambda d: str(d)}
        exec(compile(req_tree, "requirement_service", "exec"), base)
        exec(compile(app_tree, "application_service", "exec"), base)
        return base

    trainer = NS(id=1, full_name="Asha", trainer_profile=NS(id=1, verification_status="VERIFIED", headline="h", skills=[1]))
    app_row = lambda req, status="SHORTLISTED": NS(id=1, status=status, interview_at=None, requirement=req, requirement_id=1, trainer_id=1,
                                                    trainer=NS(user=NS(id=10, is_active=True), user_id=10, verification_status="VERIFIED"))

    # apply(): only an OPEN (and not expired) requirement takes applications; the refusal says why
    for status, deadline, want, word in (("OPEN", date(2030, 3, 20), 200, ""), ("FILLED", date(2030, 3, 20), 409, "filled"), ("CLOSED", date(2030, 3, 20), 409, "no longer accepting"),
                                         ("OPEN", date(2030, 3, 1), 409, "no longer accepting")):
        req = requirement(status, deadline); ns = app_ns(req)
        try:
            ns["apply"](DB(got=req), trainer, 1, NS(cover_note=None, proposed_fee=None)); code, msg = 200, ""
        except HTTPException as e:
            code, msg = e.status_code, e.detail
        must(code, want, f"apply to {status} (deadline {deadline})"); assert word in msg, f"message {msg!r} should mention {word!r}"

    # change_status(): FILLED and CLOSED applications are not actionable; OPEN and EXPIRED(=OPEN past its deadline) are
    for status, deadline, want in (("OPEN", date(2030, 3, 20), 200), ("OPEN", date(2030, 3, 1), 200), ("FILLED", date(2030, 3, 20), 409), ("CLOSED", date(2030, 3, 20), 409)):
        req = requirement(status, deadline); a = app_row(req, "APPLIED"); ns = app_ns(req); ns["_owned_application"] = lambda d, u, i, a=a: a
        must(status_of(lambda: ns["change_status"](DB(), None, 1, "SHORTLISTED", None)), want, f"shortlist on a {status} requirement")

    # hire(): refused on FILLED and CLOSED, allowed on OPEN
    for status, want in (("OPEN", 200), ("FILLED", 409), ("CLOSED", 409)):
        req = requirement(status); a = app_row(req); ns = app_ns(req); ns["_owned_application"] = lambda d, u, i, a=a: a
        must(status_of(lambda: ns["hire"](DB(got=req), None, 1, NS(start_date=None, end_date=None, agreed_fee=1, terms=None))), want, f"hire on a {status} requirement")

    # respond(): accepting fills the requirement; declining does not; a second accept for a FILLED requirement is refused and cancelled
    def accept(req, accept_it=True):
        a = app_row(req); hr = NS(id=5, status="PENDING", trainer_id=1, requirement=req, requirement_id=1, application=a, trainer=a.trainer, agreed_fee=1,
                                  start_date=req.start_date, end_date=req.end_date, sessions=3, terms=None, responded_at=None)
        ns = app_ns(req); ns["_hiring_for"] = lambda d, i: hr
        fake = types.ModuleType("app.services.training_service"); fake.create_for_hiring = lambda db, h: NS(id=9)
        sys.modules["app.services.training_service"] = fake
        return status_of(lambda: ns["respond"](DB(got=req), trainer, 5, accept_it)), hr
    req = requirement(); code, hr = accept(req); must((code, req.status, hr.status), (200, "FILLED", "ACCEPTED"), "accept fills the requirement")
    req = requirement(); code, hr = accept(req, False); must((code, req.status, hr.status), (200, "OPEN", "DECLINED"), "decline leaves it open")
    req = requirement("FILLED"); code, hr = accept(req); must((code, req.status, hr.status), (409, "FILLED", "CANCELLED"), "a second accept for a FILLED requirement is refused")
    req = requirement("CLOSED"); code, hr = accept(req); must((code, req.status, hr.status), (409, "CLOSED", "CANCELLED"), "accepting for a CLOSED requirement is refused")

    # training cancel(): reopens only when the training had not started and the requirement is FILLED
    appmod = types.ModuleType("app.services.application_service"); appmod.notify_waiting_applicants = lambda *a, **k: None
    sys.modules["app.services.application_service"] = appmod       # cancel() imports it lazily when it reopens a requirement
    def cancel(status, start_date):
        req = requirement(status); ns = load(NOW); ns["training_out"] = lambda t, role: {}
        t = training(start_date=start_date, requirement_id=1, sessions=[]); wire(ns, t=t, role="TRAINER")
        return status_of(lambda: ns["cancel"](DB(got=req), NS(id=10), 1, None)), req.status
    must(cancel("FILLED", date(2030, 3, 6)), (200, "OPEN"), "cancelled before the start: reopened")
    must(cancel("FILLED", date(2030, 3, 5)), (200, "FILLED"), "cancelled on its start day (already started): not reopened")
    must(cancel("FILLED", date(2030, 3, 1)), (200, "FILLED"), "cancelled after the start: not reopened")
    must(cancel("CLOSED", date(2030, 3, 6)), (200, "CLOSED"), "a manually closed requirement is not reopened")
    must(cancel("OPEN", date(2030, 3, 6)), (200, "OPEN"), "an open requirement is left alone")
check("requirement lifecycle: apply/change_status/hire guards, accept fills, cancel before start reopens", t_requirement_lifecycle)


# ---------- 7. the overlap predicate, in SQL (equivalent statement, not the ORM one) ----------
def t_overlap_sql():
    db = sqlite3.connect(":memory:")
    db.executescript("""
    CREATE TABLE trainings (id INTEGER PRIMARY KEY, trainer_id INT, status TEXT);
    CREATE TABLE training_sessions (id INTEGER PRIMARY KEY, training_id INT, status TEXT, session_date TEXT, start_time TEXT, end_time TEXT);
    INSERT INTO trainings VALUES (1, 1, 'ACTIVE'), (2, 1, 'ACTIVE'), (3, 1, 'COMPLETED'), (4, 2, 'ACTIVE');
    INSERT INTO training_sessions VALUES (1, 1, 'SCHEDULED', '2030-03-05', '10:00:00', '12:00:00'),
                                         (2, 3, 'COMPLETED', '2030-03-06', '10:00:00', '12:00:00'),
                                         (3, 4, 'SCHEDULED', '2030-03-07', '10:00:00', '12:00:00'),
                                         (4, 2, 'CANCELLED', '2030-03-08', '10:00:00', '12:00:00');
    """)
    q = """SELECT 1 FROM training_sessions s JOIN trainings t ON t.id = s.training_id
           WHERE t.trainer_id = ? AND t.status = 'ACTIVE' AND s.status != 'CANCELLED' AND s.session_date = ? AND s.start_time < ? AND s.end_time > ? AND s.id != ?"""
    clash = lambda trainer, day, start, end, exclude=0: db.execute(q, (trainer, day, end, start, exclude)).fetchone() is not None
    assert clash(1, "2030-03-05", "11:00:00", "13:00:00"), "overlaps the end"
    assert clash(1, "2030-03-05", "09:00:00", "10:30:00"), "overlaps the start"
    assert clash(1, "2030-03-05", "10:30:00", "11:30:00"), "inside"
    assert clash(1, "2030-03-05", "09:00:00", "13:00:00"), "contains it"
    assert not clash(1, "2030-03-05", "12:00:00", "13:00:00"), "touching after is fine"
    assert not clash(1, "2030-03-05", "09:00:00", "10:00:00"), "touching before is fine"
    assert not clash(1, "2030-03-06", "10:00:00", "12:00:00"), "another day"
    assert not clash(1, "2030-03-06", "10:00:00", "12:00:00"), "a completed training does not block"
    assert not clash(1, "2030-03-08", "10:00:00", "12:00:00"), "a cancelled session does not block"
    assert not clash(1, "2030-03-07", "10:00:00", "12:00:00"), "another trainer's session does not block"
    assert not clash(1, "2030-03-05", "10:00:00", "12:00:00", exclude=1), "a session never clashes with itself when rescheduled"
check("trainer double-booking predicate (date AND time) on SQLite, equivalent SQL", t_overlap_sql)


# ---------- Phase 11: notification registry, outbox decisions and the outbox worker ----------
import importlib.util
import re as _re
import logging


def _load_registry():
    spec = importlib.util.spec_from_file_location("notification_types", SERVICES / "notification_types.py")
    mod = importlib.util.module_from_spec(spec)
    sys.modules["notification_types"] = mod          # dataclasses need the module registered
    spec.loader.exec_module(mod)
    return mod


def t_registry():
    reg = _load_registry()
    root = SERVICES.parent
    # every type renders, with exactly the fields its templates name
    import string
    for key, t in reg.TYPES.items():
        fields = {f for tpl in (t.title, t.body or "", t.link or "") for _, f, _, _ in string.Formatter().parse(tpl) if f}
        out = reg.render(key, **{f: "X" for f in fields})
        assert out["title"] and (t.link is None or out["link"].startswith("/")), key
        assert len(key) <= 30, f"{key} does not fit notifications.type / notification_deliveries.type (String(30))"
    try:
        reg.render("NOPE")
        raise AssertionError("an unknown type must be refused")
    except ValueError:
        pass
    # no dead types: every registered type is emitted somewhere outside the registry, and nothing unregistered is emitted
    src = {f: f.read_text() for f in root.rglob("*.py") if f.name != "notification_types.py" and "tests" not in f.parts}
    blob = "\n".join(src.values())
    dead = [k for k in reg.TYPES if f'"{k}"' not in blob]
    assert not dead, f"registered but never emitted: {dead}"
    emitted = set(_re.findall(r'notify(?:_event)?\([^)]*?"([A-Z_]{6,})"', blob)) | set(_re.findall(r'_tell_other\([^)]*?"([A-Z_]{6,})"', blob))
    assert emitted <= set(reg.TYPES), f"emitted but unregistered: {emitted - set(reg.TYPES)}"
    # email eligibility is exactly the documented set
    assert {k for k, t in reg.TYPES.items() if t.email} == {"APPLICATION_SHORTLISTED", "INTERVIEW_SCHEDULED", "INTERVIEW_UPDATED", "INTERVIEW_REMINDER",
        "HIRING_REQUEST", "HIRING_ACCEPTED", "TRAINING_CREATED", "TRAINING_DATES_CHANGED", "TRAINING_CANCELLED", "SESSION_REMINDER", "REVIEW_REQUEST", "REVIEW_REMINDER",
        "PAYMENT_SUCCEEDED", "PAYMENT_RECEIVED", "PAYMENT_REFUNDED", "PAYOUT_RECORDED"}, "email set"
    # Phase 13 registers exactly these payment types (the Phase 11 assertion that none may exist is replaced). Chat is still out of scope.
    assert not [t for t in reg.TYPES if "CHAT" in t], "chat notifications are out of scope"
    pay = {"PAYMENT_SUCCEEDED", "PAYMENT_FAILED", "PAYMENT_RECEIVED", "PAYMENT_REFUNDED", "EARNING_AVAILABLE", "PAYOUT_RECORDED", "PAYMENT_NEEDS_REVIEW"}
    assert pay <= set(reg.TYPES), f"payment notification types missing: {pay - set(reg.TYPES)}"
    assert not [k for k in pay if reg.TYPES[k].mandatory], "payment notifications can be switched off like the others"
    for k in pay:   # no card/bank/UPI wording and no placeholders that could carry such details
        text = " ".join([reg.TYPES[k].title, reg.TYPES[k].body or ""]).lower()
        assert not any(w in text for w in ("card", "cvv", "upi", "account number", "ifsc")), k
    # the interview message carries date AND time; the link message never carries the link itself
    assert "14:30" in reg.render("INTERVIEW_SCHEDULED", requirement="R", when="Mon 05 Jan 2099, 14:30")["body"]
    assert "http" not in reg.render("TRAINING_LINK_CHANGED", title="T", action="updated", training_id=1)["body"] if reg.render("TRAINING_LINK_CHANGED", title="T", action="updated", training_id=1)["body"] else True
    # every deep link points at a route the React app really has
    routes = _re.findall(r'path="([^"]+)"', (root.parent.parent / "frontend/src/App.jsx").read_text())
    pats = [_re.compile("^" + _re.sub(r":\w+", r"[^/]+", r) + "$") for r in routes if r != "*"]
    for key, t in reg.TYPES.items():
        if t.link:
            sample = _re.sub(r"\{\w+\}", "7", t.link)
            assert any(p.match(sample) for p in pats), f"{key}: {t.link} is not a frontend route"
check("notification registry: renders, no dead or unregistered types, email set, deep links match React routes", t_registry)


def _delivery_ns(now, rows, users, prefs, provider, settings=None):
    class D(Model):
        defaults = {}
    cfg = NS(notification_max_attempts=3, notification_retry_base_seconds=60, frontend_url="http://localhost:5173", email_provider="console")
    logrec = []
    ns = {"datetime": datetime, "timedelta": __import__("datetime").timedelta, "timezone": timezone, "select": lambda *a, **k: Chain(), "NotificationDelivery": D,
          "User": type("User", (), {}), "settings": cfg, "notification_preferences": NS(get=lambda db, uid: prefs[uid]), "get_email_provider": lambda: provider,
          "redact": lambda t: _re.sub(r"[\w.+-]+@[\w-]+\.[\w.-]+", "[email]", t or ""), "log": logging.getLogger("t"), "Session": object, "_now": lambda: now}
    exec(compile(extract("delivery_service.py", ["skip_reason", "retry_state", "message_body", "process_pending"]), "delivery_service", "exec"), ns)
    return ns


def t_outbox():
    from datetime import timedelta
    now = datetime(2030, 1, 1, 12, 0, tzinfo=timezone.utc)
    mk = lambda i, uid, **k: NS(id=i, user_id=uid, status="PENDING", attempts=0, next_attempt_at=now, last_error=None, sent_at=None, title="T", body="b", link="/trainings/1", **k)
    sent = []

    class Provider:
        def __init__(self): self.fail_for = set()
        def send(self, to, subject, body, *, idempotency_key):
            if to in self.fail_for:
                raise RuntimeError(f"smtp refused {to}")
            sent.append((to, idempotency_key, body))
    prov = Provider(); prov.fail_for = {"bad@x.io"}
    users = {1: NS(is_active=True, email="ok@x.io", email_verified=True), 2: NS(is_active=True, email="ok2@x.io", email_verified=False),
             3: NS(is_active=False, email="gone@x.io", email_verified=True), 4: NS(is_active=True, email="bad@x.io", email_verified=True),
             5: NS(is_active=True, email="off@x.io", email_verified=True), 6: NS(is_active=True, email=None, email_verified=True)}
    prefs = {u: {"in_app": True, "email": True} for u in users}; prefs[5]["email"] = False
    rows = [mk(i, i) for i in range(1, 7)]
    ns = _delivery_ns(now, rows, users, prefs, prov)
    db = DB(rows=rows, users=users, now=now)
    run = lambda at: (setattr(db, "now", at), ns["process_pending"](db, now=at))[1]      # the double's query uses the clock the worker was given
    counts = run(now)
    st = {r.id: r.status for r in rows}
    must(st, {1: "SENT", 2: "SKIPPED", 3: "SKIPPED", 4: "PENDING", 5: "SKIPPED", 6: "SKIPPED"}, "statuses after the first run")
    must(counts, {"sent": 1, "skipped": 4, "retry": 1, "failed": 0}, "counts")
    assert "not verified" in rows[1].last_error and "not active" in rows[2].last_error and "switched off" in rows[4].last_error and "no email" in rows[5].last_error
    assert "bad@x.io" not in rows[3].last_error and "[email]" in rows[3].last_error, "stored errors never echo the recipient address"
    assert rows[3].attempts == 1 and rows[3].next_attempt_at == now + timedelta(seconds=60), "first retry after the base delay"
    assert [x[0] for x in sent] == ["ok@x.io"] and sent[0][1] == "delivery-1" and "http://localhost:5173/trainings/1" in sent[0][2]
    assert db.commits == 1
    # idempotent: running again at the same time sends nothing more, and the retry is not due yet
    must(run(now), {"sent": 0, "skipped": 0, "retry": 0, "failed": 0}, "second run")
    assert len(sent) == 1
    # backoff doubles, then the row gives up at the configured maximum, and a failure never raises out of the worker
    t2 = now + timedelta(seconds=61); c2 = run(t2)
    must((c2["retry"], rows[3].attempts, rows[3].next_attempt_at), (1, 2, t2 + timedelta(seconds=120)), "second attempt")
    t3 = t2 + timedelta(seconds=121); c3 = run(t3)
    must((c3["failed"], rows[3].status, rows[3].attempts), (1, "FAILED", 3), "gives up after max attempts")
    must(run(t3 + timedelta(days=1)), {"sent": 0, "skipped": 0, "retry": 0, "failed": 0}, "FAILED rows are not picked again")
    # recovery: a provider that starts working delivers the retry once
    prov.fail_for = set(); r = mk(9, 4); rows.append(r)
    must(run(t3)["sent"], 1, "recovered delivery")
    must(run(t3)["sent"], 0, "and not twice")
check("outbox worker: send, skip (inactive / unverified / switched off / no address), retry with backoff, give up, idempotent, no address in stored errors", t_outbox)


def t_provider_privacy():
    import io
    spec = importlib.util.spec_from_file_location("channels_probe", SERVICES / "channels.py")
    src = (SERVICES / "channels.py").read_text()
    tree = ast.parse(src)
    calls = [ast.unparse(n) for n in ast.walk(tree) if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute) and n.func.attr in ("info", "debug", "warning", "error")]
    assert calls, "the console provider logs something"
    assert all("to" not in [a.id for c in ast.walk(n) for a in ([c] if isinstance(c, ast.Name) else [])] for n in ast.walk(tree) if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute) and n.func.attr in ("info", "debug", "warning", "error")), "no log call may mention the recipient"
    assert "RuntimeError" in src and "'console'" in src, "an unimplemented provider is refused, never silently faked"
    assert "NOT SENT" in src, "the console provider says it sends nothing"
check("console provider: logs no recipient, says NOT SENT, refuses unknown providers", t_provider_privacy)


def t_dispatch_dedupe_and_preferences():
    reg = _load_registry()
    sent_to_provider = []
    outbox, handled = [], set()

    class Notification(Model):
        defaults = {"created_at": None, "is_read": False}
    db = DB()
    prefs = {}
    ns = {"datetime": datetime, "timezone": timezone, "event": NS(listens_for=lambda *a, **k: (lambda f: f)), "TYPES": reg.TYPES, "render": reg.render,
          "Notification": Notification, "notification_preferences": NS(get=lambda d, uid: prefs.get(uid, {"in_app": True, "email": True})),
          "delivery_service": NS(enqueue=lambda d, uid, ch, ty, ti, bo, li, key: outbox.append((uid, ch, ty, key))),
          "_handled": lambda d, uid, key: (uid, key) in handled}
    exec(compile(extract("notification_service.py", ["_dispatch", "notify", "notify_event", "serialize"]), "notification_service", "exec"), ns)

    def fire(uid, type_, key=None, **ctx):
        ctx = {"requirement": "R", "requirement_id": 1, "trainer": "T", "when": "Mon 05 Jan 2099, 14:30", **ctx}
        made = ns["notify_event"](db, uid, type_, dedupe_key=key, **ctx)
        if key and made:
            handled.add((uid, key))
        return made

    n0 = len(db.added)
    assert fire(1, "INTERVIEW_SCHEDULED") and len(db.added) == n0 + 1 and outbox == [(1, "email", "INTERVIEW_SCHEDULED", None)], "in-app row plus one email in the outbox"
    assert db.info["pending_push"][0][0] == 1 and "email" not in str(db.info["pending_push"]).lower(), "push is only queued for after the commit, with no address in it"
    o = len(outbox)
    assert fire(1, "APPLICATION_RECEIVED") and len(outbox) == o, "a type that is not email-eligible never reaches the outbox"
    # deduplication: the same key never creates a second row for that user, but another user still gets theirs
    before = (len(db.added), len(outbox))
    assert fire(2, "INTERVIEW_REMINDER", key="k1") and not fire(2, "INTERVIEW_REMINDER", key="k1") and fire(3, "INTERVIEW_REMINDER", key="k1")
    assert (len(db.added), len(outbox)) == (before[0] + 2, before[1] + 2), "two recipients, one row each, no duplicates"
    # preferences
    prefs[4] = {"in_app": False, "email": True}
    a, o = len(db.added), len(outbox)
    assert fire(4, "INTERVIEW_SCHEDULED") and len(db.added) == a and len(outbox) == o + 1, "in-app off: no row, the email is still queued"
    assert not fire(4, "APPLICATION_RECEIVED") and len(db.added) == a, "in-app off and not email-eligible: nothing at all"
    prefs[5] = {"in_app": True, "email": False}
    a, o = len(db.added), len(outbox)
    assert fire(5, "INTERVIEW_SCHEDULED") and len(db.added) == a + 1 and len(outbox) == o, "email off: in-app only"
    prefs[6] = {"in_app": False, "email": False}
    assert not fire(6, "INTERVIEW_SCHEDULED"), "everything off: nothing"
    # a mandatory type ignores the in-app switch
    reg.TYPES["SECURITY_TEST"] = reg.NotificationType("SECURITY_TEST", "Security alert", None, None, False, True)
    a = len(db.added)
    assert fire(6, "SECURITY_TEST") and len(db.added) == a + 1, "mandatory types cannot be muted"
    del reg.TYPES["SECURITY_TEST"]
    try:
        fire(1, "MADE_UP_TYPE")
        raise AssertionError("an unregistered type must be refused")
    except ValueError:
        pass
check("notify_event: in-app row + outbox row, preferences, mandatory types, per-user dedupe, push queued not sent, unknown type refused", t_dispatch_dedupe_and_preferences)


def t_business_code_never_calls_a_provider():
    """A failing provider cannot roll back a business transaction because no request path ever calls it: the request only inserts an
    outbox row; get_email_provider() / provider.send() exist only in the worker module and the provider module."""
    root = SERVICES.parent
    offenders = []
    for f in root.rglob("*.py"):
        rel = f.relative_to(root).as_posix()
        if rel in ("services/channels.py", "services/delivery_service.py"):
            continue
        t = f.read_text()
        if "get_email_provider" in t or ".send(" in t.replace("ws.send", "").replace("send_json", "") or "ConsoleEmailProvider" in t:
            offenders.append(rel)
    assert not offenders, f"these modules reach a provider directly: {offenders}"
    callers = [f.relative_to(root).as_posix() for f in root.rglob("*.py") if "process_pending" in f.read_text() and f.name != "delivery_service.py"]
    assert sorted(callers) == ["workers/loop.py", "workers/outbox.py"], f"process_pending may only run from the workers, found {callers}"
    ns_src = (SERVICES / "notification_service.py").read_text()
    assert "commit()" not in ast.unparse(next(n for n in ast.parse(ns_src).body if isinstance(n, ast.FunctionDef) and n.name == "_dispatch")), "creating a notification never commits for its caller"
check("delivery isolation: only workers reach a provider, so a failing provider cannot affect a request transaction", t_business_code_never_calls_a_provider)


def t_interview_reminders():
    from datetime import timedelta
    now = datetime(2030, 3, 4, 9, 0)
    cfg = NS(interview_reminder_hours=24)
    seen, created = set(), []

    def notify_event(db, uid, type_, link=None, dedupe_key=None, **ctx):          # mirrors the per-user dedupe of the real service
        if dedupe_key and (uid, dedupe_key) in seen:
            return False
        seen.add((uid, dedupe_key)); created.append((uid, type_, dedupe_key, link, ctx)); return True
    mk = lambda aid, at: NS(id=aid, requirement_id=7, interview_at=at, trainer=NS(user_id=10), requirement=NS(title="Python trainer", institution=NS(user_id=20)))
    apps = [mk(1, datetime(2030, 3, 4, 14, 30))]
    ns = {"datetime": datetime, "timedelta": timedelta, "select": lambda *a, **k: Chain(), "Application": type("A", (), {"status": Col(), "interview_at": Col()}),
          "settings": cfg, "local_now": lambda: now, "notify_event": notify_event, "fmt_when": lambda d: f"{d:%a %d %b %Y, %H:%M}"}
    db = DB(); db.scalars = lambda stmt: list(apps)
    exec(compile(extract("reminders.py", ["_interviews"], base=SERVICES.parent / "workers"), "reminders", "exec"), ns)
    assert ns["_interviews"](db, now) == 2, "one reminder for the trainer and one for the institution"
    kinds = {(uid, link) for uid, _, _, link, _ in created}
    assert kinds == {(10, "/trainer/applications"), (20, "/institution/requirements/7/applications")}
    assert all("14:30" in c[4]["when"] for c in created), "the reminder carries the interview time"
    assert ns["_interviews"](db, now) == 0 and ns["_interviews"](db, now + timedelta(minutes=15)) == 0, "re-running (cron every 15 minutes) never duplicates"
    apps[0] = mk(1, datetime(2030, 3, 4, 16, 0))
    assert ns["_interviews"](db, now) == 2, "a rescheduled interview earns a fresh reminder"
check("interview reminders: both parties, time included, idempotent across runs, new reminder after a reschedule", t_interview_reminders)


def t_websocket_manager():
    import asyncio
    spec = importlib.util.spec_from_file_location("realtime_probe", SERVICES / "realtime.py")
    rt = importlib.util.module_from_spec(spec); spec.loader.exec_module(rt)

    async def scenario():
        m = rt.ConnectionManager()
        qs = [await m.connect(1) for _ in range(rt.MAX_CONNECTIONS_PER_USER)]
        assert all(q is not None for q in qs) and await m.connect(1) is None, "the sixth connection is refused (per-user limit)"
        assert await m.connect(2) is not None, "the limit is per user"
        m.push(1, {"id": 1}); await asyncio.sleep(0.05)
        assert all(q.get_nowait() == {"id": 1} for q in qs), "a push reaches every open connection of that user"
        m.push(3, {"id": 2}); await asyncio.sleep(0.05)                                  # nobody connected: silently dropped
        for i in range(150):
            m.push(1, {"n": i})
        await asyncio.sleep(0.1)
        assert qs[0].qsize() == 100, "a stalled client's queue is bounded"
        m.disconnect_user(1); await asyncio.sleep(0.1)
        last = [list(q._queue)[-1] for q in qs]
        assert all(x is rt.CLOSE for x in last), "the close signal gets through even a full queue"
        m.disconnect(1, qs[0]); assert m.connection_count(1) == 4
        assert await m.connect(1) is not None, "a freed slot can be reused"
    asyncio.run(scenario())
check("WebSocket manager (real module, asyncio): per-user limit, fan-out, bounded queue, forced close of a deactivated user's sockets", t_websocket_manager)


# ---------- Phase 12: reviews and ratings ----------
from decimal import ROUND_HALF_UP, Decimal


class IntegrityError(Exception):
    pass


class Review(Model):
    defaults = {"id": 77}


def _review_ns(**extra):
    reg = _load_registry()
    ns = {"HTTPException": HTTPException, "Decimal": Decimal, "ROUND_HALF_UP": ROUND_HALF_UP, "select": lambda *a, **k: Chain(), "Review": Review, "Training": Training,
          "IntegrityError": IntegrityError, "COMMENT_MAX_LENGTH": 2000, "audit": lambda *a, **k: None, "func": NS(count=lambda: Col(), avg=lambda x: Col()), "exists": lambda *a, **k: Chain(),
          "InstitutionProfile": type("IP", (), {}), "TrainerProfile": type("TP", (), {}), "User": type("U", (), {}), "ReviewIn": object}
    ns.update(extra)
    exec(compile(extract("review_service.py", ["round_rating", "_profile_of", "cannot_review", "_direction", "_eligibility", "_clean_payload", "submit",
                                              "trainer_ids_rated_at_least"], ("TRAINER_DIR", "INSTITUTION_DIR", "CATEGORIES", "MIN_REVIEWS_FOR_RATING_FILTER", "REASON_TEXT")), "review_service", "exec"), ns)
    return ns


def t_review_rounding_and_filter_rule():
    ns = _review_ns()
    r = ns["round_rating"]
    must([r(4.25), r(4.24), r(4.2499999999), r(3.9667), r(4.35), r(1.0), r(5.0), r(2.05)], [4.3, 4.2, 4.3, 4.0, 4.4, 1.0, 5.0, 2.1], "half-up rounding")
    must(ns["MIN_REVIEWS_FOR_RATING_FILTER"], 2, "the approved threshold")
    db = DB(); db.exec_rows = [(1, 3.9667), (2, 4.25), (3, 4.2), (4, 4.04)]          # what the SQL (>= 2 reviews, avg >= min - margin) would hand over
    must(ns["trainer_ids_rated_at_least"](db, 4.0), [1, 2, 3, 4], "displayed 4.0 passes the 4.0 filter")
    must(ns["trainer_ids_rated_at_least"](db, 4.3), [2], "4.25 is displayed as 4.3, 4.2 is not")
    must(ns["trainer_ids_rated_at_least"](db, 4.5), [], "nobody reaches 4.5")
    src = (SERVICES / "review_service.py").read_text()
    assert "func.count() >= MIN_REVIEWS_FOR_RATING_FILTER" in src and "min_rating - 0.0501" in src, "the SQL narrows with the threshold and a rounding margin"
    fe = (SERVICES.parent.parent.parent / "frontend/src/utils/reviews.js").read_text()
    assert "MIN_REVIEWS_FOR_FILTER = 2" in fe, "the UI text uses the same threshold"
check("review rating rules: half-up rounding, filter uses the displayed value, two-review threshold (same number in API and UI)", t_review_rounding_and_filter_rule)


def t_review_submit_rules():
    from datetime import timedelta
    notified, audits = [], []
    ns = _review_ns(audit=lambda *a, **k: audits.append(k), notify_event_safe=lambda db, uid, type_, **k: notified.append((uid, type_, k)) or True,
                    review_out=lambda r, db: {"id": r.id, "overall": r.overall, "comment": r.comment})
    inst = NS(id=5, verification_status="VERIFIED"); trn = NS(id=1, verification_status="VERIFIED")
    iu = NS(id=20, role="INSTITUTION", is_active=True, institution_profile=inst, trainer_profile=None)
    tu = NS(id=10, role="TRAINER", is_active=True, trainer_profile=trn, institution_profile=None)
    mk = lambda **k: training(institution_id=5, trainer_id=1, **k)
    good_t = {"technical_knowledge": 5, "teaching_quality": 4, "communication": 5, "punctuality": 4, "professionalism": 5}
    good_i = {"communication": 4, "professionalism": 5, "coordination": 3}
    run = lambda user, t, ratings, comment=None, db=None: ns["submit"]((db or DB(got=t)), user, 1, NS(ratings=ratings, comment=comment))
    st = lambda *a, **k: status_of(lambda: run(*a, **k))

    must(st(iu, mk(status="ACTIVE"), good_t), 409, "active"); must(st(iu, mk(status="CANCELLED"), good_t), 409, "cancelled")
    for status, word in (("ACTIVE", "in progress"), ("CANCELLED", "cancelled")):
        try: run(iu, mk(status=status), good_t)
        except HTTPException as e: assert word in e.detail, e.detail
    stranger = NS(id=30, role="TRAINER", is_active=True, trainer_profile=NS(id=99, verification_status="VERIFIED"), institution_profile=None)
    must(st(stranger, mk(status="COMPLETED"), good_t), 404, "unrelated trainer")
    must(st(NS(id=31, role="ADMIN", is_active=True, trainer_profile=None, institution_profile=None), mk(status="COMPLETED"), good_t), 404, "admin has no side")
    must(st(NS(**{**tu.__dict__, "trainer_profile": NS(id=1, verification_status="SUSPENDED")}), mk(status="COMPLETED"), good_i), 403, "suspended trainer")
    must(st(NS(**{**iu.__dict__, "is_active": False}), mk(status="COMPLETED"), good_t), 403, "inactive institution")
    # payload rules
    bad = lambda **ch: st(iu, mk(status="COMPLETED"), {**good_t, **ch})
    for v in (True, False, 4.0, 4.5, "4", None, 0, 6, -1):
        must(bad(punctuality=v), 422, f"rating {v!r}")
    must(st(iu, mk(status="COMPLETED"), {**good_t, "coordination": 3}), 422, "extra category"); must(st(iu, mk(status="COMPLETED"), {}), 422, "no categories")
    must(st(iu, mk(status="COMPLETED"), good_i), 422, "the other direction's categories"); must(st(tu, mk(status="COMPLETED"), good_t), 422, "trainer with trainer categories")
    for c in ("", "   ", "\n\t"):
        must(st(iu, mk(status="COMPLETED"), good_t, c), 422, f"blank comment {c!r}")
    must(st(iu, mk(status="COMPLETED"), good_t, "x" * 2001), 422, "2001 characters")
    must(st(iu, mk(status="COMPLETED"), good_t, "  " + "x" * 2000 + "  "), 200, "2000 characters after trimming")
    # duplicate: service check and the constraint's IntegrityError
    must(st(iu, mk(status="COMPLETED"), good_t, db=DB(got=mk(status="COMPLETED"), overlap=1)), 409, "already reviewed")
    racing = DB(got=mk(status="COMPLETED")); racing.flush_error = IntegrityError("uq_review_per_engagement")
    must(st(iu, mk(status="COMPLETED"), good_t, db=racing), 409, "concurrent duplicate caught by the constraint"); assert racing.rolled_back and racing.commits == 0
    # success: stored values, rounding, notification target and dedupe key, one commit
    notified.clear(); audits.clear()
    db = DB(got=mk(status="COMPLETED")); out = run(iu, mk(status="COMPLETED"), good_t, "  Great  ", db=db)
    r = db.added[0]
    must((r.overall, r.comment, r.direction, r.reviewer_user_id, db.commits), (4.6, "Great", "INSTITUTION_TO_TRAINER", 20, 1), "stored review")
    must((notified[0][0], notified[0][1], notified[0][2]["dedupe_key"]), (10, "REVIEW_RECEIVED", "review-received:77"), "trainer is told, with a dedupe key")
    db = DB(got=mk(status="COMPLETED")); notified.clear(); run(tu, mk(status="COMPLETED"), good_i, db=db)
    must((db.added[0].overall, db.added[0].direction, notified[0][0]), (4.0, "TRAINER_TO_INSTITUTION", 20), "trainer reviews the institution, institution is told")
    # a body that names a reviewer or direction is simply ignored: identity comes from the token
    assert db.added[0].reviewer_user_id == 10
check("review submit rules: eligibility, 403/404/409/422 cases, booleans and floats, comments, duplicates, rounding, dedupe key, single commit", t_review_submit_rules)


def t_review_pending_sql():
    db = sqlite3.connect(":memory:")
    db.executescript("""
    CREATE TABLE trainings (id INTEGER PRIMARY KEY, trainer_id INT, institution_id INT, status TEXT, title TEXT, completed_at TEXT);
    CREATE TABLE reviews (id INTEGER PRIMARY KEY, training_id INT, direction TEXT);
    INSERT INTO trainings VALUES (1,1,5,'COMPLETED','A','2030-01-03'),(2,1,5,'COMPLETED','B','2030-01-05'),(3,1,5,'CANCELLED','C',NULL),(4,1,5,'ACTIVE','D',NULL),(5,2,5,'COMPLETED','E','2030-01-06');
    INSERT INTO reviews VALUES (1,1,'INSTITUTION_TO_TRAINER'),(2,2,'TRAINER_TO_INSTITUTION');
    """)
    q = """SELECT id FROM trainings t WHERE {owner} = ? AND status = 'COMPLETED'
           AND NOT EXISTS (SELECT 1 FROM reviews r WHERE r.training_id = t.id AND r.direction = ?) ORDER BY completed_at DESC"""
    inst = [r[0] for r in db.execute(q.format(owner="institution_id"), (5, "INSTITUTION_TO_TRAINER"))]
    trn = [r[0] for r in db.execute(q.format(owner="trainer_id"), (1, "TRAINER_TO_INSTITUTION"))]
    must((inst, trn), ([5, 2], [1]), "pending = completed trainings without a review written by this side; cancelled and active never count")
    src = (SERVICES / "review_service.py").read_text()
    assert 'Training.status == "COMPLETED"' in src and "~exists().where(Review.training_id == Training.id, Review.direction == mine)" in src, "the real query has the same shape"
check("pending reviews: equivalent SQL on SQLite (completed only, per direction, newest first) and the real query's shape", t_review_pending_sql)


def t_review_reminder_logic():
    from datetime import timedelta
    now = datetime(2030, 3, 10, 12, 0, tzinfo=timezone.utc)
    seen, created = set(), []

    def notify_event(db, uid, type_, link=None, dedupe_key=None, **ctx):
        if dedupe_key and (uid, dedupe_key) in seen:
            return False
        seen.add((uid, dedupe_key)); created.append((uid, type_, dedupe_key, ctx)); return True
    prof = lambda uid, status="VERIFIED", active=True: NS(user_id=uid, verification_status=status, user=NS(is_active=active, role="X", trainer_profile=None, institution_profile=None))
    t1 = NS(id=1, title="Python", trainer=prof(10), institution=prof(20))
    t2 = NS(id=2, title="Java", trainer=prof(11, "SUSPENDED"), institution=prof(21))
    t3 = NS(id=3, title="Go", trainer=prof(12), institution=prof(22, active=False))
    cfg = NS(review_reminder_days=3, review_reminder_window_days=14)
    reviewed = {(1, "INSTITUTION_TO_TRAINER")}                                    # in training 1 the institution has already reviewed
    db = DB(); db.exec_rows = list(reviewed); db.scalars = lambda stmt: [t1, t2, t3]
    ns = {"datetime": datetime, "timedelta": timedelta, "timezone": timezone, "select": lambda *a, **k: Chain(), "Training": Training, "Review": Review, "settings": cfg,
          "notify_event": notify_event, "INSTITUTION_DIR": "TRAINER_TO_INSTITUTION", "TRAINER_DIR": "INSTITUTION_TO_TRAINER",
          "cannot_review": lambda u: (not u.is_active)}
    exec(compile(extract("reminders.py", ["_reviews"], base=SERVICES.parent / "workers"), "reminders", "exec"), ns)
    # the worker passes profile.user to cannot_review; model the real rule (inactive user or SUSPENDED profile) on the profile objects
    real = {id(p.user): p for t in (t1, t2, t3) for p in (t.trainer, t.institution)}
    ns["cannot_review"] = lambda user: (not user.is_active) or real[id(user)].verification_status == "SUSPENDED"
    n = ns["_reviews"](db, now)
    got = sorted((uid, key) for uid, _, key, _ in created)
    must(got, [(10, "review-reminder:1:10"), (12, "review-reminder:3:12"), (21, "review-reminder:2:21")],
         "trainer of 1 (institution already reviewed), trainer of 3 (institution inactive), institution of 2 (trainer suspended)")
    must(n, 3, "count"); assert all(c[1] == "REVIEW_REMINDER" for c in created)
    must(ns["_reviews"](db, now), 0, "a second worker run creates nothing")
    must(ns["_reviews"](db, now + timedelta(days=1)), 0, "nor does a later run")
    src = (SERVICES.parent / "workers/reminders.py").read_text()
    assert "Training.completed_at <= due" in src and "Training.completed_at >= oldest" in src and 'Training.status == "COMPLETED"' in src, "SQL selects completed trainings 3 to 14 days old"
check("review reminder: one per participant who has not reviewed and may review, idempotent across runs, 3-to-14-day window in the query", t_review_reminder_logic)


def t_notify_event_safe():
    """AST-extracted notify_event_safe against a session double. This checks the control flow only (SAVEPOINT used, failure contained and logged,
    push queue truncated); the SQL behaviour of a real SAVEPOINT is covered by the PostgreSQL / pytest tests, which cannot run here."""
    reg = _load_registry(); calls = []

    class Savepoint:
        def __init__(self, db): self.db = db
        def __enter__(self): self.db.events.append("savepoint"); return self
        def __exit__(self, et, ev, tb):
            self.db.events.append("rollback-to-savepoint" if et else "release-savepoint")
            return False  # never swallows: the function under test must catch

    class FakeDB:
        def __init__(self, fail_flush=False): self.events, self.info, self.fail_flush = [], {}, fail_flush
        def flush(self):
            self.events.append("flush")
            if self.fail_flush: raise RuntimeError("caller's own flush failed")
        def begin_nested(self): return Savepoint(self)

    class Boom(Exception): pass
    mode = {"fail": False}

    def dispatch(db, uid, type_, title, body, link, key):
        calls.append((uid, type_, title, key))
        db.info.setdefault("pending_push", []).append((uid, {"title": title}))
        if mode["fail"]: raise Boom("persistence failed after the push was queued")
        return (None, True)

    records = []
    class H(logging.Handler):
        def emit(self, r): records.append(r)
    lg = logging.getLogger("t_notify"); lg.addHandler(H()); lg.setLevel(logging.DEBUG); lg.propagate = False
    ns = {"log": lg, "render": reg.render, "_dispatch": dispatch}
    exec(compile(extract("notification_service.py", ["notify_event_safe"]), "notification_service", "exec"), ns)
    f = ns["notify_event_safe"]

    db = FakeDB(); db.info["pending_push"] = [(9, {"title": "earlier"})]
    assert f(db, 1, "REVIEW_RECEIVED", dedupe_key="review-received:5", training_id=2, title="T", score=4.6) is True and calls[0][3] == "review-received:5"
    assert db.events == ["flush", "savepoint", "release-savepoint"], db.events
    assert len(db.info["pending_push"]) == 2, "a successful notification queues its push"
    n = len(calls)
    assert f(FakeDB(), 1, "REVIEW_RECEIVED", training_id=2) is False, "a missing template field is skipped, not raised"
    assert f(FakeDB(), 1, "NO_SUCH_TYPE") is False and len(calls) == n, "an unregistered type is skipped, not raised"
    assert len(records) == 2 and all(r.levelno == logging.ERROR and r.exc_info for r in records), "failures are logged with a traceback"

    # a failure INSIDE the dispatch (persistence or anything else): contained, rolled back to the savepoint, push dropped, logged, False returned
    mode["fail"] = True
    db = FakeDB(); db.info["pending_push"] = [(9, {"title": "earlier"})]
    assert f(db, 1, "PAYMENT_SUCCEEDED", dedupe_key="payment-succeeded:1:1", amount="Rs 100.00", title="T", training_id=2) is False
    assert db.events == ["flush", "savepoint", "rollback-to-savepoint"], db.events
    assert db.info["pending_push"] == [(9, {"title": "earlier"})], "the push of the failed notification is removed, earlier ones are kept"
    assert len(records) == 3 and records[-1].exc_info[0] is Boom and "nothing was delivered" in records[-1].getMessage()
    # no push queue at all
    db = FakeDB(); db.info = {}
    assert f(db, 1, "PAYMENT_SUCCEEDED", amount="Rs 100.00", title="T", training_id=2) is False
    # the caller's own pending work failing to flush is NOT swallowed (the notification must not hide a broken financial change)
    mode["fail"] = False
    try:
        f(FakeDB(fail_flush=True), 1, "PAYMENT_SUCCEEDED", amount="Rs 100.00", title="T", training_id=2)
        raise AssertionError("a failing flush of the caller's changes must propagate")
    except RuntimeError as e:
        assert "own flush" in str(e)
    # KeyboardInterrupt is not an Exception and must propagate
    def interrupt(*a): raise KeyboardInterrupt
    ns["_dispatch"] = interrupt
    try:
        f(FakeDB(), 1, "PAYMENT_SUCCEEDED", amount="Rs 100.00", title="T", training_id=2)
        raise AssertionError("KeyboardInterrupt must propagate")
    except KeyboardInterrupt:
        pass
check("notify_event_safe: SAVEPOINT-isolated, failures contained and logged, push dropped, caller's own flush errors propagate", t_notify_event_safe)


def t_push_listeners_ignore_savepoints():
    """The real-time push is sent only when the OUTERMOST transaction commits. Releasing or rolling back the SAVEPOINT of notify_event_safe must neither
    send pushes early nor throw away the pushes of earlier notifications. (AST-extracted listeners against a session double; SQLAlchemy's own event
    dispatch for SAVEPOINTs is NOT exercised here: that needs the pytest suite.)"""
    pushed = []
    ns = {"event": NS(listens_for=lambda *a, **k: (lambda fn: fn)), "Session": object, "manager": NS(push=lambda uid, payload: pushed.append((uid, payload)))}
    exec(compile(extract("notification_service.py", ["_push_after_commit", "_drop_on_rollback"]), "notification_service", "exec"), ns)

    class Sess:
        def __init__(self, nested): self.info, self.nested = {"pending_push": [(1, "a"), (2, "b")]}, nested
        def in_nested_transaction(self): return self.nested
    s = Sess(nested=True); ns["_push_after_commit"](s)
    assert pushed == [] and len(s.info["pending_push"]) == 2, "a SAVEPOINT release sends nothing and keeps the queue"
    ns["_drop_on_rollback"](s)
    assert len(s.info["pending_push"]) == 2, "a SAVEPOINT rollback keeps the earlier notifications' pushes"
    s = Sess(nested=False); ns["_push_after_commit"](s)
    assert pushed == [(1, "a"), (2, "b")] and "pending_push" not in s.info, "the outermost commit sends everything once"
    s = Sess(nested=False); ns["_drop_on_rollback"](s)
    assert "pending_push" not in s.info and pushed == [(1, "a"), (2, "b")], "the outermost rollback sends nothing and clears the queue"
check("real-time push: sent only after the outermost commit; SAVEPOINT release/rollback neither sends nor clears", t_push_listeners_ignore_savepoints)


if __name__ == "__main__":
    for name, ok, msg in RESULTS:
        print(("PASS " if ok else "FAIL ") + name + ("" if ok else f"\n     -> {msg}"))
    failed = sum(not ok for _, ok, _ in RESULTS)
    print(f"\n{len(RESULTS) - failed} passed, {failed} failed")
    sys.exit(1 if failed else 0)
