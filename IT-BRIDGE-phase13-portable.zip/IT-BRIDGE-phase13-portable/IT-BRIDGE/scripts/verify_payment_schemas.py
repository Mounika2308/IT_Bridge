#!/usr/bin/env python3
"""Phase 13 remediation: REAL Pydantic validation of the payment request schemas (needs only `pydantic` v2; no FastAPI, no SQLAlchemy).
Loads backend/app/schemas/payment.py by path and exercises every request model, then checks that the list of review reasons is identical in the
Pydantic schema, the rules module, the SQLAlchemy model's CHECK and migration 0006's CHECK (four copies of one list must not drift).
Usage: python scripts/verify_payment_schemas.py   (exit code 1 on any failure; 2 when pydantic is not installed = BLOCKED)"""
import importlib.util
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent / "backend"
try:
    from pydantic import ValidationError
except ImportError:
    print("BLOCKED: pydantic is not installed; nothing was checked")
    sys.exit(2)


def load(rel, name):
    spec = importlib.util.spec_from_file_location(name, ROOT / rel)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


S = load("app/schemas/payment.py", "payment_schemas")
results = []


def check(label, ok, detail=""):
    results.append((ok, label + ("" if ok else f"  -> {detail}")))


def valid(model, **kw):
    try:
        return model(**kw)
    except ValidationError:
        return None


# PaymentCreateIn: strict positive integer paise, capped
for v in (1, 100, 10_000_000_000_000):
    check(f"PaymentCreateIn accepts {v}", valid(S.PaymentCreateIn, amount_paise=v) is not None)
for v in (0, -1, 10_000_000_000_001, 100.5, 100.0, "100", True, False, None, [1], {"a": 1}, float("nan"), float("inf")):
    check(f"PaymentCreateIn rejects {v!r}", valid(S.PaymentCreateIn, amount_paise=v) is None)
check("PaymentCreateIn requires amount_paise", valid(S.PaymentCreateIn) is None)
check("PaymentCreateIn ignores client-supplied status/commission fields (they are not part of the model)", "status" not in S.PaymentCreateIn.model_fields and "commission_paise" not in S.PaymentCreateIn.model_fields)

# RefundIn / PayoutIn
check("RefundIn: reason optional, max 300", valid(S.RefundIn) is not None and valid(S.RefundIn, reason="x" * 300) is not None and valid(S.RefundIn, reason="x" * 301) is None)
check("PayoutIn: reference 3-80 characters", valid(S.PayoutIn, reference="abc") is not None and valid(S.PayoutIn, reference="ab") is None and valid(S.PayoutIn, reference="x" * 81) is None)

# ReviewResolveIn
reasons = ["LATE_SUCCESS", "OVER_CAP", "DUPLICATE_CHARGE", "AMOUNT_MISMATCH", "CURRENCY_MISMATCH", "TRAINING_CANCELLED", "STUCK_PROCESSING", "REFUND_STUCK"]
check("ReviewResolveIn: note only (reason omitted) is valid", valid(S.ReviewResolveIn, note="checked it").reason is None)
for r in reasons:
    check(f"ReviewResolveIn accepts reason {r}", valid(S.ReviewResolveIn, note="checked it", reason=r) is not None)
for r in ("late_success", "BOGUS", "", " OVER_CAP", 1, True, ["OVER_CAP"]):
    check(f"ReviewResolveIn rejects reason {r!r}", valid(S.ReviewResolveIn, note="checked it", reason=r) is None)
check("ReviewResolveIn trims the note and enforces 3-500 characters", valid(S.ReviewResolveIn, note="   ok!  ").note == "ok!" and valid(S.ReviewResolveIn, note="  ab  ") is None
      and valid(S.ReviewResolveIn, note="x" * 500) is not None and valid(S.ReviewResolveIn, note="x" * 501) is None and valid(S.ReviewResolveIn) is None)
check("ReviewResolveIn: reason null is the same as omitted", valid(S.ReviewResolveIn, note="checked it", reason=None).reason is None)

# the status literals are what the rules module defines
for name, fn in (("PaymentStatus", S.PaymentStatus), ("EarningStatus", S.EarningStatus), ("SandboxOutcome", S.SandboxOutcome)):
    check(f"{name} is a Literal", hasattr(fn, "__args__"))

# four copies of the review-reason list
schema_reasons = list(S.ReviewReason.__args__)
check("schema list == the eight expected reasons", schema_reasons == reasons, str(schema_reasons))
R = load("app/services/payment_rules.py", "payment_rules")
check("payment_rules.REVIEW_REASONS is the same list", list(R.REVIEW_REASONS) == reasons, str(R.REVIEW_REASONS))
for rel, label in (("app/models/payment.py", "model CHECK ck_review_flag_reason"), ("alembic/versions/0006_payment_review_flags.py", "migration 0006 CHECK ck_review_flag_reason")):
    text = (ROOT / rel).read_text()
    m = re.search(r"reason IN \(([^)]*)\)", text)
    got = re.findall(r"'([A-Z_]+)'", m.group(1)) if m else []
    check(f"{label} lists the same reasons", sorted(got) == sorted(reasons), str(got))
check("rules.REVIEW_TEXT has a sentence for every reason", set(R.REVIEW_TEXT) == set(reasons))

failed = [m for ok, m in results if not ok]
for ok, m in results:
    if not ok:
        print("FAIL ", m)
print(f"{len(results) - len(failed)} passed, {len(failed)} failed (real Pydantic {__import__('pydantic').VERSION}; request models only, not FastAPI routing)")
sys.exit(1 if failed else 0)
