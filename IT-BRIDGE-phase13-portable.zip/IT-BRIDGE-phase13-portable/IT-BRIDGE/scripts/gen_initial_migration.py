#!/usr/bin/env python3
"""Writes backend/alembic/versions/0001_initial_schema.py by reading the SQLAlchemy models with `ast`.

Used once because the repo had no migration revisions and this environment cannot install SQLAlchemy to run
`alembic revision --autogenerate`. After installing dependencies, confirm with `alembic check` (or run
backend/tests/test_migrations.py): any drift means this file needs a follow-up revision.
"""
import ast
import re
from pathlib import Path

BACK = Path(__file__).resolve().parent.parent / "backend"
SA_NAMES = r"\b(String|Integer|BigInteger|JSON|Boolean|DateTime|Date|Float|Time|ForeignKey)\b"
BASE = {"int": "Integer()", "str": "String()", "bool": "Boolean()", "datetime": "DateTime()", "date": "Date()",
        "time": "Time()", "float": "Float()", "dict": "JSON()", "list": "JSON()"}


def sa(text: str) -> str:
    return re.sub(SA_NAMES, r"sa.\1", text)


def kw(call: ast.Call, name: str):
    return next((k.value for k in call.keywords if k.arg == name), None)


def true(node) -> bool:
    return isinstance(node, ast.Constant) and node.value is True


def column(name: str, call: ast.Call, annotation: str | None, indexes: list, uniques: list, table: str):
    explicit_type = next((a for a in call.args if not (isinstance(a, ast.Call) and getattr(a.func, "id", "") == "ForeignKey")), None)
    fk = next((a for a in call.args if isinstance(a, ast.Call) and getattr(a.func, "id", "") == "ForeignKey"), None)
    optional = bool(annotation and "None" in annotation)
    if explicit_type is not None:
        typ = sa(ast.unparse(explicit_type))
    elif fk is not None:
        typ = "sa.Integer()"
    else:
        base = re.sub(r"\s*\|\s*None", "", annotation or "").strip().strip("'\"")
        typ = "sa." + BASE[base.split("[")[0]]
    pk = true(kw(call, "primary_key"))
    nullable_kw = kw(call, "nullable")
    nullable = (nullable_kw.value if nullable_kw is not None else optional) and not pk
    parts = [f'"{name}"', typ] + ([sa(ast.unparse(fk))] if fk is not None else []) + [f"nullable={nullable}"]
    unique, index = true(kw(call, "unique")), true(kw(call, "index"))
    if unique and index:
        indexes.append((f"ix_{table}_{name}", [name], True))
    elif unique:
        uniques.append(f'sa.UniqueConstraint("{name}")')
    elif index:
        indexes.append((f"ix_{table}_{name}", [name], False))
    ref = re.search(r"""['"](\w+)\.""", ast.unparse(fk)).group(1) if fk is not None else None
    return f"sa.Column({', '.join(parts)})", pk, ref


def parse():
    tables = {}
    for f in sorted((BACK / "app/models").glob("*.py")):
        tree = ast.parse(f.read_text())
        for n in tree.body:
            if isinstance(n, ast.ClassDef):
                tn = next((s.value.value for s in n.body if isinstance(s, ast.Assign) and getattr(s.targets[0], "id", "") == "__tablename__"), None)
                if not tn:
                    continue
                cols, pks, idx, uq, deps = [], [], [], [], set()
                for s in n.body:
                    if isinstance(s, ast.AnnAssign) and isinstance(s.value, ast.Call) and getattr(s.value.func, "id", "") == "mapped_column":
                        ann = ast.unparse(s.annotation.slice) if isinstance(s.annotation, ast.Subscript) else None
                        c, pk, dep = column(s.target.id, s.value, ann, idx, uq, tn)
                        cols.append(c); deps.add(dep) if dep else None
                        pks.append(s.target.id) if pk else None
                    if isinstance(s, ast.Assign) and getattr(s.targets[0], "id", "") == "__table_args__":
                        for item in s.value.elts:
                            fn = item.func.id
                            if fn == "UniqueConstraint":
                                uq.append(sa("sa." + ast.unparse(item)).replace("sa.UniqueConstraint", "sa.UniqueConstraint", 1).replace("sa.sa.", "sa."))
                            if fn == "Index":
                                idx.append((item.args[0].value, [a.value for a in item.args[1:]], true(kw(item, "unique"))))
                tables[tn] = (cols, pks, idx, uq, deps - {tn})
            if isinstance(n, ast.Assign) and isinstance(n.value, ast.Call) and getattr(n.value.func, "id", "") == "Table":
                tn = n.value.args[0].value
                cols, pks, deps = [], [], set()
                for a in n.value.args[2:]:
                    c, pk, dep = column(a.args[0].value, ast.Call(func=a.func, args=a.args[1:], keywords=a.keywords), None, [], [], tn)
                    cols.append(c); pks.append(a.args[0].value) if pk else None; deps.add(dep) if dep else None
                tables[tn] = (cols, pks, [], [], deps)
    return tables


def order(tables):
    done, out = set(), []
    while len(out) < len(tables):
        for t, (_, _, _, _, deps) in sorted(tables.items()):
            if t not in done and deps <= done:
                done.add(t); out.append(t)
                break
        else:
            raise SystemExit("circular foreign keys: " + ", ".join(set(tables) - done))
    return out


def main():
    tables = parse()
    seq = order(tables)
    up, down = [], []
    for t in seq:
        cols, pks, idx, uq, _ = tables[t]
        body = ",\n        ".join(cols + [f"sa.PrimaryKeyConstraint({', '.join(repr(p) for p in pks)})"] + uq)
        up.append(f'    op.create_table(\n        "{t}",\n        {body},\n    )')
        for name, cs, unique in idx:
            up.append(f'    op.create_index(op.f("{name}"), "{t}", {cs!r}, unique={unique})')
    for t in reversed(seq):
        for name, cs, unique in tables[t][2]:
            down.append(f'    op.drop_index(op.f("{name}"), table_name="{t}")')
        down.append(f'    op.drop_table("{t}")')
    text = '"""initial schema (generated from the SQLAlchemy models)\n\nRevision ID: 0001\nRevises: None\n"""\nimport sqlalchemy as sa\nfrom alembic import op\n\nrevision = "0001"\ndown_revision = None\nbranch_labels = None\ndepends_on = None\n\n\ndef upgrade() -> None:\n' + "\n".join(up) + "\n\n\ndef downgrade() -> None:\n" + "\n".join(down) + "\n"
    out = BACK / "alembic/versions/0001_initial_schema.py"
    if out.exists():
        raise SystemExit(f"{out.name} already exists and later revisions build on it. Use `alembic revision --autogenerate` instead.")
    out.write_text(text)
    print(f"wrote {out.relative_to(BACK.parent)}: {len(seq)} tables")
    print(", ".join(seq))


if __name__ == "__main__":
    main()
