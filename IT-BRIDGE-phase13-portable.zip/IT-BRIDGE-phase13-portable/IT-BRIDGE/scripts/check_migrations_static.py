#!/usr/bin/env python3
"""Replays the Alembic migrations against a recording stub (no database, no SQLAlchemy needed) and compares the resulting
schema with the SQLAlchemy models: tables, columns, types, nullability and indexes. Also replays every downgrade.

Phase 13 additions: the stubs also record primary keys, unique/check constraints, foreign keys with ON DELETE and partial indexes, which
are compared with the models in backend/app/models/payment.py, and the payment tables are built in STRICT mode (real NOT NULL, CHECK,
UNIQUE, FOREIGN KEY ... ON DELETE and partial unique index in SQLite) so scripts/verify_payments.py can exercise them.

This is an interim check. It cannot see server defaults or PostgreSQL behaviour (SQLite is not PostgreSQL: its types, locking and
partial-index syntax differ): the authoritative checks are `alembic upgrade head` on PostgreSQL and backend/tests/test_migrations.py
once the dependencies are installed.
Usage: python scripts/check_migrations_static.py   (exit code 1 on any mismatch)
"""
import ast
import importlib.util
import re
import sys
import types
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "scripts"))
sys.path.insert(0, str(ROOT / "backend"))        # the migrations import app.core.migration_guard (standard library only)
import gen_initial_migration as gen  # noqa: E402  (AST-based model reader)


# ---------- recording stubs for sqlalchemy and alembic.op ----------
class T:
    def __init__(self, name, args=None, **kw):
        self.name, self.args, self.kw = name, args, kw

    def __repr__(self):
        if self.name == "String":
            return f"String({self.args})" if self.args is not None else "String"
        if self.kw.get("timezone"):
            return f"{self.name}(timezone=True)"
        return self.name


class FK:
    def __init__(self, target, ondelete=None, **kw):
        self.target, self.ondelete = target, ondelete


class PK:
    def __init__(self, *cols, **kw):
        self.cols = tuple(cols)


class UQ:
    def __init__(self, *cols, name=None, **kw):
        self.cols, self.name = tuple(cols), name


class CK:
    def __init__(self, sqltext, name=None, **kw):
        self.text, self.name = str(sqltext), name


class Text(str):
    """sa.text(...)"""


class Column:
    def __init__(self, name, *args, nullable=True, **kw):
        self.name, self.nullable = name, nullable
        # SQLAlchemy accepts a type instance (sa.Integer()) or the bare class (sa.Integer); the generated migration uses both
        args = [a() if getattr(a, "is_type_factory", False) else a for a in args]
        self.type = next((a for a in args if isinstance(a, T)), None)
        self.fk = next((a for a in args if isinstance(a, FK)), None)


sa = types.ModuleType("sqlalchemy")
_TYPES = ("Integer", "BigInteger", "JSON", "Boolean", "DateTime", "Date", "Time", "Float")
for _n in _TYPES:
    setattr(sa, _n, lambda *a, _n=_n, **k: T(_n, **k))
sa.String = lambda n=None, **k: T("String", n)
for _n in _TYPES + ("String",):
    getattr(sa, _n).is_type_factory = True
sa.Column = Column
sa.ForeignKey = FK
sa.PrimaryKeyConstraint = PK
sa.UniqueConstraint = UQ
sa.CheckConstraint = CK
sa.text = Text

SCHEMA: dict[str, dict] = {}


class Batch:
    def __init__(self, table):
        self.table, self.t = table, SCHEMA[table]

    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False

    def alter_column(self, name, existing_type=None, nullable=None, **kw):
        if nullable is not None:
            self.t["cols"][name].nullable = nullable

    def drop_column(self, name):
        del self.t["cols"][name]
        if Op.conn:
            Op.conn.execute(f'ALTER TABLE "{self.table}" DROP COLUMN "{name}"')


SQLITE_TYPES = {"String": "TEXT", "Integer": "INTEGER", "BigInteger": "INTEGER", "Boolean": "INTEGER", "DateTime": "TEXT", "Date": "TEXT", "Time": "TEXT", "Float": "REAL", "JSON": "TEXT"}


def _ddl_type(col):
    return SQLITE_TYPES[repr(col.type).split("(")[0]]


class Op:
    executed: list = []
    conn = None  # when set, every operation is also executed on this SQLite connection
    strict = False  # when True, create_table emits the real constraints; otherwise the loose DDL of the 0001-0004 replay is used
    loose_pk = False  # loose tables still get their PRIMARY KEY (needed so strict tables can reference them with foreign keys on)

    def create_table(self, name, *items):
        cols = {c.name: c for c in items if isinstance(c, Column)}
        SCHEMA[name] = {
            "cols": cols, "idx": set(), "where": {},
            "pk": next((i.cols for i in items if isinstance(i, PK)), ()),
            "uq": {(i.cols, i.name) for i in items if isinstance(i, UQ)},
            "ck": {i.name: i.text for i in items if isinstance(i, CK)},
            "fk": {c.name: (c.fk.target, c.fk.ondelete) for c in cols.values() if c.fk},
        }
        if not Op.conn:
            return
        t = SCHEMA[name]
        q = lambda cs: ", ".join(f'"{c}"' for c in cs)  # noqa: E731
        if Op.strict:
            parts = [f'"{c.name}" {_ddl_type(c)}{"" if c.nullable else " NOT NULL"}' for c in cols.values()]
            parts.append(f"PRIMARY KEY ({q(t['pk'])})")
            parts += [f'CONSTRAINT "{n}" UNIQUE ({q(c)})' if n else f"UNIQUE ({q(c)})" for c, n in sorted(t["uq"], key=str)]
            parts += [f'CONSTRAINT "{n}" CHECK ({x})' for n, x in t["ck"].items()]
            for col, (target, ondel) in t["fk"].items():
                tt, tc = target.split(".")
                parts.append(f'FOREIGN KEY ("{col}") REFERENCES "{tt}" ("{tc}")' + (f" ON DELETE {ondel}" if ondel else ""))
        else:
            parts = [f'"{c.name}" {_ddl_type(c)}' for c in cols.values()]
            if Op.loose_pk and t["pk"]:
                parts.append(f"PRIMARY KEY ({q(t['pk'])})")
        Op.conn.execute(f'CREATE TABLE "{name}" ({", ".join(parts)})')

    def drop_table(self, name):
        del SCHEMA[name]
        if Op.conn:
            Op.conn.execute(f'DROP TABLE "{name}"')

    def add_column(self, table, col):
        SCHEMA[table]["cols"][col.name] = col
        if Op.conn:
            Op.conn.execute(f'ALTER TABLE "{table}" ADD COLUMN "{col.name}" {_ddl_type(col)}')

    def batch_alter_table(self, table):
        return Batch(table)

    def f(self, name):
        return name

    def create_index(self, name, table, cols, unique=False, **kw):
        SCHEMA[table]["idx"].add((name, tuple(cols), bool(unique)))
        where = kw.get("sqlite_where")
        if where is not None:
            SCHEMA[table]["where"][name] = str(where)
        if Op.conn:
            Op.conn.execute(f'CREATE {"UNIQUE " if unique else ""}INDEX "{name}" ON "{table}" ({", ".join(chr(34) + c + chr(34) for c in cols)})'
                            + (f" WHERE {where}" if where is not None else ""))

    def drop_index(self, name, table_name=None):
        SCHEMA[table_name]["idx"] = {i for i in SCHEMA[table_name]["idx"] if i[0] != name}
        SCHEMA[table_name]["where"].pop(name, None)
        if Op.conn:
            Op.conn.execute(f'DROP INDEX "{name}"')

    def execute(self, sql):
        Op.executed.append(str(sql))
        if Op.conn:
            Op.conn.execute(str(sql))

    def get_bind(self):
        """The connection the migration runs on. The downgrade guards of 0005/0006 count rows through it, and 0007 asks its dialect name:
        this stub is SQLite when a connection is attached and otherwise an empty database (every count is 0)."""
        return Bind()


class _Result:
    def __init__(self, value):
        self.value = value

    def scalar(self):
        return self.value


class Bind:
    class dialect:  # noqa: N801  (mirrors connection.dialect.name)
        name = "sqlite"

    def execute(self, sql):
        if Op.conn is None:
            return _Result(0)
        row = Op.conn.execute(str(sql)).fetchone()
        return _Result(row[0] if row else None)


op = Op()
sys.modules["sqlalchemy"] = sa
alembic = types.ModuleType("alembic")
alembic.op = op


class _Ctx:
    """Stands for the MigrationContext of one `alembic downgrade` run (a fresh object per run; weak-referenceable like the real one)."""


class Run:
    ctx, target, offline = _Ctx(), None, False       # target None = base, exactly what alembic.context.get_revision_argument() returns for `base`


class _Script:
    """STAND-IN for ScriptDirectory.iterate_revisions(upper, lower, select_for_downgrade=True) on a linear chain, as read in Alembic's source: starts at
    `upper`, goes down, and leaves out the target; a relative target '-N' means N steps down from `upper`. This is NOT Alembic. `mode` lets a scenario make it
    misbehave the way the real one might: 'oldest_first' (the opposite ordering), 'raises' (the call fails), 'narrow' (silently omits everything below 0005)."""
    order: list = []
    mode = "normal"

    def walk(self, upper, lower):
        """The revisions the harness itself runs, newest first (independent of `mode`)."""
        i = self.order.index(upper)
        if lower in (None, "base"):
            j = -1
        elif lower.startswith("-") and lower[1:].isdigit():
            j = i - int(lower[1:])
            if j < -1:
                raise ValueError(f"Relative revision {lower} didn't produce {lower[1:]} migrations")
        else:
            j = self.order.index(lower)
        return list(reversed(self.order[j + 1:i + 1])) if j < i else []

    def iterate_revisions(self, upper, lower, select_for_downgrade=False, **kw):
        assert select_for_downgrade, "the guard must ask for the downgrade selection"
        if self.mode == "raises":
            raise RuntimeError("stand-in: iterate_revisions failed")
        revs = self.walk(upper, lower)
        if self.mode == "oldest_first":
            revs = list(reversed(revs))
        elif self.mode == "narrow":
            revs = [r for r in revs if r >= "0005"]
        return [types.SimpleNamespace(revision=r) for r in revs]


alembic.context = types.SimpleNamespace(is_offline_mode=lambda: Run.offline, get_context=lambda: Run.ctx, get_revision_argument=lambda: Run.target,
                                        script=_Script())
sys.modules["alembic"] = alembic


def downgrade_run(chain, start, target="base", offline=False):
    """STAND-IN for `alembic downgrade <target>` run from revision <start>: one run (a fresh context) executes each revision's REAL downgrade() newest first.
    It uses the stub op / context above, so it checks the guard logic and the migration code, not Alembic itself. Returns the revisions it ran."""
    _Script.order = [m.revision for m in chain]
    Run.ctx, Run.target, Run.offline = _Ctx(), (None if target == "base" else target), offline
    mods = {m.revision: m for m in chain}
    ran = []
    try:
        for r in _Script().walk(start, target):
            ran.append(r)
            mods[r].downgrade()
    finally:
        Run.ctx, Run.target, Run.offline = _Ctx(), None, False
    return ran


def load_chain():
    mods = {}
    for p in (ROOT / "backend/alembic/versions").glob("*.py"):
        spec = importlib.util.spec_from_file_location(p.stem, p)
        m = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(m)
        mods[m.revision] = m
    order, cur = [], next(r for r, m in mods.items() if m.down_revision is None)
    while cur:
        order.append(mods[cur])
        cur = next((r for r, m in mods.items() if m.down_revision == cur), None)
    assert len(order) == len(mods), "migration history is not a single linear chain"
    return order


def norm(t: str) -> str:
    t = t.replace("sa.", "").replace(" ", "")
    return t[:-2] if t.endswith("()") else t


def model_schema():
    out = {}
    for table, (cols, _pks, idx, _uq, _deps) in gen.parse().items():
        parsed = {}
        for c in cols:
            m = re.match(r'^sa\.Column\("(\w+)", (.+?)(?:, sa\.ForeignKey\(.*\))?, nullable=(True|False)\)$', c)
            parsed[m.group(1)] = (norm(m.group(2)), m.group(3) == "True")
        out[table] = {"cols": parsed, "idx": {(n, tuple(cs), bool(u)) for n, cs, u in idx}}
    return out


def _sql(t: str) -> str:
    return re.sub(r"\s+", " ", t).strip()


def model_constraints() -> dict:
    """Primary keys, named unique/check constraints, foreign keys (with ON DELETE) and partial-index conditions of the Phase 13
    models, read with `ast` from backend/app/models/payment.py (the models of Phases 1-12 define no named constraints)."""
    tree = ast.parse((ROOT / "backend/app/models/payment.py").read_text())
    consts = {n.targets[0].id: n.value.args[0].value for n in tree.body
              if isinstance(n, ast.Assign) and isinstance(n.value, ast.Call) and getattr(n.value.func, "id", "") == "text"}
    out = {}
    for n in tree.body:
        if not isinstance(n, ast.ClassDef):
            continue
        tn = next((s.value.value for s in n.body if isinstance(s, ast.Assign) and getattr(s.targets[0], "id", "") == "__tablename__"), None)
        if not tn:
            continue
        d = {"pk": [], "uq": set(), "ck": {}, "fk": {}, "where": {}}
        for s in n.body:
            if isinstance(s, ast.AnnAssign) and isinstance(s.value, ast.Call) and getattr(s.value.func, "id", "") == "mapped_column":
                if gen.true(gen.kw(s.value, "primary_key")):
                    d["pk"].append(s.target.id)
                for a in s.value.args:
                    if isinstance(a, ast.Call) and getattr(a.func, "id", "") == "ForeignKey":
                        od = gen.kw(a, "ondelete")
                        d["fk"][s.target.id] = (a.args[0].value, od.value if od is not None else None)
            if isinstance(s, ast.Assign) and getattr(s.targets[0], "id", "") == "__table_args__":
                for item in s.value.elts:
                    fn, nm = item.func.id, gen.kw(item, "name")
                    if fn == "UniqueConstraint":
                        d["uq"].add((tuple(a.value for a in item.args), nm.value if nm is not None else None))
                    elif fn == "CheckConstraint":
                        d["ck"][nm.value] = _sql(item.args[0].value)
                    elif fn == "Index" and gen.kw(item, "sqlite_where") is not None:
                        d["where"][item.args[0].value] = consts[gen.kw(item, "sqlite_where").id]
        d["pk"] = tuple(d["pk"])
        out[tn] = d
    return out


def compare_constraints() -> list[str]:
    problems = []
    for t, m in model_constraints().items():
        a = SCHEMA.get(t)
        if a is None:
            continue  # the table-set comparison reports it
        if tuple(a["pk"]) != m["pk"]:
            problems.append(f"{t}: primary key model {m['pk']} vs migrations {tuple(a['pk'])}")
        if a["uq"] != m["uq"]:
            problems.append(f"{t}: unique constraints differ: model {sorted(m['uq'], key=str)} vs migrations {sorted(a['uq'], key=str)}")
        if {k: _sql(v) for k, v in a["ck"].items()} != m["ck"]:
            problems.append(f"{t}: check constraints differ: model {sorted(m['ck'].items())} vs migrations {sorted(a['ck'].items())}")
        if a["fk"] != m["fk"]:
            problems.append(f"{t}: foreign keys differ: model {m['fk']} vs migrations {a['fk']}")
        if {k: _sql(v) for k, v in a["where"].items()} != m["where"]:
            problems.append(f"{t}: partial index conditions differ: model {m['where']} vs migrations {a['where']}")
        bad = {c: f for c, f in m["fk"].items() if f[1] != "RESTRICT"}
        if bad:
            problems.append(f"{t}: financial foreign keys must be ON DELETE RESTRICT, found {bad}")
    return problems


def strict_database(chain=None):
    """A SQLite database where 0001-0004 are built loosely (parents only need their primary key) and 0005 is built STRICT:
    NOT NULL, CHECK, UNIQUE, FOREIGN KEY ... ON DELETE RESTRICT and the partial unique index are real. Returns (connection, chain).
    The caller owns the connection and must call strict_database_close() when done."""
    import sqlite3
    chain = chain or load_chain()
    conn = sqlite3.connect(":memory:", isolation_level=None)
    Op.conn, Op.loose_pk = conn, True
    for m in chain[:4]:
        m.upgrade()
    Op.strict = True
    for m in chain[4:]:
        m.upgrade()
    Op.strict = False
    conn.execute("PRAGMA foreign_keys = ON")
    return conn, chain


def strict_database_close():
    Op.conn, Op.loose_pk, Op.strict = None, False, False
    SCHEMA.clear()


def sqlite_replay(chain) -> list[str]:
    """Builds the 0001 schema in a real SQLite database, inserts sample rows, applies 0002 and 0003 (their DDL and their
    backfill SQL) and checks the data. NOT NULL, foreign keys and the nullability change in 0002 are not exercised by SQLite here."""
    import os
    import sqlite3
    problems = []
    conn = sqlite3.connect(":memory:")
    Op.conn = conn
    try:
        chain[0].upgrade()
        conn.executescript("""
        INSERT INTO training_requirements (id, technology, mode, location, description) VALUES (1, 'Python', 'OFFLINE', 'Pune', 'Intro to Python');
        INSERT INTO hiring_requests (id, terms) VALUES (1, 'Travel covered'), (2, NULL);
        INSERT INTO trainings (id, requirement_id, hiring_request_id, title) VALUES (1, 1, 1, 'Python workshop'), (2, 1, 2, 'Second');
        INSERT INTO training_sessions (id, training_id, title) VALUES (1, 1, 'A'), (2, 1, 'B'), (3, 2, 'C');
        INSERT INTO attendance (id, session_id, notes) VALUES (1, 1, 'Covered loops');
        INSERT INTO applications (id, status) VALUES (1, 'INTERVIEW');
        """)
        for m in chain[1:]:
            m.upgrade()
        rows = conn.execute("SELECT id, technology, mode, location, description, terms FROM trainings ORDER BY id").fetchall()
        want = [(1, "Python", "OFFLINE", "Pune", "Intro to Python", "Travel covered"), (2, "Python", "OFFLINE", "Pune", "Intro to Python", None)]
        if rows != want:
            problems.append(f"0002 backfill produced {rows}, expected {want}")
        notes = conn.execute("SELECT id, notes FROM training_sessions ORDER BY id").fetchall()
        if notes != [(1, "Covered loops"), (2, None), (3, None)]:
            problems.append(f"0003 session notes backfill produced {notes}")
        if conn.execute("SELECT interview_at FROM applications").fetchall() != [(None,)]:
            problems.append("0003 applications.interview_at missing or not NULL for existing rows")
        if conn.execute("SELECT notes FROM attendance").fetchall() != [("Covered loops",)]:
            problems.append("attendance.notes was changed (it must be kept)")
        if conn.execute("SELECT meeting_link FROM trainings").fetchall() != [(None,), (None,)]:
            problems.append("trainings.meeting_link missing or not NULL")
        print(f"sqlite {sqlite3.sqlite_version}: 0001 schema built, sample data migrated through 0002 and 0003, backfills verified")
        if sqlite3.sqlite_version_info >= (3, 35):
            os.environ["ITB_ALLOW_FINANCIAL_DOWNGRADE"] = "I_UNDERSTAND_DATA_WILL_BE_DESTROYED"      # sample data is present: the downgrade must be authorised
            try:
                downgrade_run(chain, chain[-1].revision, chain[0].revision)
            finally:
                os.environ.pop("ITB_ALLOW_FINANCIAL_DOWNGRADE", None)
            cols = {t: [r[1] for r in conn.execute(f'PRAGMA table_info("{t}")')] for t in ("trainings", "training_sessions", "applications")}
            gone = {"trainings": {"technology", "mode", "location", "description", "terms", "meeting_link"}, "training_sessions": {"notes"}, "applications": {"interview_at"}}
            for t, names in gone.items():
                if names & set(cols[t]):
                    problems.append(f"downgrade left columns behind in {t}: {sorted(names & set(cols[t]))}")
            if conn.execute("SELECT COUNT(*) FROM trainings").fetchone()[0] != 2:
                problems.append("downgrade lost training rows")
            print("downgrades 0003 and 0002 executed on SQLite: new columns removed, rows kept")
    except Exception as e:  # a failing migration statement is a real finding
        problems.append(f"migration failed on SQLite: {type(e).__name__}: {e}")
    finally:
        Op.conn = None
        SCHEMA.clear()
    return problems


def downgrade_guard_checks(conn, chain) -> list[str]:
    """Financial records are never discarded silently: with a row in a payment table the 0006 and 0005 downgrades must refuse and change nothing;
    only the explicit environment switch lets them run. (SQLite stand-in for the guard logic; the PostgreSQL run is a separate gate.)"""
    import os
    problems = []
    conn.execute("PRAGMA foreign_keys = OFF")
    conn.execute("INSERT INTO invoice_counters (series, year, last_number) VALUES ('INV', 2099, 1)")
    saved = os.environ.pop("ITB_ALLOW_FINANCIAL_DOWNGRADE", None)
    try:
        Op.strict = True
        for rev, table in (("0005", "invoice_counters"),):
            try:
                downgrade_run(chain, rev, "0004")
                problems.append(f"{rev} downgrade ran although {table} holds a row (it must refuse)")
            except RuntimeError as e:
                if "Refusing to downgrade" not in str(e):
                    problems.append(f"{rev} downgrade raised an unexpected message: {e}")
        names = {r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        if "invoice_counters" not in names or conn.execute("SELECT COUNT(*) FROM invoice_counters").fetchone()[0] != 1:
            problems.append("a refused downgrade still changed the database")
        else:
            print("0005 downgrade REFUSED with a financial row present, database unchanged")
        conn.execute("DELETE FROM invoice_counters")
    finally:
        Op.strict = False
        if saved is not None:
            os.environ["ITB_ALLOW_FINANCIAL_DOWNGRADE"] = saved
        conn.execute("PRAGMA foreign_keys = ON")
    return problems


def core_downgrade_guard_checks(chain) -> list[str]:
    """0001's downgrade drops EVERY application table, so it refuses while any of them holds a row and changes nothing. An empty database is not affected, a
    value other than the exact switch does not unlock it, and the exact switch does. (SQLite stand-in for the guard logic through the recording stub; the real
    Alembic/PostgreSQL run is a separate gate.)"""
    import os
    import sqlite3
    problems = []
    saved = os.environ.pop("ITB_ALLOW_FINANCIAL_DOWNGRADE", None)
    unrelated = {k: os.environ.pop(k, None) for k in ("ALLOW_DOWNGRADE", "ITB_ALLOW_DOWNGRADE", "ITB_ALLOW_DESTRUCTIVE_DOWNGRADE", "I_UNDERSTAND_DATA_WILL_BE_DESTROYED")}

    def build():
        conn = sqlite3.connect(":memory:")
        Op.conn = conn
        SCHEMA.clear()
        chain[0].upgrade()
        return conn

    def tables(conn):
        return {r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    try:
        conn = build()
        before = tables(conn)
        downgrade_run(chain, "0001", "base")
        if tables(conn):
            problems.append(f"0001 downgrade on an EMPTY database left tables behind: {sorted(tables(conn))}")
        else:
            print(f"0001 downgrade on an empty database: allowed without any switch ({len(before)} tables removed)")
        conn = build()
        conn.execute("INSERT INTO skills (id, name, is_active) VALUES (1, 'Python', 1)")
        refusals = 0
        attempts = [("no switch", {}), ("wrong value", {"ITB_ALLOW_FINANCIAL_DOWNGRADE": "true"}), ("partial phrase", {"ITB_ALLOW_FINANCIAL_DOWNGRADE": "I_UNDERSTAND"}),
                    ("lower case", {"ITB_ALLOW_FINANCIAL_DOWNGRADE": "i_understand_data_will_be_destroyed"}), ("padded", {"ITB_ALLOW_FINANCIAL_DOWNGRADE": " I_UNDERSTAND_DATA_WILL_BE_DESTROYED"}),
                    ("other variable names", {k: "I_UNDERSTAND_DATA_WILL_BE_DESTROYED" for k in unrelated})]
        for label, env in attempts:
            os.environ.update(env)
            try:
                downgrade_run(chain, "0001", "base")
                problems.append(f"0001 downgrade ran although skills holds a row ({label})")
            except RuntimeError as e:
                refusals += 1
                if "Refusing to downgrade" not in str(e) or "skills 1 rows" not in str(e):
                    problems.append(f"0001 downgrade refusal ({label}) has an unexpected message: {e}")
            finally:
                for k in env:
                    os.environ.pop(k, None)
        if tables(conn) != before or conn.execute("SELECT COUNT(*) FROM skills").fetchone()[0] != 1:
            problems.append("a refused 0001 downgrade still changed the database")
        else:
            print(f"0001 downgrade REFUSED {refusals} times (no switch, 4 wrong values, other variable names) with a row present, database unchanged")
        os.environ["ITB_ALLOW_FINANCIAL_DOWNGRADE"] = "I_UNDERSTAND_DATA_WILL_BE_DESTROYED"
        downgrade_run(chain, "0001", "base")
        if tables(conn):
            problems.append(f"0001 downgrade with the exact switch left tables behind: {sorted(tables(conn))}")
        else:
            print("0001 downgrade with the exact switch: proceeds (test databases only)")
    except Exception as e:
        problems.append(f"0001 guard check failed: {type(e).__name__}: {e}")
    finally:
        os.environ.pop("ITB_ALLOW_FINANCIAL_DOWNGRADE", None)
        if saved is not None:
            os.environ["ITB_ALLOW_FINANCIAL_DOWNGRADE"] = saved
        for k, v in unrelated.items():
            if v is not None:
                os.environ[k] = v
        Op.conn = None
        SCHEMA.clear()
    return problems


def whole_path_downgrade_checks(chain) -> list[str]:
    """The downgrade policy (app/core/migration_guard.py) on a database built through all seven revisions. Every refusal must happen BEFORE any revision
    runs (the database is compared table by table, column by column and row by row afterwards), the guard must look at exactly the revisions the run
    removes (nothing more), and the exact switch must be the only way through. STAND-IN: the stub op/context and a stub revision walk, SQLite, no
    Alembic and no PostgreSQL. It runs the real downgrade() code of every migration and the real guard module."""
    import os
    problems = []
    SWITCH, PHRASE = "ITB_ALLOW_FINANCIAL_DOWNGRADE", "I_UNDERSTAND_DATA_WILL_BE_DESTROYED"
    saved = os.environ.pop(SWITCH, None)
    head = chain[-1].revision

    def fresh(rows=()):
        strict_database_close()
        conn, _ = strict_database(chain)
        conn.execute("PRAGMA foreign_keys = OFF")
        for sql in rows:
            conn.execute(sql)
        return conn

    def snapshot(conn):
        names = [r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY 1")]
        return ([tuple(r) for r in conn.execute("SELECT type, name, sql FROM sqlite_master ORDER BY 1, 2")],
                {t: [tuple(r) for r in conn.execute(f'SELECT * FROM "{t}" ORDER BY 1')] for t in names})

    USER = "INSERT INTO users (id, email) VALUES (1, 'a@example.com')"
    PREF = "INSERT INTO notification_preferences (id, user_id, channel, enabled) VALUES (1, 1, 'EMAIL', 0)"
    FIN = "INSERT INTO invoice_counters (series, year, last_number) VALUES ('INV', 2099, 1)"
    TRAIN = "INSERT INTO trainings (id, technology, mode) VALUES (1, 'Python', 'ONLINE')"
    NOTES = "INSERT INTO training_sessions (id, notes) VALUES (1, 'covered loops')"
    INTERVIEW = "INSERT INTO applications (id, interview_at) VALUES (1, '2030-01-01 10:00')"

    def refused(label, rows, start, target, must_name, must_not_name=(), offline=False):
        conn = fresh(rows)
        before = snapshot(conn)
        try:
            downgrade_run(chain, start, target, offline=offline)
            problems.append(f"{label}: the downgrade ran although it must refuse")
        except RuntimeError as e:
            msg = str(e)
            if not msg.startswith("Refusing to"):          # "Refusing to downgrade" online, "Refusing to generate an offline (--sql) downgrade" offline
                problems.append(f"{label}: unexpected error {msg[:150]}")
            for x in must_name:
                if x not in msg:
                    problems.append(f"{label}: the refusal does not name {x!r}")
            for x in must_not_name:
                if x in msg:
                    problems.append(f"{label}: the refusal names {x!r}, which this run does not remove")
        if snapshot(conn) != before:
            problems.append(f"{label}: a REFUSED downgrade changed the database (a revision ran before the refusal)")
        return conn

    def allowed(label, rows, start, target, expect_ran, offline=False):
        conn = fresh(rows)
        try:
            ran = downgrade_run(chain, start, target, offline=offline)
            if ran != expect_ran:
                problems.append(f"{label}: ran {ran}, expected {expect_ran}")
        except RuntimeError as e:
            problems.append(f"{label}: refused although nothing it removes holds data: {str(e)[:160]}")
        return conn

    try:
        # --- the failure scenario of the review: core data present, the refusal used to come from 0001 after 0007..0002 had already run (SQLite) ---
        conn = fresh([USER])
        before = snapshot(conn)
        from app.core import migration_guard as mg
        real_preflight = mg.preflight_downgrade
        mg.preflight_downgrade = lambda rev: None             # the situation BEFORE the whole-path check: only each revision's own guard (migrations import it inside downgrade())
        try:
            downgrade_run(chain, head, "base")
            problems.append("without the pre-flight, the 0001 guard did not refuse (the scenario cannot be reproduced)")
        except RuntimeError:
            if snapshot(conn) == before:
                problems.append("without the pre-flight the refusal changed nothing: the partial-downgrade scenario is not reproduced by this harness")
            else:
                print("scenario reproduced WITHOUT the pre-flight: the 0001 guard refused only after 0007..0002 had changed the SQLite database (partial downgrade)")
        conn = fresh([PREF])
        downgrade_run(chain, head, "0003")
        if conn.execute("SELECT name FROM sqlite_master WHERE name='notification_preferences'").fetchone() is None:
            print("scenario reproduced WITHOUT the pre-flight: `downgrade 0003` silently dropped notification_preferences together with its row")
        else:
            problems.append("the unguarded 0004 scenario is not reproduced by this harness")
        mg.preflight_downgrade = real_preflight                            # back to the real thing

        # --- with the pre-flight: refusals happen before anything runs ---
        refused("downgrade base, core data present", [USER], head, "base", ["0001: users 1 rows"], ["0004", "0005"])
        refused("downgrade 0003, a notification preference present", [USER, PREF], head, "0003", ["0004: notification_preferences 1 rows"], ["0001", "users"])
        refused("downgrade 0004, a financial row present", [USER, FIN], head, "0004", ["0005: invoice_counters 1 rows"], ["0001", "users"])
        refused("downgrade 0001, a training present (snapshot columns, meeting link)", [TRAIN], head, "0001", ["0002: trainings.(technology"])
        refused("downgrade 0002, a session note present", [NOTES], head, "0002", ["0003: training_sessions.(notes)"])
        refused("downgrade 0002, an interview time present", [INTERVIEW], head, "0002", ["0003: applications.(interview_at)"])
        refused("relative -3 reaches 0005", [FIN], head, "-3", ["0005"])
        refused("two revisions hold data: both are named", [USER, PREF, FIN], head, "base", ["0001: users", "0004: notification_preferences", "0005: invoice_counters"])
        refused("offline --sql of a destructive path", [], head, "base", ["offline"], offline=True)
        print("whole-path refusals: base / 0003 / 0004 / 0001 / 0002 / relative -3 / several at once / offline: each refused before any revision ran (database identical)")

        # --- every revision as the FIRST step of a run (a database that is at that revision): only then does its own preflight call do the checking ---
        for rev, rows, name in (("0002", [TRAIN], "0002: trainings.(technology"), ("0003", [NOTES], "0003: training_sessions.(notes)"),
                                ("0004", [PREF], "0004: notification_preferences"), ("0005", [FIN], "0005: invoice_counters")):
            refused(f"a run that starts at {rev} holding its data", [USER, *rows], rev, "-1", [name], ["0001"])
            refused(f"a run that starts at {rev} with an explicit target", [USER, *rows], rev, "0001", [name], ["0001: users"])
        allowed("a run that starts at 0004 is not stopped by the financial data above it", [USER, FIN, TRAIN], "0004", "-1", ["0004"])
        print("each of 0002 / 0003 / 0004 / 0005 as the first step of a run refuses its own data through its own pre-flight call, and ignores data in revisions above it")

        # --- and the path is exactly what the run removes: other data is not in the way ---
        allowed("downgrade 0006 with a financial row (0007 only)", [USER, FIN], head, "0006", ["0007"])
        allowed("downgrade -1 with core, notification and financial data present", [USER, PREF, FIN], head, "-1", ["0007"])
        allowed("downgrade 0005 with core and notification data present (0007, 0006)", [USER, PREF, TRAIN], head, "0005", ["0007", "0006"])
        allowed("downgrade 0004 with core and notification data present (0007..0005, empty)", [USER, PREF, TRAIN], head, "0004", ["0007", "0006", "0005"])
        allowed("downgrade --sql 0007 only", [], head, "0006", ["0007"], offline=True)
        allowed("downgrade base on an empty database", [], head, "base", [m.revision for m in reversed(chain)])
        conn = allowed("downgrade 0003 with an empty notification outbox but users present", [USER], head, "0003", ["0007", "0006", "0005", "0004"])
        names = {r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        if "notification_preferences" in names or "notification_deliveries" in names or "users" not in names:
            problems.append("downgrade 0003 did not remove exactly the 0004 tables")
        print("whole-path allowed: only the revisions a run removes are looked at (0006 / -1 / 0005 / 0004 / --sql 0007 / empty base / 0003 with users present)")

        # --- a misbehaving revision walk (what real Alembic might do differently) must not blind or over-block the guard ---
        try:
            _Script.mode = "oldest_first"
            refused("alembic answers oldest-first: downgrade base", [USER, PREF], head, "base", ["0001: users 1 rows", "0004: notification_preferences 1 rows"])
            allowed("alembic answers oldest-first: -1 with data below", [USER, PREF, FIN], head, "-1", ["0007"])
            _Script.mode = "raises"
            refused("alembic's walk fails: downgrade base", [USER], head, "base", ["0001: users 1 rows", "not available"])
            refused("alembic's walk fails: 0003 with a notification preference", [PREF], head, "0003", ["0004: notification_preferences 1 rows", "not available"])
            refused("alembic's walk fails: -1 cannot be cross-checked, so everything below is checked", [USER, PREF, FIN], head, "-1", ["0001: users", "cross-checked", "alembic downgrade 0006"])
            allowed("alembic's walk fails: -1 on an empty database", [], head, "-1", ["0007"])
            allowed("alembic's walk fails: 0006", [USER, PREF, FIN], head, "0006", ["0007"])
            _Script.mode = "narrow"
            refused("alembic's walk omits revisions: the union still sees 0001", [USER], head, "base", ["0001: users 1 rows", "differs"])
        finally:
            _Script.mode = "normal"
        print("misbehaving revision walk (oldest-first / raises / omits revisions): still refused before anything ran; `-1` with no cross-check checks everything below, naming the target (`0006`) explicitly still works")

        # --- the switch: exact phrase only, and then everything goes ---
        for label, env in (("no switch", {}), ("true", {SWITCH: "true"}), ("1", {SWITCH: "1"}), ("lower case", {SWITCH: PHRASE.lower()}), ("padded", {SWITCH: PHRASE + " "}),
                           ("other variable", {"ITB_ALLOW_DOWNGRADE": PHRASE, "ALLOW_DOWNGRADE": PHRASE, "ITB_ALLOW_FINANCIAL_DOWNGRADES": PHRASE})):
            os.environ.update(env)
            try:
                refused(f"switch attempt: {label}", [USER, PREF, FIN, TRAIN], head, "base", ["Refusing to downgrade"])
            finally:
                for k in env:
                    os.environ.pop(k, None)
        os.environ[SWITCH] = PHRASE
        conn = allowed("the exact switch with core, notification and financial data present", [USER, PREF, FIN, TRAIN, NOTES, INTERVIEW], head, "base",
                       [m.revision for m in reversed(chain)])
        os.environ.pop(SWITCH, None)
        if {r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}:
            problems.append("the exact switch did not let the downgrade remove everything")
        print("switch: 6 wrong attempts refused with the database unchanged; the exact phrase authorises the whole path")
    except Exception as e:
        problems.append(f"whole-path check failed: {type(e).__name__}: {e}")
    finally:
        os.environ.pop(SWITCH, None)
        if saved is not None:
            os.environ[SWITCH] = saved
        _Script.mode = "normal"
        from app.core import migration_guard as mg
        if "real_preflight" in locals():
            mg.preflight_downgrade = real_preflight
        strict_database_close()
    return problems


def strict_replay(chain) -> list[str]:
    """0005 on SQLite with real constraints: the build must succeed, every table must exist, and the downgrade must remove them."""
    problems = []
    try:
        conn, _ = strict_database(chain)
        names = {r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        want = set(model_constraints())
        if not want <= names:
            problems.append(f"strict build is missing tables {sorted(want - names)}")
        parts = conn.execute("SELECT sql FROM sqlite_master WHERE name='uq_payment_one_in_flight'").fetchone()
        if not parts or "WHERE" not in parts[0].upper():
            problems.append("the partial unique index uq_payment_one_in_flight was not created with its WHERE condition")
        print(f"strict SQLite build of 0005: {len(want)} payment tables with CHECK / UNIQUE / FOREIGN KEY ... ON DELETE RESTRICT and the partial unique index")
        problems += downgrade_guard_checks(conn, chain)
        Op.strict = True
        downgrade_run(chain, "0007", "0004")      # 0007 (no-op off PostgreSQL), 0006, 0005
        Op.strict = False
        left = want & {r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        if left:
            problems.append(f"downgrading 0007-0005 left tables behind: {sorted(left)}")
        else:
            print("0007, 0006 and 0005 downgrades executed on SQLite: all payment tables removed (empty database)")
    except Exception as e:
        problems.append(f"strict 0005 build failed on SQLite: {type(e).__name__}: {e}")
    finally:
        strict_database_close()
    return problems


def main() -> int:
    chain = load_chain()
    problems = []
    for m in chain:
        m.upgrade()
    print(f"replayed upgrades: {' -> '.join(m.revision for m in chain)} ({len(Op.executed)} data statements recorded)")
    model = model_schema()
    if set(model) != set(SCHEMA):
        problems.append(f"tables differ: only in models {sorted(set(model) - set(SCHEMA))}, only in migrations {sorted(set(SCHEMA) - set(model))}")
    for t in sorted(set(model) & set(SCHEMA)):
        mc = model[t]["cols"]
        ac = {n: (norm(repr(c.type)), c.nullable) for n, c in SCHEMA[t]["cols"].items()}
        for n in sorted(set(mc) | set(ac)):
            if n not in ac:
                problems.append(f"{t}.{n}: in the model, missing from migrations")
            elif n not in mc:
                problems.append(f"{t}.{n}: in migrations, missing from the model")
            elif mc[n] != ac[n]:
                problems.append(f"{t}.{n}: model {mc[n]} vs migrations {ac[n]}")
        if model[t]["idx"] != SCHEMA[t]["idx"]:
            problems.append(f"{t}: indexes differ: model {sorted(model[t]['idx'])} vs migrations {sorted(SCHEMA[t]['idx'])}")
    problems += compare_constraints()
    n_cols = sum(len(v["cols"]) for v in SCHEMA.values())
    print(f"compared {len(model)} model tables with {len(SCHEMA)} migrated tables: {n_cols} columns, types, nullability, indexes; "
          f"primary keys, unique/check constraints, foreign keys (ON DELETE) and partial indexes of the {len(model_constraints())} payment tables")
    downgrade_run(chain, chain[-1].revision, "base")
    if SCHEMA:
        problems.append(f"downgrade to base leaves tables behind: {sorted(SCHEMA)}")
    else:
        print("replayed downgrades back to base: nothing left behind")
    problems += core_downgrade_guard_checks(chain)
    problems += whole_path_downgrade_checks(chain)
    problems += sqlite_replay(chain)
    problems += strict_replay(chain)
    for p in problems:
        print("PROBLEM", p)
    print(f"\n{len(problems)} problem(s)")
    return 1 if problems else 0


if __name__ == "__main__":
    sys.exit(main())
