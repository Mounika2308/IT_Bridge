#!/usr/bin/env python3
"""Static integration audit (stdlib only, no installs needed).

Checks, without running the app:
  1. every `from app.x import y` in the backend resolves to a real module and name
  2. unused imports in backend modules
  3. every API call made by the React code matches a real FastAPI route (method + path)
  4. every in-app link / navigate target matches a React route
  5. every relative JS import resolves, including named imports
Exit code is 1 if any hard problem is found.  Usage: python scripts/audit_integration.py
"""
import ast
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
BACK, FRONT = ROOT / "backend", ROOT / "frontend" / "src"
problems: list[str] = []
notes: list[str] = []


# ---------- 1 + 2: python imports ----------
def top_level_names(tree: ast.Module) -> set[str]:
    names = set()
    for n in tree.body:
        if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            names.add(n.name)
        elif isinstance(n, (ast.Assign, ast.AnnAssign)):
            for t in (n.targets if isinstance(n, ast.Assign) else [n.target]):
                if isinstance(t, ast.Name):
                    names.add(t.id)
        elif isinstance(n, (ast.Import, ast.ImportFrom)):
            for a in n.names:
                names.add((a.asname or a.name).split(".")[0])
    return names


def module_file(mod: str) -> Path | None:
    p = BACK.joinpath(*mod.split("."))
    if p.with_suffix(".py").exists():
        return p.with_suffix(".py")
    if (p / "__init__.py").exists():
        return p / "__init__.py"
    return None


def check_python():
    for f in sorted(BACK.rglob("*.py")):
        if "alembic/versions" in str(f):
            continue
        src = f.read_text()
        tree = ast.parse(src)
        imported: dict[str, int] = {}
        for node in ast.walk(tree):
            if isinstance(node, ast.ImportFrom) and node.module and node.module.startswith("app"):
                target = module_file(node.module)
                if not target:
                    problems.append(f"{f.relative_to(ROOT)}:{node.lineno} imports missing module {node.module}")
                    continue
                names = top_level_names(ast.parse(target.read_text()))
                for a in node.names:
                    sub = module_file(f"{node.module}.{a.name}")
                    if a.name not in names and not sub and a.name != "*":
                        problems.append(f"{f.relative_to(ROOT)}:{node.lineno} '{a.name}' not defined in {node.module}")
            if isinstance(node, (ast.Import, ast.ImportFrom)) and node.col_offset == 0 or isinstance(node, (ast.Import, ast.ImportFrom)):
                for a in node.names:
                    imported[(a.asname or a.name).split(".")[0]] = node.lineno
        if f.name == "__init__.py":
            continue
        used = {n.id for n in ast.walk(tree) if isinstance(n, ast.Name)} | {n.value.id for n in ast.walk(tree) if isinstance(n, ast.Attribute) and isinstance(n.value, ast.Name)}
        used |= {n.value for n in ast.walk(tree) if isinstance(n, ast.Constant) and isinstance(n.value, str)}  # string annotations
        lines = src.splitlines()
        for name, ln in imported.items():
            if name not in used and "noqa" not in lines[ln - 1] and name != "annotations":
                notes.append(f"unused import: {f.relative_to(ROOT)}:{ln} {name}")


# ---------- 3: API calls vs routes ----------
def norm(p: str) -> str:
    p = re.sub(r"\$\{action\}", "{action}", p)
    p = re.sub(r"\$\{[^}]*\}", "{}", p)
    p = re.sub(r"\{[^}/]*\}", "{}", p)
    return p.split("?")[0].rstrip("/") or "/"


def backend_routes() -> set[tuple[str, str]]:
    main = ast.parse((BACK / "app/main.py").read_text())
    included = {}  # router variable name -> prefix
    for n in ast.walk(main):
        if isinstance(n, ast.Call) and getattr(n.func, "attr", "") == "include_router":
            r = n.args[0]
            prefix = next((k.value.value for k in n.keywords if k.arg == "prefix"), "")
            if isinstance(r, ast.Attribute):
                included[(r.value.id, r.attr)] = prefix
    routes = set()
    for f in (BACK / "app/api/v1").glob("*.py"):
        tree = ast.parse(f.read_text())
        routers = {}
        for n in tree.body:
            if isinstance(n, ast.Assign) and isinstance(n.value, ast.Call) and getattr(n.value.func, "id", "") == "APIRouter":
                prefix = next((k.value.value for k in n.value.keywords if k.arg == "prefix"), "")
                routers[n.targets[0].id] = prefix
        for n in ast.walk(tree):
            if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)):
                for d in n.decorator_list:
                    if isinstance(d, ast.Call) and isinstance(d.func, ast.Attribute) and d.func.value.id in routers:
                        verb = d.func.attr.upper()
                        base = included.get((f.stem, d.func.value.id))
                        if base is None:
                            notes.append(f"router {f.stem}.{d.func.value.id} is defined but not included in main.py")
                            continue
                        routes.add((verb, norm(base + routers[d.func.value.id] + d.args[0].value)))
    return routes


CALL = re.compile(r"""\b(?:api|axios)\.(get|post|put|patch|delete)\(\s*(?:`([^`]*)`|"([^"]*)")""")


def check_api_calls(routes):
    for f in sorted(FRONT.rglob("*.js*")):
        for m in CALL.finditer(f.read_text()):
            verb, path = m.group(1).upper(), (m.group(2) or m.group(3))
            path = path.replace("${api.defaults.baseURL}", "")
            full = norm("/api/v1" + path)
            if full.endswith("/{action}") or "${action}" in path:  # one call site serves several sibling routes (accept|decline|cancel)
                stem = full.rsplit("/", 1)[0]
                if any(v == verb and r.rsplit("/", 1)[0] == stem for v, r in routes):
                    continue
            if (verb, full) not in routes:
                problems.append(f"{f.relative_to(ROOT)}: {verb} {path} has no matching backend route")
    return routes


# ---------- 4: links vs react routes ----------
def check_links():
    app = (FRONT / "App.jsx").read_text()
    patterns = [norm(re.sub(r":\w+", "{}", p)) for p in re.findall(r'path="([^"*]+)"', app)]

    def known(link: str) -> bool:
        link = norm(re.sub(r"/\d+(?=/|$)", "/{}", re.sub(r"\$\{[^}]*\}", "{}", link)))   # a concrete id in a test fixture stands for a route parameter
        return any(link == p for p in patterns)

    link_re = re.compile(r"""(?:\bto=|\bhref=|nav\(|assign\(|\[)\s*\{?\s*(?:`([^`]*)`|"([^"]*)")""")
    seen = set()
    for f in sorted(FRONT.rglob("*.jsx")):
        for m in link_re.finditer(f.read_text()):
            link = m.group(1) or m.group(2)
            if not link.startswith("/") or link.startswith("//") or "." in re.sub(r"\$\{[^}]*\}", "", link.split("/")[-1]):
                continue
            seen.add(norm(re.sub(r"\$\{[^}]*\}", "{}", link)))
            if not known(link):
                problems.append(f"{f.relative_to(ROOT)}: link '{link}' has no React route")
    for p in patterns:
        if p not in seen and p not in ("/", "/login", "/register"):
            notes.append(f"React route {p} is not linked from anywhere (only reachable by typing the URL or via dynamic links)")


# ---------- 5: js imports ----------
IMPORT = re.compile(r"""import\s+(?:(\w+)\s*,?\s*)?(?:\{([^}]*)\})?\s*(?:\*\s+as\s+\w+\s*)?from\s+["'](\.[^"']+)["']""")


def check_js_imports():
    for f in sorted(FRONT.rglob("*.js*")):
        for m in IMPORT.finditer(f.read_text()):
            default, named, rel = m.groups()
            target = (f.parent / rel).resolve()
            cands = [target] + [target.with_suffix(s) for s in (".js", ".jsx")] + [target / "index.js"]
            t = next((c for c in cands if c.is_file()), None)
            if not t:
                problems.append(f"{f.relative_to(ROOT)}: import '{rel}' does not resolve")
                continue
            if t.suffix == ".css":
                continue
            body = t.read_text()
            if default and "export default" not in body:
                problems.append(f"{f.relative_to(ROOT)}: default import from '{rel}' but it has no default export")
            for n in [x.strip().split(" as ")[0] for x in (named or "").split(",") if x.strip()]:
                if not re.search(rf"export\s+(?:const|function|async function|class)\s+{n}\b|export\s*\{{[^}}]*\b{n}\b", body):
                    problems.append(f"{f.relative_to(ROOT)}: '{n}' is not exported by '{rel}'")


if __name__ == "__main__":
    check_python()
    routes = backend_routes()
    check_api_calls(routes)
    check_links()
    check_js_imports()
    print(f"backend routes found: {len(routes)}")
    for n in sorted(set(notes)):
        print("NOTE   ", n)
    for p in problems:
        print("PROBLEM", p)
    print(f"\n{len(problems)} problem(s), {len(set(notes))} note(s)")
    sys.exit(1 if problems else 0)
