#!/usr/bin/env python3
"""Phase 13: executes the payment DATABASE INVARIANTS in a real SQL engine (SQLite, with foreign keys ON).

What this is: migration 0005 is replayed in STRICT mode (real NOT NULL, CHECK, UNIQUE, FOREIGN KEY ... ON DELETE RESTRICT and the partial
unique index; see scripts/check_migrations_static.py), then rows are inserted and every financial invariant is attacked directly, bypassing
the service layer. Each rejected insert is paired with the valid insert it was derived from, so a rejection cannot be caused by something else.

What this is NOT: PostgreSQL. SQLite has no row locks (SELECT ... FOR UPDATE is a no-op), no real concurrency here, and different type
rules, so the concurrency design (lock order, SAVEPOINT counters, simultaneous requests) is NOT verified by this script. It also does not
run the SQLAlchemy models or the services. Run backend/tests/test_payments_phase13.py against PostgreSQL for those.
Usage: python scripts/verify_payments.py   (exit code 1 on any failure)
"""
import sqlite3
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import check_migrations_static as cm  # noqa: E402  (installs the sqlalchemy/alembic recording stubs)

SCHEMA = cm.SCHEMA
results: list[tuple[bool, str]] = []
_n = [100]


def n() -> int:
    _n[0] += 1
    return _n[0]


def generic(col, name):
    t = repr(col.type).split("(")[0]
    return {"String": f"{name}-{n()}", "Integer": n(), "BigInteger": n(), "Boolean": 0, "DateTime": "2030-01-01 00:00:00", "JSON": "{}"}[t]


SHARED_PARENTS = {"users.id", "institution_profiles.id", "trainer_profiles.id"}   # one row is enough
DEFAULTS = {
    "payments": dict(attempt_no=None, amount_paise=10_000, currency="INR", commission_bps=1000, platform_fee_paise=1000, net_paise=9000, status="FAILED",
                     provider="sandbox", needs_review=0, request_fingerprint="f" * 64),
    "payment_transactions": dict(type="CHARGE", amount_paise=10_000, provider="sandbox"),
    "payment_refunds": dict(amount_paise=10_000, status="PENDING", attempts=0),
    "trainer_earnings": dict(gross_paise=10_000, commission_paise=1000, net_paise=9000, status="PENDING"),
    "platform_commissions": dict(rate_bps=1000, amount_paise=1000, status="RECORDED"),
    "invoices": dict(amount_paise=10_000, currency="INR", snapshot="{}"),
    "payment_webhook_events": dict(outcome="succeeded", source="WEBHOOK"),
}


def parent(conn, target):
    table, col = target.split(".")
    if target in SHARED_PARENTS:
        conn.execute(f'INSERT OR IGNORE INTO "{table}" ("{col}") VALUES (1)')
        return 1
    if table in DEFAULTS:                                          # a strict payment table: make a fresh valid row
        return row(conn, table)
    i = n()
    conn.execute(f'INSERT INTO "{table}" ("{col}") VALUES ({i})')  # loose parents (trainings ...) only need their id
    return i


def row(conn, table, **given):
    """Inserts one row, filling every NOT NULL column the caller did not give. Returns its id (or None for a table without one)."""
    cols, vals = SCHEMA[table]["cols"], {}
    for name, c in cols.items():
        if name in given:
            vals[name] = given[name]
        elif name == "id":
            continue
        elif name in DEFAULTS.get(table, {}) and DEFAULTS[table][name] is not None:
            vals[name] = DEFAULTS[table][name]
        elif c.nullable:
            continue
        elif c.fk:
            vals[name] = parent(conn, c.fk.target)
        else:
            vals[name] = generic(c, name)
    if table == "payments" and vals.get("status") == "SUCCEEDED" and "paid_at" not in given:
        vals["paid_at"] = "2030-01-01 00:00:00"
    names = ", ".join(f'"{k}"' for k in vals)
    cur = conn.execute(f'INSERT INTO "{table}" ({names}) VALUES ({", ".join("?" * len(vals))})', list(vals.values()))
    return cur.lastrowid if "id" in cols else None


def ok(label, fn):
    try:
        fn()
        results.append((True, f"accepted: {label}"))
    except Exception as e:
        results.append((False, f"should have been ACCEPTED but failed: {label}: {e}"))


def rejected(label, fn, contains):
    try:
        fn()
    except sqlite3.IntegrityError as e:
        good = contains.lower() in str(e).lower()
        results.append((good, f"rejected: {label}" if good else f"rejected for the wrong reason: {label}: {e} (wanted {contains!r})"))
        return
    except Exception as e:
        results.append((False, f"unexpected error type for {label}: {type(e).__name__}: {e}"))
        return
    results.append((False, f"should have been REJECTED but was accepted: {label}"))


def scenarios(conn):
    T = n()
    conn.execute(f'INSERT INTO trainings (id) VALUES ({T})')
    uid = lambda: parent(conn, "users.id")  # noqa: E731

    # ---- payments: value constraints (each negative is a one-field change of a valid row) ----
    ok("a valid payment", lambda: row(conn, "payments", training_id=T, attempt_no=1))
    for label, change, name in [
        ("amount 0", dict(amount_paise=0, platform_fee_paise=0, net_paise=0), "ck_payment_amount_positive"),
        ("negative amount", dict(amount_paise=-5, platform_fee_paise=0, net_paise=-5), "ck_payment_amount_positive"),
        ("commission above the amount", dict(platform_fee_paise=10_001, net_paise=-1), "ck_payment_fee_range"),
        ("negative commission", dict(platform_fee_paise=-1, net_paise=10_001), "ck_payment_fee_range"),
        ("net that is not amount minus commission", dict(net_paise=9001), "ck_payment_net"),
        ("rate above 100%", dict(commission_bps=10_001), "ck_payment_bps"),
        ("negative rate", dict(commission_bps=-1), "ck_payment_bps"),
        ("attempt number 0", dict(attempt_no=0), "ck_payment_attempt_no"),
        ("a currency other than INR", dict(currency="USD"), "ck_payment_currency"),
        ("an unknown status", dict(status="PAID"), "ck_payment_status"),
        ("lower-case status", dict(status="succeeded", paid_at="2030-01-01 00:00:00"), "ck_payment_status"),
        ("SUCCEEDED without paid_at", dict(status="SUCCEEDED", paid_at=None), "ck_payment_paid_at"),
    ]:
        rejected(f"payment with {label}", lambda change=change: row(conn, "payments", **{"training_id": parent(conn, "trainings.id"), "attempt_no": 1, **change}), name)
    rejected("payment without a request fingerprint", lambda: row(conn, "payments", training_id=T, attempt_no=n(), request_fingerprint=None), "NOT NULL")
    ok("zero commission (rate 0) is valid", lambda: row(conn, "payments", training_id=parent(conn, "trainings.id"), attempt_no=1, commission_bps=0, platform_fee_paise=0, net_paise=10_000))
    ok("100% commission is valid", lambda: row(conn, "payments", training_id=parent(conn, "trainings.id"), attempt_no=1, commission_bps=10_000, platform_fee_paise=10_000, net_paise=0))
    ok("a 5-billion-rupee fee fits (BigInteger paise)", lambda: row(conn, "payments", training_id=parent(conn, "trainings.id"), attempt_no=1,
                                                                  amount_paise=10_000_000_000_000, platform_fee_paise=1_000_000_000_000, net_paise=9_000_000_000_000))

    # ---- payments: attempts, idempotency, provider order, one in flight ----
    rejected("the same attempt number twice for one training", lambda: row(conn, "payments", training_id=T, attempt_no=1), "payments.training_id, payments.attempt_no")
    ok("the next attempt number", lambda: row(conn, "payments", training_id=T, attempt_no=2))
    U1, U2 = uid(), (conn.execute("INSERT INTO users (id) VALUES (2)"), 2)[1]
    T2 = parent(conn, "trainings.id")
    row(conn, "payments", training_id=T2, attempt_no=1, payer_user_id=U1, idempotency_key="key-aaaaaaaa")
    rejected("the same idempotency key twice for one payer", lambda: row(conn, "payments", training_id=parent(conn, "trainings.id"), attempt_no=1, payer_user_id=U1, idempotency_key="key-aaaaaaaa"),
             "payments.payer_user_id, payments.idempotency_key")
    ok("the same idempotency key for a DIFFERENT payer (keys are scoped)", lambda: row(conn, "payments", training_id=parent(conn, "trainings.id"), attempt_no=1, payer_user_id=U2, idempotency_key="key-aaaaaaaa"))
    ok("two payments without a key", lambda: (row(conn, "payments", training_id=parent(conn, "trainings.id"), attempt_no=1), row(conn, "payments", training_id=parent(conn, "trainings.id"), attempt_no=1)))
    row(conn, "payments", training_id=parent(conn, "trainings.id"), attempt_no=1, provider_order_id="order_X")
    rejected("the same provider order id twice for one provider", lambda: row(conn, "payments", training_id=parent(conn, "trainings.id"), attempt_no=1, provider_order_id="order_X"), "payments.provider, payments.provider_order_id")
    ok("the same order id at another provider", lambda: row(conn, "payments", training_id=parent(conn, "trainings.id"), attempt_no=1, provider_order_id="order_X", provider="other"))

    T3 = parent(conn, "trainings.id")
    ok("one PENDING attempt", lambda: row(conn, "payments", training_id=T3, attempt_no=1, status="PENDING"))
    rejected("a second PENDING attempt for the same training", lambda: row(conn, "payments", training_id=T3, attempt_no=2, status="PENDING"), "payments.training_id")
    rejected("a PROCESSING attempt next to the PENDING one", lambda: row(conn, "payments", training_id=T3, attempt_no=3, status="PROCESSING"), "payments.training_id")
    ok("closed attempts do not take the in-flight slot (FAILED, CANCELLED, EXPIRED, SUCCEEDED)", lambda: [row(conn, "payments", training_id=T3, attempt_no=10 + i, status=s) for i, s in enumerate(("FAILED", "CANCELLED", "EXPIRED", "SUCCEEDED"))])
    ok("another training can have its own PENDING attempt", lambda: row(conn, "payments", training_id=parent(conn, "trainings.id"), attempt_no=1, status="PENDING"))
    conn.execute("UPDATE payments SET status = 'FAILED' WHERE training_id = ? AND status = 'PENDING'", (T3,))
    ok("after the open attempt failed, a retry (new attempt) may start", lambda: row(conn, "payments", training_id=T3, attempt_no=20, status="PENDING"))
    rejected("reopening a closed attempt while another is in flight", lambda: conn.execute("UPDATE payments SET status = 'PENDING' WHERE training_id = ? AND attempt_no = 10", (T3,)), "payments.training_id")

    # ---- transactions: one CHARGE and one REFUND per payment, provider ids unique ----
    P = row(conn, "payments", training_id=parent(conn, "trainings.id"), attempt_no=1, status="SUCCEEDED")
    ok("a CHARGE transaction", lambda: row(conn, "payment_transactions", payment_id=P, provider_txn_id="txn_1"))
    rejected("a second CHARGE for the same payment", lambda: row(conn, "payment_transactions", payment_id=P, provider_txn_id="txn_2"), "payment_transactions.payment_id, payment_transactions.type")
    P2 = row(conn, "payments", training_id=parent(conn, "trainings.id"), attempt_no=1, status="SUCCEEDED")
    rejected("the same provider transaction id on another payment", lambda: row(conn, "payment_transactions", payment_id=P2, provider_txn_id="txn_1"), "provider_txn_id")
    ok("one REFUND transaction", lambda: row(conn, "payment_transactions", payment_id=P, type="REFUND", provider_txn_id="rf_1"))
    rejected("a second REFUND transaction", lambda: row(conn, "payment_transactions", payment_id=P, type="REFUND", provider_txn_id="rf_2"), "payment_transactions.payment_id, payment_transactions.type")
    rejected("an unknown transaction type", lambda: row(conn, "payment_transactions", payment_id=P2, type="PAYOUT", provider_txn_id="x1"), "ck_txn_type")
    rejected("a zero-amount transaction", lambda: row(conn, "payment_transactions", payment_id=P2, amount_paise=0, provider_txn_id="x2"), "ck_txn_amount_positive")

    # ---- webhook events: a provider event id is stored once ----
    ok("a webhook event", lambda: row(conn, "payment_webhook_events", event_id="evt_1", event_type="payment.succeeded", provider="sandbox"))
    rejected("the same provider event id twice (replay)", lambda: row(conn, "payment_webhook_events", event_id="evt_1", event_type="payment.succeeded", provider="sandbox"), "payment_webhook_events.provider, payment_webhook_events.event_id")
    ok("the same event id at another provider", lambda: row(conn, "payment_webhook_events", event_id="evt_1", event_type="payment.succeeded", provider="other"))

    # ---- invoices ----
    ok("an invoice", lambda: row(conn, "invoices", payment_id=P, number="ITB-2030-000001"))
    rejected("a second invoice for the same payment", lambda: row(conn, "invoices", payment_id=P, number="ITB-2030-000002"), "invoices.payment_id")
    rejected("a duplicate invoice number", lambda: row(conn, "invoices", payment_id=P2, number="ITB-2030-000001"), "invoices.number")
    rejected("a zero-amount invoice", lambda: row(conn, "invoices", payment_id=P2, number="ITB-2030-000009", amount_paise=0), "ck_invoice_amount_positive")
    ok("a counter row", lambda: row(conn, "invoice_counters", series="INV", year=2030, last_number=1))
    rejected("a second counter row for the same series and year", lambda: row(conn, "invoice_counters", series="INV", year=2030, last_number=1), "invoice_counters")
    ok("the same year in the credit-note series", lambda: row(conn, "invoice_counters", series="CN", year=2030, last_number=1))

    # ---- refunds ----
    ok("a PENDING refund", lambda: row(conn, "payment_refunds", payment_id=P, idempotency_key="refund-1"))
    rejected("a second refund of the same payment", lambda: row(conn, "payment_refunds", payment_id=P, idempotency_key="refund-1b"), "payment_refunds.payment_id")
    rejected("a duplicate refund idempotency key", lambda: row(conn, "payment_refunds", payment_id=P2, idempotency_key="refund-1"), "payment_refunds.idempotency_key")
    rejected("a SUCCEEDED refund without a credit note and completion time", lambda: row(conn, "payment_refunds", payment_id=P2, idempotency_key="refund-2", status="SUCCEEDED"), "ck_refund_completed")
    rejected("an unknown refund status", lambda: row(conn, "payment_refunds", payment_id=P2, idempotency_key="refund-2", status="PARTIAL"), "ck_refund_status")
    rejected("a zero refund", lambda: row(conn, "payment_refunds", payment_id=P2, idempotency_key="refund-2", amount_paise=0), "ck_refund_amount_positive")
    ok("a completed refund with a credit note", lambda: row(conn, "payment_refunds", payment_id=P2, idempotency_key="refund-3", status="SUCCEEDED", completed_at="2030-01-02 00:00:00", credit_note_number="ITB-CN-2030-000001"))
    P3 = row(conn, "payments", training_id=parent(conn, "trainings.id"), attempt_no=1, status="SUCCEEDED")
    rejected("a duplicate credit-note number", lambda: row(conn, "payment_refunds", payment_id=P3, idempotency_key="refund-4", status="SUCCEEDED", completed_at="2030-01-02 00:00:00", credit_note_number="ITB-CN-2030-000001"), "credit_note_number")

    # ---- earnings ----
    ok("a PENDING earning", lambda: row(conn, "trainer_earnings", payment_id=P))
    rejected("a second earning for the same payment", lambda: row(conn, "trainer_earnings", payment_id=P), "trainer_earnings.payment_id")
    for label, change, name in [
        ("net that is not gross minus commission", dict(net_paise=9001), "ck_earning_net"),
        ("commission above gross", dict(commission_paise=10_001, net_paise=-1), "ck_earning_commission_range"),
        ("zero gross", dict(gross_paise=0, commission_paise=0, net_paise=0), "ck_earning_gross_positive"),
        ("an unknown status", dict(status="RELEASED"), "ck_earning_status"),
        ("AVAILABLE without available_at", dict(status="AVAILABLE"), "ck_earning_available_at"),
        ("PAID without who, when and reference", dict(status="PAID", available_at="2030-01-01 00:00:00"), "ck_earning_paid_fields"),
        ("PAID without a payout reference", dict(status="PAID", available_at="2030-01-01 00:00:00", paid_at="2030-01-03 00:00:00", paid_by=1), "ck_earning_paid_fields"),
        ("paid_at on an earning that is not PAID", dict(status="AVAILABLE", available_at="2030-01-01 00:00:00", paid_at="2030-01-03 00:00:00"), "ck_earning_paid_only"),
    ]:
        rejected(f"earning with {label}", lambda change=change: row(conn, "trainer_earnings", payment_id=row(conn, "payments", training_id=parent(conn, "trainings.id"), attempt_no=1, status="SUCCEEDED"), **change), name)
    ok("a fully recorded PAID earning", lambda: row(conn, "trainer_earnings", payment_id=row(conn, "payments", training_id=parent(conn, "trainings.id"), attempt_no=1, status="SUCCEEDED"),
                                                    status="PAID", available_at="2030-01-01 00:00:00", paid_at="2030-01-03 00:00:00", paid_by=1, payout_reference="BATCH-1"))
    ok("an AVAILABLE earning", lambda: row(conn, "trainer_earnings", payment_id=row(conn, "payments", training_id=parent(conn, "trainings.id"), attempt_no=1, status="SUCCEEDED"),
                                           status="AVAILABLE", available_at="2030-01-01 00:00:00"))

    # ---- commission records ----
    ok("a commission record", lambda: row(conn, "platform_commissions", payment_id=P))
    rejected("a second commission record for the same payment", lambda: row(conn, "platform_commissions", payment_id=P), "platform_commissions.payment_id")
    rejected("REVERSED without reversed_at", lambda: row(conn, "platform_commissions", payment_id=P2, status="REVERSED"), "ck_commission_reversed_at")
    rejected("reversed_at on a RECORDED commission", lambda: row(conn, "platform_commissions", payment_id=P2, reversed_at="2030-01-02 00:00:00"), "ck_commission_reversed_at")
    ok("a REVERSED commission", lambda: row(conn, "platform_commissions", payment_id=P2, status="REVERSED", reversed_at="2030-01-02 00:00:00"))
    rejected("a commission rate above 100%", lambda: row(conn, "platform_commissions", payment_id=P3, rate_bps=10_001), "ck_commission_rate")

    # ---- review flags (Phase 13 remediation, migration 0006): several reasons per payment, one OPEN flag per reason ----
    PF = row(conn, "payments", training_id=parent(conn, "trainings.id"), attempt_no=1, status="SUCCEEDED")
    ok("an open review flag", lambda: row(conn, "payment_review_flags", payment_id=PF, reason="LATE_SUCCESS"))
    ok("a second, different open flag on the same payment", lambda: row(conn, "payment_review_flags", payment_id=PF, reason="DUPLICATE_CHARGE"))
    ok("a third open flag (every reason can be open at once)", lambda: row(conn, "payment_review_flags", payment_id=PF, reason="AMOUNT_MISMATCH"))
    rejected("a second OPEN flag with the same reason", lambda: row(conn, "payment_review_flags", payment_id=PF, reason="LATE_SUCCESS"), "payment_review_flags.payment_id, payment_review_flags.reason")
    rejected("an unknown reason", lambda: row(conn, "payment_review_flags", payment_id=PF, reason="WHATEVER"), "ck_review_flag_reason")
    rejected("a flag resolved without who and a note", lambda: row(conn, "payment_review_flags", payment_id=PF, reason="STUCK_PROCESSING", resolved_at="2030-01-02 00:00:00"), "ck_review_flag_resolution")
    rejected("a resolver without a resolution time", lambda: row(conn, "payment_review_flags", payment_id=PF, reason="STUCK_PROCESSING", resolved_by=uid(), resolution_note="x"), "ck_review_flag_resolution")
    rejected("a resolution note on an open flag", lambda: row(conn, "payment_review_flags", payment_id=PF, reason="STUCK_PROCESSING", resolution_note="x"), "ck_review_flag_resolution")
    ok("a fully resolved flag", lambda: row(conn, "payment_review_flags", payment_id=PF, reason="STUCK_PROCESSING", resolved_at="2030-01-02 00:00:00", resolved_by=uid(), resolution_note="checked"))
    ok("history: the same reason resolved twice (only OPEN flags are unique)", lambda: [row(conn, "payment_review_flags", payment_id=PF, reason="REFUND_STUCK", resolved_at=f"2030-01-0{i} 00:00:00", resolved_by=uid(), resolution_note="done") for i in (3, 4)])
    conn.execute("UPDATE payment_review_flags SET resolved_at='2030-01-05 00:00:00', resolved_by=?, resolution_note='ok' WHERE payment_id=? AND reason='LATE_SUCCESS'", (uid(), PF))
    ok("after that reason was resolved, the same reason can be flagged again", lambda: row(conn, "payment_review_flags", payment_id=PF, reason="LATE_SUCCESS"))
    rejected("a flag for a payment that does not exist", lambda: row(conn, "payment_review_flags", payment_id=999_999, reason="LATE_SUCCESS"), "FOREIGN KEY")
    rejected("deleting a payment that has review flags", lambda: conn.execute("DELETE FROM payments WHERE id = ?", (PF,)), "FOREIGN KEY")
    rejected("deleting a user who resolved a flag", lambda: conn.execute("DELETE FROM users WHERE id = (SELECT resolved_by FROM payment_review_flags WHERE resolved_by IS NOT NULL LIMIT 1)"), "FOREIGN KEY")

    # ---- ON DELETE RESTRICT: financial records cannot be removed from under their dependants ----
    rejected("deleting a payment that has transactions, an invoice, a refund, an earning and a commission record", lambda: conn.execute("DELETE FROM payments WHERE id = ?", (P,)), "FOREIGN KEY")
    rejected("deleting a user who made a payment", lambda: conn.execute("DELETE FROM users WHERE id = 1"), "FOREIGN KEY")
    rejected("deleting a training that has payments", lambda: conn.execute("DELETE FROM trainings WHERE id = ?", (T,)), "FOREIGN KEY")
    rejected("deleting an institution profile that has payments", lambda: conn.execute("DELETE FROM institution_profiles WHERE id = 1"), "FOREIGN KEY")
    rejected("deleting a trainer profile that has earnings", lambda: conn.execute("DELETE FROM trainer_profiles WHERE id = 1"), "FOREIGN KEY")
    rejected("a payment for a training that does not exist", lambda: row(conn, "payments", training_id=999_999, attempt_no=1), "FOREIGN KEY")
    rejected("a transaction for a payment that does not exist", lambda: row(conn, "payment_transactions", payment_id=999_999, provider_txn_id="ghost"), "FOREIGN KEY")
    ok("a payment nobody references can be deleted (RESTRICT only protects dependants)", lambda: conn.execute("DELETE FROM payments WHERE id = (SELECT id FROM payments p WHERE NOT EXISTS (SELECT 1 FROM payment_transactions t WHERE t.payment_id = p.id) AND NOT EXISTS (SELECT 1 FROM invoices i WHERE i.payment_id = p.id) AND NOT EXISTS (SELECT 1 FROM payment_refunds r WHERE r.payment_id = p.id) AND NOT EXISTS (SELECT 1 FROM trainer_earnings e WHERE e.payment_id = p.id) AND NOT EXISTS (SELECT 1 FROM platform_commissions c WHERE c.payment_id = p.id) AND NOT EXISTS (SELECT 1 FROM payment_webhook_events w WHERE w.payment_id = p.id) LIMIT 1)"))


# ---------- static structure checks (read the source with `ast`; they prove how the code is wired, not that it behaves) ----------
ROOT = Path(__file__).resolve().parent.parent / "backend" / "app"
MONEY_FILES = ["services/payment_rules.py", "services/payment_service.py", "services/payment_admin_service.py", "services/earning_service.py",
               "services/invoice_service.py", "models/payment.py", "schemas/payment.py"]


def static_checks() -> None:
    import ast
    trees = {f: ast.parse((ROOT / f).read_text()) for f in MONEY_FILES + ["api/v1/payments.py", "services/payment_providers.py"]}

    def check(label, good, detail=""):
        results.append((good, f"static: {label}" + ("" if good else f": {detail}")))

    # 1. money never touches floating point
    bad = []
    for f in MONEY_FILES:
        annotations = {id(x) for a in ast.walk(trees[f]) if isinstance(a, ast.arg) and a.annotation is not None for x in ast.walk(a.annotation)}   # `seconds: float` is time, not money
        for n in ast.walk(trees[f]):
            if id(n) in annotations:
                continue
            if isinstance(n, ast.BinOp) and isinstance(n.op, ast.Div):
                bad.append(f"{f}:{n.lineno} true division")
            if isinstance(n, ast.Name) and n.id in ("float", "Float", "Decimal"):
                bad.append(f"{f}:{n.lineno} {n.id}")
            if isinstance(n, ast.Constant) and isinstance(n.value, float):
                bad.append(f"{f}:{n.lineno} float literal {n.value}")
    check("no float, Decimal or true division in any payment module", not bad, "; ".join(bad))

    # 2. a provider result changes a payment only through process_event, which only handle_webhook and reconcile call
    callers = {}
    for f, tree in trees.items():
        for fn in [n for n in ast.walk(tree) if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))]:
            for c in [n for n in ast.walk(fn) if isinstance(n, ast.Call)]:
                name = getattr(c.func, "id", getattr(c.func, "attr", ""))
                callers.setdefault(name, set()).add((f.split("/")[-1], fn.name))
    check("process_event is called only by handle_webhook and reconcile's per-payment helper", callers.get("process_event", set()) <= {("payment_service.py", "handle_webhook"), ("payment_service.py", "_reconcile_one")},
          str(callers.get("process_event")))
    check("_reconcile_one is called only by reconcile", callers.get("_reconcile_one", set()) == {("payment_service.py", "reconcile")}, str(callers.get("_reconcile_one")))
    check("signed sandbox events are built only by the sandbox simulation", callers.get("build_signed_event", set()) == {("payment_service.py", "simulate")}, str(callers.get("build_signed_event")))
    check("handle_webhook is the only caller of the signature check", callers.get("check_webhook", set()) == {("payment_service.py", "handle_webhook")}, str(callers.get("check_webhook")))
    check("the sandbox simulation reaches the same handle_webhook", ("payment_service.py", "simulate") in callers.get("handle_webhook", set()))
    check("the provider refund is called only from complete_refund", callers.get("refund", set()) <= {("payment_admin_service.py", "complete_refund")}, str(callers.get("refund")))
    check("PaymentRefund rows are created only by request_refund", callers.get("PaymentRefund", set()) <= {("payment_admin_service.py", "request_refund")}, str(callers.get("PaymentRefund")))
    check("TrainerEarning rows are created only by the settlement step", callers.get("TrainerEarning", set()) <= {("payment_service.py", "_settle")}, str(callers.get("TrainerEarning")))
    check("Invoice rows are created only by invoice_service.issue", callers.get("Invoice", set()) <= {("invoice_service.py", "issue")}, str(callers.get("Invoice")))
    check("PlatformCommission rows are created only by the settlement step", callers.get("PlatformCommission", set()) <= {("payment_service.py", "_settle")}, str(callers.get("PlatformCommission")))

    # 3. a payment's status is assigned only where the state machine allows it
    allowed = {"process_event", "cancel_payment", "on_training_cancelled", "_expire"}
    writers = set()
    for f in ("services/payment_service.py", "services/payment_admin_service.py", "services/earning_service.py"):
        for fn in [n for n in ast.walk(trees[f]) if isinstance(n, ast.FunctionDef)]:
            for n in ast.walk(fn):
                if isinstance(n, ast.Assign) and any(isinstance(t, ast.Attribute) and t.attr == "status" and getattr(t.value, "id", "") == "p" for t in n.targets):
                    writers.add(fn.name)
    check("Payment.status is assigned only in " + ", ".join(sorted(allowed)), writers <= allowed, str(writers - allowed))
    check("process_event guards every status change with can_transition", "can_transition" in ast.unparse(next(n for n in ast.walk(trees["services/payment_service.py"]) if isinstance(n, ast.FunctionDef) and n.name == "process_event")))

    # 4. the HTTP surface: no PATCH/PUT/DELETE at all, and exactly the expected POSTs
    routes = []
    for n in ast.walk(trees["api/v1/payments.py"]):
        if isinstance(n, ast.FunctionDef):
            for d in n.decorator_list:
                if isinstance(d, ast.Call) and isinstance(d.func, ast.Attribute) and d.func.attr in ("get", "post", "put", "patch", "delete"):
                    routes.append((d.func.attr, d.args[0].value, n))
    check("the payments API has no PUT, PATCH or DELETE route", not [r for r in routes if r[0] in ("put", "patch", "delete")])
    check("the POST routes are exactly create, cancel, sandbox, webhook and the admin refund / resolve-review / payout",
          sorted(r[1] for r in routes if r[0] == "post") == sorted(["/payments/webhook", "/trainings/{tid}/payments", "/payments/{pid}/cancel", "/payments/{pid}/sandbox/{outcome}",
                                                                      "/admin/payments/{pid}/refund", "/admin/payments/{pid}/resolve-review", "/admin/earnings/{eid}/payout"]))
    unprotected = [r[1] for r in routes if "require_roles" not in ast.unparse(r[2]) and r[1] != "/payments/webhook"]
    check("every route except the signed webhook requires a role", not unprotected, str(unprotected))
    admin_routes = [r for r in routes if r[1].startswith("/admin/")]
    check("every /admin route requires exactly the ADMIN role", admin_routes and all("require_roles('ADMIN')" in ast.unparse(r[2]) for r in admin_routes))
    check("no body field of the create request can carry a status, rate or fee", {a.target.id for a in ast.walk(trees["schemas/payment.py"]) if isinstance(a, ast.AnnAssign)
          and isinstance(a.target, ast.Name)} .isdisjoint({"status", "commission_bps", "platform_fee_paise", "net_paise", "paid_at"}))
    # 5. no card, bank or UPI field anywhere in the models or schemas
    words = ("card", "cvv", "cvc", "pan_number", "account_number", "ifsc", "upi", "vpa")
    named = [f"{f}:{n.target.id}" for f in ("models/payment.py", "schemas/payment.py") for n in ast.walk(trees[f]) if isinstance(n, ast.AnnAssign) and isinstance(n.target, ast.Name)
             and any(w in n.target.id.lower() for w in words)]
    check("no card, bank-account or UPI field exists in the payment models or schemas", not named, str(named))

    # 6. wiring of the fixes made after the independent review
    def fn_src(tree, name):
        return ast.unparse(next(n for n in ast.walk(tree) if isinstance(n, ast.FunctionDef) and n.name == name))

    svc = trees["services/payment_service.py"]
    check("the final commission is computed at settlement by settle_commission", "settle_commission" in fn_src(svc, "_settle"))
    check("every successful payment gets an invoice (process_event settles on d.invoice, the earning only when d.settle)",
          "d.invoice" in fn_src(svc, "process_event") and "full=d.settle" in fn_src(svc, "process_event"))
    check("handle_webhook does not depend on PAYMENTS_ENABLED (a charge made earlier must still be recorded)",
          "payments_enabled" not in fn_src(svc, "handle_webhook") and "payments_on" not in fn_src(svc, "handle_webhook"))
    uses = [fn.name for fn in ast.walk(svc) if isinstance(fn, ast.FunctionDef) and "settings.payments_enabled" in ast.unparse(fn)]
    check("settings.payments_enabled is read only by payments_on", uses == ["payments_on"], str(uses))
    rec = fn_src(svc, "reconcile")
    check("reconcile isolates each payment and each later step with try/except and rolls back", rec.count("except Exception") >= 2 and rec.count("rollback()") >= 2)
    guard = {f: "assert_safe_payment_config" in (ROOT / f).read_text() for f in ("main.py", "workers/payments.py", "workers/loop.py")}
    check("the API, the payment worker and the scheduler loop all run the payment config guard", all(guard.values()), str(guard))
    ts = ast.parse((ROOT / "services/training_service.py").read_text())
    for name in ("complete", "cancel"):
        src = fn_src(ts, name)
        check(f"training_service.{name} locks and re-reads the training before checking it is ACTIVE", "refresh(t, with_for_update=True)" in src
              and src.index("refresh(t, with_for_update=True)") < src.index("_require_active"))
    api = (ROOT / "api/v1/payments.py").read_text()
    check("the webhook refuses an oversized body", "MAX_WEBHOOK_BYTES" in api and "413" in api)

    # 7. wiring of the Phase 13 remediation (static: it shows how the code is connected, NOT that it behaves; the service code has still never run)
    pe = fn_src(svc, "process_event")
    check("B1: the fee cap in process_event is measured on SETTLED money of the other payments (settled_totals), not on money held (collected_paise)",
          "settled_totals(db, t.id, exclude_payment_id=p.id)" in pe and "collected_paise" not in pe, pe[:0])
    check("B1: the finalised commission uses the same settled basis", "settled_totals" in fn_src(svc, "_settle") or "settled" in fn_src(svc, "_settle"))
    st = fn_src(svc, "settled_totals")
    check("B1: settled_totals counts only SUCCEEDED payments with a RECORDED commission and can exclude one payment", "C_RECORDED" in st and "SUCCEEDED" in st and "exclude_payment_id" in st)
    flag_callers = callers.get("PaymentReviewFlag", set())
    check("B2: PaymentReviewFlag rows are created only by flag_for_review", flag_callers <= {("payment_service.py", "flag_for_review")}, str(flag_callers))
    sets = set()
    for f in ("services/payment_service.py", "services/payment_admin_service.py", "services/earning_service.py"):
        for fn in [n for n in ast.walk(trees[f]) if isinstance(n, ast.FunctionDef)]:
            for n in ast.walk(fn):
                targets = n.targets if isinstance(n, ast.Assign) else [n.target] if isinstance(n, ast.AugAssign) else []
                for t in targets:
                    for e in (t.elts if isinstance(t, ast.Tuple) else [t]):
                        if isinstance(e, ast.Attribute) and e.attr in ("needs_review", "review_reason"):
                            sets.add(fn.name)
    check("B2: needs_review / review_reason are written only by sync_review_state (the summary of the open flags)", sets <= {"sync_review_state"}, str(sets))
    rr = fn_src(trees["services/payment_admin_service.py"], "resolve_review")
    check("B2: resolve_review picks ONE flag with pick_flag, applies resolve_refusal to it and re-syncs the summary", "pick_flag" in rr and "resolve_refusal(picked" in rr and "sync_review_state" in rr)
    check("B2: the resolve route passes the named reason", "body.reason" in api)
    check("order id: create_payment validates the provider order id before the insert", fn_src(svc, "create_payment").index("valid_order_id") < fn_src(svc, "create_payment").index("db.add(p)"))
    check("reconcile takes the least recently visited attempts first", "order_by(Payment.updated_at, Payment.id)" in fn_src(svc, "reconcile") and "_touch" in fn_src(svc, "_reconcile_one"))
    ns_src = (ROOT / "services/notification_service.py").read_text()
    nes = fn_src(ast.parse(ns_src), "notify_event_safe")
    check("notifications: notify_event_safe runs inside begin_nested(), catches Exception, logs with a traceback and returns False", "begin_nested()" in nes and "except Exception" in nes and "log.exception" in nes and "return False" in nes)
    safe_callers = {c for c in ("payment_service.py", "payment_admin_service.py", "earning_service.py", "training_service.py")}
    plain = []
    for f in ("services/payment_service.py", "services/payment_admin_service.py", "services/earning_service.py"):
        plain += [f"{f}:{n.lineno}" for n in ast.walk(trees[f]) if isinstance(n, ast.Call) and getattr(n.func, "id", "") in ("notify_event", "notify")]
    check("notifications: no payment, refund, payout or earning code calls the unprotected notify_event / notify", not plain, str(plain) + str(safe_callers))
    check("notifications: completing a training (which releases earnings) uses notify_event_safe only", "notify_event(" not in fn_src(ts, "complete"))
    pg = (ROOT / "core/payment_guard.py").read_text()
    check("config: the guard passes the sandbox opt-in and no longer depends on pydantic internals to tell whether ENVIRONMENT was set", "sandbox_opt_in=settings.payment_sandbox_enabled" in pg and "environment_explicit" not in pg and "model_fields_set" not in pg)
    check("config: the sandbox is usable only through rules.sandbox_usable (payments switch + opt-in + development/test)", "sandbox_usable" in fn_src(svc, "payments_on"))
    check("config: the sandbox opt-in defaults to false", "payment_sandbox_enabled: bool = False" in (ROOT / "core/config.py").read_text())
    landing = (Path(__file__).resolve().parents[1] / "frontend/src/pages/Landing.jsx").read_text()
    check("landing page: no unsupported 'spending trends' / analytics claim", "spending trend" not in landing.lower() and "Analytics" not in landing and "Trend analytics are not available yet" in landing)


def main() -> int:
    static_checks()
    conn, chain = cm.strict_database()
    try:
        scenarios(conn)
    finally:
        conn.close()
        cm.strict_database_close()
    bad = [m for good, m in results if not good]
    for good, m in results:
        print(("PASS  " if good else "FAIL  ") + m)
    print(f"\n{len(results) - len(bad)} passed, {len(bad)} failed (real SQL in SQLite {sqlite3.sqlite_version}; NOT PostgreSQL, no concurrency)")
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
