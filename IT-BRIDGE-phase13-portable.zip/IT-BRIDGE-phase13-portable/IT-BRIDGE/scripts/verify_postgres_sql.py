#!/usr/bin/env python3
"""Phase 13 remediation: SQL-LEVEL checks on a REAL PostgreSQL server (needs only the `psql` client and Python's standard library).

WHAT THIS IS
  * It builds the schema of migrations 0001-0007 by replaying them through the project's own recording stub (scripts/check_migrations_static.py)
    and sending the DDL it records to PostgreSQL. 0001-0004 are built loosely (primary keys only); 0005, 0006 and 0007 carry their real
    constraints, partial unique indexes, functions and triggers.
  * It then attacks the database directly: constraints, the 0006 backfill, the 0007 integrity triggers (with the exact insert order the services
    use), the SQL of the fee-cap query, and a set of CONCURRENCY PROBES that use several simultaneous psql sessions: one-in-flight payment,
    scoped idempotency key, duplicate webhook, first-time invoice numbering, refund racing with payout, and lock ordering with a deadlock control.

WHAT THIS IS NOT
  * It is NOT Alembic: the DDL text comes from the stub, so `alembic upgrade head`, `alembic downgrade` and the model/migration drift check
    (backend/tests/test_migrations_postgres.py) are NOT covered by it.
  * It is NOT the application: no SQLAlchemy, FastAPI or service code runs, so the five service-level concurrency scenarios in
    backend/tests/test_postgres_concurrency.py are NOT covered by it. The probes below are SQL mirrors of the services' locking and uniqueness
    patterns; they show how PostgreSQL behaves, not that the Python code uses the patterns correctly.

USAGE  (libpq environment variables select the server; the database itb_verify_test is DROPPED and recreated)
    PGHOST=127.0.0.1 PGPORT=55432 PGUSER=postgres python scripts/verify_postgres_sql.py

SAFETY. It refuses (exit 3) to do anything, and connects to nothing, unless
  * PGHOST is exactly 127.0.0.1 or ::1, PGPORT is set, 1024-65535 and not 5432, and no other libpq variable is set except PGUSER, PGPASSWORD and
    PGCONNECT_TIMEOUT (PGHOSTADDR, PGSERVICE, PGDATABASE, PGOPTIONS ... could send a connection elsewhere);
  * the database name (ITB_PG_VERIFY_DB) is itb_verify_test followed by at most 20 of [a-z0-9_].
and then, in the SAME psql session that executes `DROP DATABASE IF EXISTS`, a server-side guard raises unless the server is a PostgreSQL 16 primary
whose cluster was prepared for this on purpose: at least one other database carries the comment ITB_PHASE13_DISPOSABLE
(COMMENT ON DATABASE itbridge_test IS 'ITB_PHASE13_DISPOSABLE'), EVERY database except `postgres` carries it, and an existing itb_verify_test carries it.
The database it creates gets the comment too. A server that also holds a development or production database is therefore never touched.
Exit code 1 on any failure, 2 when no PostgreSQL server can be reached (the checks are then BLOCKED, not passed), 3 when a safety rule refused.
"""
import os
import re
import subprocess
import sys
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import check_migrations_static as cm  # noqa: E402

DB = os.environ.get("ITB_PG_VERIFY_DB", "itb_verify_test")
MARKER = "ITB_PHASE13_DISPOSABLE"
ALLOWED_PG_ENV = {"PGHOST", "PGPORT", "PGUSER", "PGPASSWORD", "PGCONNECT_TIMEOUT"}
RESULTS: list[tuple[bool, str]] = []


class Refused(Exception):
    pass


def environment_problems(environ=None, db: str | None = None) -> list[str]:
    """Pure. Everything that could make the DROP DATABASE below reach a server other than the throwaway one. Empty list = nothing wrong."""
    environ = os.environ if environ is None else environ
    out = [f"{k} is set (not allowed: it could redirect the connection)" for k in sorted(environ) if k.startswith("PG") and k not in ALLOWED_PG_ENV]
    if environ.get("PGHOST") not in ("127.0.0.1", "::1"):
        out.append(f"PGHOST must be exactly 127.0.0.1 or ::1 (it is {environ.get('PGHOST')!r}; 'localhost' and unix sockets are not accepted)")
    port = environ.get("PGPORT", "")
    if not re.fullmatch(r"[1-9][0-9]{3,4}", port) or not 1024 <= int(port) <= 65535 or port == "5432":
        out.append(f"PGPORT must be a port in 1024-65535 other than 5432 (it is {port!r}); use the throwaway cluster's own port")
    if "PGUSER" in environ and not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]{0,62}", environ["PGUSER"]):
        out.append("PGUSER must match [A-Za-z_][A-Za-z0-9_]*")
    if not re.fullmatch(r"itb_verify_test[a-z0-9_]{0,20}", DB if db is None else db):
        out.append(f"ITB_PG_VERIFY_DB {DB if db is None else db!r} must be itb_verify_test followed by at most 20 of [a-z0-9_]")
    return out


def server_guard(db: str) -> str:
    """Server-side guard, a DO block that RAISES. `db` has been checked against a fixed pattern, so quoting it is safe."""
    mk = "coalesce(shobj_description(d.oid, 'pg_database'), '')"
    return (
        "DO $itbguard$ BEGIN "
        "IF current_setting('server_version_num')::int NOT BETWEEN 160000 AND 169999 THEN RAISE EXCEPTION 'itb gate: PostgreSQL 16 is required'; END IF; "
        "IF pg_is_in_recovery() THEN RAISE EXCEPTION 'itb gate: the server is a replica'; END IF; "
        f"IF NOT EXISTS (SELECT 1 FROM pg_database d WHERE NOT d.datistemplate AND d.datname NOT IN ('postgres', '{db}') AND {mk} = '{MARKER}') THEN "
        f"RAISE EXCEPTION 'itb gate: no database of this cluster carries the {MARKER} comment: it was not prepared as a throwaway cluster'; END IF; "
        f"IF EXISTS (SELECT 1 FROM pg_database d WHERE NOT d.datistemplate AND d.datname <> 'postgres' AND {mk} <> '{MARKER}') THEN "
        f"RAISE EXCEPTION 'itb gate: the cluster holds a database without the {MARKER} comment (including an existing {db} without it)'; END IF; "
        "END $itbguard$;"
    )


# ---------- psql plumbing ----------
def psql(sql: str, db: str | None = DB, timeout: int = 120) -> tuple[int, str, str]:
    cmd = ["psql", "-X", "-q", "-t", "-A", "-v", "ON_ERROR_STOP=1", "-v", "VERBOSITY=verbose"] + (["-d", db] if db else [])
    env = {k: v for k, v in os.environ.items() if not k.startswith("PG") or k in ALLOWED_PG_ENV}      # same set environment_problems() accepts
    env.setdefault("PGCONNECT_TIMEOUT", "5")
    r = subprocess.run(cmd, input=sql, capture_output=True, text=True, timeout=timeout, env=env)
    return r.returncode, r.stdout.strip(), r.stderr.strip()


def check(label: str, good: bool, detail: str = "") -> None:
    RESULTS.append((good, label + ("" if good else f"  -> {detail}")))


def accepted(label: str, sql: str) -> None:
    rc, out, err = psql(sql)
    check(f"accepted: {label}", rc == 0, err)


def rejected(label: str, sql: str, wanted: str, sqlstate: str | None = None) -> None:
    rc, out, err = psql(sql)
    good = rc != 0 and wanted.lower() in err.lower() and (sqlstate is None or sqlstate in err)
    check(f"rejected: {label}", good, ("was ACCEPTED" if rc == 0 else f"wrong error: {err[:300]} (wanted {wanted!r}{', ' + sqlstate if sqlstate else ''})"))


def scalar(sql: str):
    rc, out, err = psql(sql)
    if rc != 0:
        raise RuntimeError(err)
    return out


# ---------- schema ----------
class Rec:
    """Collects the statements the stub would have executed."""
    def __init__(self):
        self.s: list[str] = []

    def execute(self, sql):
        self.s.append(str(sql))
        return self

    def fetchone(self):
        return (0,)


def build_ddl() -> dict[str, str]:
    cm.SQLITE_TYPES.update({"String": "TEXT", "Integer": "INTEGER", "BigInteger": "BIGINT", "Boolean": "BOOLEAN", "DateTime": "TIMESTAMPTZ",
                            "Date": "DATE", "Time": "TIME", "Float": "DOUBLE PRECISION", "JSON": "JSON"})
    orig = cm._ddl_type

    def ddl_type(col):
        t = col.type
        return f"VARCHAR({t.args})" if t.name == "String" and t.args else orig(col)
    cm._ddl_type = ddl_type
    cm.Bind.dialect.name = "postgresql"
    chain = cm.load_chain()
    rec = Rec()
    cm.Op.conn, cm.Op.loose_pk = rec, True
    out = {}
    for m in chain[:4]:
        m.upgrade()
    out["0001-0004"], rec.s = ";\n".join(rec.s) + ";\n", []
    cm.Op.strict = True
    for m in chain[4:]:
        m.upgrade()
        out[m.revision], rec.s = ";\n".join(rec.s) + ";\n", []
    for m in reversed(chain[4:]):
        m.downgrade()
        out["down" + m.revision], rec.s = ";\n".join(rec.s) + ";\n", []
    cm.Op.conn = None
    # Alembic/SQLAlchemy create a SERIAL for an integer primary key; the stub emits a bare INTEGER NOT NULL. Give the strict tables the same default.
    return {k: v.replace('"id" INTEGER NOT NULL', '"id" INTEGER GENERATED BY DEFAULT AS IDENTITY') for k, v in out.items()}


def create_database() -> None:
    """DROP + CREATE in one psql session, the guard first. ON_ERROR_STOP makes a raising guard end the script before DROP DATABASE is sent."""
    problems = environment_problems()
    if problems:
        raise Refused("; ".join(problems))
    script = server_guard(DB) + f'\nDROP DATABASE IF EXISTS "{DB}";\nCREATE DATABASE "{DB}";\nCOMMENT ON DATABASE "{DB}" IS \'{MARKER}\';\n'
    rc, _, err = psql(script, db="postgres")
    if rc != 0:
        if "itb gate:" in err:
            raise Refused(err.split("itb gate:", 1)[1].splitlines()[0].strip())
        raise RuntimeError(err)


# ---------- fixtures ----------
NOW = "now()"


def fixtures() -> str:
    """Parents of the payment tables. The loose 0001-0004 tables need only their id."""
    return ("INSERT INTO users (id) VALUES (1), (2), (3); INSERT INTO institution_profiles (id) VALUES (1); INSERT INTO trainer_profiles (id) VALUES (1);"
            "INSERT INTO trainings (id) SELECT g FROM generate_series(1, 70) g;")


_pid = [1000]


def payment(training=1, status="SUCCEEDED", amount=10_000, fee=1_000, bps=1000, attempt=1, payer=2, key=None, order=None, pid=None, **extra) -> tuple[int, str]:
    _pid[0] += 1
    pid = pid or _pid[0]
    cols = dict(id=pid, training_id=training, institution_id=1, trainer_id=1, payer_user_id=payer, attempt_no=attempt, amount_paise=amount, currency="'INR'",
                commission_bps=bps, platform_fee_paise=fee, net_paise=amount - fee, status=f"'{status}'", provider="'sandbox'",
                provider_order_id=f"'ord-{pid}'" if order is None else f"'{order}'", request_fingerprint="'" + "f" * 64 + "'", needs_review="false",
                created_at=NOW, updated_at=NOW)
    if key:
        cols["idempotency_key"] = f"'{key}'"
    if status == "SUCCEEDED":
        cols["paid_at"] = NOW
    cols.update(extra)
    return pid, f"INSERT INTO payments ({', '.join(cols)}) VALUES ({', '.join(str(v) for v in cols.values())});"


def children(pid, training, amount=10_000, fee=1_000, bps=1000) -> str:
    return (f"INSERT INTO invoices (id, payment_id, number, institution_id, trainer_id, training_id, amount_paise, currency, snapshot, issued_at) "
            f"VALUES ({pid}, {pid}, 'ITB-2030-{pid:06d}', 1, 1, {training}, {amount}, 'INR', '{{}}', {NOW});"
            f"INSERT INTO payment_transactions (id, payment_id, type, amount_paise, provider, provider_txn_id, created_at) "
            f"VALUES ({pid}, {pid}, 'CHARGE', {amount}, 'sandbox', 'txn-{pid}', {NOW});"
            f"INSERT INTO trainer_earnings (id, payment_id, trainer_id, training_id, gross_paise, commission_paise, net_paise, status, created_at, updated_at) "
            f"VALUES ({pid}, {pid}, 1, {training}, {amount}, {fee}, {amount - fee}, 'PENDING', {NOW}, {NOW});"
            f"INSERT INTO platform_commissions (id, payment_id, rate_bps, amount_paise, status, created_at) VALUES ({pid}, {pid}, {bps}, {fee}, 'RECORDED', {NOW});")


# ---------- group A: schema, indexes, 0006 backfill ----------
def group_schema(ddl: dict[str, str]) -> None:
    for rev in ("0001-0004", "0005"):
        rc, _, err = psql(ddl[rev])
        check(f"DDL of {rev} applies on PostgreSQL", rc == 0, err)
    # 0006 backfill: payments that were flagged / resolved under the single-reason columns
    seed = fixtures()
    rows = []
    for i, (needs, reason, by, at, note) in enumerate([
        ("true", "'OVER_CAP'", "NULL", "NULL", "'x'"),                              # open flag
        ("false", "'LATE_SUCCESS'", "2", f"{NOW}", "'looked at it'"),               # resolved
        ("false", "NULL", "NULL", "NULL", "NULL"),                                  # never flagged
        ("false", "'DUPLICATE_CHARGE'", "NULL", "NULL", "NULL"),                    # cleared without a resolver: cannot be represented, skipped
    ], start=1):
        _, sql = payment(training=i, status="SUCCEEDED", attempt=1, pid=500 + i, needs_review=needs, review_reason=reason, reviewed_by=by, reviewed_at=at, review_note=note)
        rows.append(sql)
    rc, _, err = psql(seed + "".join(rows))
    check("legacy flagged/resolved payments can be inserted before 0006", rc == 0, err)
    rc, _, err = psql(ddl["0006"])
    check("DDL of 0006 applies on PostgreSQL, including its backfill", rc == 0, err)
    out = scalar("SELECT string_agg(payment_id || ':' || reason || ':' || (resolved_at IS NOT NULL) || ':' || coalesce(resolution_note, '-'), ' | ' ORDER BY payment_id) FROM payment_review_flags")
    check("0006 backfill: the open flag stays open, the resolved one becomes history, the others are not invented",
          out == "501:OVER_CAP:false:- | 502:LATE_SUCCESS:true:looked at it", out)
    rc, _, err = psql(ddl["0007"])
    check("DDL of 0007 (functions and triggers) applies on PostgreSQL", rc == 0, err)
    n = scalar("SELECT count(*) FROM pg_trigger WHERE NOT tgisinternal")
    check("8 integrity triggers are installed", n == "8", n)
    idx = scalar("SELECT indexdef FROM pg_indexes WHERE indexname = 'uq_review_flag_open'")
    check("uq_review_flag_open is a UNIQUE partial index on (payment_id, reason) WHERE resolved_at IS NULL",
          "UNIQUE" in idx and "(payment_id, reason)" in idx and "WHERE (resolved_at IS NULL)" in idx, idx)
    idx = scalar("SELECT indexdef FROM pg_indexes WHERE indexname = 'uq_payment_one_in_flight'")
    check("uq_payment_one_in_flight is a UNIQUE partial index on training_id for PENDING/PROCESSING", "UNIQUE" in idx and "training_id" in idx and "PENDING" in idx and "PROCESSING" in idx, idx)


# ---------- group B: constraints of the review flags ----------
def group_flags() -> None:
    pid, sql = payment(training=10, pid=700)
    accepted("a payment to attach flags to", sql)
    ins = lambda reason, extra="": f"INSERT INTO payment_review_flags (payment_id, reason, created_at{', ' + extra[0] if extra else ''}) VALUES (700, '{reason}', now(){', ' + extra[1] if extra else ''});"  # noqa: E731
    accepted("flag LATE_SUCCESS", ins("LATE_SUCCESS"))
    accepted("a different open flag on the same payment (DUPLICATE_CHARGE)", ins("DUPLICATE_CHARGE"))
    accepted("a third open flag (AMOUNT_MISMATCH)", ins("AMOUNT_MISMATCH"))
    rejected("a second open flag with the same reason", ins("LATE_SUCCESS"), "uq_review_flag_open", "23505")
    rejected("an unknown reason", ins("BOGUS"), "ck_review_flag_reason", "23514")
    rejected("resolved without resolver and note", ins("OVER_CAP", ("resolved_at", "now()")), "ck_review_flag_resolution", "23514")
    accepted("a fully resolved flag", ins("OVER_CAP", ("resolved_at, resolved_by, resolution_note", "now(), 1, 'refunded'")))
    accepted("resolving one open flag leaves the others open",
             "UPDATE payment_review_flags SET resolved_at = now(), resolved_by = 1, resolution_note = 'done' WHERE payment_id = 700 AND reason = 'DUPLICATE_CHARGE';")
    check("two flags are still open on the payment", scalar("SELECT count(*) FROM payment_review_flags WHERE payment_id = 700 AND resolved_at IS NULL") == "2")
    accepted("the resolved reason can be flagged again", ins("DUPLICATE_CHARGE"))
    rejected("deleting a payment that has flags", "DELETE FROM payments WHERE id = 700;", "foreign key", "23503")


# ---------- group C: the 0007 triggers, replaying the services' insert order ----------
def group_triggers() -> None:
    # normal settlement: payment SUCCEEDED first, then invoice, charge, earning, commission (payment_service.process_event / invoice_service.issue)
    pid, sql = payment(training=11, pid=800)
    accepted("settlement in the service's order: SUCCEEDED payment, invoice, charge, earning, commission", sql + children(800, 11))
    # over-cap payment: invoice and charge only, fee 0
    pid2, sql2 = payment(training=11, attempt=2, fee=0, pid=801)
    accepted("an over-cap payment: SUCCEEDED, fee 0, invoice and charge, no earning, no commission", sql2 + children(801, 11, fee=0).split("INSERT INTO trainer_earnings")[0])
    # refund of the settled payment: full amount, then credit note
    accepted("a full refund of a SUCCEEDED payment with its ledger row", "INSERT INTO payment_refunds (id, payment_id, amount_paise, status, idempotency_key, attempts, created_by, created_at, completed_at, credit_note_number) "
             "VALUES (800, 800, 10000, 'SUCCEEDED', 'refund-800', 1, 1, now(), now(), 'ITB-CN-2030-000001');"
             "INSERT INTO payment_transactions (id, payment_id, type, amount_paise, provider, provider_txn_id, created_at) VALUES (9800, 800, 'REFUND', 10000, 'sandbox', 'rf-800', now());")
    accepted("status, review state and timestamps of a payment may change (not identity columns)",
             "UPDATE payments SET status = 'SUCCEEDED', needs_review = true, review_reason = 'LATE_SUCCESS', updated_at = now(), provider_meta = '{}' WHERE id = 800;")
    accepted("the earning and the commission may change status (they are not immutable)",
             "UPDATE trainer_earnings SET status = 'REFUNDED', updated_at = now() WHERE id = 800; UPDATE platform_commissions SET status = 'REVERSED', reversed_at = now() WHERE id = 800;")
    # --- children must agree with the payment ---
    pid, sql = payment(training=12, status="PENDING", pid=810)
    accepted("a PENDING payment", sql)
    base = "INSERT INTO invoices (id, payment_id, number, institution_id, trainer_id, training_id, amount_paise, currency, snapshot, issued_at) VALUES (%d, %d, '%s', 1, 1, %d, %d, 'INR', '{}', now());"
    rejected("an invoice for a PENDING payment", base % (810, 810, "ITB-2030-900001", 12, 10_000), "invoice does not match", "23000")
    pid, sql = payment(training=13, pid=811)
    accepted("a SUCCEEDED payment", sql)
    rejected("an invoice with another amount", base % (811, 811, "ITB-2030-900002", 13, 9_999), "invoice does not match", "23000")
    rejected("an invoice for another training", base % (811, 811, "ITB-2030-900003", 14, 10_000), "invoice does not match", "23000")
    rejected("an invoice for a payment that does not exist (the trigger runs before the foreign key check)", base % (99, 9999, "ITB-2030-900004", 13, 10_000), "invoice does not match", "23000")
    ear = "INSERT INTO trainer_earnings (id, payment_id, trainer_id, training_id, gross_paise, commission_paise, net_paise, status, created_at, updated_at) VALUES (811, 811, 1, 13, %d, %d, %d, 'PENDING', now(), now());"
    rejected("an earning with another gross", ear % (9_000, 900, 8_100), "earning does not match", "23000")
    rejected("an earning with another commission (still a valid earning row)", ear % (10_000, 500, 9_500), "earning does not match", "23000")
    rejected("an earning for a PENDING payment", "INSERT INTO trainer_earnings (id, payment_id, trainer_id, training_id, gross_paise, commission_paise, net_paise, status, created_at, updated_at) "
             "VALUES (812, 810, 1, 12, 10000, 1000, 9000, 'PENDING', now(), now());", "earning does not match", "23000")
    com = "INSERT INTO platform_commissions (id, payment_id, rate_bps, amount_paise, status, created_at) VALUES (811, 811, %d, %d, 'RECORDED', now());"
    rejected("a commission with another amount", com % (1000, 999), "commission does not match", "23000")
    rejected("a commission with another rate", com % (500, 1000), "commission does not match", "23000")
    rejected("a commission for a PENDING payment", "INSERT INTO platform_commissions (id, payment_id, rate_bps, amount_paise, status, created_at) VALUES (812, 810, 1000, 1000, 'RECORDED', now());", "commission does not match", "23000")
    ref = "INSERT INTO payment_refunds (id, payment_id, amount_paise, status, idempotency_key, attempts, created_by, created_at) VALUES (%d, %d, %d, 'PENDING', 'rk-%d', 0, 1, now());"
    rejected("a partial refund", ref % (811, 811, 5_000, 811), "does not match the amount", "23000")
    rejected("a refund larger than the payment", ref % (811, 811, 10_001, 811), "does not match the amount", "23000")
    rejected("a refund of a PENDING payment", ref % (810, 810, 10_000, 810), "only a SUCCEEDED payment", "23000")
    txn = "INSERT INTO payment_transactions (id, payment_id, type, amount_paise, provider, provider_txn_id, created_at) VALUES (%d, %d, '%s', %d, 'sandbox', '%s', now());"
    rejected("a ledger row with another amount", txn % (811, 811, "CHARGE", 9_999, "t-811"), "does not match the amount", "23000")
    # --- immutability ---
    rejected("updating an invoice", "UPDATE invoices SET number = 'ITB-2030-777777' WHERE id = 800;", "immutable", "23000")
    rejected("updating an invoice's amount", "UPDATE invoices SET amount_paise = amount_paise + 1 WHERE id = 800;", "immutable", "23000")
    rejected("deleting an invoice", "DELETE FROM invoices WHERE id = 800;", "immutable", "23000")
    rejected("updating a ledger row", "UPDATE payment_transactions SET amount_paise = 1 WHERE id = 800;", "immutable", "23000")
    rejected("deleting a ledger row", "DELETE FROM payment_transactions WHERE id = 800;", "immutable", "23000")
    for col, val in [("amount_paise", "amount_paise + 1"), ("currency", "'USD'"), ("training_id", "20"), ("institution_id", "2"), ("trainer_id", "2"), ("payer_user_id", "3"),
                     ("provider", "'other'"), ("provider_order_id", "'changed'"), ("attempt_no", "attempt_no + 5"), ("idempotency_key", "'changed-key'"),
                     ("request_fingerprint", "'" + "e" * 64 + "'")]:
        rejected(f"changing payments.{col} after the fact", f"SET session_replication_role = DEFAULT; UPDATE payments SET {col} = {val} WHERE id = 811;", "immutable" if col in ("amount_paise", "currency", "training_id", "provider", "provider_order_id", "attempt_no", "idempotency_key", "request_fingerprint") else "", None)
    accepted("an UPDATE that changes nothing in the identity is fine", "UPDATE payments SET updated_at = now() WHERE id = 811;")


# ---------- group F: what the 0007 triggers do NOT protect (13B.1) ----------
def in_rolled_back_tx(sql: str) -> str:
    return "BEGIN; " + sql + " ROLLBACK;"


def group_not_protected() -> None:
    """Executable record of the limits documented in README / ARCHITECTURE / PROJECT_PROGRESS. Each statement runs inside a transaction that is rolled
    back. 'accepted' here means PostgreSQL ALLOWS hand-written SQL to do it: the documentation must therefore not call these records immutable.
    Rejections that come from plain CHECK constraints (not from 0007) are named as such."""
    pid, sql = payment(training=15, pid=820)
    accepted("a settled payment for the non-protection checks", sql + children(820, 15))
    accepted("UPDATE platform_commissions (amount) is ALLOWED: commissions are only checked at INSERT", in_rolled_back_tx("UPDATE platform_commissions SET amount_paise = 1 WHERE id = 820;"))
    accepted("DELETE FROM platform_commissions is ALLOWED", in_rolled_back_tx("DELETE FROM platform_commissions WHERE id = 820;"))
    accepted("a self-consistent UPDATE of trainer_earnings (gross, commission, net together) is ALLOWED",
             in_rolled_back_tx("UPDATE trainer_earnings SET gross_paise = 20000, commission_paise = 2000, net_paise = 18000 WHERE id = 820;"))
    rejected("an INCONSISTENT UPDATE of trainer_earnings is stopped by the CHECK constraint ck_earning_net, not by a 0007 trigger",
             in_rolled_back_tx("UPDATE trainer_earnings SET gross_paise = 20000 WHERE id = 820;"), "ck_earning_net", "23514")
    accepted("DELETE FROM trainer_earnings is ALLOWED", in_rolled_back_tx("DELETE FROM trainer_earnings WHERE id = 820;"))
    accepted("UPDATE payment_refunds (amount) is ALLOWED: refunds are only checked at INSERT", in_rolled_back_tx("UPDATE payment_refunds SET amount_paise = 1 WHERE id = 800;"))
    accepted("DELETE FROM payment_refunds is ALLOWED", in_rolled_back_tx("DELETE FROM payment_refunds WHERE id = 800;"))
    accepted("UPDATE and DELETE of payment_webhook_events are ALLOWED",
             in_rolled_back_tx("INSERT INTO payment_webhook_events (provider, event_id, event_type, outcome, payload, source, received_at, id) VALUES "
                               "('sandbox', 'evt-np', 'payment.succeeded', 'succeeded', '{}', 'WEBHOOK', now(), 99001); "
                               "UPDATE payment_webhook_events SET outcome = 'ignored' WHERE id = 99001; DELETE FROM payment_webhook_events WHERE id = 99001;"))
    accepted("DELETE FROM payment_review_flags is ALLOWED (history can be erased by hand)", in_rolled_back_tx("DELETE FROM payment_review_flags WHERE payment_id = 700;"))
    accepted("UPDATE payments.status SUCCEEDED -> FAILED is ALLOWED (only identity columns are frozen)", in_rolled_back_tx("UPDATE payments SET status = 'FAILED' WHERE id = 820;"))
    accepted("UPDATE invoice_counters is ALLOWED", in_rolled_back_tx("UPDATE invoice_counters SET last_number = 0;"))
    check("those statements were rolled back: the fixture payment is still SUCCEEDED with its commission and earning",
          scalar("SELECT (SELECT status FROM payments WHERE id = 820) || '/' || (SELECT amount_paise FROM platform_commissions WHERE id = 820) || '/' "
                 "|| (SELECT gross_paise FROM trainer_earnings WHERE id = 820)") == "SUCCEEDED/1000/10000")


# ---------- group G: PostgreSQL's transactional DDL, the premise of the atomic downgrade refusal (13B.1) ----------
SNAPSHOT_SQL = ("SELECT md5(string_agg(x, '|' ORDER BY x)) || ' ' || count(*) FROM ("
                "SELECT 'T:' || tablename AS x FROM pg_tables WHERE schemaname = 'public' "
                "UNION ALL SELECT 'I:' || indexdef FROM pg_indexes WHERE schemaname = 'public' "
                "UNION ALL SELECT 'C:' || conrelid::regclass::text || conname || pg_get_constraintdef(oid) FROM pg_constraint WHERE connamespace = 'public'::regnamespace "
                "UNION ALL SELECT 'G:' || pg_get_triggerdef(oid) FROM pg_trigger WHERE NOT tgisinternal "
                "UNION ALL SELECT 'F:' || proname || md5(prosrc) FROM pg_proc WHERE pronamespace = 'public'::regnamespace) s")


def group_transactional_ddl(ddl: dict[str, str]) -> None:
    """NOT an Alembic run and NOT equivalent to one. It replays, as ONE psql transaction, the SQL that `alembic downgrade 0004` would emit for 0007 and
    0006 (taken from the recording stub), then fails like 0005's guard does, and checks that PostgreSQL undid the DDL. That proves the premise only
    (DDL is transactional on PostgreSQL). Whether Alembic really runs the downgrade in one transaction is tested by
    backend/tests/test_migrations_postgres.py::test_the_downgrade_refuses_to_discard_financial_records_and_changes_nothing, which needs Alembic."""
    before = scalar(SNAPSHOT_SQL)
    inside = scalar("BEGIN; " + ddl["down0007"] + ddl["down0006"] + "SELECT (SELECT count(*) FROM pg_trigger WHERE NOT tgisinternal) || '/' || "
                    "(SELECT count(*) FROM pg_tables WHERE tablename = 'payment_review_flags'); ROLLBACK;").splitlines()[-1]
    check("control: inside the transaction the 0007 and 0006 downgrade SQL really does remove every trigger and payment_review_flags", inside == "0/0", inside)
    check("the control transaction was rolled back and left the schema as it was", scalar(SNAPSHOT_SQL) == before)
    rejected("a failure after the 0007 and 0006 downgrade SQL aborts the transaction (stands in for 0005's guard raising)",
             "BEGIN; " + ddl["down0007"] + ddl["down0006"] + "SELECT 1/0; COMMIT;", "division by zero", "22012")
    check("after the failed transaction every table, index, constraint, trigger and function is exactly as before (PostgreSQL DDL is transactional)",
          scalar(SNAPSHOT_SQL) == before, scalar(SNAPSHOT_SQL))
    check("the 8 triggers are still installed and enabled", scalar("SELECT count(*) FROM pg_trigger WHERE NOT tgisinternal AND tgenabled = 'O'") == "8")


# ---------- group D: the SQL of the fee cap (B1) ----------
SETTLED = ("SELECT coalesce(sum(p.amount_paise), 0), coalesce(sum(c.amount_paise), 0) FROM payments p JOIN platform_commissions c ON c.payment_id = p.id "
           "WHERE p.training_id = {t} AND p.status = 'SUCCEEDED' AND c.status = 'RECORDED'{ex}")
HELD = ("SELECT coalesce(sum(p.amount_paise), 0) FROM payments p WHERE p.training_id = {t} AND p.status = 'SUCCEEDED' "
        "AND NOT EXISTS (SELECT 1 FROM payment_refunds r WHERE r.payment_id = p.id AND r.status = 'SUCCEEDED')")


def group_cap() -> None:
    """Fee Rs 100. B (60) expired then reports a late success while A (60) is settled and C (40) is open. The cap basis (settled money) must exclude
    B's money, which is held but has no commission record. The queries are hand-written mirrors of payment_service.settled_totals / collected_paise."""
    T = 30
    a, sa = payment(training=T, amount=6_000, fee=600, attempt=2, pid=900)
    b, sb = payment(training=T, amount=6_000, fee=0, attempt=1, pid=901)
    c, sc = payment(training=T, amount=4_000, fee=400, attempt=3, status="PENDING", pid=902)
    accepted("A settled (6000, commission 600), B over-cap late success (6000, no commission, invoice), C open (4000)",
             sa + children(900, T, 6_000, 600) + sb + children(901, T, 6_000, 0).split("INSERT INTO trainer_earnings")[0] + sc)
    q = lambda sql: scalar(sql.replace("|", ""))  # noqa: E731
    settled = scalar(SETTLED.format(t=T, ex=" AND p.id <> 902"))
    held = scalar(HELD.format(t=T))
    check("cap basis for C = settled money only: (6000, 600), B excluded", settled == "6000|600", settled)
    check("money HELD counts B as well (12000): it blocks new attempts, but is not the cap basis", held == "12000", held)
    check("with the old basis (held) C would have been over the cap: 12000 + 4000 > 10000; with the new basis it is not: 6000 + 4000 <= 10000",
          int(held) + 4_000 > 10_000 and int(settled.split("|")[0]) + 4_000 <= 10_000)
    accepted("C succeeds and settles (4000, commission 400)", "UPDATE payments SET status = 'SUCCEEDED', paid_at = now() WHERE id = 902;" + children(902, T, 4_000, 400))
    check("settled money is now exactly the fee (10000) with commission 1000", scalar(SETTLED.format(t=T, ex="")) == "10000|1000")
    accepted("B is refunded in full", "INSERT INTO payment_refunds (id, payment_id, amount_paise, status, idempotency_key, attempts, created_by, created_at, completed_at, credit_note_number) "
             "VALUES (901, 901, 6000, 'SUCCEEDED', 'refund-901', 1, 1, now(), now(), 'ITB-CN-2030-000901');")
    check("after B's refund the settled money is unchanged (10000|1000) and the money held is back at the fee (10000)",
          scalar(SETTLED.format(t=T, ex="")) == "10000|1000" and scalar(HELD.format(t=T)) == "10000")
    check("exactly one invoice per succeeded payment (3) and two earnings, two commissions",
          scalar("SELECT (SELECT count(*) FROM invoices WHERE training_id = 30) || '/' || (SELECT count(*) FROM trainer_earnings WHERE training_id = 30) || '/' "
                 "|| (SELECT count(*) FROM platform_commissions c JOIN payments p ON p.id = c.payment_id WHERE p.training_id = 30)") == "3/2/2")


# ---------- group E: concurrency probes (several simultaneous psql sessions) ----------
def session(sql: str, delay: float = 0.0) -> dict:
    if delay:
        time.sleep(delay)
    t0 = time.time()
    rc, out, err = psql(sql)
    return {"rc": rc, "out": out, "err": err, "secs": time.time() - t0}


def parallel(sqls: list[str], stagger: float = 0.0) -> list[dict]:
    with ThreadPoolExecutor(max_workers=len(sqls)) as pool:
        futures = [pool.submit(session, sql, i * stagger) for i, sql in enumerate(sqls)]
        return [f.result(timeout=180) for f in futures]


def group_concurrency() -> None:
    # 1. one payment in flight per training: the second INSERT waits for the first transaction, then fails on the partial unique index
    hold = "BEGIN; {ins} SELECT pg_sleep(2); COMMIT;"
    _, i1 = payment(training=40, status="PENDING", attempt=1, pid=1101)
    _, i2 = payment(training=40, status="PENDING", attempt=2, pid=1102)
    r = parallel([hold.format(ins=i1), "SELECT pg_sleep(0.5);" + i2], stagger=0.0)
    check("one-in-flight: the simultaneous second PENDING attempt BLOCKS, then is rejected by uq_payment_one_in_flight",
          r[0]["rc"] == 0 and r[1]["rc"] != 0 and "uq_payment_one_in_flight" in r[1]["err"] and r[1]["secs"] >= 1.5, str(r))
    # 2. the same idempotency key from the same payer, simultaneously
    _, k1 = payment(training=41, status="PENDING", key="key-race-0001", pid=1111)
    _, k2 = payment(training=42, status="PENDING", key="key-race-0001", pid=1112)
    r = parallel([hold.format(ins=k1), "SELECT pg_sleep(0.5);" + k2])
    check("same key, same payer: exactly one INSERT wins, the other fails on uq_payment_idempotency (the service then re-reads and replays)",
          sorted(x["rc"] != 0 for x in r) == [False, True] and any("uq_payment_idempotency" in x["err"] for x in r), str(r))
    # 3. the same provider event delivered twice
    ev = "INSERT INTO payment_webhook_events (provider, event_id, event_type, outcome, payload, source, received_at, id) VALUES ('sandbox', 'evt-race', 'payment.succeeded', 'succeeded', '{}', 'WEBHOOK', now(), %d);"
    r = parallel(["BEGIN; " + ev % 1 + " SELECT pg_sleep(1.5); COMMIT;", "SELECT pg_sleep(0.4);" + ev % 2])
    check("duplicate webhook: the second delivery of an event id fails on the unique (provider, event_id)",
          sorted(x["rc"] != 0 for x in r) == [False, True] and scalar("SELECT count(*) FROM payment_webhook_events WHERE event_id = 'evt-race'") == "1", str(r))
    # 4. first-time invoice numbering, as invoice_service.next_number does it: lock the row, create it in a SAVEPOINT on first use, lock again, increment
    number = ("BEGIN; SELECT last_number FROM invoice_counters WHERE series = 'INV' AND year = 2099 FOR UPDATE;"
              "DO $$ BEGIN INSERT INTO invoice_counters (series, year, last_number) VALUES ('INV', 2099, 0); EXCEPTION WHEN unique_violation THEN NULL; END $$;"
              "SELECT last_number FROM invoice_counters WHERE series = 'INV' AND year = 2099 FOR UPDATE;"
              "UPDATE invoice_counters SET last_number = last_number + 1 WHERE series = 'INV' AND year = 2099 RETURNING last_number;"
              "SELECT pg_sleep(0.3); COMMIT;")
    r = parallel([number] * 8)
    got = sorted(int(x["out"].split("\n")[-1].split("UPDATE")[0].strip() or 0) for x in r if x["rc"] == 0)
    check("first-time invoice numbering: 8 simultaneous sessions get 1..8 exactly once, none fails", all(x["rc"] == 0 for x in r) and got == list(range(1, 9)), f"{got} {[x['err'] for x in r if x['rc']]}")
    # 5. refund racing with payout: both lock payment then earning, in the same order. Exactly one wins, whatever the interleaving.
    wins = {"refunded": 0, "paid": 0, "inconsistent": 0}
    for trial in range(12):
        pid = 2000 + trial
        _, ins = payment(training=50 + (trial % 10), attempt=trial // 10 + 1, pid=pid)
        accepted(f"race fixture {trial}", ins + children(pid, 50 + (trial % 10)) + f"UPDATE trainer_earnings SET status = 'AVAILABLE', available_at = now() WHERE id = {pid};")
        refund = (f"BEGIN; SELECT id FROM payments WHERE id = {pid} FOR UPDATE; SELECT status FROM trainer_earnings WHERE id = {pid} FOR UPDATE;"
                  f"DO $$ BEGIN IF (SELECT status FROM trainer_earnings WHERE id = {pid}) IN ('PENDING', 'AVAILABLE') THEN "
                  f"INSERT INTO payment_refunds (id, payment_id, amount_paise, status, idempotency_key, attempts, created_by, created_at, completed_at, credit_note_number) "
                  f"VALUES ({pid}, {pid}, 10000, 'SUCCEEDED', 'rf-{pid}', 1, 1, now(), now(), 'CN-{pid}'); UPDATE trainer_earnings SET status = 'REFUNDED' WHERE id = {pid}; "
                  f"UPDATE platform_commissions SET status = 'REVERSED', reversed_at = now() WHERE id = {pid}; END IF; END $$; SELECT pg_sleep(0.05); COMMIT;")
        payout = (f"BEGIN; SELECT id FROM payments WHERE id = {pid} FOR UPDATE; SELECT status FROM trainer_earnings WHERE id = {pid} FOR UPDATE;"
                  f"DO $$ BEGIN IF NOT EXISTS (SELECT 1 FROM payment_refunds WHERE payment_id = {pid}) AND (SELECT status FROM trainer_earnings WHERE id = {pid}) = 'AVAILABLE' THEN "
                  f"UPDATE trainer_earnings SET status = 'PAID', paid_at = now(), paid_by = 1, payout_reference = 'B-{pid}' WHERE id = {pid}; END IF; END $$; SELECT pg_sleep(0.05); COMMIT;")
        r = parallel([refund, payout])
        state = scalar(f"SELECT (SELECT status FROM trainer_earnings WHERE id = {pid}) || '/' || (SELECT count(*) FROM payment_refunds WHERE payment_id = {pid})")
        if not all(x["rc"] == 0 for x in r):
            wins["inconsistent"] += 1
        elif state == "REFUNDED/1":
            wins["refunded"] += 1
        elif state == "PAID/0":
            wins["paid"] += 1
        else:
            wins["inconsistent"] += 1
    check("refund vs payout, 12 simultaneous trials: always exactly one winner (REFUNDED+refund or PAID+no refund), never both, never neither", wins["inconsistent"] == 0 and wins["refunded"] + wins["paid"] == 12, str(wins))
    # 6. lock ordering: the same order never deadlocks; opposite orders do (control, so we know the harness can see a deadlock)
    _, a = payment(training=65, attempt=1, pid=3001)
    _, b = payment(training=66, attempt=1, pid=3002)
    accepted("lock-order fixture", a + b)
    same = [f"BEGIN; SELECT id FROM payments WHERE id = 3001 FOR UPDATE; SELECT pg_sleep(0.4); SELECT id FROM payments WHERE id = 3002 FOR UPDATE; COMMIT;"] * 2
    r = parallel(same, stagger=0.1)
    check("two sessions locking payment 3001 then 3002 (the services' fixed order): no deadlock", all(x["rc"] == 0 for x in r), str(r))
    opposite = [same[0], "BEGIN; SELECT id FROM payments WHERE id = 3002 FOR UPDATE; SELECT pg_sleep(0.4); SELECT id FROM payments WHERE id = 3001 FOR UPDATE; COMMIT;"]
    r = parallel(opposite)
    check("CONTROL: opposite lock orders deadlock and PostgreSQL aborts one session (40P01)", any("40P01" in x["err"] for x in r), str(r))


def main() -> int:
    try:
        return run()
    except Refused as e:
        print(f"REFUSED: {e}\nNothing was dropped or created; no check ran.")
        return 3
    except (FileNotFoundError, subprocess.TimeoutExpired) as e:
        print(f"BLOCKED: psql could not be run to completion ({type(e).__name__}: {e})\nThese checks did NOT run; nothing is reported as passed.")
        return 2


def run() -> int:
    problems = environment_problems()
    if problems:                                  # before the first connection
        raise Refused("; ".join(problems))
    rc, out, err = psql("SELECT 1", db="postgres")
    if rc != 0:
        print(f"BLOCKED: no PostgreSQL server reachable through psql ({err[:200]})\nThese checks did NOT run; nothing is reported as passed.")
        return 2
    print("server:", scalar("SHOW server_version") if False else psql("SHOW server_version", db="postgres")[1])
    ddl = build_ddl()
    create_database()
    for group in (lambda: group_schema(ddl), group_flags, group_triggers, group_not_protected, group_cap, lambda: group_transactional_ddl(ddl), group_concurrency):
        group()
    # the downgrades: 0007 and 0006 are safe on data; the guards are in Python (migration code), so only the SQL they emit is run here
    rc, _, err = psql(ddl["down0007"])
    check("DDL of the 0007 downgrade (drop triggers and functions) applies", rc == 0, err)
    check("no trigger is left after the 0007 downgrade", scalar("SELECT count(*) FROM pg_trigger WHERE NOT tgisinternal") == "0")
    check("no itb_ function is left after the 0007 downgrade", scalar("SELECT count(*) FROM pg_proc WHERE proname LIKE 'itb\\_%'") == "0")
    rc, _, err = psql(ddl["0007"])
    check("0007 upgrades again after its downgrade", rc == 0, err)
    failed = [m for ok, m in RESULTS if not ok]
    for ok, m in RESULTS:
        print(("PASS  " if ok else "FAIL  ") + m)
    print(f"\n{len(RESULTS) - len(failed)} passed, {len(failed)} failed (real PostgreSQL via psql; NOT Alembic, NOT SQLAlchemy, NOT the application)")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
