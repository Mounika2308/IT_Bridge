# IT BRIDGE: Institutions to Trainer Bridge

A two-sided platform where institutions post training requirements and trainers apply, get hired and deliver training.
Stack: React 18 + Vite + Tailwind, FastAPI, SQLAlchemy 2, Alembic, PostgreSQL. Redis is provisioned but not used yet.

> **Status: Phase 13 (Payments, invoices and trainer earnings), through the Phase 13B.2 acceptance gate. SANDBOX-ONLY. Final acceptance is BLOCKED: this environment cannot run the full backend suite, Alembic, the PostgreSQL integration tests, Vitest, Vite or Docker. Phase 14 has not started. NOT production payment ready.**
> No real payment provider exists: no real money can be collected, and nothing here may be described as working real payments. What has really run: real pytest on the test files that need no FastAPI/SQLAlchemy
> (383 passed on the rule/matching/static files; 60 passed and 111 skipped on the start-up guard files), real Pydantic validation, SQL-level checks on a real PostgreSQL 16 server through `psql` (110 passed; this is not Alembic and not the application),
> and `docker compose config` (static validation only). What has **not** run: the full backend pytest suite and the payment API tests, the app-level start-up tests, `alembic upgrade/downgrade/check` on PostgreSQL,
> the PostgreSQL integration and notification-savepoint tests, real Vitest, the Vite build and `docker compose up`. Run the commands below once and report any failure before building new features; the exact list is in `PROJECT_PROGRESS.md`.

## What exists
Accounts (trainer, institution, admin) with JWT auth and role checks, trainer and institution profiles, skills and categories,
training requirements, trainer discovery with filters, an explainable matching engine, applications, hiring requests,
trainings (created from accepted hiring requests, with a lifecycle, agreed details and an online meeting link; Phase 9),
sessions with attendance, notes and enforced time rules, a calendar with interviews, trainings, sessions and deadlines (Phase 10), notifications (Phase 11: one registry of event types, in-app via REST + WebSocket, per-user in-app and email preferences, an email outbox with retries, interview, session and training reminders), reviews and ratings (Phase 12: validated two-sided reviews of completed trainings, public trainer and institution reviews, dashboards, a review reminder), and payments, invoices and trainer earnings (Phase 13: a provider abstraction with a **sandbox that moves no real money**, integer-paise accounting, platform invoices, admin refunds and recorded payouts; see below).
Not built yet: a real payment provider, an admin dashboard and verification screens, analytics, file uploads, chat, password reset, an email verification flow, real email/SMS/WhatsApp providers, rate limiting, Celery workers, CI/CD. Details and honest per-feature status are in `PROJECT_PROGRESS.md`.

## Quick start (Docker)
    cp .env.example .env            # keep DB_PASSWORD and DATABASE_URL in sync
    docker compose up --build
Frontend http://localhost:5173, API docs http://localhost:8000/docs. The backend container runs `alembic upgrade head`
and `python -m app.seed` (skills, categories, optional admin) before starting; the worker waits for the backend's health check, so it never starts before the schema exists.

**Deployment order (migrations first).** Always `alembic upgrade head` on the target database **before** starting (or restarting) the API, the worker or the scheduler loop of a new version.
Migrations 0005-0007 add the payment tables, the review-flag table and (PostgreSQL only) integrity triggers; code that expects them fails against an older schema. Take a backup first.
**Downgrades are refused up front when they would delete data.** Every revision's `downgrade()` starts with a pre-flight (`backend/app/core/migration_guard.py`) that works out EVERY revision the command will remove (from the revision chain, cross-checked against Alembic's `iterate_revisions`; the wider answer is used), counts what the database holds in the tables and columns each of them discards, and refuses the whole command **before the first revision runs** if any of it is held: 0001 (all 19 core tables: users, profiles, requirements, applications, trainings, reviews, audit logs ...), 0002 (the training snapshot columns and the meeting link), 0003 (session notes and interview times), 0004 (notification preferences and the email outbox), 0005 and 0006 (the financial tables). Only the revisions a command removes are looked at: `downgrade -1` or `downgrade 0006` is not blocked by users or payments, because it does not remove them. An empty database is unaffected. This replaces the old behaviour in which a refusal at 0001 came last, after 0004-0002 had already run (on SQLite, where DDL cannot be rolled back, that left a half-downgraded database; 0002-0004 had no guard at all). **`ITB_ALLOW_FINANCIAL_DOWNGRADE=I_UNDERSTAND_DATA_WILL_BE_DESTROYED` keeps its old name but now authorises destroying EVERYTHING the downgrade path removes: core application data, notifications, trainings snapshot columns, session notes, interview times AND financial records.** It is an exact match on that one variable and phrase (nothing else enables it), for disposable databases only; the documented test-database workflow (`downgrade base` with the override) is unchanged. Without the override an offline `--sql` downgrade is refused when its path drops data (it cannot count rows). **With the override set, `alembic downgrade --sql` DOES generate the destructive DDL**, so never set it outside a disposable database. If the target is not one the guard recognises, or a relative target such as `-1` cannot be cross-checked against Alembic, everything from the starting revision down to base is checked instead (so data in any revision below blocks the command and the message says so); naming the target revision explicitly (`alembic downgrade 0006`) avoids that. On PostgreSQL the whole `alembic downgrade` command also runs in one transaction (single `context.begin_transaction()`, transactional DDL), so a failure part-way rolls back. That, the pre-flight and the relative-target forms (`-1`) are covered by `backend/tests/test_migrations.py` (real Alembic on SQLite) and `backend/tests/test_migrations_postgres.py` (needs Alembic and PostgreSQL); **neither has been run where this was written**.

## Quick start (without Docker)
    # PostgreSQL running locally; set DATABASE_URL in backend/.env
    cd backend && pip install -r requirements.txt
    alembic upgrade head && python -m app.seed
    uvicorn app.main:app --reload
    cd ../frontend && npm install && npm run dev
First admin: set `ADMIN_EMAIL` and `ADMIN_PASSWORD`, then run `python -m app.seed`. Admins can never self-register.

## Database and migrations
The schema comes only from Alembic. `backend/alembic/versions/0001_initial_schema.py` was generated from the models by
`scripts/gen_initial_migration.py` because autogenerate could not run during the audit. After installing dependencies, verify it:
    cd backend && pytest tests/test_migrations.py        # upgrade/downgrade and model-vs-migration drift check
    alembic check                                        # should report no new operations
Any change to a model needs a new revision: `alembic revision --autogenerate -m "describe change"`.

## Tests and checks
**Status (13B.4): Phase 13 is NOT accepted.** The 13B.4 attempt to install the declared dependencies failed because the session's egress policy denies `pypi.org` and `registry.npmjs.org` (HTTP 403 at the proxy); allow them, or supply a mirror, to unblock. The full pytest suite, Alembic against PostgreSQL, the three PostgreSQL test files, real Vitest, the real Vite build and Docker runtime have not run on Phase 13 because the available environment lacks FastAPI, SQLAlchemy, Alembic, psycopg2, Vitest, Vite and a Docker daemon. What did run is listed, with the tool that ran it, in PROJECT_PROGRESS.md ("Phase 13B.3"). Dependencies are not pinned and there is no frontend lockfile yet.
    cd backend && pytest                                  # API, services, matching, migrations, integration audit
    python scripts/audit_integration.py                   # no dependencies: frontend calls, links and imports vs real routes
    python scripts/check_migrations_static.py             # no dependencies: replays migrations, compares with models, runs backfills on SQLite
    python scripts/verify_session_rules.py                # no dependencies: runs the real session/attendance/interview rules against test doubles
    python scripts/verify_payments.py                     # no dependencies: payment tables on strict SQLite (constraints, RESTRICT, partial unique index) + AST wiring checks (SQLite, NOT PostgreSQL)
    python scripts/verify_payment_schemas.py              # needs only pydantic: real request validation
    PGHOST=127.0.0.1 PGPORT=55432 PGUSER=postgres python scripts/verify_postgres_sql.py   # needs psql + a THROWAWAY PostgreSQL 16 cluster marked as such (see below): SQL-level checks (exit 2 = BLOCKED, 3 = REFUSED by its safety rules); not Alembic, not the app
    # a dedicated database that is WIPED. The URL must be exactly postgresql[+psycopg2]://USER[:PASSWORD]@127.0.0.1:PORT/NAME (or [::1]): no query string, no "localhost", port 1024-65535 but not 5432,
    # NAME contains "test"; and the database (and every other one in its cluster except postgres) must carry the comment ITB_PHASE13_DISPOSABLE, set on purpose:
    #   psql -h 127.0.0.1 -p 55432 -U postgres -c "COMMENT ON DATABASE itbridge_test IS 'ITB_PHASE13_DISPOSABLE'"
    # No PG* variable (PGHOST, PGHOSTADDR, PGPORT, PGSERVICE ...) may be set except PGPASSWORD. A name containing "test" alone is never enough.
    export ITB_TEST_DATABASE_URL=postgresql+psycopg2://itbridge:itbridge@127.0.0.1:55432/itbridge_test
    cd backend && pytest tests/test_migrations_postgres.py tests/test_postgres_concurrency.py tests/test_postgres_notifications.py -rs   # Alembic up/down/drift + atomic downgrade refusal, 5 concurrency scenarios, notification SAVEPOINT isolation; SKIPPED (not passed) without the variable
    cd backend && pytest tests/test_payment_guard_unit.py tests/test_startup_hermetic.py -rs   # start-up guard: the first needs only pytest; the second runs the real app in a child process (empty temp cwd, scrubbed environment, optional explicit .env) and SKIPS without fastapi/pydantic-settings/SQLAlchemy
    cd frontend && npm test                               # vitest
    cd frontend && npm run build                          # production build
    node tools/frontend-shim/shim.mjs check && node tools/frontend-shim/shim.mjs test   # stop-gap ONLY when npm cannot run (not Vitest, not Vite); see tools/frontend-shim/README.md

## Configuration (.env)
`ENVIRONMENT` (**required**: `development`, `test` or `production`; no default, a missing or unknown value refuses to start the API and the payment workers), `DATABASE_URL`, `JWT_SECRET` (32+ random characters; `ENVIRONMENT=production` refuses to start otherwise), `CORS_ORIGINS`,
`APP_TIMEZONE` (default Asia/Kolkata: deadlines and session dates are judged in this timezone), `REDIS_URL`
(unused for now), optional `ADMIN_EMAIL` / `ADMIN_PASSWORD`. Notifications: `EMAIL_PROVIDER` (only `console` exists), `FRONTEND_URL`, `NOTIFICATION_MAX_ATTEMPTS`, `NOTIFICATION_RETRY_BASE_SECONDS`, `DAY_BEFORE_REMINDER_HOUR`, `INTERVIEW_REMINDER_HOURS`, `REVIEW_REMINDER_DAYS` (3), `REVIEW_REMINDER_WINDOW_DAYS` (14). Payments (Phase 13): `PAYMENTS_ENABLED` (default **false**), `PAYMENT_SANDBOX_ENABLED` (default **false**; the explicit opt-in the simulator needs), `PAYMENT_PROVIDER` (only `sandbox` exists), `PAYMENT_WEBHOOK_SECRET`, `PAYMENT_WEBHOOK_TOLERANCE_SECONDS`, `PLATFORM_COMMISSION_BPS` (1000 = 10%, a **development placeholder**), `PAYMENT_COMMISSION_CONFIRMED`, `PAYMENT_EXPIRY_MINUTES`, `PAYMENT_RECONCILE_AFTER_MINUTES`, `PAYMENT_PROCESSING_TIMEOUT_MINUTES`, `EARNING_HOLD_DAYS` (0). Never commit `.env`.

## Notifications and scheduled jobs
Events (all created inside the business transaction, so a rollback leaves no notification): application received, shortlisted, under review, rejected and withdrawn;
interview scheduled, rescheduled (date and time included) and reminder; hiring request, accepted, declined and cancelled; requirement filled, reopened and closed;
training created, dates changed, meeting link changed, completed, cancelled and starts tomorrow; session scheduled, rescheduled, cancelled and tomorrow; review requested and received.
Payments add: payment succeeded / failed / received, payment refunded, earning available, payout recorded, and (admins) payment needs review, each with a stable dedupe key.
The list lives in one place, `backend/app/services/notification_types.py`. Attendance and status changes do not notify.

**Preferences** (`Settings` link on the notifications page, `GET/PUT /api/v1/notifications/preferences`): in-app and email, both on by default. A type marked `mandatory`
in the registry ignores the in-app switch; none is mandatory today because the app has no security or account notification yet. Email is only attempted for a small set of
important events, only if the user left email on, and only to an address that is verified at send time.

**Delivery.** A request only writes rows (the in-app notification and, for email-eligible events, an outbox row in `notification_deliveries`). A separate worker sends the outbox,
retrying with exponential backoff up to `NOTIFICATION_MAX_ATTEMPTS`. A provider failure therefore cannot affect the request that caused it.

**Scheduling** (run from `backend/`; every job is idempotent, so overlapping or repeated runs create nothing twice):

    */2 * * * *   python -m app.workers.outbox                         # send queued email
    */15 * * * *  python -m app.workers.reminders --kind interview     # interviews within INTERVIEW_REMINDER_HOURS
    0 17 * * *    python -m app.workers.reminders --kind day_before    # sessions and trainings starting tomorrow (set cron's timezone to APP_TIMEZONE)
    0 * * * *     python -m app.workers.reminders --kind review        # one review reminder, 3 days after completion, to whoever has not reviewed

or one process that does all of them: `python -m app.workers.loop` (the `worker` service in `docker-compose.yml`).

## Reviews and ratings
After a training is **completed** (only the institution can complete it), the institution reviews the trainer (five categories: technical knowledge, teaching quality, communication, punctuality, professionalism) and the trainer reviews the institution (three: communication, professionalism, coordination). Each category is a whole number from 1 to 5; booleans, decimals and strings are rejected by the API.
A comment is optional, at most 2,000 characters after trimming, and cannot be blank. One review per side per training (service check plus a database constraint). **Reviews cannot be edited or deleted.** Inactive or suspended accounts cannot review; active or cancelled trainings cannot be reviewed, and the API says why.

**How ratings are calculated.** A review's `overall` is the mean of its categories; a profile's rating is the mean of its visible reviews' `overall` values (hidden reviews never count). Both are rounded **half up to one decimal** (4.25 is shown as 4.3) by one function, `review_service.round_rating`, and shown with one decimal everywhere ("4.0").
A profile with no reviews has no rating (`null`, shown as "No reviews yet"). A profile with one review shows that rating and "1 review" truthfully, but the **minimum-rating search filter requires at least 2 reviews** and compares the same rounded value that is displayed (so a trainer shown as 4.0 passes "4 and above"). The search form says "(2+ reviews)" and a single-review profile carries a note.

Endpoints: `POST/GET /trainings/{id}/reviews`, `GET /trainers/{id}/reviews`, `GET /institutions/{id}/reviews` (name, verified flag, rating summary and reviews; no contact details), `GET /reviews/me` (own rating summary and `my_pending_reviews`). Notifications: `REVIEW_REQUEST` and `REVIEW_RECEIVED` carry dedupe keys, and `REVIEW_REMINDER` is sent once, 3 days after completion (not for trainings completed over 14 days ago), only to a participant who may still review and has not. Reviews have no moderation screen yet: the `is_hidden` flag works but nothing sets it.

## Payments, invoices and trainer earnings (Phase 13): sandbox only
**No real money moves, and this phase must not be described as production payment ready.** The only provider is a sandbox. It works only if **all** of these hold: `PAYMENTS_ENABLED=true`, `PAYMENT_SANDBOX_ENABLED=true` (a second, deliberate opt-in; `.env.example` ships both as `false`),
`PAYMENT_PROVIDER=sandbox`, and `ENVIRONMENT` is `development` or `test`. Otherwise payments are off. **`ENVIRONMENT` is required and has no default**: `development`, `test` or `production` (`prod` is accepted for production). A missing, empty or unrecognised value is refused at start-up by the API, the payment worker and the scheduler loop, **whether or not payments are enabled**, so a forgotten variable can never be taken for development (this no longer relies on any pydantic-settings internals; `.env.example` sets `ENVIRONMENT=development` for local use and the test suite sets it explicitly). The standalone notification-outbox and reminder workers do not run this guard. The guard also refuses: payments enabled with the sandbox but without the opt-in; in production the sandbox, its opt-in, a provider that is not implemented (none is), or `PAYMENT_COMMISSION_CONFIRMED=false` while payments are enabled. **`ENVIRONMENT=production` refuses to start unless `PAYMENT_WEBHOOK_SECRET` is a strong random value (32+ characters), whether or not payments are enabled**: a missing, empty, weak, placeholder or example value (including the one in `.env.example`) is refused (13B.2). Development and test accept any secret, including none (the sandbox webhook then answers 503). The webhook request handler applies the same test as defence in depth: in production (or an unknown environment) it will not authenticate with an empty, weak or example secret, and answers 503. There is no card, bank or UPI field anywhere.

- **Money** is whole **paise** (₹100 = 10000) in `BigInteger` columns; no float, Decimal or division is used (checked by `scripts/verify_payments.py`). The institution pays the agreed fee (nothing on top); the **platform commission is taken from the trainer's share**:
  `commission = (amount × bps + 5000) // 10000` (half up). The 10% rate is a **configurable development placeholder**, snapshotted on each payment; a training keeps the rate of its first money. Instalments are allowed, can never total more than the fee, and the final commission of an instalment is computed when it succeeds so the live commissions always add up to the commission on the money held.
- **Attempts.** Every try is a new `payments` row (`PENDING → PROCESSING → SUCCEEDED | FAILED | CANCELLED | EXPIRED`); a retry never rewrites an old attempt. One attempt may be in flight per training (partial unique index). The request needs an `Idempotency-Key` header and an explicit `amount_paise`; the same key with the same request returns the same payment, with different parameters it is a 409. A zero-fee training cannot be charged.
- **The browser can never mark a payment paid.** A result arrives only as a provider event at `POST /api/v1/payments/webhook` (HMAC-SHA256 over `timestamp.body`, timestamp tolerance, event id replay-protection, amount and currency checked; fails closed with no secret). The sandbox "simulate" buttons build a **signed** event and send it through the same code. A late or odd result (success after cancel/expiry/failure, a second charge, a different amount or currency, money above the fee, a cancelled training) is **recorded and flagged for an administrator, never discarded**. A payment can carry **several open review flags at once** (one durable row per reason in `payment_review_flags`, each resolved and audited on its own); it stays in the review queue until every flag is closed, and an over-cap payment cannot be closed before it is refunded. The fee cap counts only money that was really settled, so an over-cap late success never makes a later legitimate payment look over-cap. Money above the fee that is waiting for its refund is **held, not paid**: the payment panel then says that a payment is on hold until an administrator refunds it and names the amount of the agreed fee still due (`block_reason=AWAITING_REFUND`, summary fields `settled_paise` and `due_paise`); "paid in full" is shown only when settled money reaches the fee. The cap rules themselves are unchanged.
- **Invoices** are IT BRIDGE **platform invoices, not GST or tax invoices**; tax treatment and marketplace invoicing need professional accounting advice before production. One immutable invoice per successful payment, numbered `ITB-YYYY-NNNNNN` from a locked counter. A refund creates a separate credit note (`ITB-CN-YYYY-NNNNNN`); the invoice is never changed. Institutions see only their own payments and invoices, and never the commission.
- **Trainer earnings:** `PENDING` until the training is **COMPLETED**, then `AVAILABLE` (zero-day hold, `EARNING_HOLD_DAYS`), then `PAID` when an **admin records** the payout (a free-text reference; account numbers and UPI ids are refused; nothing is sent anywhere). A trainer sees only their own earnings, commission and net.
- **Refunds:** full only, admin only (`POST /admin/payments/{id}/refund`), two phases (a PENDING refund row is committed, then the provider is called with no locks held), safe to repeat, retried by the worker, refused once the earning is paid out. A training **cancelled after payment** is flagged for review; there is no automatic refund.
- **Admin API (no dashboard):** `GET /admin/payments`, `POST /admin/payments/{id}/refund`, `POST /admin/payments/{id}/resolve-review`, `GET /admin/earnings`, `POST /admin/earnings/{id}/payout`. Institution: `POST /trainings/{id}/payments`, `GET /payments`, `/payments/{id}`, `/payments/summary`, `/payments/{id}/invoice`, `POST /payments/{id}/cancel`, `/payments/{id}/sandbox/{outcome}`, `GET /trainings/{id}/payment-summary`. Trainer: `GET /earnings`, `/earnings/summary`.
- **Worker:** `python -m app.workers.payments` (also run by `app.workers.loop` every minute): looks up open attempts, expires abandoned ones, flags and closes attempts stuck in PROCESSING, retries pending refunds, makes earnings available. Each payment is processed in isolation, and attempts are visited least-recently-examined first so a failing one cannot starve the rest.
- **Frontend:** payment panel on the training page (honest PENDING/PROCESSING text, automatic refresh while open, duplicate-submission guard), `/institution/payments`, printable `/institution/payments/:id/invoice`, `/trainer/earnings`, dashboard cards, and a sandbox banner wherever payments are shown.

- **Notifications never decide a financial outcome.** Payment, refund and payout notifications are written inside a SAVEPOINT (`notify_event_safe`): if one fails it is logged, skipped and never reported as delivered, and the money change is kept. A few non-financial training notices (date change, requirement reopened, waiting applicants) are not yet protected.
- **Database protection (PostgreSQL only, migration 0007).** Exactly this, and no more (see the docstring of `0007_financial_integrity_triggers.py`; the limits are checked with hand-written SQL by `scripts/verify_postgres_sql.py`). On SQLite none of it exists.

  | Protection | Tables |
  |---|---|
  | **Every UPDATE and DELETE rejected** | `invoices`, `payment_transactions` (the ledger) |
  | **UPDATE restricted**: identity columns (amount, currency, training, institution, trainer, payer, provider, order id, attempt, idempotency key, fingerprint) cannot change; all other columns, `status` included, can | `payments` |
  | **Checked at INSERT only** against the row's own payment (payment SUCCEEDED where stated; amount/rate/parties equal) | `invoices`, `trainer_earnings`, `platform_commissions`, `payment_refunds` (full refunds only), `payment_transactions` (amount only) |
  | **Cross-table relationships validated** | only the child-versus-its-own-payment checks above; nothing validates the payer against a child or re-checks a child after the payment changes |
  | **Still editable or deletable by hand-written SQL** (only CHECK / FOREIGN KEY / UNIQUE constraints apply) | `platform_commissions`, `trainer_earnings` (a self-consistent edit passes), `payment_refunds`, `payment_webhook_events`, `payment_review_flags`, `invoice_counters`, and `payments` outside its identity columns |

  So **commissions, refunds, earnings, review flags, webhook events and payment statuses are not immutable**; the application changes some of them on purpose. "Immutable ledger" here means `payment_transactions` (and issued invoices) only. 0007 is a strict precondition before any real provider.

**Gates before anyone may call payments real:** run the full verification below on a provisioned machine and fix what it finds (the service code has never run under SQLAlchemy/FastAPI); a real provider adapter and its webhook format; provider-side order cancellation and `create_order` outside the training lock; an approved commission policy; decisions on cancelled-training earnings, unresolved reviews, partial refunds and refund after payout; accounting/tax advice on the invoices; a payout execution design; an admin review screen and monitoring of flagged payments and stuck refunds. See `PROJECT_PROGRESS.md` for the full list of limitations and the exact verification steps.

## External services: what is and is not real
Email goes through a **development console provider only**: it logs that a message would be sent (the delivery id, never the address) and sends nothing. SMS and WhatsApp do not exist.
Before anyone may claim email works in production it still needs: a real provider implementing `EmailProvider` (SES, SendGrid or similar), its credentials and sender domain,
an email verification flow (nothing sets `email_verified` yet, so today no email would be attempted even with a real provider), bounce and complaint handling, and monitoring of FAILED outbox rows.
The WebSocket manager is single-process: with several API processes a push only reaches sockets of the process that created it (polling covers the rest). Redis pub/sub, Celery,
SMS, WhatsApp, retention and admin broadcasts are later phases. **No real payment provider exists**: payments are a sandbox simulation.

## More
`ARCHITECTURE.md` explains layers, flows and statuses.
