# IT BRIDGE: portable project package (Phase 13 candidate, UNAPPROVED)

**Phase 13 is INCOMPLETE and UNAPPROVED.** No real backend test, Alembic migration test, PostgreSQL integration test, payment/webhook test, Vitest run or Vite build has ever been executed on this code: the authoring environment cannot reach PyPI or npm and has Node 22 instead of 20. This package is the whole project plus everything needed to run that validation once, on an internet-enabled machine, **without running anything on your laptop**. Phase 14 is on hold. `PROJECT_PROGRESS.md` is unchanged.

## 1. Status of the checks (nothing here is rounded up)

**Completed: real, executed**
| Check | Result |
|---|---|
| Transfer tar checksum and its 10 contents (`PHASE13_KIT.SHA256SUMS`) | OK |
| Tree rebuilt from the 13B.4 baseline + `PHASE13_ENGINEERING_FIXES.diff` (26 files) | `9d2280022999b74b40af3015743c5c93eebaabed3704d2d35a1bef32fe1d33ca`, as expected |
| Baseline archives unchanged | 13B.4 `e12dd391…9710`, Phase 12 `f60c33ba…ad0c` |
| Safety-gate attack battery, offline part | 690 passed, 0 failed (tests the gate, not the application) |
| Safety-gate attack battery, live part, on two throwaway PostgreSQL 16.15 clusters | 63 passed, 0 failed (gate only; run in the authoring session, not repeated since) |

**Failed**
| Check | Result |
|---|---|
| Any real application check | **None failed, because none has run.** The one real driver run ended `VERDICT: INCOMPLETE`, exit 3 (not FAIL). |

**Blocked**
| Blocker | Effect |
|---|---|
| `pypi.org`, `files.pythonhosted.org`, `registry.npmjs.org` unreachable (DNS failure, checked several times, last 2026-10-12 04:34 UTC) | pytest, SQLAlchemy, FastAPI, Alembic, psycopg2, Vitest, Vite cannot be installed |
| Node 20 absent (only v22.22.0) | the driver's Node check cannot pass under the required toolchain |
| Consequence | the real driver run halted at `versions: alembic` (MISSING_DEPENDENCY); **30 of 34 checks NOT_RUN**. The 4 version checks it recorded as PASS ran under deliberately overridden expectations (`EXPECT_PY=3.13`, `EXPECT_NODE=22`) and therefore **do not count**. |

**Not run (all 34 driver checks, none counts yet)**
Tool/Python/Node/PostgreSQL-client/Alembic versions · tree check inside the driver · static checks with real Alembic · backend imports · gate stage · **full backend pytest** (payment, webhook oversized body / unusual `Content-Length` / huge timestamp, concurrency, notification SAVEPOINT, SQLite and PostgreSQL migration tests) · migration canaries · `verify_postgres_sql.py` · the 16-check Alembic CLI matrix (heads, history, revision, upgrade head, `alembic check`, refusals with unchanged snapshots, `-1`, `-3`, named revision, `base`, override, offline `--sql`, upgrade again) · `npm install` · `vitest run` · `vite build` · tree-unchanged check.

**Static or stand-in only: NOT approval evidence**
Stand-in test-runner counts (`test_pg_gate` 97, `test_verify_postgres_sql_gate` 49, `test_migration_guards_static` 50, `test_migration_guard` 139, `test_payment_rules` 381; not pytest) · fake-pytest/Alembic/npm driver battery (80 assertions) and its 11 mutants · 13 gate mutants · `check_migrations_static` (stub Alembic on SQLite), `audit_integration`, ruff `F` (no new finding vs baseline), `ast.parse`, `bash -n`.

**Written for this package, never executed on a remote machine:** `.github/workflows/phase13-validation.yml` and `validation-kit/ci_run.sh` (section 6).

## 2. What is in this package

```
README.md                         this file
PACKAGE.SHA256SUMS                checksums of every file in this package (new; the originals below are kept as they were)
IT-BRIDGE/                        THE PROJECT: the verified tree, byte for byte (tree hash 9d228002…33ca). Edit nothing in here.
.github/workflows/                phase13-validation.yml: one-click remote validation (GitHub Actions)
validation-kit/                   run_phase13_validation.sh (driver), itb_db_gate.py (safety gate), itb_db_gate_selftest.py,
                                  ci_run.sh (new wrapper for a remote machine), PHASE13_RUNTIME_VALIDATION_HANDOFF.md,
                                  PHASE13_EXTERNAL_RUNBOOK.md, README_TRANSFER.md   (all but ci_run.sh are byte-identical to the originals)
provenance/                       the ORIGINAL transfer package, unchanged:
                                    itb-phase13-transfer.tar (+ .sha256)  = baselines, diff, kit, docs, derived tree zip
                                    PHASE13_KIT.SHA256SUMS.original
                                    evidence/real-env-driver-run-2026-10-12/  status.tsv, summary.txt, driver_stdout.txt of the one real (INCOMPLETE) run
```
`IT-BRIDGE/` contains the complete application: backend (FastAPI app, Alembic migrations 0001-0007, tests), frontend (React, Vite, Vitest tests), scripts, Docker files, docs. It is Phase 12 + Phase 13B.4 + the 26-file Phase 13 engineering diff; nothing was rewritten.

## 3. Remote environment requirements

| Need | Requirement |
|---|---|
| OS | Linux x86_64 (GitHub-hosted `ubuntu-24.04` is what the workflow uses) |
| Network (outbound HTTPS) | `pypi.org`, `files.pythonhosted.org`, `registry.npmjs.org`, Docker Hub (to pull `postgres:16`), the Ubuntu apt mirrors (for `postgresql-client-16`) |
| Python | **3.12.x** (the driver refuses anything else) |
| Node | **20.x** (the driver refuses anything else; any recent npm) |
| PostgreSQL | **16.x** server in a brand-new throwaway Docker container, plus `psql` and `pg_dump` **16.x** clients |
| Tools | Docker, git, GNU coreutils/findutils, `patch`, `unzip`, `tar` |
| Resources | no figure can be established from the files; the pytest stage allows 60 minutes and the job limit in the workflow is 6 hours |
| Access | a **private** GitHub repository you own; GitHub Actions enabled (minutes on private repositories depend on your plan) |

Any other internet-enabled Linux machine or cloud shell with that list works: `bash validation-kit/ci_run.sh A` does the same job there.

## 4. Next steps (numbered)

1. **Verify the download.** Compare the SHA-256 of `IT-BRIDGE-phase13-portable.zip` with the value given with the download, then unzip it.
2. **Create a private GitHub repository** (github.com/new, visibility *Private*, name e.g. `it-bridge`). Do not add a `.gitignore` or license.
3. **Import the package.** Choose one:
   - **3a. Git on your laptop (no project code is run):**
     ```bash
     cd IT-BRIDGE-phase13-portable
     git init -b main && git add -A && git commit -m "IT BRIDGE Phase 13 candidate (unapproved) + validation kit"
     git remote add origin https://github.com/<you>/<repo>.git && git push -u origin main
     ```
     Pushing `.github/workflows/` needs a credential with the `workflow` permission (a personal access token with `workflow`, or `gh auth login`).
   - **3b. Browser only (GitHub Codespaces):** create the repository with "Add a README" ticked, open *Code > Codespaces > Create codespace on main*, drag the zip into the file tree, then in the terminal:
     ```bash
     unzip -q IT-BRIDGE-phase13-portable.zip && cp -a IT-BRIDGE-phase13-portable/. ./ && rm -rf IT-BRIDGE-phase13-portable IT-BRIDGE-phase13-portable.zip
     git add -A && git commit -m "IT BRIDGE Phase 13 candidate (unapproved) + validation kit" && git push
     ```
     If the push of `.github/workflows/phase13-validation.yml` is refused, add that one file in the GitHub web editor (*Add file > Create new file*, paste its contents) and push the rest.
   - Do not edit, reformat or "tidy" anything under `IT-BRIDGE/`. Git does not store the six empty directories of the tree (`database/migrations`, `database/seed`, `docker`, `frontend/public`, `frontend/src/assets`, `.github/workflows` inside `IT-BRIDGE/`); nothing references them and they are not part of the tree hash.
4. **Run the validation.** In the repository: *Actions > Phase 13 runtime validation > Run workflow*, leave "run_b" off, run it. It verifies every checksum and the tree hash first, installs the project's requirements with Alembic constrained to 1.13.3, starts a disposable PostgreSQL 16 container, passes the safety gate, and runs the unchanged driver with all 34 checks.
5. **Read the result.** The job summary shows the `VERDICT:` line and exit code. Green means `VERDICT: PASS` (all 34 checks, no skips). Red means FAIL (1), INCOMPLETE (3), a blocked step (5) or a refused gate (6); the cause is in the evidence. Download the artifact **`phase13-evidence-run-A`** from the run page.
6. **Bring the evidence back.** Upload the artifact (a zip) to the next session. It contains `results-A/status.tsv`, `summary.txt`, `environment.txt`, all logs, `pytest-junit.xml`, `cli/*`, `driver-stdout-A.txt`, `exit-code-A.txt`, `pip-freeze-A.txt`, `pip-install-A.log`, `alembic-version-A.txt`, `tool-versions-A.txt`, `hashes-before.txt`, `hashes-after.txt`, `VERDICT.txt`. Reviewing it needs no registry access.
7. **Only after run A is recorded**, optionally run the workflow again with "run_b" on (newest Alembic, separate environment). B decides only whether the Alembic pin may later be widened; it can never rescue a failed A.
8. **If anything is red:** do not edit `IT-BRIDGE/` to get a pass and do not weaken a test, the gate or the migration policy. Bring the evidence; fixes are minimal, reviewed, and re-validated.

## 5. Safety rules that stay on

- The only database ever touched is a brand-new Docker PostgreSQL 16 on `127.0.0.1` (port 55432 for A, 55433 for B), random password, nothing persisted, removed afterwards.
- `itb_db_gate.py` accepts a target only if: strict URL form (no query, no `localhost`, port not 5432), no `PG*` variables, server is PostgreSQL 16 and a primary, the database is named with `test` **and** carries the comment `ITB_PHASE13_DISPOSABLE`, and every other database in the cluster carries it too. It is re-run before every database command. A refusal stops the run (exit 6).
- Payments stay disabled: Alembic commands run with `ENVIRONMENT=test PAYMENTS_ENABLED=false PAYMENT_SANDBOX_ENABLED=false`; the code has no real payment provider (only a sandbox simulator); no payment credential or webhook secret is used.
- The workflow has read-only repository permission and no secrets.

## 6. What is unverified (read before trusting a first run)

1. `ci_run.sh` and the workflow have **never been run on a remote machine**. Tested locally: shell and YAML syntax; the git round trip of the tree (232 files, hash unchanged after `git add`, commit and clone); and `ci_run.sh` steps 1-3 (provenance, tree, toolchain), including five failure cases (edited tree file, extra file in the tree, edited kit file, edited transfer tar, bad argument) that all stop with exit 2 and a clean run that stops at the toolchain check where Python is not 3.12. **Steps 4-7 (venv and pip, PostgreSQL container, gate pre-check, driver run, evidence hygiene) have not been executed anywhere.** A first remote run can fail for a reason that is in the wrapper or the workflow (a runner image detail, Docker Hub rate limiting, a quoting error), not in the project. Such a fix belongs in `validation-kit/ci_run.sh` or the workflow, outside `IT-BRIDGE/`, and must be reported as such.
2. Nothing is pinned by the project: `backend/requirements.txt` lists 13 names with no versions, `frontend/package.json` has caret ranges only, **there is no frontend lockfile**, and none was generated. `alembic==1.13.3` is only the validation candidate (reasoning, not evidence). Every resolved version is unknown until run A records `pip freeze` and `npm ls`.
3. Unknown until a real run: Alembic 1.13.3 with the newest SQLAlchemy; the newest pytest, httpx, FastAPI, Pydantic with the tests; `tzdata` (undeclared; the wrapper checks `Asia/Kolkata` and stops rather than guessing); Vitest in its default Node environment (no `jsdom` declared; `@testing-library/react` declared but unused); every PostgreSQL-only test and `verify_postgres_sql.py` (written and reviewed, never executed); the Alembic guard assumptions D1-D9 (handoff section 2).
4. Approval needs run A to end `VERDICT: PASS` on **all 34 checks with zero skips**, matching hashes, the other conditions in handoff section 8, and a person's review. Until then: no `PROJECT_PROGRESS.md` update, no pins, no lockfile, no Phase 14.
