#!/usr/bin/env bash
# IT BRIDGE Phase 13: staged runtime validation driver. See PHASE13_RUNTIME_VALIDATION_HANDOFF.md.
#
#   REPO=/path/to/IT-BRIDGE  ITB_TEST_DATABASE_URL=postgresql+psycopg2://postgres@127.0.0.1:55432/itbridge_test  bash run_phase13_validation.sh
# Optional: PYTHON=python3.12  RESULTS=/dir/outside/the/repo  STAGES=static,deps,gate,pytest,sqlsmoke,cli,frontend  ALEMBIC_EXPECTED=1.13.3|any
#           EXPECTED_TREE_SHA256=...  (default: the value baked into this file)   T_PYTEST=3600 T_ALEMBIC=300 ...  (per-stage timeouts in seconds)
# Run it from OUTSIDE the repository.
#
# WHAT THE VERDICT MEANS
#   Every check has a fixed name (EXPECTED below) and ends in exactly one status:
#     PASS | FAIL | MISSING_DEPENDENCY | ENVIRONMENT | TIMEOUT | REFUSED | NOT_RUN | INTERRUPTED          (INFO lines are notes, not checks)
#   PASS      exit 0: EVERY expected check was recorded exactly as PASS. Nothing was skipped, unselected, blocked, refused, timed out or interrupted.
#   FAIL      exit 1: at least one check ran and failed (a wrong tree, a wrong tool version and a failing test all count).
#   INCOMPLETE exit 3 (exit 4 if interrupted / the driver itself stopped early): no check failed, but at least one expected check did not PASS or was never
#             recorded. A skipped test, a missing dependency, an unselected stage, a refused database, a timeout are all INCOMPLETE: NOT approval evidence.
#   A PASS verdict is runtime EVIDENCE for a person to review. It does not itself approve Phase 13.
#   The first two checks (tool versions, repository tree) are fatal: if either does not PASS, nothing else runs (those checks are then NOT_RUN).
#
# DATABASE SAFETY. The only database the driver ever touches is the one in ITB_TEST_DATABASE_URL, and only through itb_db_gate.py (strict URL, marker
# comment ITB_PHASE13_DISPOSABLE, every other database of the cluster marked, server-side guard in the same session as the destructive statement), re-checked
# immediately before EVERY Alembic command, test run and SQL script. Every child process runs under `env -i`: PG* variables, DATABASE_URL, .env lookups of
# your shell can reach nothing. Without the variable no database command is run and those checks are NOT_RUN.
set -u -o pipefail

KIT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# ---- configuration -------------------------------------------------------------------------------------------------------------------------------
EXPECTED_TREE_SHA256="${EXPECTED_TREE_SHA256:-9d2280022999b74b40af3015743c5c93eebaabed3704d2d35a1bef32fe1d33ca}"      # the tree this kit was built for (the Phase 13 engineering-fixes diff applied to the 13B.4 baseline)
EXPECT_PY="${EXPECT_PY:-3.12}"          # backend/Dockerfile: python:3.12-slim
EXPECT_NODE="${EXPECT_NODE:-20}"        # frontend/Dockerfile: node:20-alpine
EXPECT_PG="${EXPECT_PG:-16}"            # docker-compose.yml: postgres:16 (psql and pg_dump must be 16.x too)
ALEMBIC_EXPECTED="${ALEMBIC_EXPECTED:-1.13.3}"      # candidate pin (see the handoff); "any" = unpinned comparison run, the version found is recorded
STAGES="${STAGES:-static,deps,gate,pytest,sqlsmoke,cli,frontend}"
T_STATIC="${T_STATIC:-300}"; T_DEPS="${T_DEPS:-120}"; T_PYTEST="${T_PYTEST:-3600}"; T_CANARY="${T_CANARY:-1800}"; T_SQLSMOKE="${T_SQLSMOKE:-900}"
T_ALEMBIC="${T_ALEMBIC:-300}"; T_NPM="${T_NPM:-1200}"
PY="${PYTHON:-python3}"
URL="${ITB_TEST_DATABASE_URL:-}"
REPO="${REPO:-}"
[ -n "$REPO" ] && [ -f "$REPO/backend/alembic.ini" ] || { echo "set REPO to the IT-BRIDGE tree under test (it must contain backend/alembic.ini)"; exit 2; }
REPO="$(cd "$REPO" && pwd)"
RESULTS="${RESULTS:-$PWD/phase13-results-$(date +%Y%m%dT%H%M%S)}"
mkdir -p "$RESULTS/cli" "$RESULTS/home" "$RESULTS/work" || { echo "cannot create $RESULTS"; exit 2; }
RESULTS="$(cd "$RESULTS" && pwd)"
case "$RESULTS/" in "$REPO"/*) echo "RESULTS must be outside the repository"; exit 2;; esac
case "$EXPECTED_TREE_SHA256" in @@*) echo "this copy of the driver has no tree hash baked in (EXPECTED_TREE_SHA256): refusing to run"; exit 2;; esac
ISOHOME="$RESULTS/home"          # an empty HOME for children: no ~/.pgpass, ~/.pg_service.conf, ~/.config
SUMMARY="$RESULTS/summary.txt"; TSV="$RESULTS/status.tsv"
: >"$SUMMARY"; : >"$TSV"
GATE=(env -i PATH="$PATH" HOME="$ISOHOME" LANG=C.UTF-8 "$PY" -I -B "$KIT/itb_db_gate.py")

# ---- the checks that must ALL be PASS for a PASS verdict ---------------------------------------------------------------------------------------------
EXPECTED=(
  "versions: tools (timeout, sha256sum, cmp, find, psql, pg_dump)" "versions: python" "versions: node and npm" "versions: postgres clients" "versions: alembic"
  "tree: matches the expected SHA-256"
  "static: check_migrations_static (stub Alembic, SQLite)" "static: audit_integration"
  "deps: backend imports"
  "gate: disposable PostgreSQL"
  "pytest: full backend suite"
  "canary: Alembic API assumptions (pytest migration files)"
  "sqlsmoke: verify_postgres_sql (psql, not Alembic)"
  "cli: heads / history without the app package"
  "cli: alembic revision renders the pre-flight template"
  "cli: upgrade head + alembic check (no drift)"
  "cli: base_refused_core_data" "cli: revision_0003_refused_notification_data" "cli: revision_0004_refused_financial_data"
  "cli: wrong_switch_value_true" "cli: wrong_switch_name"
  "cli: minus1_allowed" "cli: revision_0006_allowed" "cli: revision_0005_allowed"
  "cli: minus1_from_0004_removes_the_notification_tables" "cli: minus3_from_0005_reaches_0004"
  "cli: offline --sql of a destructive path"
  "cli: exact override lets base proceed" "cli: upgrade head again after a full downgrade"
  "canary: Alembic API assumptions (CLI matrix)"
  "frontend: npm install" "frontend: vitest run" "frontend: vite build"
  "tree: unchanged by the run"
)

wants() { case ",$STAGES," in *",$1,"*) return 0;; esac; return 1; }
record() {   # record NAME STATUS DETAIL
  printf '%s\t%s\t%s\n' "$1" "$2" "$3" >>"$TSV"
  printf '%-9s %-62s %s\n' "$2" "$1" "$3" | tee -a "$SUMMARY"
}
has() { grep -qE "$2" "$1" 2>/dev/null; }
status_of() { awk -F'\t' -v n="$1" '$1==n {print $2}' "$TSV" | tail -1; }
recorded() { [ -n "$(status_of "$1")" ]; }
ENV_RE='Connection refused|could not connect|connection to server|ENOTFOUND|EAI_AGAIN|ETIMEDOUT|E403|403 Forbidden|Temporary failure in name resolution|CONNECT tunnel failed'

# A failing command is MISSING_DEPENDENCY only when a THIRD-PARTY module / program is missing. "No module named 'app...'" or "cannot import name" is a defect in the project: FAIL.
classify() {   # classify LOG RC -> prints status
  local log="$1" rc="$2" m
  [ "$rc" -eq 124 ] || [ "$rc" -eq 137 ] && { echo TIMEOUT; return; }
  m="$(grep -ohE "No module named '[^'.]+" "$log" 2>/dev/null | sed "s/.*'//" | grep -vxE 'app|tests|scripts|conftest' | head -1)"
  if [ -n "$m" ] || has "$log" 'command not found|: not found$|Cannot find module|ERR_MODULE_NOT_FOUND|executable file not found'; then echo MISSING_DEPENDENCY
  elif has "$log" "$ENV_RE"; then echo ENVIRONMENT
  else echo FAIL; fi
}

# ---- children: background + wait (so a signal reaches the trap), timeout (kills the whole process group), env -i is added by the callers ---------------
CHILD=""
runc() {   # runc LOG SECS DIR CMD...   -> exit status of CMD (124 = timeout)
  local log="$1" secs="$2" dir="$3"; shift 3
  ( cd "$dir" 2>/dev/null && exec timeout -k 15 "$secs" "$@" ) >"$log" 2>&1 &
  CHILD=$!
  wait "$CHILD"; local rc=$?
  CHILD=""
  return $rc
}
run() {   # run NAME SECS DIR CMD...  : one check, one record
  local name="$1" secs="$2" dir="$3"; shift 3
  local f; f="$(printf '%s' "$name" | tr -c 'A-Za-z0-9._-' '_')"
  runc "$RESULTS/$f.log" "$secs" "$dir" "$@"; local rc=$?
  if [ $rc -eq 0 ]; then record "$name" PASS "exit 0"; return 0; fi
  record "$name" "$(classify "$RESULTS/$f.log" $rc)" "exit $rc; see $f.log"
  return $rc
}

# ---- verdict, interruption, early exit -----------------------------------------------------------------------------------------------------------
FINISHED=0
finish() {   # finish [FORCED_EXIT_CODE REASON]
  local forced="${1:-}" reason="${2:-}" n fails=0 other=0 id st line
  [ $FINISHED -eq 1 ] && return; FINISHED=1
  for id in "${EXPECTED[@]}"; do recorded "$id" || { record "$id" NOT_RUN "never recorded (stage not selected, not reached, or the run stopped)"; }; done
  while IFS=$'\t' read -r id st line; do
    case "$st" in PASS|INFO) ;; FAIL) fails=$((fails+1));; *) other=$((other+1));; esac
  done <"$TSV"
  # a name listed as expected must not be hiding a second, failing record: the loop above already counted every record, not only the last one
  n=${#EXPECTED[@]}
  echo; echo "Results: $RESULTS   (status.tsv is the machine-readable record)"
  if [ -n "$forced" ] && [ "$fails" -eq 0 ]; then echo "VERDICT: INCOMPLETE ($reason): NOT approval evidence"; exit "$forced"; fi
  if [ "$fails" -gt 0 ]; then echo "VERDICT: FAIL ($fails check(s) failed; $other other check(s) did not pass)"; exit 1; fi
  if [ "$other" -gt 0 ]; then echo "VERDICT: INCOMPLETE ($other of $n expected check(s) did not PASS or never ran): NOT approval evidence"; exit 3; fi
  echo "VERDICT: PASS (all $n expected checks passed: runtime EVIDENCE for review, not an approval)"; exit 0
}
on_signal() { [ -n "$CHILD" ] && kill -TERM "$CHILD" 2>/dev/null; record "driver" INTERRUPTED "received SIG$1 while running; the remaining checks did not run"; finish 4 "interrupted by SIG$1"; }
trap 'on_signal INT' INT; trap 'on_signal TERM' TERM; trap 'on_signal HUP' HUP
trap '[ $FINISHED -eq 0 ] && { record "driver" INTERRUPTED "the driver stopped before the end"; finish 4 "the driver stopped early"; }' EXIT

HALT=""   # set by a fatal check: no further check runs (they become NOT_RUN in finish)
halt() { HALT="$1"; echo "HALT: $1"; }

# ---- fatal checks: tools, versions, tree ---------------------------------------------------------------------------------------------------------
tools_missing=""
for t in timeout sha256sum cmp find sort xargs awk psql pg_dump "$PY"; do command -v "$t" >/dev/null 2>&1 || tools_missing="$tools_missing $t"; done
if [ -n "$tools_missing" ]; then record "versions: tools (timeout, sha256sum, cmp, find, psql, pg_dump)" MISSING_DEPENDENCY "not installed:$tools_missing"; halt "required tools missing"
else record "versions: tools (timeout, sha256sum, cmp, find, psql, pg_dump)" PASS "present"; fi

if [ -z "$HALT" ]; then
  pyv="$("$PY" -c 'import sys; print("%d.%d.%d" % sys.version_info[:3])' 2>&1)"
  if [ "${pyv%.*}" = "$EXPECT_PY" ]; then record "versions: python" PASS "$pyv ($(command -v "$PY"))"; else record "versions: python" ENVIRONMENT "found '$pyv', expected $EXPECT_PY.x"; halt "wrong Python"; fi
  nodev="$(node --version 2>&1)"; npmv="$(npm --version 2>&1)"
  if [[ "$nodev" =~ ^v${EXPECT_NODE}\.[0-9]+\.[0-9]+$ ]] && [[ "$npmv" =~ ^[0-9]+\.[0-9]+ ]]; then record "versions: node and npm" PASS "node $nodev, npm $npmv"
  else record "versions: node and npm" ENVIRONMENT "node '$nodev' (expected v$EXPECT_NODE.x), npm '$npmv'"; halt "wrong or missing Node"; fi
  psv="$(psql --version 2>&1 | head -1)"; pdv="$(pg_dump --version 2>&1 | head -1)"
  if [[ "$psv" =~ ^psql\ \(PostgreSQL\)\ ${EXPECT_PG}\.[0-9]+ ]] && [[ "$pdv" =~ ^pg_dump\ \(PostgreSQL\)\ ${EXPECT_PG}\.[0-9]+ ]]; then record "versions: postgres clients" PASS "$psv; $pdv"
  else record "versions: postgres clients" ENVIRONMENT "'$psv' / '$pdv': PostgreSQL $EXPECT_PG clients are required"; halt "wrong PostgreSQL clients"; fi
  # alembic: the executable next to the interpreter (same environment as pytest), its package version and the pin
  PYEXE="$("$PY" -c 'import sys; print(sys.executable)' 2>/dev/null)"
  ALEMBIC_BIN="${ALEMBIC_BIN:-$(dirname "$PYEXE")/alembic}"; [ -x "$ALEMBIC_BIN" ] || ALEMBIC_BIN="$(command -v alembic 2>/dev/null || true)"
  alv="$("$PY" -c 'import importlib.metadata as m; print(m.version("alembic"))' 2>/dev/null)"
  if [ -z "$alv" ] || [ -z "$ALEMBIC_BIN" ]; then record "versions: alembic" MISSING_DEPENDENCY "alembic is not installed for $PY (package '${alv:-none}', executable '${ALEMBIC_BIN:-none}')"; halt "alembic missing"
  elif [ "$ALEMBIC_EXPECTED" != "any" ] && [ "$alv" != "$ALEMBIC_EXPECTED" ]; then record "versions: alembic" ENVIRONMENT "found $alv, the candidate pin is $ALEMBIC_EXPECTED (use ALEMBIC_EXPECTED=any only for the separate newest-release comparison run)"; halt "wrong Alembic"
  elif ! { head -1 "$ALEMBIC_BIN" | grep -qF "$PYEXE" || "$ALEMBIC_BIN" --version 2>&1 | grep -qF "$alv"; }; then record "versions: alembic" ENVIRONMENT "the alembic executable $ALEMBIC_BIN does not belong to $PYEXE (mixed environments)"; halt "mixed Alembic environments"
  else record "versions: alembic" PASS "$alv ($([ "$ALEMBIC_EXPECTED" = any ] && echo 'unpinned comparison run' || echo "= pin")), $ALEMBIC_BIN"; fi
fi

tree_hash() {
  (cd "$REPO" && find . -type f ! -path './frontend/node_modules/*' ! -path './frontend/dist/*' ! -path '*/__pycache__/*' ! -path './.git/*' ! -path '*/.venv/*' \
     ! -path '*/.pytest_cache/*' ! -path '*/.ruff_cache/*' ! -name '*.pyc' ! -path './backend/.env' ! -path './.env' | LC_ALL=C sort | xargs -d '\n' sha256sum | sha256sum | cut -d' ' -f1)
}
if [ -z "$HALT" ]; then
  T0="$(tree_hash)"
  if [ "$T0" = "$EXPECTED_TREE_SHA256" ]; then record "tree: matches the expected SHA-256" PASS "$T0"
  else record "tree: matches the expected SHA-256" FAIL "found $T0, expected $EXPECTED_TREE_SHA256: this is not the tree the kit was built for"; halt "wrong tree"; fi
  {
    echo "date_utc: $(date -u +%FT%TZ)"; echo "TREE_SHA256: $T0"; uname -a
    echo "--- python"; "$PY" --version; "$PY" -m pip --version; "$PY" -m pip freeze
    echo "--- node"; node --version; npm --version
    echo "--- postgres clients"; psql --version; pg_dump --version
    echo "--- alembic"; echo "$ALEMBIC_BIN"; "$ALEMBIC_BIN" --version
    echo "--- caller PG*/DATABASE_URL variables (ignored: every child runs under env -i)"; env | grep -E '^(PG|DATABASE_URL|ITB_)' | sed -E 's/(PASSWORD|SECRET)=.*/\1=<hidden>/; s#://([^:@/]*):[^@/]*@#://\1:<hidden>@#'
  } >"$RESULTS/environment.txt" 2>&1
  record "env: evidence (pip freeze, versions, caller PG* variables) -> environment.txt" INFO "recorded"
fi

# ---- static (standard library only) --------------------------------------------------------------------------------------------------------------
if [ -z "$HALT" ] && wants static; then
  run "static: check_migrations_static (stub Alembic, SQLite)" "$T_STATIC" "$REPO" env -i PATH="$PATH" HOME="$ISOHOME" PYTHONDONTWRITEBYTECODE=1 "$PY" -I -B scripts/check_migrations_static.py
  run "static: audit_integration" "$T_STATIC" "$REPO" env -i PATH="$PATH" HOME="$ISOHOME" PYTHONDONTWRITEBYTECODE=1 "$PY" -I -B scripts/audit_integration.py
fi

# ---- deps ----------------------------------------------------------------------------------------------------------------------------------------
DEPS_OK=0
if [ -z "$HALT" ] && wants deps; then
  cat >"$RESULTS/deps_check.py" <<'PYEOF'
import importlib, importlib.metadata as md, sys
mods = {"fastapi": "fastapi", "uvicorn": "uvicorn", "pydantic_settings": "pydantic-settings", "email_validator": "email-validator", "sqlalchemy": "sqlalchemy",
        "alembic": "alembic", "psycopg2": "psycopg2-binary", "jose": "python-jose", "bcrypt": "bcrypt", "redis": "redis", "celery": "celery", "pytest": "pytest", "httpx": "httpx"}
missing = []
for m, dist in mods.items():
    try:
        importlib.import_module(m)
    except Exception as e:                    # noqa: BLE001
        missing.append(m)
        print(f"ModuleNotFoundError: No module named '{m}' ({e!r})")
        continue
    try:
        print(f"{dist}=={md.version(dist)}")
    except Exception:                         # noqa: BLE001
        print(f"{dist}==(version unknown)")
sys.exit(3 if missing else 0)
PYEOF
  runc "$RESULTS/deps.log" "$T_DEPS" "$RESULTS/work" env -i PATH="$PATH" HOME="$ISOHOME" "$PY" -I -B "$RESULTS/deps_check.py"; rc=$?
  if [ $rc -eq 0 ]; then DEPS_OK=1; record "deps: backend imports" PASS "$(grep -c '==' "$RESULTS/deps.log") packages imported; versions in deps.log"
  elif [ $rc -eq 3 ]; then record "deps: backend imports" MISSING_DEPENDENCY "$(grep -c '^ModuleNotFoundError' "$RESULTS/deps.log") module(s) missing; see deps.log"
  else record "deps: backend imports" "$(classify "$RESULTS/deps.log" $rc)" "exit $rc; see deps.log"; fi
fi

# ---- the gate and the re-gate ---------------------------------------------------------------------------------------------------------------------
GATE_OK=0
regate() {   # regate WHAT : immediately before a database command. A refusal stops every later database command.
  [ $GATE_OK -eq 1 ] || return 1
  local rc=0
  "${GATE[@]}" check "$URL" >"$RESULTS/regate.log" 2>&1 || rc=$?
  [ $rc -eq 0 ] && return 0
  GATE_OK=0
  record "gate: re-check before $1" "$([ $rc -eq 3 ] && echo REFUSED || echo ENVIRONMENT)" "$(tail -1 "$RESULTS/regate.log"); no further database command will run"
  return 1
}
if [ -z "$HALT" ] && wants gate; then
  if [ -z "$URL" ]; then record "gate: disposable PostgreSQL" NOT_RUN "ITB_TEST_DATABASE_URL is not set"
  elif "${GATE[@]}" check "$URL" --expect-empty >"$RESULTS/gate.log" 2>&1; then GATE_OK=1; record "gate: disposable PostgreSQL" PASS "$(sed -n 3p "$RESULTS/gate.log" | sed 's/^ *//')"
  else rc=$?; record "gate: disposable PostgreSQL" "$([ $rc -eq 3 ] && echo REFUSED || echo ENVIRONMENT)" "$(tail -1 "$RESULTS/gate.log")"; fi
fi

# ---- pytest --------------------------------------------------------------------------------------------------------------------------------------
pytest_run() {   # pytest_run LOG SECS ARGS...   (the PostgreSQL tests WIPE the schema of ITB_TEST_DATABASE_URL: they only ever see a URL the gate has just passed)
  local log="$1" secs="$2"; shift 2
  local pgvar=(); regate "pytest" && pgvar=("ITB_TEST_DATABASE_URL=$URL")
  runc "$log" "$secs" "$REPO/backend" env -i PATH="$PATH" HOME="$ISOHOME" LANG=C.UTF-8 PYTHONDONTWRITEBYTECODE=1 ${pgvar[@]+"${pgvar[@]}"} "$PY" -m pytest -q -p no:cacheprovider "$@"
}
if [ -z "$HALT" ] && wants pytest; then
  N="pytest: full backend suite"
  if [ $DEPS_OK -ne 1 ]; then record "$N" MISSING_DEPENDENCY "dependencies not importable (see deps stage); NOT RUN"
  else
    pytest_run "$RESULTS/pytest.log" "$T_PYTEST" -rs --junitxml="$RESULTS/pytest-junit.xml"; rc=$?
    if [ $rc -eq 1 ]; then record "$N" FAIL "exit 1: test failures; see pytest.log"
    elif [ $rc -ne 0 ]; then record "$N" "$(classify "$RESULTS/pytest.log" $rc)" "exit $rc (collection/usage error or timeout); see pytest.log"
    else
      cat >"$RESULTS/junit_check.py" <<'PYEOF'
import sys, xml.etree.ElementTree as ET
root = ET.parse(sys.argv[1]).getroot()
cases = list(root.iter("testcase"))
skipped = [c for c in cases if c.find("skipped") is not None]
must_run = ("test_migrations_postgres", "test_postgres_concurrency", "test_postgres_notifications", "test_startup_hermetic", "test_migrations", "test_migration_guard",
            "test_migration_guards_static", "test_payments_phase13", "test_pg_gate", "test_verify_postgres_sql_gate")
def of(c, m):
    cn = c.get("classname", "")
    return cn == f"tests.{m}" or cn.startswith(f"tests.{m}.")
print(f"tests={len(cases)} skipped={len(skipped)}")
bad = 0 if cases else 1
for m in must_run:
    ran = [c for c in cases if of(c, m) and c.find("skipped") is None]
    if not ran:
        bad += 1
        print(f"REQUIRED-FILE-NOT-RUN {m}: no test of it ran (collected {sum(of(c, m) for c in cases)}, all skipped or none)")
for c in skipped:
    required = any(of(c, m) for m in must_run)
    print(("REQUIRED-FILE-SKIPPED " if required else "skipped ") + f"{c.get('classname', '')}::{c.get('name')}: {(c.find('skipped').get('message') or '')[:120]}")
sys.exit(1 if bad else 0)
PYEOF
      if "$PY" -I -B "$RESULTS/junit_check.py" "$RESULTS/pytest-junit.xml" >"$RESULTS/pytest-skips.txt" 2>&1; then
        grep -q '^REQUIRED-FILE-SKIPPED' "$RESULTS/pytest-skips.txt" && record "$N" NOT_RUN "passed, but a test of a required file was SKIPPED (= not run); see pytest-skips.txt" \
          || record "$N" PASS "$(head -1 "$RESULTS/pytest-skips.txt"); every required file ran"
      else record "$N" NOT_RUN "exit 0, but a required file did not run or was skipped (or no test ran); see pytest-skips.txt"; fi
    fi
  fi
fi

# ---- canary: did Alembic behave the way the guard assumes? ----------------------------------------------------------------------------------------------
# The guard logs a WARNING ("downgrade pre-flight: ...") whenever Alembic's answers were missing or disagreed with its own: direct evidence that one of
# assumptions D1-D4 in the handoff is FALSE (the guard still stayed safe). The two real-Alembic test files are re-run only to collect those lines.
if [ -z "$HALT" ] && wants pytest; then
  N="canary: Alembic API assumptions (pytest migration files)"
  if [ $DEPS_OK -ne 1 ]; then record "$N" MISSING_DEPENDENCY "NOT RUN"
  elif ! [ $GATE_OK -eq 1 ]; then record "$N" NOT_RUN "no database: the PostgreSQL migration tests cannot run"
  else
    pytest_run "$RESULTS/canary-pytest.out" "$T_CANARY" tests/test_migrations.py tests/test_migrations_postgres.py --log-file="$RESULTS/canary-pytest.log" --log-file-level=WARNING; rc=$?
    n=$(grep -c "downgrade pre-flight:" "$RESULTS/canary-pytest.log" 2>/dev/null); n=${n:-0}
    if [ $rc -ne 0 ]; then record "$N" "$([ $rc -eq 1 ] && echo FAIL || classify "$RESULTS/canary-pytest.out" $rc)" "pytest exit $rc; see canary-pytest.out"
    elif [ "$n" -ne 0 ]; then record "$N" FAIL "$n warning(s): an assumption about Alembic did not hold (guard stayed safe); read canary-pytest.log"
    else record "$N" PASS "no 'downgrade pre-flight' warning"; fi
  fi
fi

# ---- SQL-level PostgreSQL checks (psql only; not Alembic) -----------------------------------------------------------------------------------------
if [ -z "$HALT" ] && wants sqlsmoke; then
  N="sqlsmoke: verify_postgres_sql (psql, not Alembic)"
  if [ $GATE_OK -ne 1 ]; then record "$N" NOT_RUN "gate did not pass"
  elif ! regate "sqlsmoke"; then record "$N" NOT_RUN "gate re-check refused"
  else
    if ! "${GATE[@]}" pgenv "$URL" >"$RESULTS/pgenv.txt" 2>"$RESULTS/pgenv.err"; then record "$N" ENVIRONMENT "gate pgenv failed: $(tail -1 "$RESULTS/pgenv.err")"
    else
      eval "PGENV=($(sed 's/^export //' "$RESULTS/pgenv.txt"))"
      runc "$RESULTS/sqlsmoke.log" "$T_SQLSMOKE" "$REPO" env -i PATH="$PATH" HOME="$ISOHOME" PYTHONDONTWRITEBYTECODE=1 "${PGENV[@]}" "$PY" -I -B scripts/verify_postgres_sql.py; rc=$?
      if [ $rc -eq 0 ]; then record "$N" PASS "$(grep -E '[0-9]+ passed, 0 failed' "$RESULTS/sqlsmoke.log" | tail -1)"
      elif [ $rc -eq 2 ]; then record "$N" ENVIRONMENT "BLOCKED (exit 2): see sqlsmoke.log"
      elif [ $rc -eq 3 ]; then record "$N" REFUSED "the script's own safety rules refused: $(grep REFUSED "$RESULTS/sqlsmoke.log" | head -1)"
      else record "$N" "$(classify "$RESULTS/sqlsmoke.log" $rc)" "exit $rc; see sqlsmoke.log"; fi
    fi
  fi
fi

# ---- Alembic command line on the disposable PostgreSQL -------------------------------------------------------------------------------------------
USER_SQL="INSERT INTO users (email, password_hash, full_name, role, is_active, email_verified, created_at) VALUES ('a@example.com', 'x', 'A', 'TRAINER', true, true, now())"
PREF_SQL="INSERT INTO notification_preferences (user_id, channel, enabled, updated_at) SELECT id, 'EMAIL', false, now() FROM users"
FIN_SQL="INSERT INTO invoice_counters (series, year, last_number) VALUES ('INV', 2099, 1)"
SWITCH=ITB_ALLOW_FINANCIAL_DOWNGRADE
PHRASE=I_UNDERSTAND_DATA_WILL_BE_DESTROYED

# acmd LOG [VAR=value ...] alembic ARGS...   (an EMPTY environment but PATH/HOME and the variables below: nothing inherited can point Alembic anywhere else;
# the gate is asked again immediately before the command)
acmd() {
  local log="$1"; shift
  local extra=()
  while [ $# -gt 0 ] && [[ "$1" == [A-Z_]*=* ]]; do extra+=("$1"); shift; done
  [ "${1:-}" = alembic ] && shift
  if ! regate "alembic $*"; then echo "the gate refused immediately before this command: alembic was NOT run" >"$log"; return 97; fi
  runc "$log" "$T_ALEMBIC" "$REPO/backend" env -i PATH="$PATH" HOME="$ISOHOME" LANG=C.UTF-8 PYTHONDONTWRITEBYTECODE=1 DATABASE_URL="$URL" ENVIRONMENT=test PAYMENTS_ENABLED=false \
    PAYMENT_SANDBOX_ENABLED=false ${extra[@]+"${extra[@]}"} "$ALEMBIC_BIN" "$@"
}
gsql() { "${GATE[@]}" sql "$URL" "$1"; }
snap() { "${GATE[@]}" snapshot "$URL" "$1" >/dev/null 2>&1; }
at_head() { "${GATE[@]}" reset "$URL" >/dev/null 2>&1 && acmd "$RESULTS/cli/upgrade.$1.log" alembic upgrade head && [ "$(gsql 'SELECT version_num FROM alembic_version')" = "0007" ]; }
fail_status() { [ "$1" -eq 124 ] && echo TIMEOUT || { [ "$1" -eq 97 ] && echo REFUSED || echo FAIL; }; }

# refused NAME TARGET MUST_CONTAIN MUST_NOT_CONTAIN [VAR=value...] : the command must fail, say what it must, and leave the database BYTE-FOR-BYTE unchanged
refused() {
  local name="$1" target="$2" must="$3" mustnot="$4"; shift 4
  local log="$RESULTS/cli/$name.log" why="" st=FAIL
  snap "$RESULTS/cli/$name.before.txt" && [ -s "$RESULTS/cli/$name.before.txt" ] || why="$why could not take the 'before' snapshot;"
  # shellcheck disable=SC2086
  acmd "$log" "$@" alembic downgrade $target; local rc=$?
  snap "$RESULTS/cli/$name.after.txt" && [ -s "$RESULTS/cli/$name.after.txt" ] || why="$why could not take the 'after' snapshot;"
  [ $rc -ne 0 ] || why="$why exit 0 (it ran);"
  [ $rc -ne 124 ] || { why="$why timeout;"; st=TIMEOUT; }
  [ $rc -ne 97 ] || { why="$why gate refused before the command;"; st=REFUSED; }
  has "$log" "Refusing to downgrade" || why="$why no 'Refusing to downgrade' message;"
  has "$log" "$must" || why="$why message lacks '$must';"
  { [ -z "$mustnot" ] || ! has "$log" "$mustnot"; } || why="$why message names '$mustnot';"
  cmp -s "$RESULTS/cli/$name.before.txt" "$RESULTS/cli/$name.after.txt" || why="$why DATABASE CHANGED (diff cli/$name.before.txt cli/$name.after.txt);"
  if [ -z "$why" ]; then record "cli: $name" PASS "refused, database identical"
  elif [ "$st" = FAIL ] && [ "$(classify "$log" $rc)" = MISSING_DEPENDENCY ]; then record "cli: $name" MISSING_DEPENDENCY "see cli/$name.log"
  else record "cli: $name" "$st" "$why see cli/$name.log"; fi
}
# allowed NAME TARGET EXPECT_REVISION : exit 0, the revision is right, users and notification_preferences keep their rows
allowed() {
  local name="$1" target="$2" want="$3" log="$RESULTS/cli/$1.log" why="" st=FAIL rc
  # shellcheck disable=SC2086
  acmd "$log" alembic downgrade $target; rc=$?
  [ $rc -eq 0 ] || { why="$why exit $rc;"; st="$(fail_status $rc)"; }
  [ "$(gsql 'SELECT version_num FROM alembic_version')" = "$want" ] || why="$why revision is not $want;"
  [ "$(gsql 'SELECT count(*) FROM users')" = "1" ] && [ "$(gsql 'SELECT count(*) FROM notification_preferences')" = "1" ] || why="$why rows were lost;"
  if [ -z "$why" ]; then record "cli: $name" PASS "ran, revision $want, rows kept"; else record "cli: $name" "$st" "$why see cli/$name.log"; fi
}
# prepare TAG [SEED_SQL...] : reset, upgrade to head, seed. A failure is RECORDED (never a silently skipped scenario).
prepare() {
  local tag="$1" s; shift
  if ! at_head "$tag"; then record "cli: setup $tag (reset + upgrade head)" FAIL "see cli/upgrade.$tag.log"; return 1; fi
  for s in "$@"; do gsql "$s" >/dev/null 2>>"$RESULTS/cli/$tag.seed.log" || { record "cli: setup $tag (seed)" FAIL "seed failed: ${s:0:70}; see cli/$tag.seed.log"; return 1; }; done
}
# step_to TAG REVISION : an allowed downgrade used to put the database at a lower revision before the scenario proper
step_to() {
  acmd "$RESULTS/cli/$1.stepto.log" alembic downgrade "$2" && [ "$(gsql 'SELECT version_num FROM alembic_version')" = "$2" ] \
    || { record "cli: setup $1 (step to $2)" FAIL "could not reach $2; see cli/$1.stepto.log"; return 1; }
}

if [ -z "$HALT" ] && wants cli; then
  if [ $DEPS_OK -ne 1 ]; then record "cli: Alembic matrix" MISSING_DEPENDENCY "backend dependencies not installed; NOT RUN"
  else
    # -- 1. commands that must NOT need the application: copy only alembic.ini + alembic/ to an empty directory (no `app` package anywhere on the path)
    T="$RESULTS/work/alembic_only"; rm -rf "$T"; mkdir -p "$T"; cp -r "$REPO/backend/alembic" "$REPO/backend/alembic.ini" "$T/"
    N="cli: heads / history without the app package"
    runc "$RESULTS/cli/heads_history_without_app.log" "$T_ALEMBIC" "$T" env -i PATH="$PATH" HOME="$ISOHOME" PYTHONDONTWRITEBYTECODE=1 bash -c "\"$ALEMBIC_BIN\" heads && \"$ALEMBIC_BIN\" history"; rc=$?
    if [ $rc -eq 0 ] && has "$RESULTS/cli/heads_history_without_app.log" "0007 \(head\)"; then record "$N" PASS "head 0007"
    else record "$N" "$(fail_status $rc)" "exit $rc; see cli/heads_history_without_app.log"; fi
    N="cli: alembic revision renders the pre-flight template"
    runc "$RESULTS/cli/revision_probe.log" "$T_ALEMBIC" "$T" env -i PATH="$PATH" HOME="$ISOHOME" PYTHONDONTWRITEBYTECODE=1 "$ALEMBIC_BIN" revision -m "validation probe"; rc=$?
    F="$(ls "$T"/alembic/versions/*validation_probe*.py 2>/dev/null | head -1)"
    if [ $rc -eq 0 ] && [ -n "$F" ] && grep -q "preflight_downgrade(" "$F"; then record "$N" PASS "$(grep -m1 'preflight_downgrade(' "$F" | sed 's/^ *//')"
    else record "$N" "$(fail_status $rc)" "exit $rc; see cli/revision_probe.log"; fi
    if [ $GATE_OK -ne 1 ]; then record "cli: PostgreSQL downgrade matrix" NOT_RUN "gate did not pass: no database command was run"
    else
      # -- 2. the matrix. Every scenario starts from a freshly reset, freshly upgraded database (prepare). Seeds: user, notification preference, invoice counter.
      N="cli: upgrade head + alembic check (no drift)"
      if prepare upgrade_check; then
        acmd "$RESULTS/cli/check.log" alembic check; rc=$?
        if [ $rc -eq 0 ]; then record "$N" PASS "revision 0007"; else record "$N" "$(fail_status $rc)" "exit $rc; see cli/check.log"; fi
      fi
      # refusals: nothing may change, the message must name the right revision and not name revisions the run does not remove
      prepare m1 "$USER_SQL" && refused base_refused_core_data base "0001: users 1 rows" ""
      prepare m2 "$USER_SQL" "$PREF_SQL" && refused revision_0003_refused_notification_data 0003 "0004: notification_preferences 1 rows" "0001"
      prepare m3 "$FIN_SQL" && refused revision_0004_refused_financial_data 0004 "0005: invoice_counters 1 rows" "0001"
      prepare m4 "$USER_SQL" && refused wrong_switch_value_true base "0001: users 1 rows" "" "$SWITCH=true"
      prepare m5 "$USER_SQL" && refused wrong_switch_name base "0001: users 1 rows" "" "ITB_ALLOW_DOWNGRADE=$PHRASE"
      # allowed: the path removes only 0007 (triggers/functions) and an empty 0006 table, whatever lower revisions hold
      prepare m6 "$USER_SQL" "$PREF_SQL" && allowed minus1_allowed "-1" 0006
      prepare m7 "$USER_SQL" "$PREF_SQL" && allowed revision_0006_allowed 0006 0006
      prepare m8 "$USER_SQL" "$PREF_SQL" && allowed revision_0005_allowed 0005 0005
      # relative targets are counted from the revision the DATABASE is at, not from head
      prepare m9 "$USER_SQL" "$PREF_SQL" && step_to m9 0004 && refused minus1_from_0004_removes_the_notification_tables "-1" "0004: notification_preferences 1 rows" "0001"
      prepare m10 "$USER_SQL" "$PREF_SQL" && step_to m10 0005 && refused minus3_from_0005_reaches_0004 "-3" "0004: notification_preferences 1 rows" "0001"
      # offline: must not emit destructive SQL without the override
      N="cli: offline --sql of a destructive path"
      if prepare m11; then
        acmd "$RESULTS/cli/offline_base.log" alembic downgrade 0007:base --sql; rc=$?
        if [ $rc -ne 0 ] && [ $rc -ne 124 ] && ! has "$RESULTS/cli/offline_base.log" "DROP TABLE" && has "$RESULTS/cli/offline_base.log" "Refusing to generate an offline"; then record "$N" PASS "refused with the guard's message"
        elif [ $rc -ne 0 ] && [ $rc -ne 124 ] && ! has "$RESULTS/cli/offline_base.log" "DROP TABLE"; then record "$N" FAIL "stopped safely but NOT with the guard's message (env.py has no offline branch; behaviour unverified): read cli/offline_base.log"
        else record "$N" "$(fail_status $rc)" "DESTRUCTIVE SQL WAS EMITTED, EXIT 0 OR TIMEOUT; see cli/offline_base.log"; fi
      fi
      # the exact override, on this disposable database only
      if prepare m12 "$USER_SQL" "$PREF_SQL"; then
        N="cli: exact override lets base proceed"
        acmd "$RESULTS/cli/override_base.log" "$SWITCH=$PHRASE" alembic downgrade base; rc=$?
        if [ $rc -eq 0 ] && [ "$(gsql "SELECT count(*) FROM pg_tables WHERE schemaname='public' AND tablename <> 'alembic_version'")" = "0" ]; then record "$N" PASS "every application table gone"
        else record "$N" "$(fail_status $rc)" "exit $rc; see cli/override_base.log"; fi
        N="cli: upgrade head again after a full downgrade"
        acmd "$RESULTS/cli/upgrade_again.log" alembic upgrade head; rc=$?
        if [ $rc -eq 0 ] && [ "$(gsql 'SELECT version_num FROM alembic_version')" = "0007" ]; then record "$N" PASS "0007"
        else record "$N" "$(fail_status $rc)" "exit $rc; see cli/upgrade_again.log"; fi
      fi
      N="canary: Alembic API assumptions (CLI matrix)"
      n=$(cat "$RESULTS"/cli/*.log 2>/dev/null | grep -c "downgrade pre-flight:"); n=${n:-0}
      if [ "$n" -eq 0 ]; then record "$N" PASS "no 'downgrade pre-flight' warning"
      else record "$N" FAIL "$n warning(s): an assumption about Alembic did not hold (guard stayed safe); grep 'downgrade pre-flight' in cli/*.log"; fi
      "${GATE[@]}" reset "$URL" >/dev/null 2>&1
    fi
  fi
fi

# ---- frontend (in a COPY: npm install writes package-lock.json and node_modules, and the tree under test must stay as it is) ------------------------------
if [ -z "$HALT" ] && wants frontend; then
  FE="$RESULTS/work/frontend"; rm -rf "$FE"; mkdir -p "$FE"
  (cd "$REPO/frontend" && tar --exclude=./node_modules --exclude=./dist -cf - .) | (cd "$FE" && tar -xf -)
  runc "$RESULTS/npm-install.log" "$T_NPM" "$FE" npm install; rc=$?
  if [ $rc -ne 0 ]; then record "frontend: npm install" "$(classify "$RESULTS/npm-install.log" $rc)" "exit $rc; see npm-install.log"
  else
    record "frontend: npm install" PASS "see npm-install.log (in a copy; no lockfile exists in the repository)"
    runc "$RESULTS/vitest.log" "$T_NPM" "$FE" npm test; rc=$?
    if [ $rc -eq 0 ]; then record "frontend: vitest run" PASS "$(grep -E 'Tests +[0-9]+' "$RESULTS/vitest.log" | tail -1 | sed 's/^ *//')"; else record "frontend: vitest run" "$([ $rc -eq 124 ] && echo TIMEOUT || echo FAIL)" "exit $rc; see vitest.log"; fi
    runc "$RESULTS/vite-build.log" "$T_NPM" "$FE" npm run build; rc=$?
    if [ $rc -eq 0 ]; then record "frontend: vite build" PASS "exit 0"; else record "frontend: vite build" "$([ $rc -eq 124 ] && echo TIMEOUT || echo FAIL)" "exit $rc; see vite-build.log"; fi
  fi
fi

# ---- the run must not have changed the tree it validated -----------------------------------------------------------------------------------------
if [ -z "$HALT" ]; then
  T1="$(tree_hash)"
  if [ "$T1" = "$T0" ]; then record "tree: unchanged by the run" PASS "$T1"; else record "tree: unchanged by the run" FAIL "the tree hash changed during the run ($T0 -> $T1)"; fi
fi

finish
