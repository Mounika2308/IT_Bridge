#!/usr/bin/env python3
"""Attack battery for itb_db_gate.py. Stdlib only. It touches ONLY the clusters you start for it; it never reads DATABASE_URL, .env or a PG* file.

    itb_db_gate_selftest.py offline
        needs no PostgreSQL server: URL grammar attacks, environment attacks, fake psql/pg_dump programs (silent, failing, hanging, empty-output).
        A listening decoy socket proves that no refused case ever opened a connection.
    itb_db_gate_selftest.py live TARGET_PORT DECOY_PORT [LOG_TARGET LOG_DECOY]
        needs TWO throwaway PostgreSQL 16 clusters on 127.0.0.1 (trust auth, user postgres) that YOU created for this test:
          TARGET  holds one database itbridge_test carrying the comment ITB_PHASE13_DISPOSABLE
          DECOY   holds databases WITHOUT the comment, with data (the stand-in for a dev/prod server): itbridge_test (50 rows) and devdata (20 rows)
        The decoy's databases are fingerprinted before and after every attack and must never change.
Exit 0 only if every case behaved as expected.
"""
import hashlib
import os
import socket
import subprocess
import sys
import tempfile
import threading
import time

HERE = os.path.dirname(os.path.abspath(__file__))
GATE = os.path.join(HERE, "itb_db_gate.py")
CLEAN = {"PATH": os.environ.get("PATH", "/usr/bin:/bin")}
RESULTS: list[tuple[bool, str]] = []


def gate(*args, env=None, path=None, timeout=60):
    e = dict(CLEAN if env is None else env)
    if path is not None:
        e["PATH"] = path
    r = subprocess.run([sys.executable, "-B", GATE, *args], env=e, capture_output=True, text=True, timeout=timeout)
    return r.returncode, (r.stdout + r.stderr).strip()


def expect(label, got, want, detail=""):
    ok = got == want
    RESULTS.append((ok, f"{label}: exit {got} (wanted {want}){'' if ok else '  ' + detail[:300]}"))
    return ok


class Decoy:
    """A listening socket that records connection attempts and never answers."""
    def __init__(self):
        self.s = socket.socket()
        self.s.bind(("127.0.0.1", 0))
        self.s.listen(50)
        self.port = self.s.getsockname()[1]
        self.n = 0
        threading.Thread(target=self._loop, daemon=True).start()

    def _loop(self):
        while True:
            try:
                c, _ = self.s.accept()
                self.n += 1
                c.close()
            except OSError:
                return


GOOD = "postgresql://postgres@127.0.0.1:{p}/itbridge_test"

GRAMMAR_ATTACKS = {
    # query-string redirects: SQLAlchemy/psycopg2 would honour them, a naive host/port parse would not see them
    "query host=": "postgresql://postgres@127.0.0.1:{p}/itbridge_test?host=10.9.9.9",
    "query port=": "postgresql://postgres@127.0.0.1:{p}/itbridge_test?port=5432",
    "query dbname=": "postgresql://postgres@127.0.0.1:{p}/itbridge_test?dbname=itbridge",
    "query hostaddr=": "postgresql://postgres@127.0.0.1:{p}/itbridge_test?hostaddr=10.9.9.9",
    "query service=": "postgresql://postgres@127.0.0.1:{p}/itbridge_test?service=prod",
    "query options=": "postgresql://postgres@127.0.0.1:{p}/itbridge_test?options=-csearch_path%3Dprod",
    "query sslmode (any query)": "postgresql://postgres@127.0.0.1:{p}/itbridge_test?sslmode=disable",
    "bare ?": "postgresql://postgres@127.0.0.1:{p}/itbridge_test?",
    "fragment": "postgresql://postgres@127.0.0.1:{p}/itbridge_test#x",
    "fragment host": "postgresql://postgres@127.0.0.1:{p}/itbridge_test#@10.9.9.9",
    "path parameter ;": "postgresql://postgres@127.0.0.1:{p}/itbridge_test;x=1",
    # hosts, aliases, IPv4/IPv6 forms
    "localhost": "postgresql://postgres@localhost:{p}/itbridge_test",
    "LOCALHOST": "postgresql://postgres@LOCALHOST:{p}/itbridge_test",
    "127.0.0.2": "postgresql://postgres@127.0.0.2:{p}/itbridge_test",
    "127.1": "postgresql://postgres@127.1:{p}/itbridge_test",
    "octal/hex 0x7f.0.0.1": "postgresql://postgres@0x7f.0.0.1:{p}/itbridge_test",
    "decimal 2130706433": "postgresql://postgres@2130706433:{p}/itbridge_test",
    "0.0.0.0": "postgresql://postgres@0.0.0.0:{p}/itbridge_test",
    "ipv4-mapped ipv6": "postgresql://postgres@[::ffff:127.0.0.1]:{p}/itbridge_test",
    "long ipv6 loopback": "postgresql://postgres@[0:0:0:0:0:0:0:1]:{p}/itbridge_test",
    "ipv6 without brackets": "postgresql://postgres@::1:{p}/itbridge_test",
    "ipv6 zone": "postgresql://postgres@[::1%25lo]:{p}/itbridge_test",
    "trailing dot host": "postgresql://postgres@127.0.0.1.:{p}/itbridge_test",
    "host suffix": "postgresql://postgres@127.0.0.1.evil.example:{p}/itbridge_test",
    "remote host": "postgresql://postgres@db.internal.example:{p}/itbridge_test",
    "private address": "postgresql://postgres@10.0.0.5:{p}/itbridge_test",
    "no host": "postgresql://postgres@:{p}/itbridge_test",
    "no host no user": "postgresql:///itbridge_test",
    "unix socket dir": "postgresql://postgres@%2Fvar%2Frun%2Fpostgresql:{p}/itbridge_test",
    "two hosts": "postgresql://postgres@127.0.0.1:{p},10.9.9.9:5432/itbridge_test",
    # userinfo tricks
    "userinfo @ hides real host": "postgresql://postgres:x@10.9.9.9:{p}@127.0.0.1:{p}/itbridge_test",
    "userinfo looks like host": "postgresql://127.0.0.1:{p}@10.9.9.9:{p}/itbridge_test",
    "password with @": "postgresql://postgres:p@ss@127.0.0.1:{p}/itbridge_test",
    "password with /": "postgresql://postgres:p/ss@10.9.9.9:{p}/itbridge_test",
    "encoded @ in user": "postgresql://postgres%40x@127.0.0.1:{p}/itbridge_test",
    "encoded host dot": "postgresql://postgres@127.0.0.1%2e:{p}/itbridge_test",
    "encoded user": "postgresql://post%67res@127.0.0.1:{p}/itbridge_test",
    "no user": "postgresql://127.0.0.1:{p}/itbridge_test",
    "empty password allowed? colon only + @@": "postgresql://postgres:@@127.0.0.1:{p}/itbridge_test",
    # ports
    "missing port": "postgresql://postgres@127.0.0.1/itbridge_test",
    "default port 5432": "postgresql://postgres@127.0.0.1:5432/itbridge_test",
    "port 0": "postgresql://postgres@127.0.0.1:0/itbridge_test",
    "port 1023": "postgresql://postgres@127.0.0.1:1023/itbridge_test",
    "port 65536": "postgresql://postgres@127.0.0.1:65536/itbridge_test",
    "port 99999": "postgresql://postgres@127.0.0.1:99999/itbridge_test",
    "leading zero port": "postgresql://postgres@127.0.0.1:0{p}/itbridge_test",
    "port with sign": "postgresql://postgres@127.0.0.1:+{p}/itbridge_test",
    "port decimal": "postgresql://postgres@127.0.0.1:{p}.0/itbridge_test",
    "fullwidth digits port": "postgresql://postgres@127.0.0.1:５５４３２/itbridge_test",
    "empty port": "postgresql://postgres@127.0.0.1:/itbridge_test",
    "two ports": "postgresql://postgres@127.0.0.1:{p}:5432/itbridge_test",
    # database names
    "no database": "postgresql://postgres@127.0.0.1:{p}",
    "empty database": "postgresql://postgres@127.0.0.1:{p}/",
    "dev name itbridge (no 'test')": "postgresql://postgres@127.0.0.1:{p}/itbridge",
    "postgres database": "postgresql://postgres@127.0.0.1:{p}/postgres",
    "uppercase TEST": "postgresql://postgres@127.0.0.1:{p}/ITBRIDGE_TEST",
    "encoded name": "postgresql://postgres@127.0.0.1:{p}/itbridge%5ftest",
    "encoded NUL": "postgresql://postgres@127.0.0.1:{p}/itbridge_test%00",
    "extra path": "postgresql://postgres@127.0.0.1:{p}/itbridge_test/extra",
    "double slash": "postgresql://postgres@127.0.0.1:{p}//itbridge_test",
    "quoted": 'postgresql://postgres@127.0.0.1:{p}/"itbridge_test"',
    "sql in name": "postgresql://postgres@127.0.0.1:{p}/itbridge_test;DROP",
    "space in name": "postgresql://postgres@127.0.0.1:{p}/itbridge_test x",
    "test only in user": "postgresql://test@127.0.0.1:{p}/itbridge",
    "test only in host": "postgresql://postgres@test.example:{p}/itbridge",
    "test only in query": "postgresql://postgres@127.0.0.1:{p}/itbridge?application_name=test",
    "test only in password": "postgresql://postgres:test@127.0.0.1:{p}/itbridge",
    # schemes and whitespace
    "postgres://": "postgres://postgres@127.0.0.1:{p}/itbridge_test",
    "asyncpg": "postgresql+asyncpg://postgres@127.0.0.1:{p}/itbridge_test",
    "uppercase scheme": "POSTGRESQL://postgres@127.0.0.1:{p}/itbridge_test",
    "sqlite": "sqlite:///itbridge_test.db",
    "file": "file:///var/lib/postgresql/itbridge_test",
    "leading space": " postgresql://postgres@127.0.0.1:{p}/itbridge_test",
    "trailing space": "postgresql://postgres@127.0.0.1:{p}/itbridge_test ",
    "trailing newline": "postgresql://postgres@127.0.0.1:{p}/itbridge_test\n",
    "embedded newline": "postgresql://postgres@127.0.0.1:{p}/itbridge_test\nhost=10.9.9.9",
    "tab": "postgresql://postgres@127.0.0.1:{p}/itbridge_\ttest",
    "empty string": "",
    "libpq keyword string": "host=10.9.9.9 port=5432 dbname=itbridge_test",
    "very long": "postgresql://postgres@127.0.0.1:{p}/" + "a" * 100000 + "test",
}

ENV_ATTACKS = {   # every one of these must be refused BEFORE any connection, with an otherwise perfect URL
    "PGHOST": {"PGHOST": "10.9.9.9"}, "PGHOSTADDR": {"PGHOSTADDR": "10.9.9.9"}, "PGPORT": {"PGPORT": "5432"}, "PGDATABASE": {"PGDATABASE": "itbridge"},
    "PGUSER": {"PGUSER": "prod"}, "PGSERVICE": {"PGSERVICE": "prod"}, "PGSERVICEFILE": {"PGSERVICEFILE": "/etc/pg_service.conf"},
    "PGSYSCONFDIR": {"PGSYSCONFDIR": "/etc/postgresql-common"}, "PGOPTIONS": {"PGOPTIONS": "-c search_path=prod"}, "PGPASSFILE": {"PGPASSFILE": "/root/.pgpass"},
    "PGSSLMODE": {"PGSSLMODE": "disable"}, "PGCONNECT_TIMEOUT": {"PGCONNECT_TIMEOUT": "1"}, "PGTARGETSESSIONATTRS": {"PGTARGETSESSIONATTRS": "any"},
    "PG (bare)": {"PG": "1"}, "DATABASE_URL differs": {"DATABASE_URL": "postgresql+psycopg2://itbridge:change_me@localhost:5432/itbridge"},
    "ITB_TEST_DATABASE_URL differs": {"ITB_TEST_DATABASE_URL": "postgresql://postgres@127.0.0.1:55439/itbridge_test"},
    "DATABASE_URL differs only by port": {"DATABASE_URL": "postgresql://postgres@127.0.0.1:{q}/itbridge_test"},
}


def offline() -> None:
    d = Decoy()
    p = d.port
    for label, tmpl in GRAMMAR_ATTACKS.items():
        url = tmpl.replace("{p}", str(p))
        before = d.n
        rc, out = gate("check", url)
        expect(f"grammar [{label}] check", rc, 3, out)
        rc, out = gate("url", url)
        expect(f"grammar [{label}] url", rc, 3, out)
        for sub in (("reset", url), ("sql", url, "SELECT 1"), ("snapshot", url, os.devnull), ("pgenv", url)):
            rc, out = gate(*sub)
            expect(f"grammar [{label}] {sub[0]}", rc, 3, out)
        time.sleep(0.02)
        RESULTS.append((d.n == before, f"grammar [{label}]: connections opened to the listener: {d.n - before} (wanted 0)"))
    # positive controls for the grammar itself: the accepted forms are accepted (so the refusals above are not an artefact of a broken parser)
    for label, url in {"plain": f"postgresql://postgres@127.0.0.1:{p}/itbridge_test", "psycopg2 + password": f"postgresql+psycopg2://itb_user:pw-1.x~_@127.0.0.1:{p}/itbridge_test",
                       "ipv6": f"postgresql://postgres@[::1]:{p}/itbridge_test", "name contains test": f"postgresql://postgres@127.0.0.1:{p}/contest"}.items():
        rc, out = gate("url", url)
        expect(f"grammar accepts [{label}]", rc, 0, out)
    for label, extra in ENV_ATTACKS.items():
        url = GOOD.format(p=p)
        env = dict(CLEAN)
        env.update({k: v.replace("{q}", str(p + 1)) for k, v in extra.items()})
        before = d.n
        for sub in (("check", url), ("reset", url), ("sql", url, "SELECT 1"), ("snapshot", url, os.devnull), ("pgenv", url)):
            rc, out = gate(*sub, env=env)
            expect(f"env [{label}] {sub[0]}", rc, 3, out)
        time.sleep(0.02)
        RESULTS.append((d.n == before, f"env [{label}]: connections opened to the listener: {d.n - before} (wanted 0)"))
    # a variable that must NOT trigger a refusal: PGPASSWORD (the only PG* variable the gate accepts) and an equal DATABASE_URL
    url = GOOD.format(p=p)
    rc, out = gate("check", url, env={**CLEAN, "PGPASSWORD": "x", "DATABASE_URL": url, "ITB_TEST_DATABASE_URL": url})
    expect("env [PGPASSWORD / equal DATABASE_URL] passes the environment rule (then BLOCKED: the listener is not PostgreSQL)", rc, 4, out)

    # second line of defence, tested directly: even if a caller's PG* variable reached the child-process builder it would be removed
    import importlib.util
    spec = importlib.util.spec_from_file_location("itb_db_gate_under_test", GATE)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    saved = dict(os.environ)
    try:
        os.environ.update({"PGHOSTADDR": "10.9.9.9", "PGSERVICE": "prod", "PGDATABASE": "itbridge", "PGSYSCONFDIR": "/etc", "PGSSLROOTCERT": "x"})
        child = mod._env(mod.parse(GOOD.format(p=p)))
    finally:
        os.environ.clear()
        os.environ.update(saved)
    RESULTS.append((all(k not in child for k in ("PGHOSTADDR", "PGSERVICE", "PGSYSCONFDIR", "PGSSLROOTCERT")) and child["PGHOST"] == "127.0.0.1" and child["PGDATABASE"] == "itbridge_test"
                    and child["PGPORT"] == str(p), "child environment: caller PG* variables are removed, the URL's own values are set"))
    # fake client programs: the gate must fail closed whatever the client does
    with tempfile.TemporaryDirectory() as td:
        def fake(name, body):
            f = os.path.join(td, name)
            with open(f, "w") as fh:
                fh.write("#!/bin/sh\n" + body + "\n")
            os.chmod(f, 0o755)
        base = os.path.dirname(sys.executable)
        for label, body, want, env_extra in [
            ("psql exits 0 and prints nothing", "exit 0", 4, {}),
            ("psql exits 0 and prints a token without the nonce", "echo 'ITB_GATE_OK|itbridge_test|160015|0000'", 4, {}),
            ("psql exits 0 and echoes its arguments (no server ran)", 'echo "$@"', 4, {}),
            ("psql fails (exit 2)", "echo 'could not connect' >&2; exit 2", 4, {}),
            ("psql hangs (ITB_GATE_TIMEOUT=2)", "sleep 30", 4, {"ITB_GATE_TIMEOUT": "2"}),
            ("psql killed by a signal", "kill -9 $$", 4, {}),
            ("psql claims the guard fired", "echo 'ERROR:  itb gate: forced' >&2; exit 3", 3, {}),
        ]:
            fake("psql", body)
            t0 = time.time()
            rc, out = gate("check", url, path=td + ":" + base, env={**CLEAN, **env_extra})
            expect(f"fake psql [{label}] check", rc, want, out)
            rc, out = gate("reset", url, path=td + ":" + base, env={**CLEAN, **env_extra})
            expect(f"fake psql [{label}] reset", rc, want, out)
            if "hangs" in label:
                RESULTS.append((time.time() - t0 < 20, f"fake psql [{label}]: returned in {time.time() - t0:.1f}s (timeout honoured)"))
        os.remove(os.path.join(td, "psql"))
        rc, out = gate("check", url, path=td)             # PATH without psql (and without python's own directory resolved by absolute sys.executable)
        expect("psql not installed: check", rc, 4, out)
        rc, out = gate("reset", url, path=td)
        expect("psql not installed: reset", rc, 4, out)
        rc, out = gate("snapshot", url, os.devnull, path=td)
        expect("psql/pg_dump not installed: snapshot", rc, 4, out)
    rc, out = gate("check")
    expect("usage: no arguments", rc, 2)
    rc, out = gate("check", url, "--bogus")
    expect("usage: unknown option", rc, 2)
    rc, out = gate("sql", url)
    expect("usage: sql without statement", rc, 2)
    RESULTS.append((d.n == 0 or True, f"listener saw {d.n} connection(s) in total (only the BLOCKED positive-control case may have connected)"))


# ------------------------------------------------------------------------------------------------------------------ live part
def psql_admin(port, db, sql):
    e = dict(CLEAN, PGHOST="127.0.0.1", PGPORT=str(port), PGUSER="postgres", PGCONNECT_TIMEOUT="5")
    r = subprocess.run(["psql", "-X", "-q", "-At", "-v", "ON_ERROR_STOP=1", "-d", db, "-c", sql], env=e, capture_output=True, text=True, timeout=60)
    if r.returncode != 0:
        raise RuntimeError(f"admin psql failed on {port}/{db}: {r.stderr}")
    return r.stdout.strip()


def fingerprint(port):
    """Everything an attack could change on a cluster: its databases + comments, and every row of every table of every database (read directly, not via the gate)."""
    dbs = psql_admin(port, "postgres", "SELECT datname || ':' || coalesce(shobj_description(oid, 'pg_database'), '-') FROM pg_database ORDER BY 1").split("\n")
    parts = list(dbs)
    for name in [x.split(":")[0] for x in dbs if x.split(":")[0] not in ("template0", "template1")]:
        tables = psql_admin(port, name, "SELECT schemaname || '.' || tablename FROM pg_tables WHERE schemaname NOT IN ('pg_catalog','information_schema') ORDER BY 1").split()
        parts.append(f"{name} tables {tables}")
        for t in tables:
            parts.append(f"{name} {t} " + psql_admin(port, name, f"SELECT count(*) || '|' || coalesce(md5(string_agg(x::text, '~' ORDER BY x::text)), '-') FROM {t} x"))
    return hashlib.sha256("\n".join(parts).encode()).hexdigest()[:16]


def log_connections(path):
    try:
        return sum(1 for line in open(path, errors="replace") if "connection received" in line)
    except OSError:
        return -1


class Forwarder:
    """TCP forwarder 127.0.0.1:listen -> a target chosen per connection (target_for(n) with n counting from 1)."""
    def __init__(self, target_for):
        self.target_for, self.n = target_for, 0
        self.s = socket.socket()
        self.s.bind(("127.0.0.1", 0))                       # a free port chosen by the OS: no clash with ephemeral client ports
        self.port = self.s.getsockname()[1]
        self.s.listen(20)
        threading.Thread(target=self._loop, daemon=True).start()

    def _pipe(self, a, b):
        try:
            while (data := a.recv(65536)):
                b.sendall(data)
        except OSError:
            pass
        finally:
            for x in (a, b):
                try:
                    x.shutdown(socket.SHUT_RDWR)
                except OSError:
                    pass

    def _loop(self):
        while True:
            try:
                c, _ = self.s.accept()
            except OSError:
                return
            self.n += 1
            try:
                u = socket.create_connection(("127.0.0.1", self.target_for(self.n)), timeout=5)
            except OSError:
                c.close()
                continue
            threading.Thread(target=self._pipe, args=(c, u), daemon=True).start()
            threading.Thread(target=self._pipe, args=(u, c), daemon=True).start()

    def close(self):
        try:
            self.s.shutdown(socket.SHUT_RDWR)
        except OSError:
            pass
        self.s.close()


def live(tp: int, dp: int, log_t: str | None, log_d: str | None) -> None:
    T, D = GOOD.format(p=tp), GOOD.format(p=dp)
    ok_start = {"target": psql_admin(tp, "postgres", "SELECT coalesce(shobj_description(oid,'pg_database'),'-') FROM pg_database WHERE datname='itbridge_test'"),
                "decoy": psql_admin(dp, "postgres", "SELECT coalesce(shobj_description(oid,'pg_database'),'-') FROM pg_database WHERE datname='itbridge_test'")}
    assert ok_start["target"] == "ITB_PHASE13_DISPOSABLE" and ok_start["decoy"] == "-", f"fixture wrong: {ok_start}"
    assert psql_admin(dp, "devdata", "SELECT count(*) FROM precious") == "20" and psql_admin(dp, "itbridge_test", "SELECT count(*) FROM precious") == "50", "decoy fixture wrong"
    fp0 = fingerprint(dp)

    def decoy_untouched(label):
        RESULTS.append((fingerprint(dp) == fp0, f"decoy cluster fingerprint unchanged after [{label}]"))

    # A. the decoy: right name ("itbridge_test"), right host, no marker -> every command refused, data intact
    for sub in (("check", D), ("check", D, "--expect-empty"), ("reset", D), ("sql", D, "DELETE FROM precious"), ("sql", D, "DROP TABLE precious"),
                ("sql", D, "SELECT 1"), ("snapshot", D, os.devnull), ("pgenv", D)):
        rc, out = gate(*sub)
        expect(f"decoy itbridge_test (name has 'test', no marker) {sub[0]} {' '.join(sub[2:])[:30]}", rc, 3, out)
    decoy_untouched("unmarked decoy database called itbridge_test")
    # A2. the case that defeated the first gate: the dev database is called itbridge_test and is the ONLY database next to `postgres`
    psql_admin(dp, "postgres", "DROP DATABASE devdata")
    fp_sole = fingerprint(dp)
    for sub in (("check", D), ("reset", D), ("sql", D, "DELETE FROM precious"), ("sql", D, "DROP TABLE precious"), ("snapshot", D, os.devnull)):
        rc, out = gate(*sub)
        expect(f"decoy: itbridge_test is the only database, no marker: {sub[0]}", rc, 3, out)
    RESULTS.append((fingerprint(dp) == fp_sole, "decoy cluster fingerprint unchanged after [sole unmarked database called itbridge_test]"))
    psql_admin(dp, "postgres", "CREATE DATABASE devdata")
    psql_admin(dp, "devdata", "CREATE TABLE precious(id int, v text); INSERT INTO precious SELECT g, 'keep'||g FROM generate_series(1,20) g")
    # B. a database whose name contains 'test' but is neither marked nor the cluster's only database
    rc, out = gate("check", f"postgresql://postgres@127.0.0.1:{dp}/devdata")
    expect("decoy devdata (no 'test' in name)", rc, 3, out)
    # C. a marked target on a cluster that also holds an UNMARKED database -> cluster rule
    psql_admin(dp, "postgres", "COMMENT ON DATABASE itbridge_test IS 'ITB_PHASE13_DISPOSABLE'")
    fp_marked = fingerprint(dp)
    for sub in (("check", D), ("reset", D), ("sql", D, "DELETE FROM precious")):
        rc, out = gate(*sub)
        expect(f"decoy: itbridge_test marked, but devdata is not: {sub[0]}", rc, 3, out)
    RESULTS.append((fingerprint(dp) == fp_marked, "decoy cluster fingerprint unchanged after [marked target in a cluster with an unmarked database]"))
    # D. near-miss markers
    for bad in ("itb_phase13_disposable", "ITB_PHASE13_DISPOSABLE ", " ITB_PHASE13_DISPOSABLE", "ITB_PHASE13_DISPOSABLE_2", "ITB_PHASE13", "disposable", "yes"):
        psql_admin(dp, "postgres", f"COMMENT ON DATABASE itbridge_test IS '{bad}'")
        psql_admin(dp, "postgres", f"COMMENT ON DATABASE devdata IS '{bad}'")
        rc, out = gate("check", D)
        expect(f"near-miss marker {bad!r}", rc, 3, out)
        rc, out = gate("reset", D)
        expect(f"near-miss marker {bad!r}: reset", rc, 3, out)
    psql_admin(dp, "postgres", "COMMENT ON DATABASE itbridge_test IS NULL")
    psql_admin(dp, "postgres", "COMMENT ON DATABASE devdata IS NULL")
    decoy_untouched("near-miss markers")
    # E. wrong port, wrong user, nothing listening, wrong database
    rc, out = gate("check", GOOD.format(p=tp + 7))
    expect("nothing listens on the port", rc, 4, out)
    rc, out = gate("check", f"postgresql://nobody_here@127.0.0.1:{tp}/itbridge_test")
    expect("target: role does not exist", rc, 4, out)
    rc, out = gate("check", f"postgresql://postgres@127.0.0.1:{tp}/other_test")
    expect("target cluster, database that does not exist", rc, 4, out)
    # F. connection-target mismatch: the URL says one thing, the TCP path leads elsewhere
    fwd = Forwarder(lambda n: dp)
    rc, out = gate("check", GOOD.format(p=fwd.port))
    expect("forwarder: URL port leads to the decoy (name itbridge_test, no marker)", rc, 3, out)
    rc, out = gate("reset", GOOD.format(p=fwd.port))
    expect("forwarder: reset through a path that leads to the decoy", rc, 3, out)
    fwd.close()
    decoy_untouched("forwarder to the decoy")
    # G. time-of-check/time-of-use: the first connection (check) reaches the real target, every later one (the guarded statement) the decoy
    for sub in (("reset",), ("sql", "DELETE FROM precious")):
        fwd = Forwarder(lambda n: tp if n == 1 else dp)
        rc, out = gate(sub[0], GOOD.format(p=fwd.port), *sub[1:])
        expect(f"TOCTOU: check reaches the target, {sub[0]} reaches the decoy", rc, 3, out)
        fwd.close()
    decoy_untouched("check/use redirect")
    # H. the legitimate target works, and the gate's own destructive commands act on it only
    rc, out = gate("check", T, "--expect-empty")
    expect("target: check --expect-empty", rc, 0, out)
    rc, out = gate("sql", T, "CREATE TABLE t(id int); INSERT INTO t SELECT generate_series(1,5); SELECT count(*) FROM t")
    expect("target: sql creates a table", rc, 0, out)
    RESULTS.append((out.splitlines()[-1] == "5" if out else False, f"target: sql returned the count: {out!r}"))
    rc, out = gate("check", T, "--expect-empty")
    expect("target: check --expect-empty on a non-empty target", rc, 3, out)
    rc, out = gate("sql", T, "SELECT 1; \\c postgres")
    expect("sql with a backslash meta-command", rc, 3, out)
    rc, out = gate("sql", T, "DROP DATABASE itbridge_test")
    expect("sql DROP DATABASE (cannot run inside the guarded transaction)", rc, 4, out)
    a, b = os.path.join(tempfile.gettempdir(), "itb_snap_a.txt"), os.path.join(tempfile.gettempdir(), "itb_snap_b.txt")
    rc, out = gate("snapshot", T, a)
    expect("target: snapshot", rc, 0, out)
    rc, out = gate("snapshot", T, b)
    expect("target: second snapshot", rc, 0, out)
    RESULTS.append((open(a).read() == open(b).read(), "snapshot is deterministic for an unchanged database"))
    gate("sql", T, "UPDATE t SET id = id + 100 WHERE id = 1")
    rc, out = gate("snapshot", T, b)
    RESULTS.append((open(a).read() != open(b).read(), "snapshot detects a changed row"))
    gate("sql", T, "UPDATE t SET id = id - 100 WHERE id = 101")
    gate("sql", T, "ALTER TABLE t ADD COLUMN x int")
    rc, out = gate("snapshot", T, b)
    RESULTS.append((open(a).read() != open(b).read(), "snapshot detects a changed schema"))
    rc, out = gate("reset", T)
    expect("target: reset", rc, 0, out)
    rc, out = gate("check", T, "--expect-empty")
    expect("target: empty again after reset", rc, 0, out)
    RESULTS.append((psql_admin(tp, "postgres", "SELECT coalesce(shobj_description(oid,'pg_database'),'-') FROM pg_database WHERE datname='itbridge_test'") == "ITB_PHASE13_DISPOSABLE",
                    "target: marker survives reset"))
    rc, out = gate("pgenv", T)
    RESULTS.append((rc == 0 and "export PGHOST=127.0.0.1" in out and f"export PGPORT={tp}" in out, f"target: pgenv prints the target only ({out!r})"))
    # I. the cluster rule from the other side: an unmarked database appears on the target cluster
    psql_admin(tp, "postgres", "CREATE DATABASE intruder_db")
    rc, out = gate("check", T)
    expect("target cluster gains an unmarked database", rc, 3, out)
    rc, out = gate("reset", T)
    expect("target cluster gains an unmarked database: reset", rc, 3, out)
    psql_admin(tp, "postgres", "DROP DATABASE intruder_db")
    rc, out = gate("check", T)
    expect("intruder removed: target passes again", rc, 0, out)
    # J. the decoy once it is genuinely disposable (marker on everything, as an operator would do on purpose) passes: the refusals above were the marker, not a fluke
    psql_admin(dp, "postgres", "DROP DATABASE devdata")
    psql_admin(dp, "postgres", "COMMENT ON DATABASE itbridge_test IS 'ITB_PHASE13_DISPOSABLE'")
    rc, out = gate("check", D)
    expect("control: a cluster that carries the marker everywhere passes", rc, 0, out)
    psql_admin(dp, "postgres", "COMMENT ON DATABASE itbridge_test IS NULL")
    psql_admin(dp, "postgres", "CREATE DATABASE devdata")
    psql_admin(dp, "devdata", "CREATE TABLE precious(id int, v text); INSERT INTO precious SELECT g, 'keep'||g FROM generate_series(1,20) g")
    if log_t and log_d:
        RESULTS.append((True, f"server logs: connections received target={log_connections(log_t)}, decoy={log_connections(log_d)} (informational)"))


def main() -> int:
    if len(sys.argv) >= 2 and sys.argv[1] == "offline":
        offline()
    elif len(sys.argv) >= 4 and sys.argv[1] == "live":
        live(int(sys.argv[2]), int(sys.argv[3]), *(sys.argv[4:6] if len(sys.argv) >= 6 else (None, None)))
    else:
        print(__doc__)
        return 2
    bad = [m for ok, m in RESULTS if not ok]
    for ok, m in RESULTS:
        if not ok or "-v" in sys.argv:
            print(("PASS  " if ok else "FAIL  ") + m)
    print(f"\n{len(RESULTS) - len(bad)} passed, {len(bad)} failed ({sys.argv[1]} part)")
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
