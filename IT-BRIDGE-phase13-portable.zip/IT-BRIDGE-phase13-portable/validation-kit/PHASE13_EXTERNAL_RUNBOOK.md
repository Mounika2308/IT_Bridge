# IT BRIDGE Phase 13: external runtime validation runbook

**Status: Phase 13 is UNAPPROVED. No application-level PASS evidence exists.** The only driver run on the real environment (sandbox, no registry access) ended `VERDICT: INCOMPLETE`, exit 3, halted at `versions: alembic` (MISSING_DEPENDENCY); 30 of 34 checks NOT_RUN. Everything else done so far is static analysis or tests run on stand-ins, and **none of it counts toward approval**.

This runbook is the short path. The full reasoning, the Alembic guard analysis and the 34-check list are in `PHASE13_RUNTIME_VALIDATION_HANDOFF.md` (the "handoff"); this file does not replace it. Do not edit the kit, the tree or the pins to get a pass.

## 1. Files and identity (verify before anything else)

`PHASE13_KIT.SHA256SUMS` lists these; run `sha256sum -c PHASE13_KIT.SHA256SUMS` in the folder that holds them. Every line must say `OK`.

| File | SHA-256 |
|---|---|
| `PHASE13_RUNTIME_VALIDATION_HANDOFF.md` | `504fab9505a60ecde7efe2826e2529450bb7fb006851571132ee0043c2121db0` |
| `run_phase13_validation.sh` (the driver; the tree hash below is baked in) | `137bb3c0e79ddbf41e5839e084ccbfffcec12708f2d35ae209e74282e1df1649` |
| `itb_db_gate.py` | `71eaf59eb01ffe32085ae308e3ac6dbd8d19f13a061deea88802594096ecae67` |
| `itb_db_gate_selftest.py` | `96aaf706d1d96fcf3ff6aebd23f830542899c9ce887e4a366b2ee4b723073778` |
| `PHASE13_ENGINEERING_FIXES.diff` (26 files) | `d1aa8c19880e786f1aab0f316e73954a36c912abe0b4dd3af1fa3e957289853b` |
| `IT-BRIDGE-phase13b4-stabilized.zip` (baseline, must stay untouched) | `e12dd391564a3e9cc540546ae95bfcaf3812c193aca4f3fde8dfd9c86de59710` |
| `IT-BRIDGE-phase12-stabilized.zip` (older baseline, must stay untouched) | `f60c33babb4009ce433fc2dd28b3297604055858b558058fbfa70757ff4aad0c` |

**Tree under test:** `TREE_SHA256 = 9d2280022999b74b40af3015743c5c93eebaabed3704d2d35a1bef32fe1d33ca`.

```bash
mkdir -p ~/itb-p13 && cd ~/itb-p13 && unzip -q <DIR>/IT-BRIDGE-phase13b4-stabilized.zip && cd IT-BRIDGE
patch -p1 --dry-run < <DIR>/PHASE13_ENGINEERING_FIXES.diff && patch -p1 < <DIR>/PHASE13_ENGINEERING_FIXES.diff
find . -type f ! -path './frontend/node_modules/*' ! -path './frontend/dist/*' ! -path '*/__pycache__/*' ! -path './.git/*' ! -path '*/.venv/*' \
  ! -path '*/.pytest_cache/*' ! -path '*/.ruff_cache/*' ! -name '*.pyc' ! -path './backend/.env' ! -path './.env' \
  | LC_ALL=C sort | xargs -d '\n' sha256sum | sha256sum | cut -d' ' -f1        # must print the TREE_SHA256 above
```
A different hash means stop: this is not the tree the kit was built for. (The driver checks it again as its own fatal check.)

## 2. Machine

Linux, a normal non-root user, working access to PyPI and the npm registry (mirror or allowed egress; nothing here bypasses a network policy). Versions, taken from the project files and enforced by the driver (`INCOMPLETE` on a mismatch):

| Tool | Required | Source in the project |
|---|---|---|
| Python | 3.12.x | `backend/Dockerfile`: `python:3.12-slim` |
| Node / npm | Node 20.x; npm: any (the driver records it) | `frontend/Dockerfile`: `node:20-alpine` |
| PostgreSQL server, `psql`, `pg_dump` | 16.x | `docker-compose.yml`: `postgres:16` |
| Others | GNU `find`, `xargs`, `sha256sum`, `timeout`, `tar`, `cmp`, `patch`, `unzip` | driver |

Redis is **not** needed (compose provisions it; nothing imports it). A different toolchain (`EXPECT_PY`, `EXPECT_NODE`, `EXPECT_PG`) is allowed only as a deliberate, recorded deviation, and the report must say so.

## 3. Dependencies: what the project files actually say

**Nothing is pinned.** The earlier wording "pinned dependencies" was wrong: there is no constraints file, no lockfile and no version in the Python requirements.

`backend/requirements.txt` in full (13 lines, no versions): `fastapi`, `uvicorn[standard]`, `pydantic-settings`, `email-validator`, `sqlalchemy`, `alembic`, `psycopg2-binary`, `python-jose[cryptography]`, `bcrypt`, `redis`, `celery`, `pytest`, `httpx`.

`frontend/package.json` (ranges only): dependencies `@hookform/resolvers ^3.9.0`, `@tanstack/react-query ^5.0.0`, `axios ^1.7.0`, `lucide-react ^0.400.0`, `react ^18.3.0`, `react-dom ^18.3.0`, `react-hook-form ^7.52.0`, `react-router-dom ^6.24.0`, `zod ^3.23.0`; devDependencies `@vitejs/plugin-react ^4.3.0`, `autoprefixer ^10.4.0`, `postcss ^8.4.0`, `tailwindcss ^3.4.0`, `vite ^5.3.0`, `vitest ^2.0.0`, `@testing-library/react ^16.0.0`. Scripts: `test` = `vitest run`, `build` = `vite build`. There is **no `package-lock.json`, `pnpm-lock.yaml` or `yarn.lock`** and none may be invented: `npm install` resolves the ranges (the driver does it in a copy of `frontend/`, so the tree is not modified).

**Cannot be established from the available files** (record the real value, do not guess):
1. Every resolved version (Python and npm). Only `pip freeze` / `npm ls` on the validating machine can say.
2. Whether Alembic 1.13.3 (the candidate, §5) resolves and imports with the newest SQLAlchemy that pip picks. This is the central open question; there is no evidence either way.
3. Whether the newest `pytest`, `httpx`, `fastapi`, `starlette`, `pydantic` work with the tests (nothing was ever run with real ones).
4. `tzdata`: not declared. `app/core/clock.py` calls `ZoneInfo("Asia/Kolkata")` on every `now()`. A host with `/usr/share/zoneinfo` is fine. Check with the command in §5. If it fails, installing `tzdata` into the venv is a deliberate change that must be written down; it is not a pin change.
5. Vitest's environment: `vite.config.js` has no `test` block, so Vitest runs in its default (node) environment, and `jsdom` is not declared. No test file mentions `document`, `window`, `jsdom` or `@testing-library`; they render with `react-dom/server`. Whether all ten test files pass in that environment is unknown until Vitest runs. `@testing-library/react` is declared but unused. `src/services/notificationService.test.js` mocks `axios`; that mock is unverified under real Vitest.
6. The Node 20 versus Vite 5 / Vitest 2 pairing is plausible but unverified.

Static scan (done here, no network): third-party imports in `backend/` and `scripts/` are all covered by the requirements above, except `pydantic` and `starlette`, which arrive through `fastapi`/`pydantic-settings` (transitive, not declared directly). `redis` and `celery` are never imported.

## 4. Database safety requirements (all are enforced by the kit; none may be relaxed)

- A **brand-new** PostgreSQL 16 server that only you control, bound to `127.0.0.1` (or `::1`), port 1024-65535 and **not 5432**, a random password, no volume you care about. Never reuse an existing server, a shared one or a development one.
- The database is named with the word `test` **and** carries the comment `ITB_PHASE13_DISPOSABLE`; so does every other non-template database in that cluster except `postgres`. A name alone is never enough.
- `ITB_TEST_DATABASE_URL` is the only database variable the driver reads, in exactly the form `postgresql+psycopg2://USER[:PASSWORD]@127.0.0.1:PORT/DBNAME` (no query string, no `localhost`, no `%`). The password alphabet of `secrets.token_urlsafe` is accepted.
- **Do not set** any `PG*` variable except `PGPASSWORD`, and no `DATABASE_URL`, in the shell that runs the gate. The gate refuses; the driver's children run under `env -i` anyway.
- Any `REFUSED` or `GATE REFUSED` line means stop and find out why. Never edit `itb_db_gate.py`, the marker, or the URL rules to get past it.
- **Payments:** keep them off. The driver's Alembic commands run with `ENVIRONMENT=test PAYMENTS_ENABLED=false PAYMENT_SANDBOX_ENABLED=false`. Set no payment credential, no `PAYMENT_WEBHOOK_SECRET` of your own and no `.env` file in the tree. The codebase contains **no real payment provider**, only a sandbox simulator; the payment and webhook tests turn the simulator on inside the test process and move no money.

```bash
# Option A, Docker (loopback only, random password, nothing persisted)
export ITB_PG_PASSWORD="$(python3 -c 'import secrets; print(secrets.token_urlsafe(24))')"
docker run -d --rm --name itb-p13-validation -e POSTGRES_PASSWORD="$ITB_PG_PASSWORD" -p 127.0.0.1:55432:5432 --tmpfs /var/lib/postgresql/data postgres:16
until pg_isready -h 127.0.0.1 -p 55432; do sleep 1; done
env -i PATH="$PATH" PGPASSWORD="$ITB_PG_PASSWORD" psql -h 127.0.0.1 -p 55432 -U postgres \
   -c 'CREATE DATABASE itbridge_test' -c "COMMENT ON DATABASE itbridge_test IS 'ITB_PHASE13_DISPOSABLE'"
export ITB_TEST_DATABASE_URL="postgresql+psycopg2://postgres:${ITB_PG_PASSWORD}@127.0.0.1:55432/itbridge_test"
env -i PATH="$PATH" python3 -I -B <KIT>/itb_db_gate.py check "$ITB_TEST_DATABASE_URL" --expect-empty      # must print GATE PASSED
# teardown afterwards: docker rm -f itb-p13-validation
```
(Option B, a server started with `initdb`/`pg_ctl` without Docker, is in handoff §5.)

## 5. Run A (the run that counts) and run B (comparison only)

**Alembic choice.** The project does not pin Alembic. The candidate is `alembic==1.13.3`, applied only through an external constraints file; the reasons are in handoff §4 and are reasoning, not evidence. Run A uses it. Run B uses the newest Alembic in a second new venv and only decides whether the pin may later be widened. A version is "supported" only if **its own** run ended `VERDICT: PASS` and a person reviewed it. If A fails, report it; do not use B to get a pass.

```bash
# --- run A ---------------------------------------------------------------------------------------------
printf 'alembic==1.13.3\n' > "$HOME/itb-p13-constraints.txt"
python3.12 -m venv "$HOME/itb-p13-venv-pinned" && . "$HOME/itb-p13-venv-pinned/bin/activate"
python -m pip install --upgrade pip
python -m pip install -c "$HOME/itb-p13-constraints.txt" -r ~/itb-p13/IT-BRIDGE/backend/requirements.txt  2>&1 | tee ~/itb-p13/pip-install-A.log
python -m pip check ; python -m pip freeze > ~/itb-p13/pip-freeze-A.txt ; alembic --version        # must show 1.13.3
python -c "from zoneinfo import ZoneInfo; ZoneInfo('Asia/Kolkata'); print('timezone OK')"        # see §3 item 4 if this fails
cd ~/itb-p13 && mkdir -p run-A && cd run-A        # run the driver from OUTSIDE the repository
REPO=~/itb-p13/IT-BRIDGE ITB_TEST_DATABASE_URL="$ITB_TEST_DATABASE_URL" ALEMBIC_EXPECTED=1.13.3 PYTHON="$(command -v python)" \
  RESULTS="$PWD/results-A" bash <KIT>/run_phase13_validation.sh ; echo "driver exit code: $?" | tee exit-code-A.txt
```
If pip reports "no matching distribution" for 1.13.3, or the install fails at resolution or import, **stop and report the exact output**. Do not substitute another version silently. If you add a constraint on purpose (for example a `sqlalchemy<…` bound), write down what and why, and treat it as a recorded deviation from "project as shipped".

**Run B**, only after A is fully recorded: a **new** venv `itb-p13-venv-latest`, install **without** `-c`, `ALEMBIC_EXPECTED=any`, `RESULTS=.../results-B`, and a fresh disposable cluster (or at least `itb_db_gate.py reset`). Never mix B's results into A's claim.

## 6. Evidence to return (for each run)

1. `results-*/status.tsv` complete, plus `summary.txt`, `environment.txt` (it holds `pip freeze`, tool versions, `TREE_SHA256`) and every `*.log` in the results directory.
2. The final `VERDICT:` line and the driver's exit code (0 PASS, 1 FAIL, 3 INCOMPLETE, 4 interrupted).
3. `pytest-junit.xml` and `pytest-skips.txt` (real pytest: counts of passed, failed, errors, skipped per file).
4. `cli/*` (every Alembic command line, exit code and output; before/after database snapshots for each refusal) and `canary-*` logs.
5. Frontend: `npm-install.log`, `vitest.log`, `vite-build.log`, and, as information only (do not commit it), the `package-lock.json` that `npm install` wrote into the driver's copy `results-*/work/frontend/`, plus `npm ls` run there.
6. `pip-install-*.log`, `pip-freeze-*.txt`, `alembic --version`, `node --version`, `npm --version`, `psql --version`, `pg_dump --version`.
7. The gate's before/after evidence (`gate.log`, `regate.log`) and the output of the gate self-test if you run it (`itb_db_gate_selftest.py offline`).
8. Hashes: the tree hash (§1), the diff hash, both baseline-archive hashes after the run.
9. Before sending, confirm no secret leaks: `grep -rF "$ITB_PG_PASSWORD" results-* ` must print nothing.

## 7. Outstanding runtime checks (none has been run for real)

| Group | Where in the driver |
|---|---|
| Versions of tools, Python, Node/npm, PostgreSQL clients, Alembic | `versions:` (5 checks) |
| Backend imports with the real dependencies | `deps:` |
| Full backend `pytest`, no skipped required file; includes the payment, webhook, oversized-body, unusual-`Content-Length`, huge-timestamp, concurrency and notification-SAVEPOINT tests | `pytest:` and `canary:` (pytest files) |
| SQLite and PostgreSQL migration tests; `verify_postgres_sql.py` | `pytest:` and `sqlsmoke:` |
| `alembic heads` / `history` / `revision` from the documented directory; `upgrade head` + `alembic check`; refusals with unchanged snapshots; `-1`, `-3`, named revision, `base`, override, offline `--sql`; upgrade again | `cli:` (16 checks) and `canary:` (CLI matrix) |
| PostgreSQL rollback behaviour | PostgreSQL tests and the `cli:` matrix |
| `npm install`, `vitest run`, `vite build` | `frontend:` (3 checks) |

Static checks (`check_migrations_static`, `audit_integration`, ruff, `ast.parse`) and all stand-in results (the fake pytest, Alembic and npm batteries, the stand-in test counts) are **not** approval evidence.

## 8. Approval

Phase 13 can be considered for approval only when run A ends `VERDICT: PASS` (all 34 checks PASS, no skips), the rest of handoff §8 holds, and **a person has reviewed the evidence**. Until then: do not update `PROJECT_PROGRESS.md`, do not start Phase 14, do not commit pins or a lockfile. After a fully green, reviewed run, send back `pip freeze` and `package-lock.json` for a separate pinning change.

## 9. Stop conditions (report, do not work around)

Hash mismatch, wrong tool version, a registry or DNS failure, `pip`/`npm` resolution failure, any gate refusal, a refusal that changes the database ("DATABASE CHANGED"), a `downgrade pre-flight:` line in a canary, a timeout, or any status other than PASS. Report the exact output and leave Phase 13 UNAPPROVED.
