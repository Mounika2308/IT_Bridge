#!/usr/bin/env python3
"""IT BRIDGE Phase 13 runtime validation: the safety gate in front of every command that can wipe or downgrade a database.

Needs only Python 3.10+ (standard library) and the PostgreSQL command-line clients `psql` and `pg_dump`. It imports nothing from the project.

    itb_db_gate.py check    URL [--expect-empty]   exit 0 only if URL is a marked, throwaway PostgreSQL 16 database on this machine (rules below)
    itb_db_gate.py sql      URL "SQL"              runs SQL after the guard, IN THE SAME SESSION and the same transaction; prints the result
    itb_db_gate.py reset    URL                    guard + DROP SCHEMA public CASCADE; CREATE SCHEMA public, in one session and one transaction
    itb_db_gate.py snapshot URL OUTFILE            guard, then a READ-ONLY snapshot: schema (pg_dump), checksum of every row of every table, alembic_version
    itb_db_gate.py pgenv    URL                    guard, then prints shell `export PG...=` lines for psql-based scripts (eval it in a subshell)
    itb_db_gate.py url      URL                    grammar only, no connection: exit 0 if the URL is acceptable, 3 if not

THE GATE REFUSES (exit 3) unless ALL of these hold. Nothing destructive is sent to a server that fails any of them.
  1. The URL matches ONE fixed grammar, character for character (no URL library, no decoding, no normalisation):
         postgresql://USER[:PASSWORD]@HOST:PORT/DBNAME        (the scheme may also be postgresql+psycopg2)
         USER      [A-Za-z_][A-Za-z0-9_]*          PASSWORD  [A-Za-z0-9_.~-]*  (no percent-encoding: "%" is simply not allowed)
         HOST      exactly 127.0.0.1 or [::1]      ("localhost" is refused: a name is resolved by /etc/hosts and DNS, which this gate does not control)
         PORT      1024-65535, written without a leading zero, and NOT 5432 (the default port of the project's own dev database)
         DBNAME    [a-z][a-z0-9_]*, and it contains "test"
     There is no query string, fragment, parameter, second host, whitespace, control character, "@" in the credentials or percent-encoding. That matters
     because SQLAlchemy/psycopg2 and psql do not parse a URL the same way: a "?host=", "?port=", "?dbname=", "?hostaddr=", "?service=" or "?options="
     item would make the application connect somewhere other than where this gate looked.
  2. The caller's environment cannot redirect a connection: ANY environment variable starting with PG (PGHOST, PGHOSTADDR, PGPORT, PGDATABASE,
     PGSERVICE, PGSERVICEFILE, PGSYSCONFDIR, PGOPTIONS, ...) except PGPASSWORD is a refusal, and so is DATABASE_URL or ITB_TEST_DATABASE_URL when it
     differs from the URL being checked (the application would not connect where the gate looked). Refusal, not scrubbing: a consumer started from the
     same shell would still honour them.
  3. The connection is made with that URL's own host, port, user and database, through psql with every PG* variable of the caller removed, and the
     SERVER ITSELF then proves who it is (one server-side guard, run again, in the same session, in front of every statement that follows):
       - current_database() equals the database named in the URL;
       - PostgreSQL 16, not a replica;
       - the target database carries the comment ITB_PHASE13_DISPOSABLE (set on purpose by `COMMENT ON DATABASE ... IS 'ITB_PHASE13_DISPOSABLE'`);
         a name containing "test" is NOT enough, a development or production database called itbridge_test is refused;
       - EVERY other non-template database in the cluster except `postgres` carries the same comment, so a cluster that also holds a development,
         production or unknown database is refused whatever its name is;
       - with --expect-empty: the target holds no table, view, materialized view, sequence, partitioned or foreign table outside the system schemas.
  4. If the server cannot be reached, psql/pg_dump is missing, a call times out or anything unexpected happens, the answer is BLOCKED (exit 4), never a pass.
Exit codes: 0 ok, 2 usage, 3 REFUSED by the gate, 4 BLOCKED (psql/pg_dump error, missing client, timeout, interruption).
"""
import hashlib
import os
import re
import secrets
import shlex
import shutil
import subprocess
import sys

MARKER = "ITB_PHASE13_DISPOSABLE"
GRAMMAR = re.compile(
    r"postgresql(?:\+psycopg2)?://"
    r"(?P<user>[A-Za-z_][A-Za-z0-9_]{0,62})(?::(?P<password>[A-Za-z0-9_.~-]{0,128}))?@"
    r"(?P<host>127\.0\.0\.1|\[::1\]):(?P<port>[1-9][0-9]{3,4})/"
    r"(?P<db>[a-z][a-z0-9_]{0,62})",
    re.ASCII,
)
try:                   # seconds for one psql / pg_dump call; a hung server is BLOCKED, not a pass. The environment can only SHORTEN it (used by the self-test)
    TIMEOUT = max(1, min(300, int(os.environ.get("ITB_GATE_TIMEOUT", "300"))))
except ValueError:
    TIMEOUT = 300
CONSUMER_URL_VARS = ("DATABASE_URL", "ITB_TEST_DATABASE_URL")


class Refused(Exception):
    pass


class Blocked(Exception):
    pass


def parse(url: str) -> dict:
    """Pure function, no I/O. Raises Refused unless `url` matches the grammar exactly."""
    if not isinstance(url, str) or not GRAMMAR.fullmatch(url):
        shown = url if isinstance(url, str) and len(url) < 200 else "<not a short string>"
        raise Refused(f"URL {shown!r} does not match postgresql://USER[:PASSWORD]@127.0.0.1|[::1]:PORT/DBNAME (no query, fragment, encoding or other host form)")
    m = GRAMMAR.fullmatch(url)
    port = int(m["port"])
    if not 1024 <= port <= 65535 or port == 5432:
        raise Refused(f"port {port}: a throwaway cluster must use a port in 1024-65535 other than 5432 (the default of the dev database)")
    if "test" not in m["db"]:
        raise Refused(f"database name {m['db']!r} must contain 'test' (necessary, not sufficient: the database must also carry the {MARKER} comment)")
    host = m["host"].strip("[]")
    return {"host": host, "port": str(port), "user": m["user"], "password": m["password"] or "", "db": m["db"]}


def caller_environment_problems(url: str, environ=None) -> list[str]:
    environ = os.environ if environ is None else environ
    out = [f"{k} is set" for k in sorted(environ) if k.startswith("PG") and k != "PGPASSWORD"]
    for k in CONSUMER_URL_VARS:
        if environ.get(k, url) != url:
            out.append(f"{k} differs from the URL being checked (connection-target mismatch)")
    return out


def _env(c: dict, db: str | None = None, read_only: bool = False) -> dict:
    env = {k: v for k, v in os.environ.items() if not k.startswith("PG")}          # nothing from the caller's PG* variables can redirect a command
    opts = "-c statement_timeout=120000" + (" -c default_transaction_read_only=on" if read_only else "")
    env.update(PGHOST=c["host"], PGPORT=c["port"], PGUSER=c["user"], PGDATABASE=db or c["db"], PGCONNECT_TIMEOUT="5", PGSERVICEFILE=os.devnull,
               PGPASSFILE="/nonexistent/.pgpass", PGOPTIONS=opts)
    if c["password"]:
        env["PGPASSWORD"] = c["password"]
    return env


def run(prog: str, args: list[str], c: dict, read_only: bool = False) -> str:
    if shutil.which(prog) is None:
        raise Blocked(f"{prog} is not installed (BLOCKED, not a pass)")
    try:
        r = subprocess.run([prog, *args], env=_env(c, read_only=read_only), capture_output=True, text=True, timeout=TIMEOUT, stdin=subprocess.DEVNULL)
    except subprocess.TimeoutExpired:
        raise Blocked(f"{prog} did not finish within {TIMEOUT}s (BLOCKED, not a pass)") from None
    except (OSError, ValueError) as e:
        raise Blocked(f"{prog} could not be run: {e}") from None
    if r.returncode != 0:
        err = r.stderr.strip()
        if "itb gate:" in err:                                                       # raised by the server-side guard below: a verdict, not a failure
            raise Refused(err.split("itb gate:", 1)[1].splitlines()[0].strip())
        raise Blocked(f"{prog} failed ({r.returncode}): {err[:400]}")
    return r.stdout


def guard_sql(c: dict, expect_empty: bool = False) -> str:
    """The server-side guard. It RAISES, so whatever follows it in the same -c string never runs on a database that fails it. db is regex-checked."""
    db = c["db"]
    marker_of = "coalesce(shobj_description(d.oid, 'pg_database'), '')"
    parts = [
        f"IF current_database() <> '{db}' THEN RAISE EXCEPTION 'itb gate: connected to %, not {db}', current_database(); END IF;",
        "IF current_setting('server_version_num')::int NOT BETWEEN 160000 AND 169999 THEN "
        "RAISE EXCEPTION 'itb gate: server_version_num % (PostgreSQL 16 is required)', current_setting('server_version_num'); END IF;",
        "IF pg_is_in_recovery() THEN RAISE EXCEPTION 'itb gate: the server is a replica'; END IF;",
        f"IF NOT EXISTS (SELECT 1 FROM pg_database d WHERE d.datname = '{db}' AND {marker_of} = '{MARKER}') THEN "
        f"RAISE EXCEPTION 'itb gate: database {db} does not carry the {MARKER} comment (a name containing test is not enough)'; END IF;",
        f"IF EXISTS (SELECT 1 FROM pg_database d WHERE NOT d.datistemplate AND d.datname NOT IN ('postgres', '{db}') AND {marker_of} <> '{MARKER}') THEN "
        f"RAISE EXCEPTION 'itb gate: the cluster holds a database without the {MARKER} comment: it is not a throwaway cluster'; END IF;",
    ]
    if expect_empty:
        parts.append("IF EXISTS (SELECT 1 FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace WHERE n.nspname NOT IN ('pg_catalog', 'information_schema', 'pg_toast') "
                     "AND n.nspname NOT LIKE 'pg\\_temp\\_%' AND n.nspname NOT LIKE 'pg\\_toast\\_temp\\_%' AND c.relkind IN ('r','v','m','S','p','f')) THEN "
                     "RAISE EXCEPTION 'itb gate: the target is not empty; use reset on a database created for this run'; END IF;")
    return "DO $itbguard$ BEGIN " + " ".join(parts) + " END $itbguard$;"


def psql_guarded(c: dict, sql: str = "", expect_empty: bool = False, read_only: bool = False) -> str:
    """Guard + proof + `sql` in ONE psql -c string: one session, one implicit transaction, so the guard has run immediately before the statement and in
    the same connection that executes it. A psql meta-command (\\c, \\connect, \\gexec ...) cannot be mixed into a -c string; a backslash is refused anyway.
    The server must also ANSWER with a token that contains a fresh random nonce, the database it is and its version: a psql that exits 0 without having
    talked to a server (a stub, a wrapper, a broken install) therefore cannot produce a pass."""
    if "\\" in sql or "\x00" in sql or "$itbguard$" in sql:
        raise Refused("the SQL contains a backslash, a NUL or the guard's own delimiter: refused")
    nonce = secrets.token_hex(16)
    proof = f"SELECT 'ITB_GATE_OK|' || current_database() || '|' || current_setting('server_version_num') || '|{nonce}';"
    out = run("psql", ["-X", "-q", "-At", "-v", "ON_ERROR_STOP=1", "-c", guard_sql(c, expect_empty) + " " + proof + " " + sql], c, read_only=read_only)
    first, _, rest = out.partition("\n")
    f = first.split("|")
    if len(f) != 4 or f[0] != "ITB_GATE_OK" or f[1] != c["db"] or f[3] != nonce or not 160000 <= int(f[2] or 0) < 170000:
        raise Blocked("psql returned no proof that the server ran the guard (missing or wrong token): BLOCKED, not a pass")
    return rest.strip()


def check(url: str, expect_empty: bool = False) -> dict:
    c = parse(url)
    problems = caller_environment_problems(url)
    if problems:
        raise Refused("the caller's environment could redirect a connection: " + "; ".join(problems) + " (unset it; the validation driver runs everything under env -i)")
    psql_guarded(c, "", expect_empty, read_only=True)
    c["verdicts"] = [f"url: {c['host']}:{c['port']}, database {c['db']!r}, strict grammar, no query/fragment/encoding",
                     "environment: no PG* variable, no conflicting DATABASE_URL / ITB_TEST_DATABASE_URL",
                     f"server (asked in the connection that will be used): this database, PostgreSQL 16, primary, carries {MARKER}",
                     f"cluster: every other database except postgres carries {MARKER}"]
    if expect_empty:
        c["verdicts"].append("target: empty")
    return c


def snapshot(c: dict, out: str) -> None:
    dump = run("pg_dump", ["--schema-only", "--no-owner", "--no-privileges"], c, read_only=True)
    # recent pg_dump minor releases write random \restrict / \unrestrict keys and a version header: they differ between two identical databases
    dump = "\n".join(line for line in dump.splitlines() if not re.match(r"^(\\restrict|\\unrestrict|-- Dumped )", line))

    def q(sql: str) -> str:
        return run("psql", ["-X", "-q", "-At", "-v", "ON_ERROR_STOP=1", "-c", sql], c, read_only=True).strip()
    tables = q("SELECT tablename FROM pg_tables WHERE schemaname = 'public' ORDER BY 1").split()
    lines = ["# SCHEMA (pg_dump --schema-only)", dump, "# ROWS (count, md5 of all rows, per table)"]
    for t in tables:
        n, md5 = q(f"SELECT count(*) || '|' || coalesce(md5(string_agg(x::text, '~' ORDER BY x::text)), '-') FROM \"{t}\" x").split("|")
        lines.append(f"{t}\t{n}\t{md5}")
    lines.append("# VERSION TABLE")
    lines.append(q("SELECT version_num FROM alembic_version") if "alembic_version" in tables else "(no alembic_version table)")
    text = "\n".join(lines) + "\n"
    with open(out, "w", encoding="utf-8") as f:
        f.write(text)
    print(f"snapshot {out}: {len(text.splitlines())} lines, sha256 {hashlib.sha256(text.encode()).hexdigest()[:16]}")


def main(argv: list[str]) -> int:
    try:
        if len(argv) == 3 and argv[1] == "url":
            c = parse(argv[2])
            print(f"URL ACCEPTED (grammar only, nothing was contacted): {c['host']}:{c['port']}/{c['db']}")
        elif len(argv) >= 3 and argv[1] == "check" and all(a == "--expect-empty" for a in argv[3:]):
            c = check(argv[2], "--expect-empty" in argv[3:])
            print("GATE PASSED\n  " + "\n  ".join(c["verdicts"]))
        elif len(argv) == 4 and argv[1] == "sql":
            c = check(argv[2])
            print(psql_guarded(c, argv[3]))
        elif len(argv) == 3 and argv[1] == "pgenv":
            c = check(argv[2])
            print("\n".join(f"export {k}={shlex.quote(v)}" for k, v in _env(c).items() if k in ("PGHOST", "PGPORT", "PGUSER", "PGPASSWORD", "PGCONNECT_TIMEOUT")))
        elif len(argv) == 3 and argv[1] == "reset":
            c = check(argv[2])
            psql_guarded(c, "DROP SCHEMA public CASCADE; CREATE SCHEMA public;")
            print(f"reset {c['db']}: public schema recreated empty")
        elif len(argv) == 4 and argv[1] == "snapshot":
            c = check(argv[2])
            snapshot(c, argv[3])
        else:
            print(__doc__)
            return 2
    except Refused as e:
        print(f"GATE REFUSED: {e}", file=sys.stderr)
        return 3
    except Blocked as e:
        print(f"BLOCKED: {e}", file=sys.stderr)
        return 4
    except KeyboardInterrupt:
        print("BLOCKED: interrupted (nothing is reported as passed)", file=sys.stderr)
        return 4
    except Exception as e:                                                          # noqa: BLE001 - anything unexpected is a failure of the gate, never a pass
        print(f"BLOCKED: unexpected {type(e).__name__}: {e}", file=sys.stderr)
        return 4
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
