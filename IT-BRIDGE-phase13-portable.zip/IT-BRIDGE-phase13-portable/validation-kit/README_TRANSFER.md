# IT BRIDGE Phase 13: transfer package and checklist

**Phase 13 is UNAPPROVED.** No real runtime test (pytest, Alembic, Vitest, Vite) has ever been run on this tree: the authoring environment had no package-registry access. The only driver run on a real environment ended `VERDICT: INCOMPLETE`, exit 3, halted at `versions: alembic` (MISSING_DEPENDENCY). Static checks and fake-tool batteries do not count. This package changes no source, adds no dependency pins and no lockfile, and does not touch `PROJECT_PROGRESS.md`. Phase 14 is on hold.

## 1. What is in the package (all hashes are in `PHASE13_KIT.SHA256SUMS`)

| File | Role | SHA-256 |
|---|---|---|
| `IT-BRIDGE-phase13b4-stabilized.zip` | accepted development baseline (never modify) | `e12dd391564a3e9cc540546ae95bfcaf3812c193aca4f3fde8dfd9c86de59710` |
| `IT-BRIDGE-phase12-stabilized.zip` | older baseline (never modify) | `f60c33babb4009ce433fc2dd28b3297604055858b558058fbfa70757ff4aad0c` |
| `PHASE13_ENGINEERING_FIXES.diff` | 26-file diff, baseline -> tree under test | `d1aa8c19880e786f1aab0f316e73954a36c912abe0b4dd3af1fa3e957289853b` |
| `IT-BRIDGE-phase13-candidate-tree.zip` | **derived convenience copy** of the tree under test (equals baseline + diff, checked with `diff -r`) | see `PHASE13_KIT.SHA256SUMS` |
| `run_phase13_validation.sh` | the validation driver (expected tree hash baked in) | `137bb3c0e79ddbf41e5839e084ccbfffcec12708f2d35ae209e74282e1df1649` |
| `itb_db_gate.py` | the database safety gate | `71eaf59eb01ffe32085ae308e3ac6dbd8d19f13a061deea88802594096ecae67` |
| `itb_db_gate_selftest.py` | gate attack battery (`offline` needs no server) | `96aaf706d1d96fcf3ff6aebd23f830542899c9ce887e4a366b2ee4b723073778` |
| `PHASE13_RUNTIME_VALIDATION_HANDOFF.md` | full handoff (reasoning, 34 checks, Alembic matrix) | `504fab9505a60ecde7efe2826e2529450bb7fb006851571132ee0043c2121db0` |
| `PHASE13_EXTERNAL_RUNBOOK.md` | short runbook, dependency facts, evidence list | see `PHASE13_KIT.SHA256SUMS` |

**Tree under test: `TREE_SHA256 = 9d2280022999b74b40af3015743c5c93eebaabed3704d2d35a1bef32fe1d33ca`**
(`find . -type f` excluding `frontend/node_modules`, `frontend/dist`, `__pycache__`, `.git`, `.venv`, `.pytest_cache`, `.ruff_cache`, `*.pyc`, `backend/.env`, `.env`; `LC_ALL=C sort`; `sha256sum` of each; `sha256sum` of that list.)
The older `PHASE13_RUNTIME_ACCEPTANCE_PACK.md` (pre-fix, targets the bare baseline) is deliberately **not** included; it is superseded.

## 2. Checklist (stop at the first failure and report it; never work around a refusal)

- [ ] **A. Unpack and verify the package:** `sha256sum -c PHASE13_KIT.SHA256SUMS` prints `OK` for every line.
- [ ] **B. Build the tree and check it:** the tree hash equals the one above (commands below).
- [ ] **C. Toolchain:** Python 3.12.x, Node 20.x, PostgreSQL server and `psql`/`pg_dump` 16.x, working PyPI and npm access.
- [ ] **D. Gate self-test (optional, needs no server):** `python3 -I -B itb_db_gate_selftest.py offline` -> `690 passed, 0 failed (offline part)`. This tests the gate, not the application.
- [ ] **E. Run A:** new venv, install with the Alembic 1.13.3 constraint, driver with `ALEMBIC_EXPECTED=1.13.3`.
- [ ] **F. Disposable PostgreSQL 16** created, marked, and accepted by the gate (`GATE PASSED`).
- [ ] **G. Return the evidence (section 6).** Run B (newest Alembic, separate venv) only after A is recorded.
- [ ] **H.** A person reviews the evidence. Nothing is approved before that.

## 3. Commands for the external machine

```bash
P=~/itb-p13-transfer            # the unpacked package directory (it is also the KIT directory)
cd "$P" && sha256sum -c PHASE13_KIT.SHA256SUMS                        # every line OK, else stop

# --- the tree under test: baseline + diff (the definition of the tree) ----------------------------------
W=~/itb-p13 && mkdir -p "$W" && cd "$W" && unzip -q "$P/IT-BRIDGE-phase13b4-stabilized.zip" && cd IT-BRIDGE
patch -p1 --dry-run < "$P/PHASE13_ENGINEERING_FIXES.diff" && patch -p1 < "$P/PHASE13_ENGINEERING_FIXES.diff"
find . -type f ! -path './frontend/node_modules/*' ! -path './frontend/dist/*' ! -path '*/__pycache__/*' ! -path './.git/*' ! -path '*/.venv/*' \
  ! -path '*/.pytest_cache/*' ! -path '*/.ruff_cache/*' ! -name '*.pyc' ! -path './backend/.env' ! -path './.env' \
  | LC_ALL=C sort | xargs -d '\n' sha256sum | sha256sum | cut -d' ' -f1     # must equal 9d2280022999b74b40af3015743c5c93eebaabed3704d2d35a1bef32fe1d33ca
# (optional) the derived copy must agree:  mkdir ../chk && (cd ../chk && unzip -q "$P/IT-BRIDGE-phase13-candidate-tree.zip") && diff -r . ../chk/IT-BRIDGE

# --- Python environment, run A ---------------------------------------------------------------------------
printf 'alembic==1.13.3\n' > "$HOME/itb-p13-constraints.txt"
python3.12 -m venv "$HOME/itb-p13-venv-pinned" && . "$HOME/itb-p13-venv-pinned/bin/activate"
python -m pip install --upgrade pip
python -m pip install -c "$HOME/itb-p13-constraints.txt" -r "$W/IT-BRIDGE/backend/requirements.txt" 2>&1 | tee "$W/pip-install-A.log"
python -m pip check; python -m pip freeze > "$W/pip-freeze-A.txt"; alembic --version          # must show 1.13.3
python -c "from zoneinfo import ZoneInfo; ZoneInfo('Asia/Kolkata'); print('timezone OK')"      # if this fails see runbook section 3, item 4

# --- disposable PostgreSQL 16 (Option A, Docker; Option B is in section 4) ----------------------------------
export ITB_PG_PASSWORD="$(python3 -c 'import secrets; print(secrets.token_urlsafe(24))')"
docker run -d --rm --name itb-p13-validation -e POSTGRES_PASSWORD="$ITB_PG_PASSWORD" -p 127.0.0.1:55432:5432 --tmpfs /var/lib/postgresql/data postgres:16
until pg_isready -h 127.0.0.1 -p 55432; do sleep 1; done
env -i PATH="$PATH" PGPASSWORD="$ITB_PG_PASSWORD" psql -h 127.0.0.1 -p 55432 -U postgres \
   -c 'CREATE DATABASE itbridge_test' -c "COMMENT ON DATABASE itbridge_test IS 'ITB_PHASE13_DISPOSABLE'"
export ITB_TEST_DATABASE_URL="postgresql+psycopg2://postgres:${ITB_PG_PASSWORD}@127.0.0.1:55432/itbridge_test"
env -i PATH="$PATH" python3 -I -B "$P/itb_db_gate.py" check "$ITB_TEST_DATABASE_URL" --expect-empty      # must print GATE PASSED

# --- the driver (run it from OUTSIDE the repository) ---------------------------------------------------------
mkdir -p "$W/run-A" && cd "$W/run-A"
REPO="$W/IT-BRIDGE" ITB_TEST_DATABASE_URL="$ITB_TEST_DATABASE_URL" ALEMBIC_EXPECTED=1.13.3 PYTHON="$(command -v python)" \
  RESULTS="$PWD/results-A" bash "$P/run_phase13_validation.sh"; echo "driver exit code: $?" | tee exit-code-A.txt

# --- afterwards -------------------------------------------------------------------------------------------------
grep -rF "$ITB_PG_PASSWORD" results-A ; echo "(the line above must be empty)"
docker rm -f itb-p13-validation
sha256sum "$P"/IT-BRIDGE-phase1*-stabilized.zip           # both baselines must still match section 1
```

**Driver variables** (anything not listed is ignored; the driver runs every child under `env -i`):

| Variable | Meaning | Default |
|---|---|---|
| `REPO` | the tree under test (must contain `backend/alembic.ini`) | **required** |
| `ITB_TEST_DATABASE_URL` | the one disposable database; without it every database check is `NOT_RUN` (INCOMPLETE) | unset |
| `PYTHON` | interpreter of the run-A venv (`alembic` is taken from next to it, or set `ALEMBIC_BIN`) | `python3` |
| `RESULTS` | output directory, **outside** `REPO` | `./phase13-results-<time>` |
| `ALEMBIC_EXPECTED` | `1.13.3`, or `any` (run B only) | `1.13.3` |
| `EXPECT_PY` / `EXPECT_NODE` / `EXPECT_PG` | required Python / Node / PostgreSQL-client major.minor, major, major | `3.12` / `20` / `16` |
| `STAGES` | subset of `static,deps,gate,pytest,sqlsmoke,cli,frontend` (an unselected stage makes the verdict INCOMPLETE) | all |
| `EXPECTED_TREE_SHA256` | tree hash | baked in (`9d228002…33ca`) |
| `T_STATIC` `T_DEPS` `T_PYTEST` `T_CANARY` `T_SQLSMOKE` `T_ALEMBIC` `T_NPM` | per-stage timeouts, seconds | 300 / 120 / 3600 / 1800 / 900 / 300 / 1200 |

Exit codes: `0` PASS (all 34 checks PASS), `1` FAIL, `3` INCOMPLETE (a missing dependency, skip, refusal, timeout or unselected stage), `4` interrupted or stopped early, `2` usage error. A `PASS` is evidence for a person to review, not an approval.
Do **not** export `PG*` variables (except `PGPASSWORD` for the setup commands), `DATABASE_URL`, `PAYMENTS_ENABLED`, any payment secret or credential, and do not create a `.env` file in the tree.

## 4. Disposable PostgreSQL 16: every safety requirement

The gate (`itb_db_gate.py`, run before every database command by the driver) accepts a target only if **all** hold:
1. The URL has exactly the form `postgresql[+psycopg2]://USER[:PASSWORD]@127.0.0.1|[::1]:PORT/DBNAME`: USER `[A-Za-z_][A-Za-z0-9_]*`, PASSWORD `[A-Za-z0-9_.~-]*`, PORT 1024-65535 and **not 5432**, DBNAME `[a-z][a-z0-9_]*` containing `test`. No query string, fragment, `;`, `%`, whitespace, `localhost` or second host.
2. No `PG*` variable other than `PGPASSWORD`, and no differing `DATABASE_URL`, in its environment.
3. Asked of the server **in the connection that will be used**: the connected database is the URL's database, the server is PostgreSQL 16, not a replica, the database carries the comment `ITB_PHASE13_DISPOSABLE`, and **every other non-template database except `postgres` carries it too**. A name containing `test` is never enough.
4. For the first check, `--expect-empty`: no relation outside the system schemas.
5. Every destructive statement is preceded by the same server-side guard in the same session; an Alembic command is preceded by a fresh gate check.

Create a **brand-new** server that only you control, bound to loopback, with a random password. Never reuse an existing, shared or development server. Option B, without Docker:
```bash
export ITB_PG_PASSWORD="$(python3 -c 'import secrets; print(secrets.token_urlsafe(24))')"
export PGD="$(mktemp -d)"; printf '%s' "$ITB_PG_PASSWORD" > "$PGD.pw"
initdb -D "$PGD" -U postgres --auth=scram-sha-256 --pwfile="$PGD.pw"
pg_ctl -D "$PGD" -o "-p 55432 -c listen_addresses=127.0.0.1 -c unix_socket_directories=$PGD" -l "$PGD/log" -w start
env -i PATH="$PATH" PGPASSWORD="$ITB_PG_PASSWORD" psql -h 127.0.0.1 -p 55432 -U postgres \
   -c 'CREATE DATABASE itbridge_test' -c "COMMENT ON DATABASE itbridge_test IS 'ITB_PHASE13_DISPOSABLE'"
# teardown:  pg_ctl -D "$PGD" -m immediate stop; rm -rf "$PGD" "$PGD.pw"
```
Any `REFUSED` or `GATE REFUSED` means stop and find out why. Never edit the gate, the marker or the URL rules to get past it. The Alembic override variable `ITB_ALLOW_FINANCIAL_DOWNGRADE` must never be set outside the driver's own disposable database.

**Payments stay disabled.** The driver's Alembic commands run with `ENVIRONMENT=test PAYMENTS_ENABLED=false PAYMENT_SANDBOX_ENABLED=false`. The codebase has **no real payment provider**, only a sandbox simulator (no money moves); the payment and webhook tests switch the simulator on inside their own test process. Set no payment credential and no `PAYMENT_WEBHOOK_SECRET`.

## 5. Dependencies: what the project files say, and what they do not

| Item | Fact (from the files in this tree) |
|---|---|
| Backend manifest | `backend/requirements.txt`: 13 names, **no versions**: `fastapi`, `uvicorn[standard]`, `pydantic-settings`, `email-validator`, `sqlalchemy`, `alembic`, `psycopg2-binary`, `python-jose[cryptography]`, `bcrypt`, `redis`, `celery`, `pytest`, `httpx`. No constraints file, no backend lockfile. |
| Python | 3.12 (`backend/Dockerfile`: `python:3.12-slim`). Enforced by the driver. |
| Frontend manifest | `frontend/package.json`, caret ranges only. dependencies: `@hookform/resolvers ^3.9.0`, `@tanstack/react-query ^5.0.0`, `axios ^1.7.0`, `lucide-react ^0.400.0`, `react ^18.3.0`, `react-dom ^18.3.0`, `react-hook-form ^7.52.0`, `react-router-dom ^6.24.0`, `zod ^3.23.0`. devDependencies: `@vitejs/plugin-react ^4.3.0`, `autoprefixer ^10.4.0`, `postcss ^8.4.0`, `tailwindcss ^3.4.0`, `vite ^5.3.0`, `vitest ^2.0.0`, `@testing-library/react ^16.0.0`. Scripts: `test` = `vitest run`, `build` = `vite build`. |
| Node | 20 (`frontend/Dockerfile`: `node:20-alpine`). Enforced by the driver. |
| **Lockfile status** | **None.** No `package-lock.json`, `pnpm-lock.yaml` or `yarn.lock` exists; the driver runs `npm install` in a copy of `frontend/` and the resulting `package-lock.json` is evidence only. None is generated or committed here. |
| Alembic | **Not pinned by the project.** `alembic==1.13.3` is only the candidate for this validation, supplied through an external constraints file (reasons: handoff section 4; they are reasoning, not evidence). |

**Cannot be verified from the available files (record the real value or result; do not guess):**
1. Any resolved version, Python or npm; only `pip freeze` / `npm ls` on the validating machine can say.
2. Whether `alembic==1.13.3` resolves and imports with the newest SQLAlchemy pip chooses (the central open question).
3. Whether the newest pytest, httpx, FastAPI, Starlette and Pydantic work with the tests.
4. `tzdata` is undeclared; `app/core/clock.py` needs the `Asia/Kolkata` time-zone database (the command above checks it).
5. Vitest runs in its default node environment (no `test` block in `vite.config.js`, `jsdom` undeclared); whether the 10 test files pass there, and the `axios` mock in `notificationService.test.js`, are unverified. `@testing-library/react` is declared but unused.
6. Every PostgreSQL-only test (`test_migrations_postgres`, `test_postgres_concurrency`, `test_postgres_notifications`, the guarded `tests/pg.py` on a real SQLAlchemy engine) and `verify_postgres_sql.py` against a real server: written and statically reviewed, never executed. Real pytest should collect the stand-in counts (`test_migration_guards_static` 50, `test_migration_guard` 139, `test_pg_gate` 97, `test_verify_postgres_sql_gate` 49, `test_payment_rules` 381); a difference must be explained.
7. The Alembic guard assumptions D1-D9 (handoff section 2) and that SQLAlchemy/psycopg2 treat URL query overrides as libpq does (the gate refuses such URLs regardless).
8. Docker availability on the external machine, and the `npm` version (the driver only records it).

## 6. Evidence to return (per run)

`results-*/status.tsv` (complete), `summary.txt`, `environment.txt` (pip freeze, tool versions, `TREE_SHA256`), every `*.log`, `pytest-junit.xml`, `pytest-skips.txt`, `cli/*` (each Alembic command, exit code, output, before/after snapshots), the `canary-*` logs, `gate.log` / `regate.log`, the frontend logs and `results-*/work/frontend/package-lock.json` (information only); plus `pip-install-A.log`, `pip-freeze-A.txt`, `exit-code-A.txt`, `alembic --version`, `node`/`npm`/`psql`/`pg_dump --version`, the tree hash, the diff hash and both baseline hashes after the run. Send nothing until `grep -rF "$ITB_PG_PASSWORD" results-A` prints nothing.

Outstanding checks, all NOT yet run for real: tool versions; backend imports; full pytest (payment, webhook oversized-body / `Content-Length` / huge-timestamp, concurrency, notification SAVEPOINT, SQLite and PostgreSQL migration tests); `verify_postgres_sql.py`; the 16-check Alembic CLI matrix with snapshot equality (`-1`, `-3`, named revision, `base`, override, offline `--sql`, upgrade again) and two canaries; `npm install`, `vitest run`, `vite build`.
Approval needs run A to end `VERDICT: PASS` (34 of 34, no skips), the other conditions in handoff section 8, and a person's review. Until then: no `PROJECT_PROGRESS.md` update, no pins, no lockfile, no Phase 14.
