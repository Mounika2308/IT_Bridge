# IT BRIDGE Phase 13: external runtime validation handoff (after the final safety audit of the kit)

**Recommendation: READY FOR EXTERNAL RUNTIME VALIDATION. NOT STABILITY-APPROVED.**
Phase 13B.4 is the accepted development baseline; this handoff covers the source-level hardening on top of it (26 files, `PHASE13_ENGINEERING_FIXES.diff`).
**Nothing in it has been run against real Alembic, SQLAlchemy, FastAPI, pytest, Vitest, Vite or the application on PostgreSQL.** Those need a machine with package-registry access (the authoring environment could not reach `pypi.org` / `registry.npmjs.org`: DNS resolution fails, `curl` exit 6, checked 2026-10-12; the 13B.4 attempt was refused at the proxy with HTTP 403; no install was attempted again). Phase 14 is on hold and `PROJECT_PROGRESS.md` is not to be updated until the evidence below has been produced and reviewed.

Files in this kit (none of it is inside the repository):

| File | What it is |
|---|---|
| `PHASE13_RUNTIME_VALIDATION_HANDOFF.md` | this document |
| `itb_db_gate.py` | stdlib-only safety gate: strict URL grammar, no `PG*` environment, server-side proof that the database is a prepared throwaway; also guarded `sql` / `reset`, read-only `snapshot`, `pgenv` |
| `itb_db_gate_selftest.py` | attack battery for the gate: `offline` part needs no server; `live` part needs two throwaway clusters you create (§5, §9) |
| `run_phase13_validation.sh` | staged driver: fixed list of 34 expected checks, tree and version checks first, gate re-check before every database command, per-stage timeouts, interruption handling, verdict PASS / FAIL / INCOMPLETE |
| `PHASE13_ENGINEERING_FIXES.diff` | the full diff against `IT-BRIDGE-phase13b4-stabilized.zip` (SHA-256 `e12dd391564a3e9cc540546ae95bfcaf3812c193aca4f3fde8dfd9c86de59710`), diff SHA-256 `d1aa8c19880e786f1aab0f316e73954a36c912abe0b4dd3af1fa3e957289853b` |

Identity of the tree under test: extract the baseline zip, run `patch -p1 < PHASE13_ENGINEERING_FIXES.diff` inside it, and `TREE_SHA256` must be

`9d2280022999b74b40af3015743c5c93eebaabed3704d2d35a1bef32fe1d33ca`

(`find . -type f` excluding `frontend/node_modules`, `frontend/dist`, `__pycache__`, `.git`, `.venv`, `.pytest_cache`, `.ruff_cache`, `*.pyc`, `backend/.env`, `.env`; `LC_ALL=C sort`; `sha256sum` of each; `sha256sum` of that list). **The driver computes it and refuses to run (verdict FAIL, nothing else runs) if it differs**; the value is baked into the driver.

---

## 0. What changed in the final safety audit of this kit

The first version of the kit had demonstrable bypasses; they were reproduced against the old gate on a throwaway decoy cluster, fixed, and the fixes attacked again (§9).

| # | Defect found in the earlier kit / repository | Consequence | Fix |
|---|---|---|---|
| 1 | The gate parsed the URL with `urlsplit` and **ignored the query string** | `postgresql://…:55432/itbridge_test?port=55433&dbname=devdata` PASSED the gate (it looked at port 55432) while libpq (psql, psycopg2, SQLAlchemy) connected to port 55433, database `devdata` — **reproduced with psql** | strict grammar, character for character; any `?`, `#`, `;`, `%`, `@` in credentials, second host, `localhost`, other loopback forms: refused before any connection |
| 2 | A database was "throwaway" if its **name contained `test`** and the cluster held no other database | a development database called `itbridge_test`, alone next to `postgres`, was wiped by `reset` — **reproduced**: 50 rows gone | positive marker: the database must carry the comment `ITB_PHASE13_DISPOSABLE`, and every other database of the cluster except `postgres` must carry it |
| 3 | The check and the destructive statement were **two separate connections** | the target could change between them | the guard (a `DO` block that raises) and the statement are one `psql -c` string: one session, one transaction. Tested with a forwarder that sends the first connection to the real target and every later one to the decoy: refused, decoy untouched |
| 4 | The gate **ignored** the caller's `PG*` variables instead of refusing them | a consumer started from the same shell (pytest, alembic, psql) would still honour `PGHOSTADDR`, `PGSERVICE`, … | refusal if any `PG*` variable except `PGPASSWORD` is set, or if `DATABASE_URL` / `ITB_TEST_DATABASE_URL` differs from the URL checked. The driver runs everything under `env -i`, so the caller's shell cannot reach any child |
| 5 | A `psql` that exits 0 without talking to a server (stub, wrapper, broken install) would have produced **GATE PASSED** | false pass | the server must answer with a token containing a fresh random nonce, the database and the version; missing or wrong token = BLOCKED |
| 6 | No timeout handling in the gate (`TimeoutExpired` traceback), no interruption handling | unhelpful crash | every path ends in exit 3 (refused) or 4 (blocked), never 0 |
| 7 | `backend/tests/pg.py` checked only the name and the scheme; the **host was not checked**; `DROP SCHEMA public CASCADE` ran on whatever the URL named | the PostgreSQL tests could wipe a dev database on a remote or shared host whose name contains `test` | strict loopback grammar, no `PG*` environment, the engine must equal the validated URL (no query items), and the same server-side guard runs as the first statement of every transaction that terminates sessions or drops (`assert_disposable`). 97 stand-in tests |
| 8 | `scripts/verify_postgres_sql.py` ran `DROP DATABASE IF EXISTS itb_verify_test` on **whichever server libpq reached** (unix socket and `localhost` included, PG* variables of the caller) | it could drop a database called `itb_verify_test` on a dev server, or create one there | `PGHOST` must be exactly `127.0.0.1` / `::1`, `PGPORT` explicit and not 5432, no other libpq variable, database name fixed to `itb_verify_test[a-z0-9_]{0,20}`; then one psql session runs the server-side guard and `DROP DATABASE` after it (exit 3 = refused). The database it creates carries the marker. 49 stand-in tests |
| 9 | Port lower bound missing in the new `pg.py` grammar (port 1023 was accepted) | none in practice (grammar only), but a hole | found by the new test `test_url_is_refused`; fixed |
| 10 | Driver: tree hash only recorded, tool versions only annotated, `STAGES=env` printed "every stage passed", no interruption handling, no timeouts, no re-gate, `MISSING_DEPENDENCY` assigned to any log containing `ImportError` (a project import defect would be reported as a missing package), no check that a required test file ran at least one test, verdict read by grepping ` FAIL ` in a padded text table | false PASS / mislabelled FAIL | rewritten: fixed list of 34 expected checks (a check that was not recorded is `NOT_RUN`), fatal tree and version checks, `regate` before every database command, `timeout` per stage (kills the process group), INT / TERM / HUP trap and EXIT trap (verdict INCOMPLETE, exit 4), classification of missing modules only for third-party names, JUnit analysis that fails on a required file with no executed test, machine-readable `status.tsv`, frontend work in a copy of `frontend/`, final "tree unchanged by the run" check, a bug found while testing (`$?` after an `if` in the re-gate gave the wrong status label; safety unaffected) fixed |

## 1. What the diff changes (26 files vs the 13B.4 baseline)

| File(s) | Change | Product / payment behaviour |
|---|---|---|
| `backend/app/core/migration_guard.py` (new) | Whole-run downgrade pre-flight: policy table of what each revision discards, path resolution, row counting, exact-phrase override | none (downgrade path only) |
| `backend/alembic/versions/0001`–`0007` | Each `downgrade()` starts with an in-function import and `preflight_downgrade("<rev>")`. 0001 also gains the `_refuse_to_discard` second-line guard. **Every `upgrade()` is byte-for-byte unchanged** (checked hunk by hunk) | none |
| `backend/alembic.ini`, `backend/alembic/script.py.mako` | `prepend_sys_path = .`; new revisions are generated with the pre-flight call | none |
| `README.md`, `ARCHITECTURE.md` | pre-flight, path rule, override scope; README: the PostgreSQL-test URL shape, the `ITB_PHASE13_DISPOSABLE` marker and the `PGPORT` requirement of `verify_postgres_sql.py` | docs only |
| `backend/tests/pg.py` | database safety rules in front of `DROP SCHEMA` (§0 #7, #9) | tests only |
| `backend/tests/test_pg_gate.py` (new), `test_verify_postgres_sql_gate.py` (new) | no-database tests of those rules | tests |
| `scripts/verify_postgres_sql.py` | safety rules in front of `DROP DATABASE` (§0 #8) | tooling |
| `backend/tests/test_migration_guard.py` (new), `test_migration_guards_static.py` (new), `test_migrations.py`, `test_migrations_postgres.py` | guard logic, AST checks, real-Alembic tests on SQLite / PostgreSQL | tests |
| `scripts/check_migrations_static.py` | stub-Alembic harness extended | tooling |
| `backend/app/api/v1/payments.py`, `backend/app/services/payment_rules.py` | **webhook endpoint hardening only** (below) | see below |
| `backend/app/services/payment_service.py` | **comment only** (why `create_order` runs under the training lock) | none |
| `backend/tests/test_payment_rules.py`, `test_payments_phase13.py` | regression tests for the webhook fixes, integration and provider-failure tests | tests |

**Payment behaviour is not byte-for-byte identical to 13B.4.** The complete list of changed lines under `backend/app/` outside the migration guard and the migrations is three hunks:

1. **Incremental request-body reading and the size limit** (`payments.py::raw_body`). 13B.4 read the whole body with `await request.body()` and only then compared its length with `MAX_WEBHOOK_BYTES` (64 KB). Now the body is read with `request.stream()` into a `bytearray`, and `413 TOO_LARGE` (same `PaymentError`, same message) is raised **as soon as the running total exceeds 64 KB**; at most the limit plus one transport chunk is ever held. The limit and the error are unchanged; a body that fits is returned as the same bytes.
2. **Unusual `Content-Length` values** (same function). The declared-length shortcut is `if declared and declared.isascii() and declared.isdigit() and int(declared) > MAX_WEBHOOK_BYTES`. 13B.4 had no `isascii()`: a value such as `"²"` (superscript two, `isdigit()` is true, `int()` raises `ValueError`) crashed the endpoint with HTTP 500. Now such a value skips the shortcut and the streaming loop enforces the limit. A declared length over the limit is still refused before any byte is read. **Not changed, and a residual risk:** an ASCII-digit `Content-Length` of more than 4300 digits makes `int()` raise `ValueError` (Python's integer-string limit). Whether the ASGI server lets such a header reach the application is unverified, and no test covers it; fixing it is a further change to the webhook, left for a decision (§10).
3. **Extremely large timestamps** (`payment_rules.py`, signature / timestamp check). `abs(now_epoch - ts) > tolerance_seconds` is now inside `try … except OverflowError` → `stale_timestamp`. A timestamp of a few hundred digits made the float comparison raise `OverflowError` (HTTP 500). The `ValueError` path (`bad_timestamp`), the tolerance, the signature comparison and every other outcome are unchanged.

**Unchanged** (diff and `cmp`): the payment state machine, amounts and fee calculation, idempotency, lock order training → payment → earning, `create_order` under the training lock (only a comment was added), `config.py` (byte-identical: payments off, sandbox off, `ENVIRONMENT` required, no real provider exists, no HTTP or gateway client library is imported in `app/`), models, schemas, providers, and the three open product policies: **(1)** whether a fee must be paid before a review, **(2)** what a refund does to an existing review, **(3)** whether earnings depend on reviews. No test asserts any of them.

Checks of the diff itself (executed): `patch -p1` of the diff on the baseline reproduces the working tree (identical hash); the changed-file set is exactly the 26 above; no `__pycache__`, `.pyc`, cache or archive in the tree; ruff `F` rules show the 28 findings the baseline already has and nothing new; both baseline archives are unchanged (`13b4` = `e12dd391564a3e9c…`, `phase12-stabilized` = `f60c33babb4009ce…`).

## 2. Migration guard: what the source review established, and what it cannot

Source inspection does **not** prove runtime behaviour. Each row says what the code guarantees by construction and what still needs real Alembic.

| Property | From the code (static) | Needs real Alembic/PostgreSQL |
|---|---|---|
| Uncertainty cannot narrow the check | `resolve_path`: a path is trusted only for a target the module recognises (`base`, a revision in the policy, `-N`) and, for `-N`, only with Alembic's answer confirming it; every other case checks `_everything_below(first)`, a superset of any run. Alembic's answer is only ever **added** (union). Ordering of Alembic's answer is irrelevant | That `get_revision_argument()` / `iterate_revisions(...)` behave as assumed (D1, D2) |
| Missing context, unknown revision, missing policy entry fail closed | `ctx is None` → refusal; revision not in `POLICY` → refusal; `CHAIN = tuple(POLICY)`; errors from Alembic import, context, counting or policy **propagate**; `_checked` is set only after the check passed | That Alembic propagates the exception out of `command.downgrade` unchanged (D6) |
| First destructive revision cannot run before the pre-flight | Static test: statements 0 and 1 of **every** `downgrade()` are the import and `preflight_downgrade("<own rev>")`. Mutation-checked | That Alembic runs the downgrade newest-first and calls nothing destructive before `downgrade()` (D4); it may create `alembic_version` first (D7) |
| `base`, specific revision, `-1`, `-N` | `chain_path` counts from the revision the run **starts at**; over-long / malformed targets → unknown → widest check | D1, D2 |
| Branches / merges | Not supported by design: `POLICY` is one linear chain; a revision not in `POLICY` is refused at run time | Alembic rejects multiple heads itself |
| Offline `--sql` | `is_offline_mode()` → a path that drops data is refused; nothing is counted | `env.py` has **no** offline branch: what `alembic downgrade X:base --sql` does before the guard is unverified (D5) |
| Import behaviour | Migrations import `app` only inside `downgrade()`; static test forbids a module-level `app` import | `alembic heads/history/revision` really working without `app` (D3) |
| Once per run, no stale state | `_checked` holds the last passing `MigrationContext` (strong reference) | That Alembic builds a new `MigrationContext` per command (D8) |

**Assumptions that cannot be proven without real Alembic** (each is exercised by the driver; the canary turns a false one into a recorded finding because the guard logs `downgrade pre-flight: …` whenever Alembic's answers were missing or disagreed): **D1** `get_revision_argument()` returns `None` for base, a resolved id, the raw `-N` string · **D2** `context.script.iterate_revisions(upper, lower, select_for_downgrade=True)` accepts a string `upper` and a relative `lower` (failure tolerated: widest check) · **D3** `alembic heads / history / revision` work without `app`, and `prepend_sys_path = .` is relative to the directory `alembic` runs from · **D4** newest-first from the database's current revision · **D5** `--sql` calls `downgrade()` with `is_offline_mode()` true · **D6** an exception in `downgrade()` reaches the caller and, on PostgreSQL, rolls back the one transaction · **D7** creating `alembic_version` is the only thing Alembic does before the first `downgrade()` · **D8** a new `MigrationContext` per command · **D9** PostgreSQL runs the whole `alembic downgrade` in one transaction (one `begin_transaction()` in `env.py` is pinned by a static test; `transactional_ddl` is database behaviour).

## 3. Database safety: every connection and every destructive statement in the kit and the repository

Found by searching the repository and the kit for `DROP`, `TRUNCATE`, `DELETE`, `ALTER`, `CREATE DATABASE`, `create_engine`, `psql`, `pg_dump`:

| Where | Destructive operation | Protection now |
|---|---|---|
| `itb_db_gate.py reset` | `DROP SCHEMA public CASCADE; CREATE SCHEMA public` | strict URL grammar → `PG*` / URL-variable refusal → check (own connection) → **guard + statement in one `psql -c` string** (same session, same transaction, nonce proof) |
| `itb_db_gate.py sql` | whatever SQL the driver passes | same; a backslash, NUL or the guard delimiter in the SQL is refused; `DROP DATABASE` cannot run inside the guarded transaction (exit 4) |
| `itb_db_gate.py snapshot` | none (read-only: `default_transaction_read_only=on`) | after the same check |
| `backend/tests/pg.py::wipe` (3 PostgreSQL test files) | `pg_terminate_backend` on other sessions, `DROP SCHEMA public CASCADE` | grammar, `PG*` refusal, engine = validated URL, **`assert_disposable` as the first statement of each transaction** (raises → nothing else runs) |
| `scripts/verify_postgres_sql.py::create_database` | `DROP DATABASE IF EXISTS itb_verify_test`, `CREATE DATABASE` | environment rules before any connection; guard and `DROP` in one psql session |
| Alembic downgrades (driver, tests) | Alembic's own DDL | **cannot be guarded in-session** (Alembic owns the connection): the driver runs the gate again immediately before every Alembic command; the command's `DATABASE_URL` is the gate-checked URL under `env -i`; the migration guard (§2) is the application-level protection. Residual window: §10 |
| Tests that `DELETE`/`DROP` inside SQLite or stub databases | n/a | in-memory / temporary databases created by the test |

`Settings.database_url` defaults to `postgresql+psycopg2://itbridge:change_me@localhost:5432/itbridge` and reads `backend/.env`. The driver passes an explicit `DATABASE_URL` under `env -i` to every Alembic command; under pytest `tests/conftest.py` sets `DATABASE_URL=sqlite://` before the app is imported, so the app's default engine can never reach `localhost:5432` in a test run. **Never run `alembic downgrade` from an ordinary shell in `backend/`.** `python -m alembic` run from `backend/` fails (the project's `alembic/` folder shadows the library): use the `alembic` console script. The password is in `ITB_TEST_DATABASE_URL`; the gate never prints it; before sharing results run `grep -rF "<password>" <results dir>` (must print nothing).

## 4. Versions, installation and the Alembic matrix

- **Python 3.12** (`backend/Dockerfile`: `python:3.12-slim`), **Node 20** (`frontend/Dockerfile`: `node:20-alpine`), **PostgreSQL 16** server and `psql` / `pg_dump` 16 clients (`docker-compose.yml`: `postgres:16`). The driver checks these explicitly and stops (INCOMPLETE) on a mismatch. Linux with GNU `find` / `xargs` / `sha256sum` / `timeout` / `tar`.
- Network access to PyPI and the npm registry must come from your normal route (mirror or allowed egress). Nothing here bypasses a network policy.

### Alembic: candidate pin and comparison run

**Candidate (intended supported version): `alembic==1.13.3`.** Reasons: (1) it is the last release of the 1.13 series, a patch-terminal release, so a run is reproducible and the same value can later become the production pin; (2) the repository uses SQLAlchemy 2.0-style code (`DeclarativeBase`) and Python 3.12, and to my recollection the 1.12/1.13 series is the generation that supports both; (3) the guard uses only long-standing public interfaces (`context.get_revision_argument`, `context.script.iterate_revisions`, `get_context`, `op.get_bind`). **Reasons (1)–(3) are reasoning and recollection, not verified: no package index was reachable, nothing was installed, and no compatibility with 1.13.3 or any other version is claimed until the real migration suite has passed.**

| Run | Alembic | Environment | Driver setting | Purpose |
|---|---|---|---|---|
| **A, candidate** | `1.13.3` via a constraints file | its own new venv `itb-p13-venv-pinned` | `ALEMBIC_EXPECTED=1.13.3` (default) | the version this tree is meant to be supported on |
| **B, comparison** | newest release (no constraint) | a **second, new** venv `itb-p13-venv-latest`, never sharing packages with A | `ALEMBIC_EXPECTED=any` (the version found is recorded) | does the suite still pass on what an unpinned deployment gets; decides whether the pin may be widened |

Separate `RESULTS` directories, a freshly created disposable cluster (or at least `gate reset`) for each. Never mix B's results into A's claim. Decision rule: a version is called supported only if **its own** run ended with `VERDICT: PASS` and a person reviewed it. A failing → report the failure; do not switch to B to "get a pass". A passes and B fails → pin exactly 1.13.3 and report B's failures. Both pass → only then propose a range, as a separate change. **Blocker (recorded, not worked around): the package registries were unreachable in the authoring environment, so neither run has happened.**

```bash
printf 'alembic==1.13.3\n' > "$HOME/itb-p13-constraints.txt"
python3.12 -m venv "$HOME/itb-p13-venv-pinned" && . "$HOME/itb-p13-venv-pinned/bin/activate"      # run B: a NEW venv and no -c
python -m pip install --upgrade pip
python -m pip install -c "$HOME/itb-p13-constraints.txt" -r <REPO>/backend/requirements.txt
python -m pip check && python -m pip freeze            # keep the output
alembic --version                                      # must show 1.13.3 on run A
```
If `pip` reports no matching distribution for 1.13.3, stop and report it; do not substitute silently. If the newest SQLAlchemy that resolves is incompatible with 1.13.3 at import time, that is itself a finding: record the versions, add a `sqlalchemy<…` constraint deliberately and record it too. Do not change other major versions to make a test pass. The frontend has no lockfile: `npm install` resolves the declared ranges (the driver does this in a copy of `frontend/`, so the tree under test is not modified). Do not commit pins or a lockfile from this run; only after a fully green, reviewed run, send back `pip freeze` and `package-lock.json` for a separate pinning change.

## 5. A disposable PostgreSQL 16 that cannot touch another database

Create a **brand-new** server; do not reuse any existing one. The gate accepts only a cluster you have marked on purpose. **The marker is mandatory: a name containing `test` is never enough.** The password alphabet of `secrets.token_urlsafe` (`A-Za-z0-9_-`) is accepted by the URL grammar.

**Option A, Docker** (loopback only, random password, no volume):
```bash
export ITB_PG_PASSWORD="$(python3 -c 'import secrets; print(secrets.token_urlsafe(24))')"
docker run -d --rm --name itb-p13-validation -e POSTGRES_PASSWORD="$ITB_PG_PASSWORD" -p 127.0.0.1:55432:5432 --tmpfs /var/lib/postgresql/data postgres:16
until pg_isready -h 127.0.0.1 -p 55432; do sleep 1; done
env -i PATH="$PATH" PGPASSWORD="$ITB_PG_PASSWORD" psql -h 127.0.0.1 -p 55432 -U postgres \
   -c 'CREATE DATABASE itbridge_test' -c "COMMENT ON DATABASE itbridge_test IS 'ITB_PHASE13_DISPOSABLE'"
# teardown:  docker rm -f itb-p13-validation
```
**Option B, no Docker** (ordinary non-root user, PostgreSQL 16 server binaries; `initdb`/`pg_ctl` are in `/usr/lib/postgresql/16/bin` on Debian/Ubuntu):
```bash
export ITB_PG_PASSWORD="$(python3 -c 'import secrets; print(secrets.token_urlsafe(24))')"
export PGD="$(mktemp -d)"; printf '%s' "$ITB_PG_PASSWORD" > "$PGD.pw"
initdb -D "$PGD" -U postgres --auth=scram-sha-256 --pwfile="$PGD.pw"
pg_ctl -D "$PGD" -o "-p 55432 -c listen_addresses=127.0.0.1 -c unix_socket_directories=$PGD" -l "$PGD/log" -w start
env -i PATH="$PATH" PGPASSWORD="$ITB_PG_PASSWORD" psql -h 127.0.0.1 -p 55432 -U postgres \
   -c 'CREATE DATABASE itbridge_test' -c "COMMENT ON DATABASE itbridge_test IS 'ITB_PHASE13_DISPOSABLE'"
# teardown:  pg_ctl -D "$PGD" -m immediate stop; rm -rf "$PGD" "$PGD.pw"
```
Then, in the shell that will run the driver:
```bash
export ITB_TEST_DATABASE_URL="postgresql+psycopg2://postgres:${ITB_PG_PASSWORD}@127.0.0.1:55432/itbridge_test"
KIT=<directory containing this kit>
env -i PATH="$PATH" python3 -I -B "$KIT/itb_db_gate.py" check "$ITB_TEST_DATABASE_URL" --expect-empty      # must print GATE PASSED
```
**What the gate accepts** — all of: (1) the URL is exactly `postgresql[+psycopg2]://USER[:PASSWORD]@127.0.0.1|[::1]:PORT/DBNAME` (USER `[A-Za-z_][A-Za-z0-9_]*`, PASSWORD `[A-Za-z0-9_.~-]*`, PORT 1024–65535 and not 5432, DBNAME `[a-z][a-z0-9_]*` containing `test`; no query, fragment, `;`, `%`, whitespace, `localhost`, second host); (2) no `PG*` variable except `PGPASSWORD`, and no differing `DATABASE_URL` / `ITB_TEST_DATABASE_URL`, in the gate's environment; (3) asked **in the connection that will be used**: that database, PostgreSQL 16, not a replica, comment `ITB_PHASE13_DISPOSABLE` on it, and every other non-template database except `postgres` carrying the same comment; (4) with `--expect-empty`, no relation outside the system schemas. Exit 3 = refused (nothing executed), 4 = blocked (psql/pg_dump missing or failing, timeout, interruption: never a pass). `PGPASSWORD` set in the caller's shell is allowed, but the password in the URL is what the gate uses.

## 6. Running the validation

### 6a. Everything, staged (recommended)
From a directory **outside** the repository, venv active, the URL exported (§5):
```bash
REPO=<REPO> ITB_TEST_DATABASE_URL="$ITB_TEST_DATABASE_URL" ALEMBIC_EXPECTED=1.13.3 RESULTS="$PWD/p13-results-pinned" bash "$KIT/run_phase13_validation.sh"
```
The driver ignores your shell's `PG*` variables and `DATABASE_URL` (every child runs under `env -i` with an empty `HOME`). Optional: `PYTHON=`, `STAGES=static,deps,gate,pytest,sqlsmoke,cli,frontend` (an unselected stage makes the verdict INCOMPLETE), `T_PYTEST` etc. (timeouts in seconds), `EXPECT_PY` / `EXPECT_NODE` / `EXPECT_PG` (only for a deliberately different toolchain: record why), `ALEMBIC_EXPECTED=any` (run B).

**The 34 expected checks:** `versions:` tools, python, node and npm, postgres clients, alembic · `tree:` matches the expected SHA-256 · `static:` check_migrations_static, audit_integration · `deps:` backend imports · `gate:` disposable PostgreSQL · `pytest:` full backend suite · `canary:` (pytest migration files) · `sqlsmoke:` verify_postgres_sql · `cli:` heads/history without the app package, `alembic revision` template, upgrade + `alembic check`, 5 refusals, 3 allowed runs, 2 relative-target refusals, offline `--sql`, override, upgrade again · `canary:` (CLI matrix) · `frontend:` npm install, vitest, vite build · `tree:` unchanged by the run.
The tool, Python, Node, PostgreSQL-client, Alembic and tree checks run **first and are fatal**: if one is not PASS, nothing else runs and those checks are `NOT_RUN`. The pytest stage is run with the database URL **only if the gate has just passed**, and the gate is run again immediately before every pytest invocation, the SQL script and **every** Alembic command that touches the database; a refusal there stops all later database commands.

**Verdict.** `PASS` (exit 0): all 34 recorded as PASS. `FAIL` (exit 1): at least one check ran and failed (a wrong tree or version, a failing test, a refusal that changed the database, destructive SQL emitted). `INCOMPLETE` (exit 3; exit 4 if interrupted or the driver stopped early): nothing failed but a check did not PASS or was never recorded — a skipped test, a missing dependency, a refused or absent database, an unselected stage, a timeout. **INCOMPLETE and PASS-of-stand-ins are not approval evidence; `PASS` is evidence for a person to review, not an approval.** A `kill -9` leaves no verdict line at all (and a non-zero exit); that is never a pass either.

### 6b. The same by hand
Every command that can reach a database goes through `env -i`, so a stray `PGHOST`, `PGHOSTADDR`, `PGSERVICE` or `DATABASE_URL` in your shell cannot redirect it:
```bash
ENVI=(env -i PATH="$PATH" HOME="$(mktemp -d)" LANG=C.UTF-8 PYTHONDONTWRITEBYTECODE=1)
G=(env -i PATH="$PATH" python3 -I -B "$KIT/itb_db_gate.py")
"${G[@]}" check "$ITB_TEST_DATABASE_URL" --expect-empty
cd <REPO>/backend
"${G[@]}" check "$ITB_TEST_DATABASE_URL" && "${ENVI[@]}" ITB_TEST_DATABASE_URL="$ITB_TEST_DATABASE_URL" python -m pytest -q -p no:cacheprovider -rs --junitxml="$RESULTS/pytest-junit.xml"
"${ENVI[@]}" python3 -I -B ../scripts/check_migrations_static.py && "${ENVI[@]}" python3 -I -B ../scripts/audit_integration.py
# SQL-level PostgreSQL checks (psql only): the script refuses unless PGHOST=127.0.0.1, PGPORT set (not 5432) and nothing else but PGUSER/PGPASSWORD is set
eval "PGENV=($("${G[@]}" pgenv "$ITB_TEST_DATABASE_URL" | sed 's/^export //'))" && "${ENVI[@]}" "${PGENV[@]}" python3 -I -B ../scripts/verify_postgres_sql.py
cd ../frontend && npm test && npm run build          # prefer the driver: it works in a copy
```
Without `ITB_TEST_DATABASE_URL` the PostgreSQL test files **skip**; a skip is `NOT_RUN`, never a pass. Reference counts from the stand-in runner (not pytest): `test_migration_guards_static` 50, `test_migration_guard` 139, `test_pg_gate` 97, `test_verify_postgres_sql_gate` 49; real pytest should collect the same numbers (a difference must be explained).

### 6c. Alembic command-line matrix on the disposable PostgreSQL
The driver runs every row from a freshly reset database upgraded to head; each Alembic command under `env -i` with `DATABASE_URL` = the gate-checked URL, `ENVIRONMENT=test`, payments off, and the `alembic` executable that sits next to the interpreter. **Refusals are compared by snapshot** (`pg_dump --schema-only` + count and md5 of every row of every table + `alembic_version`) taken before and after: a refusal that changes one row or one column is a FAIL.

| Scenario | Seed | Command | Expected |
|---|---|---|---|
| `base` refused | user | `downgrade base` | exit ≠ 0, `Refusing to downgrade`, names `0001: users 1 rows`, snapshot identical |
| specific revision refused | user, preference | `downgrade 0003` | refused, names `0004: notification_preferences 1 rows`, not `0001`, identical |
| financial row | invoice counter | `downgrade 0004` | refused, names `0005: invoice_counters 1 rows`, identical |
| wrong override value / name | user | `ITB_ALLOW_FINANCIAL_DOWNGRADE=true`; `ITB_ALLOW_DOWNGRADE=<phrase>` + `downgrade base` | both refused, identical |
| `-1` allowed | user, preference | `downgrade -1` | exit 0, revision `0006`, both rows kept |
| specific revision allowed | user, preference | `downgrade 0006`, `downgrade 0005` | exit 0, revision as named, rows kept |
| `-1` counts from the database's revision | first `downgrade 0004` | `downgrade -1` | refused (removes 0004), names `0004`, not `0001`, identical |
| `-3` from `0005` | first `downgrade 0005` | `downgrade -3` | refused, names `0004`, identical |
| offline | none | `downgrade 0007:base --sql` | exit ≠ 0, **no** `DROP TABLE`, message `Refusing to generate an offline` (another safe failure is a FAIL so it is read: D5) |
| override | user, preference | `ITB_ALLOW_FINANCIAL_DOWNGRADE=I_UNDERSTAND_DATA_WILL_BE_DESTROYED downgrade base` | exit 0, only `alembic_version` left; then `upgrade head` works again |
| no-app commands | none | in a directory holding only `alembic.ini` + `alembic/`: `alembic heads`, `history`, `revision -m x` | `heads` shows `0007 (head)`; the generated file contains `preflight_downgrade(` |

Never set the override variable outside this disposable database, and never run `downgrade --sql` with it set.

## 7. Statuses and how to tell a failure from a missing dependency

| Status | Meaning | Counts as |
|---|---|---|
| `PASS` | ran to completion with the expected outcome | pass |
| `FAIL` | ran and the outcome was wrong: assertion failure, database changed after a refusal, wrong message, destructive SQL emitted, **project import error** (`No module named 'app…'`, `cannot import name`), wrong tree, wrong tool version is `ENVIRONMENT`, not FAIL | **FAIL verdict** |
| `MISSING_DEPENDENCY` | a **third-party** module or program is missing (`No module named 'fastapi'`, `command not found`, …): the stage did not run | INCOMPLETE |
| `ENVIRONMENT` | server unreachable, registry blocked, DNS failure, wrong tool version | INCOMPLETE |
| `TIMEOUT` | the per-stage limit was reached; the process group was killed | INCOMPLETE |
| `REFUSED` | the gate (or the script's own rules) refused the database; nothing was executed against it | INCOMPLETE |
| `NOT_RUN` | input absent, prerequisite not passed, stage not selected or not reached, or required tests were **skipped** | INCOMPLETE |
| `INTERRUPTED` | INT / TERM / HUP, or the driver stopped early | INCOMPLETE (exit 4) |
| `INFO` | a note, not a check | ignored |

Triage of a FAIL: (1) read the first failing assertion; a refusal check failing with "DATABASE CHANGED" is a **guard failure**: stop, keep the two snapshots, report, run no further downgrade; (2) a failure in a test written but never executed (§9) can be a test bug: check the SQL or fixture first; (3) any `downgrade pre-flight:` line in a canary means an Alembic assumption (D1–D4) did not hold; the guard stayed safe but the finding must be reported with the line and the Alembic version; (4) never "fix" a failure by weakening a test, changing the policy table, or setting the override.

**Send back**, from each of the two runs: the whole results directory (`summary.txt`, `status.tsv`, `environment.txt` with `pip freeze` and `TREE_SHA256`, every `*.log`, `pytest-junit.xml`, `pytest-skips.txt`, `cli/*`, `canary-*`), after `grep -rF "$ITB_PG_PASSWORD" <dir>` printed nothing.

## 8. What approval requires (all must hold, for run A; run B only decides whether the pin may be widened)

1. `VERDICT: PASS` from the driver (all 34 checks PASS), with `TREE_SHA256` as in the header.
2. Full pytest: 0 failed, 0 errors, and no skipped test in `test_migrations`, `test_migrations_postgres`, `test_postgres_concurrency`, `test_postgres_notifications`, `test_startup_hermetic`, `test_migration_guard`, `test_migration_guards_static`, `test_payments_phase13`, `test_pg_gate`, `test_verify_postgres_sql_gate` (the driver enforces it).
3. Every row of §6c passes with snapshot equality; the canaries report no `downgrade pre-flight:` warning (otherwise D1–D4 are disproved and need a design review).
4. `alembic check` reports no drift; D3, D5–D9 observed as stated.
5. `verify_postgres_sql.py`, the five concurrency scenarios and the notification SAVEPOINT tests pass on PostgreSQL 16.
6. Vitest 0 failed (including `src/services/notificationService.test.js`, whose axios mock is unverified under real Vitest) and `vite build` exits 0.
7. Payments still default to disabled; no payment credential was used; no real-money path exercised.
8. Product decisions recorded for the three review/payment rules, and a reserve-then-call design agreed before any real payment provider.
9. A person reviews the evidence. Only then: pin dependencies, add the frontend lockfile, update `PROJECT_PROGRESS.md`.

## 9. Evidence status (nothing below is runtime-verified for Alembic, SQLAlchemy, FastAPI, pytest, Vitest or Vite)

Executed in the authoring environment (none of FastAPI, SQLAlchemy, Alembic, pytest, psycopg2 installed; PyPI / npm unreachable). **Real** = the real program; **stand-in** = my own substitute.

| Check | Result | Kind |
|---|---|---|
| Gate attack battery, `offline` part (89 URL attack shapes × 5 subcommands, 17 environment attacks × 5 subcommands, fake `psql` / `pg_dump`, usage errors) | 690 passed, 0 failed; a listening socket saw **zero** connections from any refused case | real Python; fake psql programs for the failure cases |
| Gate attack battery, `live` part: decoy cluster (unmarked `itbridge_test` + `devdata` with data), near-miss markers, forwarder to the decoy, check/use redirect, intruder database, snapshot determinism and change detection, reset, role/port/database errors | 63 passed, 0 failed; the decoy cluster fingerprint (all databases, comments, every row) unchanged after every attack | **real PostgreSQL 16.15** via psql / pg_dump, two throwaway clusters |
| Gate mutation check (13 deliberately weakened gates: query allowed, target marker removed, cluster rule removed, env refusal removed, URL-variable check removed, proof check removed, `localhost` allowed, timeout removed, guard after the statement, port 5432 allowed, backslash allowed, empty-check removed, env scrub removed) | all 13 detected by the battery | real PostgreSQL + gate mutants |
| Old-gate bypass reproduction (query redirect; sole dev database wiped) | both reproduced against the old gate, both refused by the new one | real PostgreSQL 16.15 + real libpq |
| `pg.guard_sql` on a marked / unmarked database | passes / raises `itb gate:` | real PostgreSQL 16.15 via psql |
| `tests.test_pg_gate` / `tests.test_verify_postgres_sql_gate` | 97 / 49 passed (fake engine and `sqlalchemy.text`; no database) | **stand-in** runner (not pytest) |
| `scripts/verify_postgres_sql.py` on a marked cluster / on the decoy / with an unmarked pre-existing `itb_verify_test` / with 10 hostile environments / without psql | 110 passed / REFUSED (exit 3) / REFUSED, the 3 rows intact / REFUSED before any connection / BLOCKED (exit 2) | **real PostgreSQL 16.15** via psql |
| Driver negative battery (80 assertions over 55 driver runs: tree, versions, tools, dependencies, pytest failure / project import error / third-party import error / skipped required file / partial skip / no test / missing file / timeout, no URL, decoy, hostile URL shapes, hostile caller environment, marker removed or intruder database added mid-run, guard-bypass / refuse-but-change / refuse-but-row-change / wrong-message / offline-DROP / hanging / row-losing fake Alembic, unselected stages, npm 403 / test / build failure, tree changed during the run, SIGINT, SIGTERM, SIGKILL) | 80 passed, 0 failed (final run on the driver with the tree hash baked in; an earlier run that shared a cluster with a second, stray battery instance failed 20 assertions and was discarded as an invalid test setup, then rerun alone) | **stand-in** pytest / alembic / npm, **real** gate, psql, throwaway clusters. Control flow only |
| Driver mutation check (11 mutants: NOT_RUN counted as pass, unrecorded checks ignored, skip counted as pass, JUnit check removed, import error classed as missing dependency, re-gate removed, tree mismatch not fatal, timeout removed, signal trap removed, snapshot comparison removed, Python version ignored) | 11 of 11 mutants killed (each mutated driver fails the case aimed at it); the skip-counted-as-pass mutant was killed only after the `m2b` partial-skip case was added | as above |
| `tests.test_migration_guards_static` / `test_migration_guard` / `test_payment_rules` | 50 / 139 / 381 passed | **stand-in** runner |
| `scripts/check_migrations_static.py`, `scripts/audit_integration.py` | 0 problems each | stub Alembic on SQLite (not Alembic, not PostgreSQL); static |
| `ast.parse` of every Python file; ruff `F` vs baseline; `bash -n` of the driver | clean; no new finding; clean | static |

**Written but never executed:** all new tests in `test_migrations.py` and `test_migrations_postgres.py`; the new tests in `test_payments_phase13.py` (real route → `create_payment` → real SQLite session with the in-process sandbox provider, no network); `pg.wipe` / `assert_disposable` through a real SQLAlchemy engine; the frontend tests under real Vitest. The first real run may reveal test bugs rather than product bugs.

## 10. Known risks that this validation does not remove

- **Alembic is not guarded in-session.** The gate is re-run immediately before every Alembic command, but between that check and Alembic's own connection a process on the same machine could swap the server on the same loopback port. The window is milliseconds, loopback-only, on a dedicated non-default port with a random password; the destructive statements the kit itself sends (`reset`, `pg.wipe`, `DROP DATABASE`) are guarded in-session and are not exposed to it.
- **Three copies of the URL grammar** (`itb_db_gate.py`, `backend/tests/pg.py`, the `PG*` rules in `verify_postgres_sql.py`) must be kept in step by hand; the kit's battery and the repository's tests share the attack list by copy, not by import.
- A marker is an opt-in a person can set on a database that should not carry it (`COMMENT ON DATABASE`); the gate cannot tell. Set it only on databases you created for this run.
- `kill -9` of the driver, and a SIGINT delivered to a driver started in the background by a shell that ignores SIGINT, leave no verdict (never a pass).
- On SQLite a failure after the first DDL statement of a downgrade cannot be rolled back; on PostgreSQL a row inserted between the pre-flight count and the DDL by another session is not covered. The override deletes everything on the downgrade path. A new migration needs a `POLICY` entry (template, runtime refusal and static tests enforce it, if the tests are run).
- **Webhook residual:** an ASCII-digit `Content-Length` of more than 4300 digits raises `ValueError` in `raw_body` (HTTP 500) if the server layer passes it on; unverified, untested, left unchanged because it would be a further change to payment-facing code. Recommended follow-up, with approval.
- `create_order` is called while the training lock is held and before the payment row exists. Deliberate for the sandbox; a real provider needs reserve-then-call.
- The four 0002 snapshot columns are `NOT NULL` after upgrade, so any `trainings` row blocks a 0002 downgrade: conservative and unchanged; whether the snapshot is regenerable is a product question.
