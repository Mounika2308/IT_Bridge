#!/usr/bin/env bash
# IT BRIDGE Phase 13: remote validation wrapper (NEW in the portable package; it is NOT part of the verified tree and NOT part of the original transfer package).
#
# It only scripts the commands of README_TRANSFER.md on an internet-enabled Linux machine: verify files -> verify the tree -> venv + pip install -> disposable
# PostgreSQL 16 in Docker -> safety gate -> the unchanged driver run_phase13_validation.sh -> evidence bundle. It changes no source file, writes no lockfile
# or pin into the repository, uses no fake tool, and never counts a skipped, blocked or missing check as a pass.
#
#   bash validation-kit/ci_run.sh A     run A: Alembic 1.13.3 via an external constraints file (the run that counts)
#   bash validation-kit/ci_run.sh B     run B: newest Alembic in a separate venv (comparison only; never used to rescue a failed A)
#
# Exit code: the driver's own (0 PASS, 1 FAIL, 3 INCOMPLETE, 4 interrupted) when the driver ran; otherwise
#   2 usage / wrong files / wrong tree      5 environment blocker (pip, Docker, PostgreSQL, tool missing)      6 the safety gate refused
#   7 a secret was found in the evidence (the bundle was quarantined, not published)
# Nothing but exit code 0 with "VERDICT: PASS" is evidence, and even that is only evidence for a person to review.
set -u -o pipefail

RUN="${1:-}"; case "$RUN" in A|B) ;; *) echo "usage: bash ci_run.sh A|B"; exit 2;; esac
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"; ROOT="$(cd "$HERE/.." && pwd)"
REPO="$ROOT/IT-BRIDGE"; PROV="$ROOT/provenance"
WORK="${ITB_CI_WORK:-${RUNNER_TEMP:-/tmp}/itb-p13-$RUN}"      # always outside the repository
OUT="$WORK/out"
EXPECTED_TREE="9d2280022999b74b40af3015743c5c93eebaabed3704d2d35a1bef32fe1d33ca"
case "$RUN" in A) PGPORT_CI=55432; ALEMBIC_EXPECTED_CI="1.13.3";; B) PGPORT_CI=55433; ALEMBIC_EXPECTED_CI="any";; esac
CONTAINER="itb-p13-validation-$RUN"
PW=""; STARTED_CONTAINER=0

rm -rf "$WORK"; mkdir -p "$OUT" "$WORK/orig" || { echo "cannot create $WORK"; exit 2; }
STEPS="$OUT/ci-steps.log"; : > "$STEPS"
note() { echo "[$(date -u +%FT%TZ)] $*" | tee -a "$STEPS"; }
cleanup() { if [ "$STARTED_CONTAINER" = 1 ]; then docker rm -f "$CONTAINER" >/dev/null 2>&1 && note "teardown: container $CONTAINER removed"; fi; }
trap cleanup EXIT
die() { local code="$1"; shift; note "STOP (exit $code): $*"; echo "$code" > "$OUT/exit-code-$RUN.txt"; echo "STOPPED_BEFORE_DRIVER: $*" > "$OUT/VERDICT.txt"; exit "$code"; }

tree_hash() {   # same formula as the driver and README_TRANSFER.md
  (cd "$1" && find . -type f ! -path './frontend/node_modules/*' ! -path './frontend/dist/*' ! -path '*/__pycache__/*' ! -path './.git/*' ! -path '*/.venv/*' \
     ! -path '*/.pytest_cache/*' ! -path '*/.ruff_cache/*' ! -name '*.pyc' ! -path './backend/.env' ! -path './.env' | LC_ALL=C sort | xargs -d '\n' sha256sum | sha256sum | cut -d' ' -f1)
}

# ---- 1. the original transfer package and the kit copies are exactly the verified ones -------------------------------------------------------------------
note "1. verifying provenance/ (original transfer tar, original checksums) and validation-kit/"
(cd "$PROV" && sha256sum -c itb-phase13-transfer.tar.sha256) >>"$STEPS" 2>&1 || die 2 "itb-phase13-transfer.tar does not match its recorded SHA-256"
tar -xf "$PROV/itb-phase13-transfer.tar" -C "$WORK/orig" || die 2 "cannot extract the transfer tar"
O="$WORK/orig/itb-phase13-transfer"
(cd "$O" && sha256sum -c PHASE13_KIT.SHA256SUMS) >>"$STEPS" 2>&1 || die 2 "a file inside the transfer tar does not match PHASE13_KIT.SHA256SUMS"
cmp -s "$O/PHASE13_KIT.SHA256SUMS" "$PROV/PHASE13_KIT.SHA256SUMS.original" || die 2 "provenance/PHASE13_KIT.SHA256SUMS.original differs from the one inside the tar"
for f in run_phase13_validation.sh itb_db_gate.py itb_db_gate_selftest.py PHASE13_RUNTIME_VALIDATION_HANDOFF.md PHASE13_EXTERNAL_RUNBOOK.md README_TRANSFER.md; do
  cmp -s "$O/$f" "$HERE/$f" || die 2 "validation-kit/$f is not byte-identical to the original in the transfer tar"
done
note "   provenance OK; kit files byte-identical to the originals"

# ---- 2. the tree: committed copy == baseline + diff == the expected hash -------------------------------------------------------------------------------
note "2. verifying the project tree"
T1="$(tree_hash "$REPO")"; note "   IT-BRIDGE/ tree hash: $T1"
[ "$T1" = "$EXPECTED_TREE" ] || die 2 "IT-BRIDGE/ hash $T1 is not the expected $EXPECTED_TREE (was the tree edited, or changed by git?)"
mkdir -p "$WORK/rebuild" && (cd "$WORK/rebuild" && unzip -q "$O/IT-BRIDGE-phase13b4-stabilized.zip" && cd IT-BRIDGE && patch -p1 -s < "$O/PHASE13_ENGINEERING_FIXES.diff") || die 2 "cannot rebuild the tree from baseline + diff"
T2="$(tree_hash "$WORK/rebuild/IT-BRIDGE")"; [ "$T2" = "$EXPECTED_TREE" ] || die 2 "baseline + diff gives $T2, not the expected tree"
note "   baseline + diff reproduces the same hash"
{ echo "tree_sha256_committed=$T1"; echo "tree_sha256_rebuilt=$T2"; sha256sum "$O"/PHASE13_ENGINEERING_FIXES.diff "$O"/IT-BRIDGE-phase1*-stabilized.zip "$PROV/itb-phase13-transfer.tar"; } > "$OUT/hashes-before.txt"

# ---- 3. toolchain (the driver checks again and is authoritative) ---------------------------------------------------------------------------------------
note "3. toolchain"
{ python3 --version; node --version; npm --version; psql --version; pg_dump --version; docker --version; git --version; } >>"$STEPS" 2>&1
python3 --version 2>&1 | grep -q '^Python 3\.12\.' || die 5 "Python 3.12.x is required: $(python3 --version 2>&1)"
node --version 2>&1 | grep -q '^v20\.' || die 5 "Node 20.x is required: $(node --version 2>&1)"
for t in psql pg_dump docker unzip patch; do command -v "$t" >/dev/null 2>&1 || die 5 "$t is not installed"; done
psql --version | grep -q ' 16\.' || die 5 "psql 16.x is required: $(psql --version)"

# ---- 4. venv + the project's own requirements (no pin, no lockfile written into the repository) ----------------------------------------------------------
note "4. venv and pip install (run $RUN)"
python3 -m venv "$WORK/venv" || die 5 "cannot create a venv"
PY="$WORK/venv/bin/python"
"$PY" -m pip install --upgrade pip >"$OUT/pip-upgrade-$RUN.log" 2>&1 || die 5 "pip self-upgrade failed (see pip-upgrade-$RUN.log): registry unreachable?"
if [ "$RUN" = A ]; then
  printf 'alembic==1.13.3\n' > "$WORK/constraints.txt"   # the documented CANDIDATE for this validation, supplied outside the repository
  "$PY" -m pip install -c "$WORK/constraints.txt" -r "$REPO/backend/requirements.txt" >"$OUT/pip-install-$RUN.log" 2>&1; rc=$?
else
  "$PY" -m pip install -r "$REPO/backend/requirements.txt" >"$OUT/pip-install-$RUN.log" 2>&1; rc=$?
fi
[ $rc -eq 0 ] || die 5 "pip install failed (exit $rc, see pip-install-$RUN.log). Nothing was substituted."
"$PY" -m pip check >"$OUT/pip-check-$RUN.txt" 2>&1; echo "pip check exit: $?" >>"$OUT/pip-check-$RUN.txt"
"$PY" -m pip freeze >"$OUT/pip-freeze-$RUN.txt"
"$WORK/venv/bin/alembic" --version >"$OUT/alembic-version-$RUN.txt" 2>&1 || die 5 "alembic does not run after installation (see alembic-version-$RUN.txt)"
"$PY" -c "from zoneinfo import ZoneInfo; ZoneInfo('Asia/Kolkata')" 2>"$OUT/tz-check-$RUN.txt" || die 5 "the Asia/Kolkata time-zone database is missing (tzdata is not declared by the project): record it, do not guess a fix"
note "   installed: $(tr '\n' ' ' < "$OUT/alembic-version-$RUN.txt")"

# ---- 5. disposable PostgreSQL 16 (Docker, loopback only, random password, nothing persisted) ------------------------------------------------------------
note "5. disposable PostgreSQL 16 on 127.0.0.1:$PGPORT_CI"
PW="$("$PY" -c 'import secrets; print(secrets.token_urlsafe(24))')"
[ -n "${GITHUB_ACTIONS:-}" ] && echo "::add-mask::$PW"
docker run -d --rm --name "$CONTAINER" -e POSTGRES_PASSWORD="$PW" -p "127.0.0.1:$PGPORT_CI:5432" --tmpfs /var/lib/postgresql/data postgres:16 >"$WORK/docker-run.log" 2>&1 \
  || die 5 "docker run postgres:16 failed (see docker-run.log); no database was created"
STARTED_CONTAINER=1
ok=0; for _ in $(seq 1 60); do pg_isready -h 127.0.0.1 -p "$PGPORT_CI" >/dev/null 2>&1 && { ok=1; break; }; sleep 1; done
[ $ok -eq 1 ] || die 5 "the PostgreSQL container did not become ready"
sleep 2
env -i PATH="$PATH" PGPASSWORD="$PW" psql -h 127.0.0.1 -p "$PGPORT_CI" -U postgres -v ON_ERROR_STOP=1 \
  -c 'CREATE DATABASE itbridge_test' -c "COMMENT ON DATABASE itbridge_test IS 'ITB_PHASE13_DISPOSABLE'" >"$WORK/psql-setup.log" 2>&1 || die 5 "cannot create/mark the disposable database"
export ITB_TEST_DATABASE_URL="postgresql+psycopg2://postgres:${PW}@127.0.0.1:${PGPORT_CI}/itbridge_test"
env -i PATH="$PATH" "$PY" -I -B "$HERE/itb_db_gate.py" check "$ITB_TEST_DATABASE_URL" --expect-empty >"$OUT/gate-precheck-$RUN.txt" 2>&1; rc=$?
[ $rc -eq 0 ] || die 6 "the safety gate did not pass (exit $rc): $(tail -1 "$OUT/gate-precheck-$RUN.txt" | sed "s/$PW/***/g"). Never bypass it."
note "   gate: $(tail -1 "$OUT/gate-precheck-$RUN.txt")"

# ---- 6. the unchanged driver ---------------------------------------------------------------------------------------------------------------------------
note "6. running run_phase13_validation.sh (run $RUN, ALEMBIC_EXPECTED=$ALEMBIC_EXPECTED_CI)"
cd "$WORK" || die 2 "cannot enter $WORK"
REPO="$REPO" ITB_TEST_DATABASE_URL="$ITB_TEST_DATABASE_URL" ALEMBIC_EXPECTED="$ALEMBIC_EXPECTED_CI" PYTHON="$PY" RESULTS="$OUT/results-$RUN" \
  bash "$HERE/run_phase13_validation.sh" 2>&1 | tee "$OUT/driver-stdout-$RUN.txt"
DRC=${PIPESTATUS[0]}
echo "$DRC" > "$OUT/exit-code-$RUN.txt"; echo "driver exit code: $DRC"
grep -E '^VERDICT:' "$OUT/driver-stdout-$RUN.txt" > "$OUT/VERDICT.txt" || echo "NO VERDICT LINE (driver exit $DRC): not a pass" > "$OUT/VERDICT.txt"

# ---- 7. evidence hygiene and final hashes --------------------------------------------------------------------------------------------------------------
for t in node npm psql pg_dump; do echo "$t: $("$t" --version 2>&1 | head -1)"; done > "$OUT/tool-versions-$RUN.txt"; "$PY" --version >> "$OUT/tool-versions-$RUN.txt" 2>&1
{ echo "tree_sha256_after=$(tree_hash "$REPO")"; sha256sum "$O"/PHASE13_ENGINEERING_FIXES.diff "$O"/IT-BRIDGE-phase1*-stabilized.zip "$PROV/itb-phase13-transfer.tar"; } > "$OUT/hashes-after.txt"
cmp -s <(grep -v '^tree_sha256' "$OUT/hashes-before.txt") <(grep -v '^tree_sha256' "$OUT/hashes-after.txt") || note "WARNING: a baseline, diff or transfer-tar hash changed during the run"
grep -q "tree_sha256_after=$EXPECTED_TREE" "$OUT/hashes-after.txt" || note "WARNING: the tree hash changed during the run"
if grep -rqF -- "$PW" "$OUT"; then
  mv "$OUT" "$WORK/quarantine-evidence-contains-secret"; mkdir -p "$OUT"; echo "The evidence contained the disposable database password and was quarantined on the runner (not published). Driver exit code: $DRC" > "$OUT/SECRET_FOUND.txt"
  echo "$DRC" > "$OUT/exit-code-$RUN.txt"; note "STOP (exit 7): password found in the evidence bundle"; exit 7
fi
note "7. evidence bundle: $OUT (secret check passed: the disposable password does not appear in it)"
exit "$DRC"
